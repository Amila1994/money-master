package com.example

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.core.app.ApplicationProvider
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import com.example.data.DocumentRepository
import com.example.ui.ActiveScreen
import com.example.ui.DocumentViewModel
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DeepDarkBg
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextGray
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class AppFeaturesCaptureTest {

    @get:Rule val composeTestRule = createComposeRule()

    @OptIn(ExperimentalMaterial3Api::class)
    @Test
    fun captureAppFeaturesAutomatically() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = DocumentRepository(context)
        val viewModel = DocumentViewModel(repository)

        composeTestRule.setContent {
            MyApplicationTheme {
                val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
                val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
                val showOwnerIntroDialog by viewModel.showOwnerIntroDialog.collectAsStateWithLifecycle()

                if (showOwnerIntroDialog) {
                    AlertDialog(
                        onDismissRequest = { viewModel.dismissOwnerIntroDialog() },
                        confirmButton = {
                            Button(
                                onClick = { viewModel.dismissOwnerIntroDialog() },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("dismiss_owner_intro")
                            ) {
                                Text("Start Scanning", color = DeepDarkBg, fontWeight = FontWeight.Bold)
                            }
                        },
                        title = {
                            Text(
                                text = "🚀 Welcome to CamScanner Pro",
                                color = AccentTeal,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        text = {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "👑 App Owner -: Amila Lasantha",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "📧 Email -: amilalasantha940703@gmail.com",
                                    color = TextGray,
                                    fontSize = 13.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(Color(0xFF333333))
                                )
                                Text(
                                    text = "Status: Licensed Premium Pro Activated\n(★ Magic Pro Engine Ready)",
                                    color = AccentTeal.copy(alpha = 0.9f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    lineHeight = 18.sp
                                )
                            }
                        },
                        containerColor = SurfaceDark,
                        shape = RoundedCornerShape(20.dp),
                        properties = androidx.compose.ui.window.DialogProperties(
                            dismissOnBackPress = false,
                            dismissOnClickOutside = false
                        )
                    )
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DeepDarkBg)
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DeepDarkBg)
                    ) {
                        AnimatedContent(
                            targetState = if (isLocked) ActiveScreen.LOCK else activeScreen,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith
                                        fadeOut(animationSpec = tween(220))
                            },
                            label = "screen_transition"
                        ) { targetScreen ->
                            when (targetScreen) {
                                ActiveScreen.LOCK -> ScreenLock(viewModel)
                                ActiveScreen.DASHBOARD -> ScreenDashboard(viewModel)
                                ActiveScreen.SCAN -> ScreenScan(viewModel)
                                ActiveScreen.CROP_ENHANCE -> ScreenCropEnhance(viewModel)
                                ActiveScreen.DETAIL -> ScreenDetail(viewModel)
                            }
                        }
                    }
                }
            }
        }

        // Wait for idle to render first frame (Lock Screen)
        composeTestRule.waitForIdle()

        // 1. ඇප් එක ඕපන් කරලා ඔටෝම පාස්වර්ඩ් එක ටයිප් කරයි (Input password and click unlock)
        composeTestRule.onNodeWithTag("etPassword").performTextInput("S/680746")
        composeTestRule.onNodeWithTag("btnUnlock").performClick()
        composeTestRule.waitForIdle()

        // 2. Amila Lasantha Popup එක ආවාම ඒකේ ස්ක්රීන්ෂොට් එකක් ගනියි (Capture 1_owner_popup)
        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/1_owner_popup.png")

        // 3. Popup එක close කරලා ස්කෑනර් එකට යයි (Click Start Scanning dialog button, then click FAB to go to SCAN)
        composeTestRule.onNodeWithTag("dismiss_owner_intro").performClick()
        composeTestRule.waitForIdle()
        
        composeTestRule.onNodeWithTag("scan_fab").performClick()
        composeTestRule.waitForIdle()

        // Click shutter button to simulate capture and go to enhance screen
        composeTestRule.onNodeWithTag("shutter_button").performClick()
        composeTestRule.waitForIdle()

        // 4. ෆිල්ටර්ස් මෝඩ් එකට ගියාම ඒකෙත් ඔටෝම ෆොටෝ එකක් ගනියි (Capture 2_magic_pro_screen)
        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/2_magic_pro_screen.png")
    }
}
