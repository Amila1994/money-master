package com.moneymaster.cleanapp

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import com.moneymaster.cleanapp.utils.LoanCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Money Master", appName)
  }

  @Test
  fun `loan calculator with no payments calculates interest from start date`() {
    val startDate = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
    val loan = Loan(
        id = 1,
        borrowerName = "Priyadarshani",
        borrowerPhone = "0771234567",
        principalAmount = 70000.0,
        interestRate = 8.0,
        interestPeriod = "Monthly",
        startDate = startDate
    )

    val summary = LoanCalculator.calculateLoanSummary(loan, emptyList())
    
    // Elapsed days should be exactly or very close to 30
    assertEquals(30L, summary.daysElapsed)
    // 30 days is exactly 1 month. At 8% monthly: 70000 * 0.08 * 1.0 = 5600
    assertEquals(5600.0, summary.accruedInterest, 0.01)
    assertEquals(5600.0, summary.outstandingInterest, 0.01)
    assertEquals(70000.0, summary.remainingPrincipal, 0.01)
  }

  @Test
  fun `loan calculator with interest payment calculates interest from last payment date`() {
    val startDate = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
    val paymentDate = startDate + TimeUnit.DAYS.toMillis(15)
    
    val loan = Loan(
        id = 1,
        borrowerName = "Priyadarshani",
        borrowerPhone = "0771234567",
        principalAmount = 70000.0,
        interestRate = 8.0,
        interestPeriod = "Monthly",
        startDate = startDate
    )

    // Paid 2800 (interest for first 15 days)
    val payment = Payment(
        id = 10,
        loanId = 1,
        amount = 2800.0,
        paymentDate = paymentDate,
        type = "Interest"
    )

    val summary = LoanCalculator.calculateLoanSummary(loan, listOf(payment))

    // Days elapsed since the last interest payment (from day 15 to day 30 = 15 days)
    assertEquals(15L, summary.daysElapsed)
    // At 8% monthly for 15 days: 70000 * 0.08 * 0.5 = 2800
    assertEquals(2800.0, summary.accruedInterest, 0.01)
    assertEquals(2800.0, summary.outstandingInterest, 0.01)
    assertEquals(2800.0, summary.paidInterest, 0.01)
  }

  @Test
  fun `loan calculator with principal payment reduces principal base for interest`() {
    val startDate = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
    val loan = Loan(
        id = 1,
        borrowerName = "Priyadarshani",
        borrowerPhone = "0771234567",
        principalAmount = 100000.0,
        interestRate = 10.0,
        interestPeriod = "Monthly",
        startDate = startDate
    )

    // Paid 50000 as principal
    val principalPayment = Payment(
        id = 11,
        loanId = 1,
        amount = 50000.0,
        paymentDate = startDate, // paid immediately at the start of loan
        type = "Principal"
    )

    val summary = LoanCalculator.calculateLoanSummary(loan, listOf(principalPayment))

    assertEquals(50000.0, summary.remainingPrincipal, 0.01)
    // Interest calculated on remaining principal: 50000 * 0.10 * 1.0 (30 days) = 5000
    assertEquals(5000.0, summary.accruedInterest, 0.01)
  }
}
