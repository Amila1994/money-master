package com.aistudio.classroomhub.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// --- ගුරුවරයාගේ තත්ත්වය (Teacher Status) Enum ---
enum class TeacherStatus(val label: String, val color: Color) {
    TEACHING("උගන්වන ගමනින්", Color(0xFF16A34A)),      // Green
    FREE("විවේක කාලය (Free)", Color(0xFF2563EB)),        // Blue
    COVERING("වෙනත් කාලච්ඡේදයක් Cover කරයි", Color(0xFFEA580C)), // Orange
    ABSENT("අද පැමිණ නැත (Absent)", Color(0xFFDC2626))    // Red
}

@Composable
fun LiveDashboardPopup(
    onDismissRequest: () -> Unit,
    teacherName: String = "කේ. ඒ. පෙරේරා මහතා",
    teacherStatus: TeacherStatus = TeacherStatus.TEACHING,
    nextTeacherPeriod: String = "8-A පන්තිය (ගණිතය)",
    className: String = "10-B පන්තිය",
    currentSubject: String = "විද්‍යාව",
    currentClassTeacher: String = "එම්. ඩී. සිල්වා මහත්මිය",
    nextClassSubject: String = "ඉංග්‍රීසි (ආර්. ප්‍රනාන්දු මහතා)",
    boyCount: Int = 18,
    girlCount: Int = 22,
    remainingSecondsForPeriod: Int = 831
) {
    var currentTimeString by remember { mutableStateOf("") }
    var remainingTime by remember { mutableIntStateOf(remainingSecondsForPeriod) }

    // Automatic Off-Hours / Weekend Detection logic
    val nowCalendar = Calendar.getInstance()
    val dayOfWeek = nowCalendar.get(Calendar.DAY_OF_WEEK)
    val hourOfDay = nowCalendar.get(Calendar.HOUR_OF_DAY)
    val minuteOfHour = nowCalendar.get(Calendar.MINUTE)

    val isWeekend = (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY)
    val isAfterSchoolHours = hourOfDay < 7 || (hourOfDay == 7 && minuteOfHour < 30) || hourOfDay > 13 || (hourOfDay == 13 && minuteOfHour >= 30)
    val autoOffHoursDetected = isWeekend || isAfterSchoolHours

    var manualModeOverride by remember { mutableStateOf<Boolean?>(null) }
    val isOffHoursMode = manualModeOverride ?: autoOffHoursDetected

    LaunchedEffect(Unit) {
        while (true) {
            val formatter = SimpleDateFormat("yyyy-MM-dd | hh:mm:ss a", Locale.getDefault())
            currentTimeString = formatter.format(Date())
            
            if (remainingTime > 0) {
                remainingTime--
            }
            delay(1000L)
        }
    }

    val minutesLeft = remainingTime / 60
    val secondsLeft = remainingTime % 60
    val timerText = String.format(Locale.US, "%02d:%02d", minutesLeft, secondsLeft)

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .wrapContentHeight()
                .padding(8.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 10.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // ==================== Top Bar & Mode Switcher ====================
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = if (isOffHoursMode) Color(0xFF6366F1).copy(alpha = 0.18f) else Color(0xFFEF4444).copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (isOffHoursMode) Icons.Default.Event else Icons.Default.Schedule,
                                    contentDescription = "Live Mode",
                                    tint = if (isOffHoursMode) Color(0xFF6366F1) else Color(0xFFEF4444),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isOffHoursMode) "OFF-HOURS DASHBOARD" else "LIVE DASHBOARD",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isOffHoursMode) Color(0xFF4338CA) else MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = currentTimeString,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Prominent Close Button
                    IconButton(
                        onClick = onDismissRequest,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                            .size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Live Dashboard",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Mode Selector Bar (Active vs Off-Hours Preview Toggle)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (!isOffHoursMode) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { manualModeOverride = false }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "☀️ සක්‍රිය පාසල් කාලය",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (!isOffHoursMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isOffHoursMode) Color(0xFF4338CA) else Color.Transparent)
                            .clickable { manualModeOverride = true }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "🌙 නිවාඩු / Off-Hours",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOffHoursMode) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isOffHoursMode) {
                    // =========================================================================
                    //                       OFF-HOURS & WEEKEND DASHBOARD
                    // =========================================================================

                    // 1. STATUS BANNER
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1B4B)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = Color(0xFF818CF8).copy(alpha = 0.25f),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = "🏫", fontSize = 16.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "🏫 පාසල් කාලයෙන් පසු / සති අන්ත නිවාඩු දිනයකි",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF818CF8)
                                    )
                                    Text(
                                        text = if (isWeekend) "සති අන්ත නිවාඩු කාලය (Weekend Off-Hours Mode)" else "පස්වරු 1:30 න් පසු පාසල් වේලාව අවසන්ව ඇත",
                                        fontSize = 11.sp,
                                        color = Color(0xFFC7D2FE)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2. NEXT SCHOOL DAY PREVIEW (ඊළඟ පාසල් දිනය)
                    val nextDayName = getNextSchoolDayLabel(dayOfWeek)
                    val nextDaySinName = when (dayOfWeek) {
                        Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY -> "සඳුදා"
                        Calendar.MONDAY -> "අඟහරුවාදා"
                        Calendar.TUESDAY -> "බදාදා"
                        Calendar.WEDNESDAY -> "බ්‍රහස්පතින්දා"
                        Calendar.THURSDAY -> "සිකුරාදා"
                        else -> "සඳුදා"
                    }
                    val nextDayEntries = TimetableRepository.getEntriesForDay(nextDaySinName)
                    val firstPeriod = if (nextDayEntries.isNotEmpty()) nextDayEntries[0] else null

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "🌅 ඊළඟ පාසල් දිනය (Next School Day Preview)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )

                            InfoRow(
                                title = "ඊළඟ දිනය (Next Day)",
                                value = "$nextDayName - පෙ.ව. 07:30",
                                icon = Icons.Default.Event
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Text(
                                        text = "1 වන කාලච්ඡේදය (${firstPeriod?.timeSlot ?: "07:50 AM - 08:30 AM"})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "📚 විෂය: ${firstPeriod?.subjectName ?: "සටහන් කර නොමැත"} (${firstPeriod?.targetClass ?: className})",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                    Text(
                                        text = "📝 මාතෘකාව: ${if (firstPeriod?.lessonTopic != null && firstPeriod.lessonTopic.isNotEmpty()) firstPeriod.lessonTopic else "කාලසටහන් සටහන නොමැත"}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 3. WEEKLY ATTENDANCE SUMMARY (සතිපතා පැමිණීමේ සාරාංශය)
                    val activeStudents = StudentRepository.getStudents()
                    val totalStudentCount = activeStudents.size

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "📊 සතිපතා පැමිණීමේ සාරාංශය (Weekly Attendance)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "ලියාපදිංචි සිසුන් ගණන:",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (totalStudentCount > 0) "$totalStudentCount සිසුන්" else "සිසුන් ඇතුළත් කර නොමැත",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (totalStudentCount > 0) Color(0xFF16A34A) else Color.Gray
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF2563EB).copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "සක්‍රිය පද්ධතිය",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF2563EB),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "⚠️ නොපැමිණි සිසුන් (Absentee Log):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            if (totalStudentCount == 0) {
                                Text(
                                    text = "තවමත් පද්ධතියට සිසුන් ඇතුළත් කර නොමැත.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            } else {
                                Text(
                                    text = "✅ සියලුම සිසුන්ගේ පැමිණීමේ වාර්තා යාවත්කාලීනයි.",
                                    fontSize = 11.sp,
                                    color = Color(0xFF16A34A),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. PENDING TASKS (මතක් කිරීම් - EDITABLE/ADDABLE/REMOVABLE)
                    var pendingTasks by remember { mutableStateOf(PendingTasksManager.getPendingTasks(context)) }
                    var newTaskText by remember { mutableStateOf("") }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "📌 මතක් කිරීම් (Pending Tasks & Reminders)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )

                            // Inline task input to add new reminder
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = newTaskText,
                                    onValueChange = { newTaskText = it },
                                    placeholder = { Text("නව මතක් කිරීමක් ඇතුළත් කරන්න...") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        if (newTaskText.trim().isNotEmpty()) {
                                            pendingTasks = PendingTasksManager.addPendingTask(context, newTaskText)
                                            newTaskText = ""
                                        }
                                    },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("එක් කරන්න")
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (pendingTasks.isEmpty()) {
                                Text(
                                    text = "මතක් කිරීම් නොමැත.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            } else {
                                pendingTasks.forEachIndexed { index, task ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = task,
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                pendingTasks = PendingTasksManager.removePendingTask(context, index)
                                            },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Remove",
                                                tint = Color(0xFFDC2626),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                } else {
                    // =========================================================================
                    //                       ACTIVE SCHOOL HOURS DASHBOARD
                    // =========================================================================

                    // Countdown Timer Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Timer",
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "කාලච්ඡේදය අවසන් වීමට:",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            // MM:SS formatted timer display
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFDC2626),
                                modifier = Modifier.padding(start = 6.dp)
                            ) {
                                Text(
                                    text = timerText,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 1. TOP SECTION: Teacher Live Info Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "👨‍🏫 ගුරුවරයාගේ තොරතුරු (Teacher Live Info)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )

                            InfoRow(title = "ගුරුවරයා (Teacher Name)", value = teacherName, icon = Icons.Default.Person)

                            Spacer(modifier = Modifier.height(8.dp))

                            // Current Status Badge
                            Text(text = "වත්මන් තත්ත්වය (Status):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(teacherStatus.color)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = teacherStatus.label,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            InfoRow(
                                title = "ඊළඟ කාලච්ඡේදය (Next Period)",
                                value = nextTeacherPeriod,
                                icon = Icons.Default.Schedule
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. BOTTOM SECTION: Class Live Info & Attendance Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "🏫 පන්තියේ තොරතුරු සහ පැමිණීම (Class Live Info)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )

                            InfoRow(title = "සක්‍රිය පන්තිය (Class)", value = className, icon = Icons.Default.School)
                            InfoRow(title = "දැනට පවතින විෂය (Current Subject)", value = currentSubject, icon = Icons.Default.Schedule)
                            InfoRow(title = "උගන්වන ගුරුවරයා (Subject Teacher)", value = currentClassTeacher, icon = Icons.Default.Person)
                            InfoRow(title = "ඊළඟට ඇති විෂය (Next Subject)", value = nextClassSubject, icon = Icons.Default.Schedule)

                            Spacer(modifier = Modifier.height(12.dp))

                            // Student Attendance Live Counter
                            Text(
                                text = "පැමිණ සිටින ළමුන් ගණන (Live Attendance):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CountChip(
                                    label = "පිරිමි (Boys)",
                                    count = boyCount,
                                    color = Color(0xFF2563EB),
                                    icon = Icons.Default.Male,
                                    modifier = Modifier.weight(1f)
                                )
                                CountChip(
                                    label = "ගැහැණු (Girls)",
                                    count = girlCount,
                                    color = Color(0xFFDB2777),
                                    icon = Icons.Default.Female,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val totalStudents = boyCount + girlCount
                                val pctText = if (totalStudents > 0) "100%" else "0%"
                                Text(
                                    text = "මුළු පැමිණීම: $totalStudents / $totalStudents ($pctText)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// Helper method for next school day label
private fun getNextSchoolDayLabel(dayOfWeek: Int): String {
    return when (dayOfWeek) {
        Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY -> "සඳුදා (Monday)"
        Calendar.MONDAY -> "අඟහරුවාදා (Tuesday)"
        Calendar.TUESDAY -> "බදාදා (Wednesday)"
        Calendar.WEDNESDAY -> "බ්‍රහස්පතින්දා (Thursday)"
        Calendar.THURSDAY -> "සිකුරාදා (Friday)"
        else -> "සඳුදා (Monday)"
    }
}

@Composable
private fun AbsenteeCardItem(studentName: String, absentDays: String, contact: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFFEF2F2))
            .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = studentName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                Text(text = contact, fontSize = 10.sp, color = Color(0xFF7F1D1D))
            }
            Text(text = absentDays, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
        }
    }
}

@Composable
private fun PendingTaskRow(title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Info,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium
        )
    }
}

// --- Helper Composable: Label & Value Row ---
@Composable
fun InfoRow(title: String, value: String, icon: ImageVector) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(15.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

// --- Helper Composable: Attendance Count Chip ---
@Composable
fun CountChip(
    label: String,
    count: Int,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = color, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "$label: ", fontSize = 11.sp, color = color, fontWeight = FontWeight.Medium)
        Text(text = "$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

fun showLiveDashboardDialog(context: android.content.Context) {
    val composeView = androidx.compose.ui.platform.ComposeView(context)
    val dialog = androidx.appcompat.app.AlertDialog.Builder(context)
        .setView(composeView)
        .create()

    dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

    val activeClass = ClassRepository.getActiveClass()
    val students = StudentRepository.getStudents()
    var boys = 0
    var girls = 0
    for (s in students) {
        if ("ගැහැණු" == s.gender || "Female" == s.gender) {
            girls++
        } else {
            boys++
        }
    }

    composeView.setContent {
        LiveDashboardPopup(
            className = "${activeClass?.className ?: "10-A"} (${activeClass?.academicYear ?: "2026"})",
            boyCount = boys,
            girlCount = girls,
            onDismissRequest = { dialog.dismiss() }
        )
    }

    dialog.show()
}

