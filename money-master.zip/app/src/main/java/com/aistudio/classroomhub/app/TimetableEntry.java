package com.aistudio.classroomhub.app;

import java.util.Locale;

public class TimetableEntry {
    private String id;
    private String day; // 'සඳුදා', 'අඟහරුවාදා', 'බදාදා', 'බ්‍රහස්පතින්දා', 'සිකුරාදා'
    private String periodName; // '1 වන කාලඡේදය', etc.
    private int startHour;
    private int startMinute;
    private int endHour;
    private int endMinute;
    private String subject;
    private String className;
    private String roomNo;
    private String role; // 'ප්‍රධාන විෂය', 'නියෝජන (Relief)', 'නිදහස් (Free)'
    private String notes;

    public TimetableEntry(String id, String day, String periodName, int startHour, int startMinute,
                          int endHour, int endMinute, String subject, String className,
                          String roomNo, String role, String notes) {
        this.id = id;
        this.day = day;
        this.periodName = periodName;
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
        this.subject = subject;
        this.className = className;
        this.roomNo = roomNo;
        this.role = role;
        this.notes = notes != null ? notes : "";
    }

    public String getId() {
        return id;
    }

    public String getDay() {
        return day;
    }

    public String getPeriodName() {
        return periodName;
    }

    public int getStartHour() {
        return startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public String getSubject() {
        return subject;
    }

    public String getClassName() {
        return className;
    }

    public String getRoomNo() {
        return roomNo;
    }

    public String getRole() {
        return role;
    }

    public String getNotes() {
        return notes;
    }

    public int getStartMinutesOfDay() {
        return startHour * 60 + startMinute;
    }

    public int getEndMinutesOfDay() {
        return endHour * 60 + endMinute;
    }

    public String getFormattedTimeRange() {
        return String.format(Locale.US, "%02d:%02d - %02d:%02d",
                startHour, startMinute, endHour, endMinute);
    }
}
