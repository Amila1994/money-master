package com.aistudio.classroomhub.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class PinLockActivity extends AppCompatActivity {

    private EditText etPinInput;
    private View btnUnlock;
    private TextView btnForgotPin;
    private TextView tvPinSubtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_pin_lock);

        etPinInput = findViewById(R.id.etPinInput);
        btnUnlock = findViewById(R.id.btnUnlock);
        btnForgotPin = findViewById(R.id.btnForgotPin);
        tvPinSubtitle = findViewById(R.id.tvPinSubtitle);

        if (btnUnlock != null) {
            btnUnlock.setOnClickListener(v -> attemptUnlock());
        }

        if (btnForgotPin != null) {
            btnForgotPin.setOnClickListener(v -> showForgotPinDialog());
        }
    }

    private void attemptUnlock() {
        String pin = etPinInput.getText().toString().trim();
        if (pin.isEmpty()) {
            Toast.makeText(this, AppTranslation.get(this, "enter_pin"), Toast.LENGTH_SHORT).show();
            return;
        }

        if (AppSecurityManager.verifyPin(this, pin)) {
            AppSecurityManager.setPinUnlockedSession(this, true);
            Toast.makeText(this, AppTranslation.get(this, "pin_unlocked"), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(PinLockActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, AppTranslation.get(this, "invalid_pin"), Toast.LENGTH_SHORT).show();
            etPinInput.setText("");
        }
    }

    private void showForgotPinDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_forgot_pin, null);
        RadioGroup rgMethod = view.findViewById(R.id.rgRecoveryMethod);
        RadioButton rbQuestion = view.findViewById(R.id.rbMethodQuestion);
        RadioButton rbEmail = view.findViewById(R.id.rbMethodEmail);

        LinearLayout llQuestion = view.findViewById(R.id.llContainerQuestion);
        LinearLayout llEmail = view.findViewById(R.id.llContainerEmail);

        TextView tvQuestion = view.findViewById(R.id.tvRecoveryQuestion);
        EditText etAnswer = view.findViewById(R.id.etSecurityAnswer);

        TextView tvRegisteredEmail = view.findViewById(R.id.tvRegisteredEmail);
        View btnSendOtp = view.findViewById(R.id.btnSendOtp);
        EditText etOtp = view.findViewById(R.id.etOtpInput);

        EditText etNewPin = view.findViewById(R.id.etNewPinInput);

        // Populate details
        if (tvQuestion != null) {
            tvQuestion.setText(AppTranslation.get(this, "security_question") + ": " + AppSecurityManager.getSecurityQuestion(this));
        }

        SharedPreferences userPrefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        String userEmail = userPrefs.getString(LoginActivity.KEY_USER_EMAIL, "user@gmail.com");
        if (tvRegisteredEmail != null) {
            tvRegisteredEmail.setText("Email: " + userEmail);
        }

        if (rgMethod != null) {
            rgMethod.setOnCheckedChangeListener((group, checkedId) -> {
                if (checkedId == R.id.rbMethodQuestion) {
                    llQuestion.setVisibility(View.VISIBLE);
                    llEmail.setVisibility(View.GONE);
                } else {
                    llQuestion.setVisibility(View.GONE);
                    llEmail.setVisibility(View.VISIBLE);
                }
            });
        }

        if (btnSendOtp != null) {
            btnSendOtp.setOnClickListener(v -> {
                String generatedOtp = AppSecurityManager.generateRecoveryOtp(this);
                Toast.makeText(this, "OTP: " + generatedOtp, Toast.LENGTH_LONG).show();
            });
        }

        new AlertDialog.Builder(this)
                .setView(view)
                .setPositiveButton(AppTranslation.get(this, "save"), (dialog, which) -> {
                    String newPin = etNewPin != null ? etNewPin.getText().toString().trim() : "";
                    if (newPin.isEmpty() || newPin.length() < 4) {
                        Toast.makeText(this, AppTranslation.get(this, "enter_pin"), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean isQuestionSelected = rbQuestion != null && rbQuestion.isChecked();
                    if (isQuestionSelected) {
                        String ans = etAnswer != null ? etAnswer.getText().toString().trim() : "";
                        if (AppSecurityManager.verifySecurityAnswer(this, ans)) {
                            AppSecurityManager.setPinCode(this, newPin);
                            AppSecurityManager.setPinUnlockedSession(this, true);
                            Toast.makeText(this, AppTranslation.get(this, "pin_unlocked"), Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(PinLockActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, AppTranslation.get(this, "invalid_pin"), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        String inputOtp = etOtp != null ? etOtp.getText().toString().trim() : "";
                        if (AppSecurityManager.verifyRecoveryOtp(this, inputOtp)) {
                            AppSecurityManager.setPinCode(this, newPin);
                            AppSecurityManager.setPinUnlockedSession(this, true);
                            Toast.makeText(this, AppTranslation.get(this, "pin_unlocked"), Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(PinLockActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, AppTranslation.get(this, "invalid_pin"), Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton(AppTranslation.get(this, "cancel"), null)
                .show();
    }

    @Override
    public void onBackPressed() {
        // Prevent bypassing PIN lock
        finishAffinity();
    }
}
