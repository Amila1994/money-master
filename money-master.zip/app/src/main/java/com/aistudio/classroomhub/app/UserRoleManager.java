package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class UserRoleManager {

    private static final String TAG = "UserRoleManager";
    public static final String PREFS_ROLE = "ClassroomHubRolePrefs";
    public static final String KEY_USER_ROLE = "user_role"; // "TEACHER" or "STUDENT"
    public static final String KEY_CUSTOM_UID = "custom_uid"; // "SCH-1234" or "STD-5678"
    
    // Feature toggle keys for student permissions
    public static final String FEATURE_HOMEWORK = "feature_homework";
    public static final String FEATURE_ATTENDANCE = "feature_attendance";
    public static final String FEATURE_NOTES = "feature_notes";
    public static final String FEATURE_MARKS = "feature_marks";
    public static final String FEATURE_CHAT = "feature_chat";
    public static final String FEATURE_TIMETABLE = "feature_timetable";

    public interface CustomUidCallback {
        void onUidReady(String customUid, String role);
    }

    public static String getUserRole(Context context) {
        if (context == null) return "";
        SharedPreferences prefs = context.getSharedPreferences(PREFS_ROLE, Context.MODE_PRIVATE);
        return prefs.getString(KEY_USER_ROLE, "");
    }

    public static boolean isTeacher(Context context) {
        return "TEACHER".equalsIgnoreCase(getUserRole(context));
    }

    public static boolean isStudent(Context context) {
        return "STUDENT".equalsIgnoreCase(getUserRole(context));
    }

    public static String getCustomUid(Context context) {
        if (context == null) return "";
        SharedPreferences prefs = context.getSharedPreferences(PREFS_ROLE, Context.MODE_PRIVATE);
        return prefs.getString(KEY_CUSTOM_UID, "");
    }

    public static void setUserRoleAndGenerateUid(Context context, String role, CustomUidCallback callback) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_ROLE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_USER_ROLE, role);

        String existingUid = prefs.getString(KEY_CUSTOM_UID, "");
        String customUid;
        if (!existingUid.isEmpty() && existingUid.startsWith(role.equals("TEACHER") ? "SCH-" : "STD-")) {
            customUid = existingUid;
        } else {
            customUid = generateShortUid(role);
            editor.putString(KEY_CUSTOM_UID, customUid);
        }
        editor.apply();

        // Sync role & customUid to Firestore
        syncUserProfileToFirestore(context, role, customUid, callback);
    }

    private static String generateShortUid(String role) {
        String prefix = "TEACHER".equalsIgnoreCase(role) ? "SCH-" : "STD-";
        int randomNum = 1000 + new Random().nextInt(9000); // 4-digit readable number
        return prefix + randomNum;
    }

    public static void syncUserProfileToFirestore(Context context, String role, String customUid, CustomUidCallback callback) {
        FirebaseUser user = null;
        try {
            if (!com.google.firebase.FirebaseApp.getApps(context).isEmpty()) {
                user = FirebaseAuth.getInstance().getCurrentUser();
            }
        } catch (Exception ignored) {}

        if (user == null || user.getUid() == null) {
            if (callback != null) callback.onUidReady(customUid, role);
            return;
        }

        String uid = user.getUid();
        String name = user.getDisplayName() != null && !user.getDisplayName().isEmpty() ? user.getDisplayName() : user.getEmail();
        if (name == null) name = "User";

        SharedPreferences schoolPrefs = context.getSharedPreferences("school_header_prefs", Context.MODE_PRIVATE);
        String schoolName = schoolPrefs.getString("school_name", name);

        Map<String, Object> userProfile = new HashMap<>();
        userProfile.put("uid", uid);
        userProfile.put("customUid", customUid);
        userProfile.put("role", role);
        userProfile.put("name", name);
        userProfile.put("schoolName", schoolName);
        userProfile.put("email", user.getEmail() != null ? user.getEmail() : "");
        userProfile.put("updatedAt", System.currentTimeMillis());

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        
        // Save to users/{uid}
        db.collection("users").document(uid).set(userProfile, SetOptions.merge())
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Synced user profile to Firestore"))
                .addOnFailureListener(e -> Log.e(TAG, "Failed to sync user profile", e));

        // Save index to custom_uids/{customUid}
        db.collection("custom_uids").document(customUid).set(userProfile, SetOptions.merge());

        if ("TEACHER".equalsIgnoreCase(role)) {
            db.collection("schools").document(customUid).set(userProfile, SetOptions.merge());
            db.collection("schools").document(uid).set(userProfile, SetOptions.merge());
        } else {
            db.collection("students").document(customUid).set(userProfile, SetOptions.merge());
        }

        if (callback != null) {
            callback.onUidReady(customUid, role);
        }
    }

    public static void checkOrFetchFirestoreProfile(Context context, Runnable onComplete) {
        FirebaseUser user = null;
        try {
            if (!com.google.firebase.FirebaseApp.getApps(context).isEmpty()) {
                user = FirebaseAuth.getInstance().getCurrentUser();
            }
        } catch (Exception ignored) {}

        if (user == null) {
            if (onComplete != null) onComplete.run();
            return;
        }

        FirebaseFirestore.getInstance().collection("users").document(user.getUid()).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                        DocumentSnapshot doc = task.getResult();
                        String role = doc.getString("role");
                        String customUid = doc.getString("customUid");

                        if (role != null && !role.isEmpty()) {
                            SharedPreferences prefs = context.getSharedPreferences(PREFS_ROLE, Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString(KEY_USER_ROLE, role);
                            if (customUid != null && !customUid.isEmpty()) {
                                editor.putString(KEY_CUSTOM_UID, customUid);
                            }
                            editor.apply();
                        }
                    }
                    if (onComplete != null) onComplete.run();
                });
    }

    public static boolean isFeatureEnabledForStudent(Context context, String featureKey) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_ROLE, Context.MODE_PRIVATE);
        return prefs.getBoolean(featureKey, true); // Default true
    }

    public static void setFeatureEnabledForStudent(Context context, String featureKey, boolean enabled) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_ROLE, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(featureKey, enabled).apply();
    }
}
