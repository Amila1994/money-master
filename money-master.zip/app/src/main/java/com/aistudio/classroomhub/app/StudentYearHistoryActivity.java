package com.aistudio.classroomhub.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class StudentYearHistoryActivity extends AppCompatActivity {

    public static final String EXTRA_STUDENT_ID = "extra_student_id";

    private ImageView btnBack;
    private TextView tvHeaderTitle, tvStudentFullName, tvStudentSubInfo;
    private TextView tvStatTotalSchoolDays, tvStatPresentPercent, tvStatPresentDays;
    private TextView tvStatAbsentPercent, tvStatAbsentDays, tvStatYear;
    private TextView tvEmptyLogsMessage;
    private RecyclerView rvYearDailyLogs;

    private Student student;
    private List<DailyLogItem> yearLogs = new ArrayList<>();

    private static class DailyLogItem {
        String dateStr;
        boolean isPresent;

        DailyLogItem(String dateStr, boolean isPresent) {
            this.dateStr = dateStr;
            this.isPresent = isPresent;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_year_history);

        String studentId = getIntent().getStringExtra(EXTRA_STUDENT_ID);
        student = StudentRepository.getStudentById(studentId);

        initViews();
        setupListeners();
        loadStudentYearData();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle);
        tvStudentFullName = findViewById(R.id.tvStudentFullName);
        tvStudentSubInfo = findViewById(R.id.tvStudentSubInfo);

        tvStatTotalSchoolDays = findViewById(R.id.tvStatTotalSchoolDays);
        tvStatPresentPercent = findViewById(R.id.tvStatPresentPercent);
        tvStatPresentDays = findViewById(R.id.tvStatPresentDays);
        tvStatAbsentPercent = findViewById(R.id.tvStatAbsentPercent);
        tvStatAbsentDays = findViewById(R.id.tvStatAbsentDays);
        tvStatYear = findViewById(R.id.tvStatYear);

        tvEmptyLogsMessage = findViewById(R.id.tvEmptyLogsMessage);
        rvYearDailyLogs = findViewById(R.id.rvYearDailyLogs);
        rvYearDailyLogs.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupListeners() {
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }

    private void loadStudentYearData() {
        if (student == null) {
            finish();
            return;
        }

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        String nameWithInitials = student.getNameWithInitials() != null && !student.getNameWithInitials().isEmpty()
                ? student.getNameWithInitials() : student.getName();

        tvHeaderTitle.setText(nameWithInitials + " - " + currentYear + " වාර්තාව");
        tvStudentFullName.setText(student.getName());

        String reg = student.getRollNo() != null ? student.getRollNo() : "REG-0";
        String gender = student.getGender() != null ? student.getGender() : "පිරිමි";
        tvStudentSubInfo.setText("ලියාපදිංචි අංකය: " + reg + " | ස්ත්‍රී/පුරුෂ: " + gender);

        tvStatYear.setText(String.valueOf(currentYear));

        Map<String, Map<String, AttendanceRecord>> allRecords = StudentRepository.getAttendanceRecords();
        int totalSchoolDays = 0;
        int presentDays = 0;
        int absentDays = 0;

        yearLogs.clear();

        for (Map.Entry<String, Map<String, AttendanceRecord>> entry : allRecords.entrySet()) {
            String dateStr = entry.getKey();
            if (dateStr.startsWith(String.valueOf(currentYear))) {
                Map<String, AttendanceRecord> dayMap = entry.getValue();
                if (dayMap.containsKey(student.getId())) {
                    totalSchoolDays++;
                    AttendanceRecord record = dayMap.get(student.getId());
                    boolean present = record != null && record.isPresent();
                    if (present) {
                        presentDays++;
                    } else {
                        absentDays++;
                    }
                    yearLogs.add(new DailyLogItem(dateStr, present));
                }
            }
        }

        // Sort descending by date
        Collections.sort(yearLogs, (a, b) -> b.dateStr.compareTo(a.dateStr));

        double presentPercentage = totalSchoolDays > 0 ? ((double) presentDays / totalSchoolDays) * 100 : 0.0;
        double absentPercentage = totalSchoolDays > 0 ? ((double) absentDays / totalSchoolDays) * 100 : 0.0;

        tvStatTotalSchoolDays.setText(String.valueOf(totalSchoolDays));
        tvStatPresentPercent.setText(String.format(Locale.US, "%.1f%%", presentPercentage));
        tvStatPresentDays.setText("වාර: " + presentDays);

        tvStatAbsentPercent.setText(String.format(Locale.US, "%.1f%%", absentPercentage));
        tvStatAbsentDays.setText("වාර: " + absentDays);

        if (yearLogs.isEmpty()) {
            tvEmptyLogsMessage.setVisibility(View.VISIBLE);
            rvYearDailyLogs.setVisibility(View.GONE);
        } else {
            tvEmptyLogsMessage.setVisibility(View.GONE);
            rvYearDailyLogs.setVisibility(View.VISIBLE);
            rvYearDailyLogs.setAdapter(new YearLogsAdapter(yearLogs));
        }
    }

    private class YearLogsAdapter extends RecyclerView.Adapter<YearLogsAdapter.ViewHolder> {
        private List<DailyLogItem> items;

        YearLogsAdapter(List<DailyLogItem> items) {
            this.items = items;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student_year_log, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            DailyLogItem item = items.get(position);
            holder.tvLogDate.setText("දිනය: " + item.dateStr);

            if (item.isPresent) {
                holder.tvLogStatus.setText("පැමිණ ඇත (Present)");
                holder.tvLogStatus.setTextColor(Color.parseColor("#3B82F6"));
                holder.cardYearLog.setStrokeColor(Color.parseColor("#3B82F6"));
            } else {
                holder.tvLogStatus.setText("නොපැමිණියේය (Absent)");
                holder.tvLogStatus.setTextColor(Color.parseColor("#EF4444"));
                holder.cardYearLog.setStrokeColor(Color.parseColor("#EF4444"));
            }
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            MaterialCardView cardYearLog;
            TextView tvLogDate, tvLogStatus;

            ViewHolder(@NonNull View itemView) {
                super(itemView);
                cardYearLog = itemView.findViewById(R.id.cardYearLog);
                tvLogDate = itemView.findViewById(R.id.tvLogDate);
                tvLogStatus = itemView.findViewById(R.id.tvLogStatus);
            }
        }
    }
}
