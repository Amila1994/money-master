package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.aistudio.classroomhub.app.databinding.ActivityMainBinding;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements StudentAdapter.OnStudentActionListener {

    private ActivityMainBinding binding;
    private List<Student> studentList;
    private List<Student> filteredList;
    private StudentAdapter adapter;

    private String userName;
    private String userEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Load user session
        loadUserSession();

        // Initialize sample class data
        initSampleData();

        // Setup RecyclerView
        setupRecyclerView();

        // Setup listeners
        setupListeners();

        // Update top metrics
        updateMetrics();
    }

    private void loadUserSession() {
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE);
        userName = prefs.getString(LoginActivity.KEY_USER_NAME, "Educator Account");
        userEmail = prefs.getString(LoginActivity.KEY_USER_EMAIL, "teacher@classroomhub.edu");

        binding.tvUserName.setText(userName);
        binding.tvUserEmail.setText(userEmail);

        if (userName != null && !userName.isEmpty()) {
            binding.tvUserInitial.setText(String.valueOf(userName.charAt(0)).toUpperCase());
        } else {
            binding.tvUserInitial.setText("T");
        }
    }

    private void initSampleData() {
        studentList = new ArrayList<>();
        studentList.add(new Student(UUID.randomUUID().toString(), "Alex Morgan", "101", "Grade 10-A", 94, true));
        studentList.add(new Student(UUID.randomUUID().toString(), "Benjamin Carter", "102", "Grade 10-A", 82, true));
        studentList.add(new Student(UUID.randomUUID().toString(), "Chloe Davis", "103", "Grade 10-A", 78, false));
        studentList.add(new Student(UUID.randomUUID().toString(), "Daniel Evans", "104", "Grade 10-A", 88, true));
        studentList.add(new Student(UUID.randomUUID().toString(), "Emily Foster", "105", "Grade 10-A", 91, true));
        studentList.add(new Student(UUID.randomUUID().toString(), "Gabriel Harris", "106", "Grade 10-A", 65, false));

        filteredList = new ArrayList<>(studentList);
    }

    private void setupRecyclerView() {
        adapter = new StudentAdapter(filteredList, this);
        binding.rvStudentList.setLayoutManager(new LinearLayoutManager(this));
        binding.rvStudentList.setAdapter(adapter);
    }

    private void setupListeners() {
        // Sign Out Button
        binding.btnLogout.setOnClickListener(v -> signOutUser());

        // Floating Action Button - Add Student
        binding.fabAddStudent.setOnClickListener(v -> showAddStudentDialog());

        // Search Input Watcher
        binding.etSearchStudent.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterStudents(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Tab Layout Switcher
        binding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                if (position == 0) {
                    binding.tvSectionHeader.setText("Enrolled Class Roster");
                } else if (position == 1) {
                    binding.tvSectionHeader.setText("Student Gradebook & Marks");
                } else if (position == 2) {
                    binding.tvSectionHeader.setText("Daily Class Attendance Tracker");
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void filterStudents(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(studentList);
        } else {
            String lower = query.toLowerCase().trim();
            for (Student s : studentList) {
                if (s.getName().toLowerCase().contains(lower) || s.getRollNo().contains(lower)) {
                    filteredList.add(s);
                }
            }
        }
        adapter.updateList(filteredList);
    }

    private void updateMetrics() {
        int total = studentList.size();
        if (total == 0) {
            binding.tvTotalStudentsCount.setText("0");
            binding.tvAvgMarks.setText("0%");
            binding.tvAttendanceRate.setText("0%");
            return;
        }

        int totalMarks = 0;
        int presentCount = 0;

        for (Student s : studentList) {
            totalMarks += s.getMarks();
            if (s.isPresent()) {
                presentCount++;
            }
        }

        int avgMarks = Math.round((float) totalMarks / total);
        int attendancePct = Math.round(((float) presentCount / total) * 100);

        binding.tvTotalStudentsCount.setText(String.valueOf(total));
        binding.tvAvgMarks.setText(avgMarks + "%");
        binding.tvAttendanceRate.setText(attendancePct + "%");
    }

    private void showAddStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Student");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_student, null);
        final EditText etName = dialogView.findViewById(R.id.etDialogStudentName);
        final EditText etRollNo = dialogView.findViewById(R.id.etDialogRollNo);
        final EditText etGrade = dialogView.findViewById(R.id.etDialogGrade);
        final EditText etMarks = dialogView.findViewById(R.id.etDialogMarks);

        builder.setView(dialogView);
        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String roll = etRollNo.getText().toString().trim();
            String grade = etGrade.getText().toString().trim();
            String marksStr = etMarks.getText().toString().trim();

            if (name.isEmpty() || roll.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please fill in student name and roll number.", Toast.LENGTH_SHORT).show();
                return;
            }

            int marks = 80;
            if (!marksStr.isEmpty()) {
                try {
                    marks = Integer.parseInt(marksStr);
                } catch (NumberFormatException ignored) {}
            }

            if (grade.isEmpty()) grade = "Grade 10-A";

            Student newStudent = new Student(UUID.randomUUID().toString(), name, roll, grade, marks, true);
            studentList.add(0, newStudent);
            filterStudents(binding.etSearchStudent.getText().toString());
            updateMetrics();

            Toast.makeText(MainActivity.this, name + " added to classroom roster!", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    public void onToggleAttendance(Student student) {
        student.setPresent(!student.isPresent());
        adapter.notifyDataSetChanged();
        updateMetrics();
        Toast.makeText(this, student.getName() + " marked as " + (student.isPresent() ? "Present" : "Absent"), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteStudent(Student student) {
        new AlertDialog.Builder(this)
                .setTitle("Remove Student")
                .setMessage("Are you sure you want to remove " + student.getName() + " from classroom hub?")
                .setPositiveButton("Remove", (dialog, which) -> {
                    studentList.remove(student);
                    filterStudents(binding.etSearchStudent.getText().toString());
                    updateMetrics();
                    Toast.makeText(MainActivity.this, "Student removed", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void signOutUser() {
        // Clear local session
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();

        // Firebase Sign Out
        try {
            if (!FirebaseApp.getApps(this).isEmpty()) {
                FirebaseAuth.getInstance().signOut();
            }
        } catch (Exception ignored) {}

        // Google Sign Out
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build();
        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient(this, gso);
        googleSignInClient.signOut();

        Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
