package com.aistudio.classroomhub.app;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.aistudio.classroomhub.app.databinding.ActivityMainBinding;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.tabs.TabLayout;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONObject;

import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class MainActivity extends AppCompatActivity implements StudentAdapter.OnStudentActionListener, ClassRepository.OnClassChangeListener {

    private ActivityMainBinding binding;
    private List<Student> studentList;
    private List<Student> filteredList;
    private StudentAdapter adapter;

    private String userName;
    private String userEmail;
    private DriveServiceHelper driveHelper;
    private DriveSyncManager driveSyncManager;
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "ClassroomPrefs";
    private static final String KEY_IS_RESTORED = "is_initial_restored";

    private boolean isSyncPending = false;
    private boolean isSyncInProgress = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sharedPreferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        // Load user session
        loadUserSession();

        // Register class repository listener
        ClassRepository.addListener(this);

        // Initialize sample class data
        initSampleData();

        // Setup Header Class Switcher & Badge
        setupClassSwitcher();

        // Setup 3D Navigation Grid listeners
        setupListeners();

        // Initialize Drive Sync Manager and check restore
        initDriveSyncManager();
        checkAndRestoreOnFirstLaunch();

        applyDashboardTranslations();

        // Auto-show Live Dashboard Popup on App Launch
        if (binding != null && binding.getRoot() != null) {
            binding.getRoot().post(() -> LiveDashboardPopupKt.showLiveDashboardDialog(MainActivity.this));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppSecurityManager.applyAppLocale(this);
        applyDashboardTranslations();
        setupClassSwitcher();
        studentList = StudentRepository.getStudents();
        filteredList = new ArrayList<>(studentList);
        if (adapter != null) {
            adapter.updateList(filteredList);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ClassRepository.removeListener(this);
    }

    @Override
    public void onActiveClassChanged(ClassModel newClass) {
        updateClassHeaderBadge(newClass);
        studentList = StudentRepository.getStudents();
        filteredList = new ArrayList<>(studentList);
        if (adapter != null) {
            adapter.updateList(filteredList);
        }
        updateMetrics();
        Toast.makeText(this, "ස්ථානගත වූ පන්තිය: " + newClass.getDisplayName(), Toast.LENGTH_SHORT).show();
    }

    private void setupClassSwitcher() {
        if (binding == null || binding.syncHeader == null || binding.syncHeader.spinnerClassSwitcher == null) return;

        List<ClassModel> availableClasses = ClassRepository.getClasses();
        List<String> spinnerItems = new ArrayList<>();
        int selectedIndex = 0;
        ClassModel activeClass = ClassRepository.getActiveClass();

        for (int i = 0; i < availableClasses.size(); i++) {
            ClassModel c = availableClasses.get(i);
            spinnerItems.add(c.getDisplayName());
            if (c.getId().equals(activeClass.getId())) {
                selectedIndex = i;
            }
        }
        spinnerItems.add("⚙️ Manage / Edit / Delete / Promote Classes...");
        spinnerItems.add("➕ Add / Assign New Class (නව පන්තියක් එක් කරන්න)");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                spinnerItems
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.syncHeader.spinnerClassSwitcher.setAdapter(adapter);
        binding.syncHeader.spinnerClassSwitcher.setSelection(selectedIndex, false);

        binding.syncHeader.spinnerClassSwitcher.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                List<ClassModel> currentClasses = ClassRepository.getClasses();
                if (position < currentClasses.size()) {
                    ClassModel selectedClass = currentClasses.get(position);
                    if (!selectedClass.getId().equals(ClassRepository.getActiveClass().getId())) {
                        ClassRepository.setActiveClass(selectedClass);
                    }
                } else if (position == currentClasses.size()) {
                    ClassManagementModalKt.showClassManagementDialog(MainActivity.this);
                    resetSpinnerSelection();
                } else {
                    showAddNewClassDialog();
                    resetSpinnerSelection();
                }
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        updateClassHeaderBadge(activeClass);
    }

    private void resetSpinnerSelection() {
        if (binding != null && binding.syncHeader != null && binding.syncHeader.spinnerClassSwitcher != null) {
            List<ClassModel> currentClasses = ClassRepository.getClasses();
            ClassModel active = ClassRepository.getActiveClass();
            for (int k = 0; k < currentClasses.size(); k++) {
                if (currentClasses.get(k).getId().equals(active.getId())) {
                    binding.syncHeader.spinnerClassSwitcher.setSelection(k, false);
                    break;
                }
            }
        }
    }

    private void updateClassHeaderBadge(ClassModel activeClass) {
        if (binding != null && binding.syncHeader != null && binding.syncHeader.tvClassHeaderBadge != null) {
            binding.syncHeader.tvClassHeaderBadge.setText(activeClass.getBadgeText());
            binding.syncHeader.tvClassHeaderBadge.setOnClickListener(v -> {
                ClassManagementModalKt.showClassManagementDialog(MainActivity.this);
            });
        }
    }

    private void showAddNewClassDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("➕ Add / Assign New Class (නව පන්තියක් එක් කරන්න)");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        final EditText etClassName = new EditText(this);
        etClassName.setHint("පන්තියේ නම (e.g. Grade 12-A)");
        layout.addView(etClassName);

        final EditText etYear = new EditText(this);
        etYear.setHint("අධ්‍යයන වර්ෂය (e.g. 2028)");
        layout.addView(etYear);

        final EditText etRole = new EditText(this);
        etRole.setHint("තනතුර (e.g. Class Teacher / පන්ති භාර ගුරු)");
        etRole.setText("Class Teacher");
        layout.addView(etRole);

        builder.setView(layout);

        builder.setPositiveButton("Save & Switch (එක් කරන්න)", (dialog, which) -> {
            String cName = etClassName.getText().toString().trim();
            String cYear = etYear.getText().toString().trim();
            String cRole = etRole.getText().toString().trim();

            if (cName.isEmpty()) cName = "Grade 12-A";
            if (cYear.isEmpty()) cYear = "2028";
            if (cRole.isEmpty()) cRole = "Class Teacher";

            String newId = "class_" + System.currentTimeMillis();
            ClassModel newClassModel = new ClassModel(newId, cName, cYear, cRole, false);
            ClassRepository.addClass(newClassModel);

            Toast.makeText(this, "නව පන්තිය (" + cName + ") සාර්ථකව සක්‍රිය විය!", Toast.LENGTH_SHORT).show();
            setupClassSwitcher();
        });

        builder.setNegativeButton("Cancel (අවලංගු කරන්න)", null);
        builder.show();
    }

    private void applyDashboardTranslations() {
        if (binding != null && binding.syncHeader != null && binding.syncHeader.btnLogout != null) {
            binding.syncHeader.btnLogout.setText(AppTranslation.get(this, "sign_out"));
        }
        TextView tvAdditions = findViewById(R.id.tvGridAdditions);
        if (tvAdditions != null) tvAdditions.setText(AppTranslation.get(this, "additions"));

        TextView tvRoster = findViewById(R.id.tvGridRoster);
        if (tvRoster != null) tvRoster.setText(AppTranslation.get(this, "student_roster"));

        TextView tvTimetable = findViewById(R.id.tvGridTimetable);
        if (tvTimetable != null) tvTimetable.setText(AppTranslation.get(this, "timetable"));

        TextView tvAttendance = findViewById(R.id.tvGridAttendance);
        if (tvAttendance != null) tvAttendance.setText(AppTranslation.get(this, "attendance"));

        TextView tvExams = findViewById(R.id.tvGridExams);
        if (tvExams != null) tvExams.setText(AppTranslation.get(this, "exams"));

        TextView tvSettings = findViewById(R.id.tvGridSettings);
        if (tvSettings != null) tvSettings.setText(AppTranslation.get(this, "settings"));
    }

    private void loadUserSession() {
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE);
        userName = prefs.getString(LoginActivity.KEY_USER_NAME, "Educator Account");
        userEmail = prefs.getString(LoginActivity.KEY_USER_EMAIL, "teacher@classroomhub.edu");

        if (binding.syncHeader != null) {
            binding.syncHeader.tvUserName.setText(userName);
            binding.syncHeader.tvUserEmail.setText(userEmail);

            if (userName != null && !userName.isEmpty()) {
                binding.syncHeader.tvUserInitial.setText(String.valueOf(userName.charAt(0)).toUpperCase());
            } else {
                binding.syncHeader.tvUserInitial.setText("T");
            }
        }
    }

    private void initSampleData() {
        studentList = StudentRepository.getStudents();
        filteredList = new ArrayList<>(studentList);
    }

    private void setupListeners() {
        // Sign Out Button
        if (binding.syncHeader != null && binding.syncHeader.btnLogout != null) {
            binding.syncHeader.btnLogout.setOnClickListener(v -> signOutUser());
        }

        // 3D Click Press Scale Effect Listener
        View.OnTouchListener touch3dAnimation = (view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(100).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                    break;
            }
            return false;
        };

        // Apply touch animation to all 6 grid buttons
        if (binding.btnAdditions != null) binding.btnAdditions.setOnTouchListener(touch3dAnimation);
        if (binding.btnNameList != null) binding.btnNameList.setOnTouchListener(touch3dAnimation);
        if (binding.btnTimetable != null) binding.btnTimetable.setOnTouchListener(touch3dAnimation);
        if (binding.btnAttendance != null) binding.btnAttendance.setOnTouchListener(touch3dAnimation);
        if (binding.btnExams != null) binding.btnExams.setOnTouchListener(touch3dAnimation);
        if (binding.btnSettings != null) binding.btnSettings.setOnTouchListener(touch3dAnimation);

        // Click actions for the buttons
        if (binding.btnAdditions != null) {
            binding.btnAdditions.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, AdditionsActivity.class);
                startActivity(intent);
            });
        }
        if (binding.btnNameList != null) {
            binding.btnNameList.setOnClickListener(v -> {
                Toast.makeText(this, "නම් ලැයිස්තුව (Student Roster) විවෘත වේ...", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, StudentListActivity.class);
                startActivity(intent);
            });
        }
        if (binding.btnTimetable != null) {
            binding.btnTimetable.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, TimetableActivity.class);
                startActivity(intent);
            });
        }
        if (binding.btnAttendance != null) {
            binding.btnAttendance.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, AttendanceActivity.class);
                startActivity(intent);
            });
        }
        if (binding.btnExams != null) {
            binding.btnExams.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, ExamActivity.class);
                startActivity(intent);
            });
        }
        if (binding.btnSettings != null) {
            binding.btnSettings.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(intent);
            });
        }
        if (binding.btnLiveDashboard != null) {
            binding.btnLiveDashboard.setOnClickListener(v -> {
                LiveDashboardPopupKt.showLiveDashboardDialog(MainActivity.this);
            });
        }
    }

    private void filterStudents(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(studentList);
        } else {
            String lower = query.toLowerCase().trim();
            for (Student s : studentList) {
                if (s.getName().toLowerCase().contains(lower) || s.getRollNo().contains(lower)) {
                    filteredList.add(s);
                }
            }
        }
        if (adapter != null) {
            adapter.updateList(filteredList);
        }
    }

    private void updateMetrics() {
        // Data metrics maintained internally
    }

    private void showAddStudentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Student (ළමයා එකතු කරන්න)");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_student, null);
        final EditText etName = dialogView.findViewById(R.id.etDialogStudentName);
        final EditText etInitials = dialogView.findViewById(R.id.etDialogInitials);
        final EditText etDob = dialogView.findViewById(R.id.etDialogDob);
        final EditText etGender = dialogView.findViewById(R.id.etDialogGender);
        final EditText etEthRel = dialogView.findViewById(R.id.etDialogEthRel);
        final EditText etBirthCert = dialogView.findViewById(R.id.etDialogBirthCert);

        final EditText etRollNo = dialogView.findViewById(R.id.etDialogRollNo);
        final EditText etGrade = dialogView.findViewById(R.id.etDialogGrade);
        final EditText etMedium = dialogView.findViewById(R.id.etDialogMedium);
        final EditText etAddress = dialogView.findViewById(R.id.etDialogAddress);

        final EditText etFather = dialogView.findViewById(R.id.etDialogFather);
        final EditText etFatherPhone = dialogView.findViewById(R.id.etDialogFatherPhone);
        final EditText etMother = dialogView.findViewById(R.id.etDialogMother);
        final EditText etMotherPhone = dialogView.findViewById(R.id.etDialogMotherPhone);

        final EditText etGuardian = dialogView.findViewById(R.id.etDialogGuardian);
        final EditText etEmergencyName = dialogView.findViewById(R.id.etDialogEmergencyName);
        final EditText etContact = dialogView.findViewById(R.id.etDialogContact);
        final EditText etMarks = dialogView.findViewById(R.id.etDialogMarks);

        builder.setView(dialogView);
        builder.setPositiveButton("Add (එකතු කරන්න)", (dialog, which) -> {
            String name = etName != null ? etName.getText().toString().trim() : "";
            String roll = etRollNo != null ? etRollNo.getText().toString().trim() : "";
            String grade = etGrade != null ? etGrade.getText().toString().trim() : "";
            String marksStr = etMarks != null ? etMarks.getText().toString().trim() : "";

            if (name.isEmpty() || roll.isEmpty()) {
                Toast.makeText(MainActivity.this, "කරුණාකර නම සහ ඇතුළත් වීමේ අංකය ඇතුලත් කරන්න.", Toast.LENGTH_SHORT).show();
                return;
            }

            int marks = 80;
            if (!marksStr.isEmpty()) {
                try {
                    marks = Integer.parseInt(marksStr);
                } catch (NumberFormatException ignored) {}
            }

            if (grade.isEmpty()) grade = "Grade 10-A";

            Student newStudent = new Student(UUID.randomUUID().toString(), name, roll, grade, marks, true);
            if (etInitials != null) newStudent.setNameWithInitials(etInitials.getText().toString().trim());
            if (etDob != null) newStudent.setDob(etDob.getText().toString().trim());
            if (etGender != null) newStudent.setGender(etGender.getText().toString().trim());
            if (etEthRel != null) newStudent.setEthnicity(etEthRel.getText().toString().trim());
            if (etBirthCert != null) newStudent.setBirthCertNo(etBirthCert.getText().toString().trim());
            if (etMedium != null) newStudent.setMedium(etMedium.getText().toString().trim());
            if (etAddress != null) newStudent.setPermAddress(etAddress.getText().toString().trim());
            if (etFather != null) newStudent.setFatherName(etFather.getText().toString().trim());
            if (etFatherPhone != null) newStudent.setFatherPhone(etFatherPhone.getText().toString().trim());
            if (etMother != null) newStudent.setMotherName(etMother.getText().toString().trim());
            if (etMotherPhone != null) newStudent.setMotherPhone(etMotherPhone.getText().toString().trim());
            if (etGuardian != null) newStudent.setGuardianName(etGuardian.getText().toString().trim());
            if (etEmergencyName != null) newStudent.setEmergencyName(etEmergencyName.getText().toString().trim());
            if (etContact != null) newStudent.setEmergencyPhone(etContact.getText().toString().trim());

            StudentRepository.addStudent(newStudent);
            filterStudents("");
            updateMetrics();
            onDataChanged();

            Toast.makeText(MainActivity.this, name + " සාර්ථකව ඇතුළත් කරන ලදී!", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(MainActivity.this, StudentListActivity.class);
            startActivity(intent);
        });

        builder.setNegativeButton("Cancel (අවලංගු කරන්න)", null);
        builder.show();
    }

    @Override
    public void onDeleteStudent(Student student) {
        new AlertDialog.Builder(this)
                .setTitle("Remove Student")
                .setMessage("Are you sure you want to remove " + student.getName() + " from classroom hub?")
                .setPositiveButton("Remove", (dialog, which) -> {
                    StudentRepository.removeStudent(student);
                    filterStudents("");
                    updateMetrics();
                    onDataChanged();
                    Toast.makeText(MainActivity.this, "Student removed", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onStudentClick(Student student) {
        StringBuilder details = new StringBuilder();
        details.append("ඇතුළත් අංකය: ").append(student.getRollNo() != null ? student.getRollNo() : "-").append("\n");
        if (student.getNameWithInitials() != null && !student.getNameWithInitials().isEmpty()) {
            details.append("මුලකුරු සමග නම: ").append(student.getNameWithInitials()).append("\n");
        }
        details.append("ශ්‍රේණිය: ").append(student.getGrade()).append("\n");
        if (student.getDob() != null && !student.getDob().isEmpty()) {
            details.append("උපන් දිනය: ").append(student.getDob()).append("\n");
        }
        if (student.getGender() != null && !student.getGender().isEmpty()) {
            details.append("ස්ත්‍රී/පුරුෂ භාවය: ").append(student.getGender()).append("\n");
        }
        if (student.getPermAddress() != null && !student.getPermAddress().isEmpty()) {
            details.append("ලිපිනය: ").append(student.getPermAddress()).append("\n");
        }
        if (student.getFatherName() != null && !student.getFatherName().isEmpty()) {
            details.append("පියාගේ නම: ").append(student.getFatherName());
            if (student.getFatherPhone() != null && !student.getFatherPhone().isEmpty()) {
                details.append(" (").append(student.getFatherPhone()).append(")");
            }
            details.append("\n");
        }
        if (student.getMotherName() != null && !student.getMotherName().isEmpty()) {
            details.append("මවගේ නම: ").append(student.getMotherName());
            if (student.getMotherPhone() != null && !student.getMotherPhone().isEmpty()) {
                details.append(" (").append(student.getMotherPhone()).append(")");
            }
            details.append("\n");
        }
        if (student.getGuardianName() != null && !student.getGuardianName().isEmpty()) {
            details.append("භාරකරු: ").append(student.getGuardianName()).append("\n");
        }
        if (student.getEmergencyPhone() != null && !student.getEmergencyPhone().isEmpty()) {
            details.append("හදිසි දුරකථන: ").append(student.getEmergencyPhone()).append("\n");
        }
        details.append("ලකුණු %: ").append(student.getGradeBadge());

        new AlertDialog.Builder(this)
                .setTitle(student.getName())
                .setMessage(details.toString())
                .setPositiveButton("වසා දමන්න", null)
                .show();
    }

    public void onDataChanged() {
        isSyncPending = true;
        triggerInstantDriveBackup();
    }

    private void triggerInstantDriveBackup() {
        if (isSyncInProgress || driveSyncManager == null) {
            return;
        }

        isSyncInProgress = true;
        String latestJson = getLatestAppDataAsJson();

        driveSyncManager.autoBackupToDrive(latestJson)
                .addOnSuccessListener(success -> {
                    isSyncPending = false;
                    isSyncInProgress = false;
                    Log.d("DriveSync", "Instant backup successful!");
                })
                .addOnFailureListener(e -> {
                    isSyncInProgress = false;
                    Log.e("DriveSync", "Instant backup failed: " + e.getMessage());
                });
    }

    @Override
    public void onBackPressed() {
        if (isSyncPending || isSyncInProgress) {
            ProgressDialog closingDialog = new ProgressDialog(this);
            closingDialog.setMessage("Saving pending changes to Google Drive...");
            closingDialog.setCancelable(false);
            closingDialog.show();

            String currentDataJson = getLatestAppDataAsJson();
            if (driveSyncManager != null) {
                driveSyncManager.autoBackupToDrive(currentDataJson)
                        .addOnCompleteListener(task -> {
                            closingDialog.dismiss();
                            isSyncPending = false;
                            finish();
                        });
            } else {
                closingDialog.dismiss();
                finish();
            }
        } else {
            finish();
        }
    }

    private void checkAndRestoreOnFirstLaunch() {
        boolean isAlreadyRestored = sharedPreferences.getBoolean(KEY_IS_RESTORED, false);

        if (!isAlreadyRestored && driveSyncManager != null) {
            ProgressDialog startupDialog = new ProgressDialog(this);
            startupDialog.setMessage("Syncing latest data from Google Drive...");
            startupDialog.setCancelable(false);
            startupDialog.show();

            driveSyncManager.fetchLatestBackup()
                    .addOnSuccessListener(jsonContent -> {
                        startupDialog.dismiss();
                        if (jsonContent != null && !jsonContent.isEmpty()) {
                            applyDataToApp(jsonContent);
                        }
                        sharedPreferences.edit().putBoolean(KEY_IS_RESTORED, true).apply();
                    })
                    .addOnFailureListener(e -> startupDialog.dismiss());
        }
    }

    private String getLatestAppDataAsJson() {
        return serializeStudentListToJson();
    }

    private void applyDataToApp(String json) {
        updateUIWithDriveData(json);
    }

    private void initDriveSyncManager() {
        try {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
            if (account != null && account.getAccount() != null) {
                GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(
                        this, Collections.singleton(DriveScopes.DRIVE_APPDATA));
                credential.setSelectedAccount(account.getAccount());

                Drive driveService = new Drive.Builder(
                        new NetHttpTransport(),
                        new GsonFactory(),
                        credential)
                        .setApplicationName("Classroom Hub")
                        .build();

                driveSyncManager = new DriveSyncManager(driveService);
                driveHelper = new DriveServiceHelper(driveService);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String serializeStudentListToJson() {
        try {
            JSONArray array = new JSONArray();
            for (Student s : studentList) {
                JSONObject obj = new JSONObject();
                obj.put("id", s.getId());
                obj.put("name", s.getName());
                obj.put("rollNo", s.getRollNo());
                obj.put("grade", s.getGrade());
                obj.put("marks", s.getMarks());
                obj.put("present", s.isPresent());
                array.put(obj);
            }
            return array.toString();
        } catch (Exception e) {
            return "[]";
        }
    }

    private List<Student> parseStudentListFromJson(String jsonContent) {
        List<Student> list = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(jsonContent);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String id = obj.optString("id", UUID.randomUUID().toString());
                String name = obj.optString("name", "Student");
                String rollNo = obj.optString("rollNo", "00");
                String grade = obj.optString("grade", "Grade 10");
                int marks = obj.optInt("marks", 0);
                boolean present = obj.optBoolean("present", true);
                list.add(new Student(id, name, rollNo, grade, marks, present));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public String convertAllDataToJson() {
        return serializeStudentListToJson();
    }

    public void saveAllDataToDrive() {
        if (driveHelper == null) {
            initDriveSyncManager();
        }
        if (driveHelper == null) {
            Toast.makeText(this, "Google account not signed in for Drive access.", Toast.LENGTH_SHORT).show();
            return;
        }

        String jsonOutput = convertAllDataToJson();

        driveHelper.saveDataToDrive("classroom_data.json", jsonOutput)
                .addOnSuccessListener(fileId -> {
                    Toast.makeText(this, "Data Saved to Drive!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to save: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    public void updateUIWithDriveData(String jsonContent) {
        List<Student> restored = parseStudentListFromJson(jsonContent);
        if (!restored.isEmpty()) {
            studentList.clear();
            studentList.addAll(restored);
            filterStudents("");
            updateMetrics();
            Toast.makeText(this, "Data Restored from Google Drive!", Toast.LENGTH_SHORT).show();
        } else {
            showEmptyState();
        }
    }

    public void showEmptyState() {
        Toast.makeText(this, "No backup found for this Google Account.", Toast.LENGTH_SHORT).show();
    }

    public void loadDataFromDrive() {
        if (driveHelper == null) {
            initDriveSyncManager();
        }
        if (driveHelper == null) {
            Toast.makeText(this, "Google account not signed in for Drive access.", Toast.LENGTH_SHORT).show();
            return;
        }

        driveHelper.readDataFromDrive("classroom_data.json")
                .addOnSuccessListener(jsonContent -> {
                    if (jsonContent != null && !jsonContent.isEmpty()) {
                        updateUIWithDriveData(jsonContent);
                    } else {
                        showEmptyState();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error loading data from Drive: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void performBackupToDrive() {
        saveAllDataToDrive();
    }

    private void performRestoreFromDrive() {
        loadDataFromDrive();
    }

    private void signOutUser() {
        // Clear local session
        SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();

        // Firebase Sign Out
        try {
            if (!FirebaseApp.getApps(this).isEmpty()) {
                FirebaseAuth.getInstance().signOut();
            }
        } catch (Exception ignored) {}

        // Google Sign Out
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build();
        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient(this, gso);
        googleSignInClient.signOut();

        Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
