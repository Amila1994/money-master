package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ClassTimetableRepository {

    private static final List<ClassTimetableEntry> entries = new ArrayList<>();

    static {
        initSampleClassTimetableData();
    }

    private static void initSampleClassTimetableData() {
        if (!entries.isEmpty()) return;

        // Monday (සඳුදා)
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "කේ. ඒ. පෙරේරා මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "විද්‍යාව", "එස්. එම්. ප්‍රනාන්දු මිය", "Lab 01"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "සිංහල", "ඩබ්. ඒ. රත්නායක මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ඉංග්‍රීසි", "ජේ. ඩී. සිල්වා මිය", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "5 වන කාලඡේදය", 10, 50, 11, 30, "ඉතිහාසය", "ආර්. පී. විජේසිංහ මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "6 වන කාලඡේදය", 11, 30, 12, 10, "තොරතුරු තාක්ෂණය", "එම්. කේ. කුමාර මහතා", "Computer Lab"));

        // Tuesday (අඟහරුවාදා)
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "බුද්ධ ධර්මය", "පූජ්‍ය ධම්මානන්ද හිමි", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "ගණිතය", "කේ. ඒ. පෙරේරා මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "විද්‍යාව", "එස්. එම්. ප්‍රනාන්දු මිය", "Lab 01"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "සෞඛ්‍යය", "ජී. එච්. බණ්ඩාර මහතා", "Hall 02"));

        // Wednesday (බදාදා)
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බදාදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "තොරතුරු තාක්ෂණය", "එම්. කේ. කුමාර මහතා", "Computer Lab"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බදාදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "ගණිතය", "කේ. ඒ. පෙරේරා මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බදාදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "ඉතිහාසය", "ආර්. පී. විජේසිංහ මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බදාදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "චිත්‍ර / සංගීතය", "එච්. ඇන්. ලියනගේ මිය", "Art Room"));

        // Thursday (බ්‍රහස්පතින්දා)
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "කේ. ඒ. පෙරේරා මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "2 වන කාලඡේදය", 8, 30, 9, 10, "සිංහල", "ඩබ්. ඒ. රත්නායක මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "3 වන කාලඡේදය", 9, 10, 9, 50, "විද්‍යාව", "එස්. එම්. ප්‍රනාන්දු මිය", "Lab 01"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ඉංග්‍රීසි", "ජේ. ඩී. සිල්වා මිය", "Hall 02"));

        // Friday (සිකුරාදා)
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "කේ. ඒ. පෙරේරා මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "තොරතුරු තාක්ෂණය", "එම්. කේ. කුමාර මහතා", "Computer Lab"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "දෙමළ භාෂාව", "එස්. තේවරාජ් මහතා", "Hall 02"));
        entries.add(new ClassTimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ශාරීරික අධ්‍යාපනය", "පී. කේ. සොයිසා මහතා", "Playground"));
    }

    public static List<ClassTimetableEntry> getEntries() {
        return entries;
    }

    public static List<ClassTimetableEntry> getEntriesForDay(String day) {
        List<ClassTimetableEntry> result = new ArrayList<>();
        for (ClassTimetableEntry e : entries) {
            if (e.getDay().equalsIgnoreCase(day)) {
                result.add(e);
            }
        }
        return result;
    }

    public static void addEntry(ClassTimetableEntry entry) {
        entries.add(entry);
    }

    public static void removeEntry(String id) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getId().equals(id)) {
                entries.remove(i);
                break;
            }
        }
    }
}
