package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;

import java.util.Locale;
import java.util.Random;

public class AppSecurityManager {

    private static final String PREFS_SECURITY = "AppSecurityPrefs";
    private static final String KEY_COUNTRY = "selected_country";
    private static final String KEY_LANGUAGE_CODE = "selected_language_code";
    private static final String KEY_PIN_ENABLED = "is_pin_enabled";
    private static final String KEY_PIN_CODE = "pin_code";
    private static final String KEY_SECURITY_QUESTION = "security_question";
    private static final String KEY_SECURITY_ANSWER = "security_answer";
    private static final String KEY_PIN_UNLOCKED = "pin_unlocked_session";
    private static final String KEY_RECOVERY_OTP = "recovery_otp_code";

    private static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREFS_SECURITY, Context.MODE_PRIVATE);
    }

    // --- Country & Language ---
    public static String getSelectedCountry(Context context) {
        return getPrefs(context).getString(KEY_COUNTRY, "Sri Lanka");
    }

    public static void setSelectedCountry(Context context, String country) {
        getPrefs(context).edit().putString(KEY_COUNTRY, country).apply();
    }

    public static String getSelectedLanguageCode(Context context) {
        return getPrefs(context).getString(KEY_LANGUAGE_CODE, "si");
    }

    public static void setSelectedLanguageCode(Context context, String languageCode) {
        getPrefs(context).edit().putString(KEY_LANGUAGE_CODE, languageCode).apply();
    }

    public static Context applyAppLocale(Context context) {
        String langCode = getSelectedLanguageCode(context);
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);

        Resources res = context.getResources();
        Configuration config = new Configuration(res.getConfiguration());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            config.setLocale(locale);
            return context.createConfigurationContext(config);
        } else {
            config.locale = locale;
            res.updateConfiguration(config, res.getDisplayMetrics());
            return context;
        }
    }

    // --- PIN Security Lock ---
    public static boolean isPinEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_PIN_ENABLED, false);
    }

    public static void setPinEnabled(Context context, boolean enabled) {
        getPrefs(context).edit().putBoolean(KEY_PIN_ENABLED, enabled).apply();
    }

    public static String getPinCode(Context context) {
        return getPrefs(context).getString(KEY_PIN_CODE, "");
    }

    public static void setPinCode(Context context, String pin) {
        getPrefs(context).edit().putString(KEY_PIN_CODE, pin).apply();
    }

    public static boolean verifyPin(Context context, String pin) {
        String savedPin = getPinCode(context);
        return savedPin != null && savedPin.equals(pin);
    }

    // --- Security Question & Answer ---
    public static String getSecurityQuestion(Context context) {
        return getPrefs(context).getString(KEY_SECURITY_QUESTION, "ඔබේ පළමු සුරතලාගේ නම කුමක්ද? (First pet's name)");
    }

    public static void setSecurityQuestion(Context context, String question) {
        getPrefs(context).edit().putString(KEY_SECURITY_QUESTION, question).apply();
    }

    public static String getSecurityAnswer(Context context) {
        return getPrefs(context).getString(KEY_SECURITY_ANSWER, "");
    }

    public static void setSecurityAnswer(Context context, String answer) {
        getPrefs(context).edit().putString(KEY_SECURITY_ANSWER, answer.trim().toLowerCase()).apply();
    }

    public static boolean verifySecurityAnswer(Context context, String answer) {
        String savedAnswer = getSecurityAnswer(context);
        return savedAnswer != null && !savedAnswer.isEmpty() && savedAnswer.equalsIgnoreCase(answer.trim());
    }

    // --- Session Unlock State ---
    public static boolean isPinUnlockedSession(Context context) {
        return getPrefs(context).getBoolean(KEY_PIN_UNLOCKED, false);
    }

    public static void setPinUnlockedSession(Context context, boolean unlocked) {
        getPrefs(context).edit().putBoolean(KEY_PIN_UNLOCKED, unlocked).apply();
    }

    // --- OTP Verification ---
    public static String generateRecoveryOtp(Context context) {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        String otpStr = String.valueOf(otp);
        getPrefs(context).edit().putString(KEY_RECOVERY_OTP, otpStr).apply();
        return otpStr;
    }

    public static boolean verifyRecoveryOtp(Context context, String inputOtp) {
        String savedOtp = getPrefs(context).getString(KEY_RECOVERY_OTP, "");
        return savedOtp != null && !savedOtp.isEmpty() && savedOtp.equals(inputOtp.trim());
    }
}
