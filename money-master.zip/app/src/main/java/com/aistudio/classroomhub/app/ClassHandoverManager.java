package com.aistudio.classroomhub.app;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ClassHandoverManager {

    public enum ClassStatus {
        ACTIVE,
        HANDED_OVER
    }

    public static class ClassInfo {
        private String classId;
        private String className;
        private ClassStatus status;
        private String handedOverDate;

        public ClassInfo(String classId, String className) {
            this.classId = classId;
            this.className = className;
            this.status = ClassStatus.ACTIVE;
            this.handedOverDate = null;
        }

        public String getClassId() {
            return classId;
        }

        public String getClassName() {
            return className;
        }

        public ClassStatus getStatus() {
            return status;
        }

        public void setStatus(ClassStatus status) {
            this.status = status;
        }

        public String getHandedOverDate() {
            return handedOverDate;
        }

        public void setHandedOverDate(String handedOverDate) {
            this.handedOverDate = handedOverDate;
        }
    }

    private static final Map<String, ClassInfo> classStore = new HashMap<>();

    static {
        // Initialize sample class Grade 10-A
        classStore.put("class_10a", new ClassInfo("class_10a", "Grade 10-A"));
    }

    public static ClassInfo getClass(String classId) {
        return classStore.get(classId);
    }

    /**
     * A ගුරුවරයාගේ App එකේ Class Status එක Update කිරීම
     * දත්ත Delete නොකර Status එක පමණක් 'HANDED_OVER' ලෙස වෙනස් කිරීම (Read-only ලෙස තබා ගැනීමට)
     */
    public static boolean markClassAsHandedOver(String classId) {
        ClassInfo selectedClass = classStore.get(classId);
        if (selectedClass != null) {
            selectedClass.setStatus(ClassStatus.HANDED_OVER);
            String formattedDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.getDefault()).format(new Date());
            selectedClass.setHandedOverDate(formattedDate);
            return true;
        }
        return false;
    }

    /**
     * A ගුරුවරයාට පසුව කැමති නම් පමණක් Delete කිරීමට Option එකක් තැබීම
     */
    public static boolean deleteClassPermanently(String classId) {
        if (classStore.containsKey(classId)) {
            classStore.remove(classId);
            return true;
        }
        return false;
    }
}
