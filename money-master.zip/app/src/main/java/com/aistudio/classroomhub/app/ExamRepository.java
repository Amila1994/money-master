package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExamRepository {

    public static final List<String> ALL_SUBJECTS = new ArrayList<>(Arrays.asList(
            "ගණිතය", "විද්‍යාව", "සිංහල", "ඉංග්‍රීසි", "ඉතිහාසය",
            "බුද්ධ ධර්මය", "තොරතුරු තාක්ෂණය (ICT)", "වාණිජ", "චිත්‍ර", "සංගීතය"
    ));

    public static void addSubjectToMasterList(String subject) {
        if (subject != null && !subject.trim().isEmpty()) {
            String trimmed = subject.trim();
            if (!ALL_SUBJECTS.contains(trimmed)) {
                ALL_SUBJECTS.add(trimmed);
            }
        }
    }

    private static final Map<String, List<String>> studentSubjects = new HashMap<>();
    private static final Map<String, Map<String, Double>> studentMarks = new HashMap<>();
    private static final Map<String, Double> previousExamTotals = new HashMap<>();

    static {
        initDefaults();
    }

    private static void initDefaults() {
        List<Student> students = StudentRepository.getStudents();
        for (int i = 0; i < students.size(); i++) {
            Student s = students.get(i);
            String id = s.getId();

            // Default enrolled subjects
            List<String> subjects = new ArrayList<>(ALL_SUBJECTS);
            studentSubjects.put(id, subjects);

            // Default initial marks
            Map<String, Double> marks = new HashMap<>();
            double baseMark = 65.0 + (i * 4) % 30;
            for (String sub : subjects) {
                double subMark = Math.min(100.0, Math.max(35.0, baseMark + (sub.hashCode() % 15)));
                marks.put(sub, subMark);
            }
            studentMarks.put(id, marks);

            // Previous exam total
            previousExamTotals.put(id, baseMark * subjects.size() - 12.0);
        }
    }

    public static List<String> getStudentSubjects(String studentId) {
        if (!studentSubjects.containsKey(studentId)) {
            studentSubjects.put(studentId, new ArrayList<>(ALL_SUBJECTS));
        }
        return studentSubjects.get(studentId);
    }

    public static void setStudentSubjects(String studentId, List<String> subjects) {
        studentSubjects.put(studentId, new ArrayList<>(subjects));
        // Remove marks for unselected subjects
        Map<String, Double> marks = getStudentMarks(studentId);
        List<String> toRemove = new ArrayList<>();
        for (String key : marks.keySet()) {
            if (!subjects.contains(key)) {
                toRemove.add(key);
            }
        }
        for (String r : toRemove) marks.remove(r);
        // Add default 0 for new subjects if needed
        for (String s : subjects) {
            if (!marks.containsKey(s)) {
                marks.put(s, 60.0);
            }
        }
    }

    public static Map<String, Double> getStudentMarks(String studentId) {
        if (!studentMarks.containsKey(studentId)) {
            studentMarks.put(studentId, new HashMap<>());
        }
        return studentMarks.get(studentId);
    }

    public static void setStudentMark(String studentId, String subject, double mark) {
        getStudentMarks(studentId).put(subject, mark);
    }

    public static double getPreviousExamTotal(String studentId) {
        Double prev = previousExamTotals.get(studentId);
        return prev != null ? prev : 220.0;
    }

    public static String calculateGrade(double mark) {
        if (mark >= 75.0) return "A";
        if (mark >= 65.0) return "B";
        if (mark >= 55.0) return "C";
        if (mark >= 35.0) return "S";
        return "F";
    }

    public static double calculateTotalMarks(String studentId) {
        Map<String, Double> marks = getStudentMarks(studentId);
        double total = 0.0;
        for (Double m : marks.values()) {
            if (m != null) total += m;
        }
        return total;
    }

    public static double calculateAverageMarks(String studentId) {
        Map<String, Double> marks = getStudentMarks(studentId);
        if (marks.isEmpty()) return 0.0;
        return calculateTotalMarks(studentId) / marks.size();
    }

    public static class StudentExamResult {
        public Student student;
        public double totalMarks;
        public double averageMarks;
        public int rank;
        public double progressGrowth;
        public Map<String, Double> marks;

        public StudentExamResult(Student student, double totalMarks, double averageMarks, Map<String, Double> marks) {
            this.student = student;
            this.totalMarks = totalMarks;
            this.averageMarks = averageMarks;
            this.marks = marks;
        }
    }

    public static List<StudentExamResult> getRankedResults() {
        List<Student> students = StudentRepository.getStudents();
        List<StudentExamResult> results = new ArrayList<>();

        for (Student s : students) {
            double total = calculateTotalMarks(s.getId());
            double avg = calculateAverageMarks(s.getId());
            Map<String, Double> marks = getStudentMarks(s.getId());
            StudentExamResult res = new StudentExamResult(s, total, avg, marks);

            double prevTotal = getPreviousExamTotal(s.getId());
            res.progressGrowth = total - prevTotal;

            results.add(res);
        }

        // Sort by total marks descending
        Collections.sort(results, (a, b) -> Double.compare(b.totalMarks, a.totalMarks));

        // Assign rank
        for (int i = 0; i < results.size(); i++) {
            results.get(i).rank = i + 1;
        }

        return results;
    }

    public static class SubjectStat {
        public String subject;
        public String highestStudentName;
        public double highestMark = -1;
        public String lowestStudentName;
        public double lowestMark = 101;
        public double averageMark = 0.0;
    }

    public static List<SubjectStat> getSubjectStats() {
        List<SubjectStat> stats = new ArrayList<>();
        List<Student> students = StudentRepository.getStudents();

        for (String sub : ALL_SUBJECTS) {
            SubjectStat stat = new SubjectStat();
            stat.subject = sub;
            double sum = 0.0;
            int count = 0;

            for (Student s : students) {
                Map<String, Double> marks = getStudentMarks(s.getId());
                if (marks.containsKey(sub)) {
                    double m = marks.get(sub);
                    sum += m;
                    count++;

                    if (m > stat.highestMark) {
                        stat.highestMark = m;
                        stat.highestStudentName = s.getName();
                    }
                    if (m < stat.lowestMark) {
                        stat.lowestMark = m;
                        stat.lowestStudentName = s.getName();
                    }
                }
            }

            if (count > 0) {
                stat.averageMark = sum / count;
                stats.add(stat);
            }
        }

        return stats;
    }
}
