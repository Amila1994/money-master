package com.aistudio.classroomhub.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class StudentListActivity extends AppCompatActivity implements StudentAdapter.OnStudentActionListener {

    private ImageView btnBack;
    private TextView tvStudentCount;
    private EditText etSearchStudent;
    private RecyclerView rvStudentList;

    private List<Student> filteredList;
    private StudentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_student_list);

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        filterStudents(etSearchStudent != null ? etSearchStudent.getText().toString() : "");
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvStudentCount = findViewById(R.id.tvStudentCount);
        etSearchStudent = findViewById(R.id.etSearchStudent);
        rvStudentList = findViewById(R.id.rvStudentList);
    }

    private void initData() {
        filteredList = new ArrayList<>(StudentRepository.getStudents());
        updateStudentCount();
    }

    private void setupRecyclerView() {
        adapter = new StudentAdapter(filteredList, this);
        rvStudentList.setLayoutManager(new LinearLayoutManager(this));
        rvStudentList.setAdapter(adapter);
    }

    private void setupListeners() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        if (etSearchStudent != null) {
            etSearchStudent.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterStudents(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });
        }
    }

    private void filterStudents(String query) {
        filteredList.clear();
        List<Student> allStudents = StudentRepository.getStudents();
        if (query.trim().isEmpty()) {
            filteredList.addAll(allStudents);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Student student : allStudents) {
                String fullName = student.getName() != null ? student.getName().toLowerCase() : "";
                String initials = student.getNameWithInitials() != null ? student.getNameWithInitials().toLowerCase() : "";
                String regNo = student.getRollNo() != null ? student.getRollNo().toLowerCase() : "";

                if (fullName.contains(lowerQuery) || initials.contains(lowerQuery) || regNo.contains(lowerQuery)) {
                    filteredList.add(student);
                }
            }
        }
        if (adapter != null) {
            adapter.updateList(filteredList);
        }
        updateStudentCount();
    }

    private void updateStudentCount() {
        if (tvStudentCount != null) {
            tvStudentCount.setText("ශිෂ්‍යයන්: " + filteredList.size() + " යි");
        }
    }

    @Override
    public void onDeleteStudent(Student student) {
        SafeDeleteHelper.showSafeDeleteDialog(this, student, () -> {
            StudentRepository.removeStudent(student);
            filterStudents(etSearchStudent != null ? etSearchStudent.getText().toString() : "");
            Toast.makeText(this, student.getName() + " මකා දමන ලදී.", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onStudentClick(Student student) {
        if (student == null) return;

        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.setBackgroundColor(0xFFFFFFFF);

        android.widget.LinearLayout container = new android.widget.LinearLayout(this);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        container.setPadding(32, 28, 32, 28);
        container.setBackgroundColor(0xFFFFFFFF);

        // Header Layout with Title & Top-Right Compact PDF Button
        android.widget.RelativeLayout headerLayout = new android.widget.RelativeLayout(this);
        headerLayout.setPadding(0, 0, 0, 12);

        TextView tvHeaderTitle = new TextView(this);
        tvHeaderTitle.setText("👤 ශිෂ්‍ය තොරතුරු පත්‍රිකාව");
        tvHeaderTitle.setTextSize(16);
        tvHeaderTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvHeaderTitle.setTextColor(0xFF111827);

        android.widget.RelativeLayout.LayoutParams lpTitle = new android.widget.RelativeLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        lpTitle.addRule(android.widget.RelativeLayout.ALIGN_PARENT_LEFT);
        lpTitle.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
        tvHeaderTitle.setLayoutParams(lpTitle);

        com.google.android.material.button.MaterialButton btnTopPdf = new com.google.android.material.button.MaterialButton(this);
        btnTopPdf.setText("📄 PDF");
        btnTopPdf.setTextSize(12);
        btnTopPdf.setTextColor(android.graphics.Color.WHITE);
        btnTopPdf.setBackgroundColor(0xFF4338CA);
        btnTopPdf.setCornerRadius(16);

        android.widget.RelativeLayout.LayoutParams lpTopPdf = new android.widget.RelativeLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        lpTopPdf.addRule(android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
        lpTopPdf.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
        btnTopPdf.setLayoutParams(lpTopPdf);

        btnTopPdf.setOnClickListener(v -> PdfReportExporter.exportFullProfilePdf(StudentListActivity.this, student));

        headerLayout.addView(tvHeaderTitle);
        headerLayout.addView(btnTopPdf);
        container.addView(headerLayout);

        // Divider Line
        android.view.View divider1 = new android.view.View(this);
        divider1.setBackgroundColor(0xFFE2E8F0);
        android.widget.LinearLayout.LayoutParams lpDiv1 = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, 2);
        lpDiv1.setMargins(0, 0, 0, 16);
        divider1.setLayoutParams(lpDiv1);
        container.addView(divider1);

        // Section 1: Basic Information
        TextView tvSec1 = new TextView(this);
        tvSec1.setText("📋 මූලික තොරතුරු (Basic Information)");
        tvSec1.setTextSize(13);
        tvSec1.setTypeface(null, android.graphics.Typeface.BOLD);
        tvSec1.setTextColor(0xFF2563EB);
        tvSec1.setPadding(0, 0, 0, 10);
        container.addView(tvSec1);

        addProfileRow(container, "ලියාපදිංචි අංකය (Admission No / Reg No)", student.getRollNo());
        addProfileRow(container, "මුලකුරු සමග නම (Name with Initials)", student.getNameWithInitials());
        addProfileRow(container, "සම්පූර්ණ නම (Full Name)", student.getName());
        addProfileRow(container, "ශ්‍රේණිය / පන්තිය (Grade / Class)", student.getGrade());
        addProfileRow(container, "ස්ත්‍රී / පුරුෂ භාවය (Gender)", student.getGender());
        addProfileRow(container, "උපන් දිනය (Date of Birth)", student.getDob());
        addProfileRow(container, "ලිපිනය (Address)", student.getPermAddress());

        // Section 2: Parent & Guardian Information
        TextView tvSec2 = new TextView(this);
        tvSec2.setText("\n👪 දෙමාපිය හා භාරකරු තොරතුරු (Parent Details)");
        tvSec2.setTextSize(13);
        tvSec2.setTypeface(null, android.graphics.Typeface.BOLD);
        tvSec2.setTextColor(0xFF2563EB);
        tvSec2.setPadding(0, 0, 0, 10);
        container.addView(tvSec2);

        String fatherInfo = (student.getFatherName() != null ? student.getFatherName() : "") +
                (student.getFatherPhone() != null && !student.getFatherPhone().isEmpty() ? " (" + student.getFatherPhone() + ")" : "");
        addProfileRow(container, "පියාගේ නම (Father)", fatherInfo);

        String motherInfo = (student.getMotherName() != null ? student.getMotherName() : "") +
                (student.getMotherPhone() != null && !student.getMotherPhone().isEmpty() ? " (" + student.getMotherPhone() + ")" : "");
        addProfileRow(container, "මවගේ නම (Mother)", motherInfo);

        addProfileRow(container, "භාරකරු (Guardian)", student.getGuardianName());
        addProfileRow(container, "හදිසි දුරකථන අංකය (Emergency Phone)", student.getEmergencyPhone());

        // Direct Dial Options
        java.util.List<String[]> callOptions = new java.util.ArrayList<>();
        if (student.getFatherPhone() != null && !student.getFatherPhone().trim().isEmpty()) {
            callOptions.add(new String[]{"📞 ඇමතුමක්: පියා (" + student.getFatherPhone() + ")", student.getFatherPhone()});
        }
        if (student.getMotherPhone() != null && !student.getMotherPhone().trim().isEmpty()) {
            callOptions.add(new String[]{"📞 ඇමතුමක්: මව (" + student.getMotherPhone() + ")", student.getMotherPhone()});
        }
        if (student.getEmergencyPhone() != null && !student.getEmergencyPhone().trim().isEmpty()) {
            callOptions.add(new String[]{"📞 ඇමතුමක්: හදිසි (" + student.getEmergencyPhone() + ")", student.getEmergencyPhone()});
        }

        if (!callOptions.isEmpty()) {
            TextView tvCallHeader = new TextView(this);
            tvCallHeader.setText("\n☎️ සෘජු ඇමතුම් (Tap Phone to Dial):");
            tvCallHeader.setTextSize(12);
            tvCallHeader.setTypeface(null, android.graphics.Typeface.BOLD);
            tvCallHeader.setTextColor(0xFF059669);
            container.addView(tvCallHeader);

            for (String[] opt : callOptions) {
                com.google.android.material.button.MaterialButton btnCall = new com.google.android.material.button.MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle);
                btnCall.setText(opt[0]);
                btnCall.setTextSize(12);
                btnCall.setTextColor(0xFF059669);
                btnCall.setOnClickListener(v -> {
                    try {
                        Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + opt[1].trim()));
                        startActivity(callIntent);
                    } catch (Exception e) {
                        Toast.makeText(StudentListActivity.this, "ඇමතුම ලබාගත නොහැකි විය: " + opt[1], Toast.LENGTH_SHORT).show();
                    }
                });
                container.addView(btnCall);
            }
        }

        // Bottom Compact PDF Action
        android.widget.RelativeLayout bottomBar = new android.widget.RelativeLayout(this);
        bottomBar.setPadding(0, 16, 0, 0);

        com.google.android.material.button.MaterialButton btnBtmPdf = new com.google.android.material.button.MaterialButton(this);
        btnBtmPdf.setText("📄 PDF ලබාගන්න");
        btnBtmPdf.setTextSize(12);
        btnBtmPdf.setTextColor(android.graphics.Color.WHITE);
        btnBtmPdf.setBackgroundColor(0xFF4338CA);
        btnBtmPdf.setCornerRadius(8);

        android.widget.RelativeLayout.LayoutParams lpBtmPdf = new android.widget.RelativeLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        lpBtmPdf.addRule(android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
        btnBtmPdf.setLayoutParams(lpBtmPdf);

        btnBtmPdf.setOnClickListener(v -> PdfReportExporter.exportFullProfilePdf(StudentListActivity.this, student));
        bottomBar.addView(btnBtmPdf);

        container.addView(bottomBar);

        scrollView.addView(container);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("ශිෂ්‍ය සම්පූර්ණ විස්තරය (Student Full Profile)")
                .setView(scrollView)
                .setPositiveButton("වසා දමන්න", null)
                .setNeutralButton("පැමිණීමේ වාර්තාව", (d, which) -> {
                    Intent intent = new Intent(StudentListActivity.this, StudentYearHistoryActivity.class);
                    intent.putExtra(StudentYearHistoryActivity.EXTRA_STUDENT_ID, student.getId());
                    startActivity(intent);
                })
                .create();

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE));
        }
    }

    private void addProfileRow(android.widget.LinearLayout parent, String label, String value) {
        if (value == null || value.trim().isEmpty()) {
            value = "-";
        }

        android.widget.LinearLayout row = new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.VERTICAL);
        row.setPadding(20, 10, 20, 10);
        row.setBackgroundColor(0xFFF8FAFC);

        TextView tvLabel = new TextView(this);
        tvLabel.setText(label);
        tvLabel.setTextSize(11);
        tvLabel.setTextColor(0xFF64748B);
        tvLabel.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvValue = new TextView(this);
        tvValue.setText(value);
        tvValue.setTextSize(13);
        tvValue.setTextColor(0xFF111827);
        tvValue.setPadding(0, 2, 0, 0);

        row.addView(tvLabel);
        row.addView(tvValue);

        android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, 8);
        row.setLayoutParams(lp);

        parent.addView(row);
    }
}
