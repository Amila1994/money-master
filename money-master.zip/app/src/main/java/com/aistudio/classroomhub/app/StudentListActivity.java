package com.aistudio.classroomhub.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class StudentListActivity extends AppCompatActivity implements StudentAdapter.OnStudentActionListener {

    private ImageView btnBack;
    private TextView tvStudentCount;
    private EditText etSearchStudent;
    private RecyclerView rvStudentList;

    private List<Student> filteredList;
    private StudentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);

        initViews();
        initData();
        setupRecyclerView();
        setupListeners();
    }

    @Override
    protected void onResume() {
        super.onResume();
        filterStudents(etSearchStudent != null ? etSearchStudent.getText().toString() : "");
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvStudentCount = findViewById(R.id.tvStudentCount);
        etSearchStudent = findViewById(R.id.etSearchStudent);
        rvStudentList = findViewById(R.id.rvStudentList);
    }

    private void initData() {
        filteredList = new ArrayList<>(StudentRepository.getStudents());
        updateStudentCount();
    }

    private void setupRecyclerView() {
        adapter = new StudentAdapter(filteredList, this);
        rvStudentList.setLayoutManager(new LinearLayoutManager(this));
        rvStudentList.setAdapter(adapter);
    }

    private void setupListeners() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        if (etSearchStudent != null) {
            etSearchStudent.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterStudents(s.toString());
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });
        }
    }

    private void filterStudents(String query) {
        filteredList.clear();
        List<Student> allStudents = StudentRepository.getStudents();
        if (query.trim().isEmpty()) {
            filteredList.addAll(allStudents);
        } else {
            String lowerQuery = query.toLowerCase().trim();
            for (Student student : allStudents) {
                String fullName = student.getName() != null ? student.getName().toLowerCase() : "";
                String initials = student.getNameWithInitials() != null ? student.getNameWithInitials().toLowerCase() : "";
                String regNo = student.getRollNo() != null ? student.getRollNo().toLowerCase() : "";

                if (fullName.contains(lowerQuery) || initials.contains(lowerQuery) || regNo.contains(lowerQuery)) {
                    filteredList.add(student);
                }
            }
        }
        if (adapter != null) {
            adapter.updateList(filteredList);
        }
        updateStudentCount();
    }

    private void updateStudentCount() {
        if (tvStudentCount != null) {
            tvStudentCount.setText("ශිෂ්‍යයන්: " + filteredList.size() + " යි");
        }
    }

    @Override
    public void onDeleteStudent(Student student) {
        StudentRepository.removeStudent(student);
        filterStudents(etSearchStudent != null ? etSearchStudent.getText().toString() : "");
        Toast.makeText(this, student.getName() + " ලැයිස්තුවෙන් ඉවත් කරන ලදී.", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStudentClick(Student student) {
        StringBuilder details = new StringBuilder();
        details.append("ලියාපදිංචි අංකය (Reg No): ").append(student.getRollNo() != null && !student.getRollNo().isEmpty() ? student.getRollNo() : "-").append("\n\n");
        details.append("මුලකුරු සමග නම: ").append(student.getNameWithInitials() != null && !student.getNameWithInitials().isEmpty() ? student.getNameWithInitials() : "-").append("\n\n");
        details.append("සම්පූර්ණ නම: ").append(student.getName() != null && !student.getName().isEmpty() ? student.getName() : "-").append("\n\n");
        
        if (student.getDob() != null && !student.getDob().isEmpty()) {
            details.append("උපන් දිනය: ").append(student.getDob()).append("\n\n");
        }
        if (student.getGender() != null && !student.getGender().isEmpty()) {
            details.append("ස්ත්‍රී/පුරුෂ භාවය: ").append(student.getGender()).append("\n\n");
        }
        if (student.getGrade() != null && !student.getGrade().isEmpty()) {
            details.append("ශ්‍රේණිය: ").append(student.getGrade()).append("\n\n");
        }
        if (student.getPermAddress() != null && !student.getPermAddress().isEmpty()) {
            details.append("ලිපිනය: ").append(student.getPermAddress()).append("\n\n");
        }
        if (student.getFatherName() != null && !student.getFatherName().isEmpty()) {
            details.append("පියාගේ නම: ").append(student.getFatherName());
            if (student.getFatherPhone() != null && !student.getFatherPhone().isEmpty()) {
                details.append(" (").append(student.getFatherPhone()).append(")");
            }
            details.append("\n\n");
        }
        if (student.getMotherName() != null && !student.getMotherName().isEmpty()) {
            details.append("මවගේ නම: ").append(student.getMotherName());
            if (student.getMotherPhone() != null && !student.getMotherPhone().isEmpty()) {
                details.append(" (").append(student.getMotherPhone()).append(")");
            }
            details.append("\n\n");
        }
        if (student.getGuardianName() != null && !student.getGuardianName().isEmpty()) {
            details.append("භාරකරු: ").append(student.getGuardianName()).append("\n\n");
        }
        if (student.getEmergencyPhone() != null && !student.getEmergencyPhone().isEmpty()) {
            details.append("හදිසි දුරකථන: ").append(student.getEmergencyPhone()).append("\n\n");
        }

        new AlertDialog.Builder(this)
                .setTitle("ශිෂ්‍ය සම්පූර්ණ විස්තරය")
                .setMessage(details.toString().trim())
                .setPositiveButton("වසා දමන්න", null)
                .setNeutralButton("පැමිණීමේ වාර්තාව", (dialog, which) -> {
                    Intent intent = new Intent(StudentListActivity.this, StudentYearHistoryActivity.class);
                    intent.putExtra(StudentYearHistoryActivity.EXTRA_STUDENT_ID, student.getId());
                    startActivity(intent);
                })
                .show();
    }
}
