package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // App එක open වෙද්දීම Internet තිබේදැයි පරීක්ෂා කිරීම
        checkNetworkAndProceed();
    }

    private void checkNetworkAndProceed() {
        if (!NetworkUtils.isInternetAvailable(this)) {
            // Internet නැත්නම් Dialog එකක් පෙන්නා App එක ඉදිරියට යාම තහනම් කිරීම
            showNoInternetDialog();
        } else {
            // Internet තිබේ නම් පමණක් Session Check කර Dashboard එකට හෝ Login එකට යවන්න
            proceedToNextActivity();
        }
    }

    private void showNoInternetDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Internet Connection Required")
                .setMessage("Please check your internet connection to access the app.")
                .setCancelable(false) // Dialog එක පිටත touch කර close කිරීම වැළැක්වීමට
                .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // නැවත Internet තිබේදැයි පරීක්ෂා කිරීම
                        checkNetworkAndProceed();
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish(); // App එක ක්ලෝස් කිරීම
                    }
                })
                .show();
    }

    private void proceedToNextActivity() {
        final SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        final boolean isLoggedIn = prefs.getBoolean(LoginActivity.KEY_IS_LOGGED_IN, false);

        FirebaseUser currentUser = null;
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this);
            }
            currentUser = FirebaseAuth.getInstance().getCurrentUser();
        } catch (Exception ignored) {
        }

        if (currentUser != null) {
            // Current user ව Server එකෙන් Refresh කර බලයි (Disabled ද නැද්ද කියා)
            currentUser.reload().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        // Account එක Active -> Dashboard (MainActivity) එකට යන්න
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                        finish();
                    } else {
                        // Account එක Disable කර ඇත හෝ සෙසු දෝෂයක් -> Sign Out කර Login Screen එකට යවන්න
                        prefs.edit().clear().apply();
                        try {
                            FirebaseAuth.getInstance().signOut();
                        } catch (Exception ignored) {
                        }
                        Toast.makeText(SplashActivity.this, "Your account is disabled!", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                        finish();
                    }
                }
            });
        } else if (isLoggedIn) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }
}
