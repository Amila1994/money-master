package com.aistudio.classroomhub.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

object PendingTasksManager {
    private const val PREF_NAME = "pending_tasks_pref"
    private const val KEY_TASKS = "tasks_json"

    private val defaultTasks = listOf(
        "📝 1 වන වාර විභාග ලකුණු ඇතුළත් කිරීම",
        "📢 මව්පිය - ගුරු හමුව සංවිධානය කිරීම",
        "📋 සතිපතා පැමිණීමේ ලේඛනය අත්සන් කර තහවුරු කිරීම",
        "📚 ඊළඟ පාසල් දිනයේ 1 වන කාලච්ඡේදය සඳහා පාඩම් සූදානම් කිරීම"
    )

    fun getPendingTasks(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_TASKS, null) ?: return defaultTasks
        return try {
            val jsonArray = JSONArray(jsonStr)
            val list = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) {
                list.add(jsonArray.getString(i))
            }
            if (list.isEmpty()) defaultTasks else list
        } catch (e: Exception) {
            defaultTasks
        }
    }

    fun addPendingTask(context: Context, taskText: String): List<String> {
        val current = getPendingTasks(context).toMutableList()
        if (taskText.trim().isNotEmpty()) {
            current.add(0, taskText.trim())
            saveTasks(context, current)
        }
        return current
    }

    fun removePendingTask(context: Context, index: Int): List<String> {
        val current = getPendingTasks(context).toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            saveTasks(context, current)
        }
        return current
    }

    private fun saveTasks(context: Context, tasks: List<String>) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonArray = JSONArray()
        for (t in tasks) {
            jsonArray.put(t)
        }
        prefs.edit().putString(KEY_TASKS, jsonArray.toString()).apply()
    }
}
