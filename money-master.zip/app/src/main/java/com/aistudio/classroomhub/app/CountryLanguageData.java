package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CountryLanguageData {

    public static class LanguageItem {
        public String name;
        public String code;

        public LanguageItem(String name, String code) {
            this.name = name;
            this.code = code;
        }

        @Override
        public String toString() {
            return name + " (" + code + ")";
        }
    }

    private static final Map<String, List<LanguageItem>> countryLanguagesMap = new HashMap<>();
    private static final List<LanguageItem> allGlobalLanguages = new ArrayList<>();
    private static final List<String> allCountries = new ArrayList<>();

    static {
        // Define Language Items
        LanguageItem sinhala = new LanguageItem("සිංහල (Sinhala)", "si");
        LanguageItem tamil = new LanguageItem("தமிழ் (Tamil)", "ta");
        LanguageItem english = new LanguageItem("English", "en");
        LanguageItem hindi = new LanguageItem("हिन्दी (Hindi)", "hi");
        LanguageItem bengali = new LanguageItem("বাংলা (Bengali)", "bn");
        LanguageItem spanish = new LanguageItem("Español (Spanish)", "es");
        LanguageItem french = new LanguageItem("Français (French)", "fr");
        LanguageItem german = new LanguageItem("Deutsch (German)", "de");
        LanguageItem japanese = new LanguageItem("日本語 (Japanese)", "ja");
        LanguageItem chinese = new LanguageItem("中文 (Chinese)", "zh");
        LanguageItem arabic = new LanguageItem("العربية (Arabic)", "ar");
        LanguageItem portuguese = new LanguageItem("Português (Portuguese)", "pt");
        LanguageItem russian = new LanguageItem("Русский (Russian)", "ru");
        LanguageItem korean = new LanguageItem("한국어 (Korean)", "ko");
        LanguageItem italian = new LanguageItem("Italiano (Italian)", "it");

        // All Global Languages List
        allGlobalLanguages.add(sinhala);
        allGlobalLanguages.add(tamil);
        allGlobalLanguages.add(english);
        allGlobalLanguages.add(hindi);
        allGlobalLanguages.add(bengali);
        allGlobalLanguages.add(spanish);
        allGlobalLanguages.add(french);
        allGlobalLanguages.add(german);
        allGlobalLanguages.add(japanese);
        allGlobalLanguages.add(chinese);
        allGlobalLanguages.add(arabic);
        allGlobalLanguages.add(portuguese);
        allGlobalLanguages.add(russian);
        allGlobalLanguages.add(korean);
        allGlobalLanguages.add(italian);

        // Mapped Countries & Official/Spoken Languages
        countryLanguagesMap.put("Sri Lanka 🇱🇰", Arrays.asList(sinhala, tamil, english));
        countryLanguagesMap.put("India 🇮🇳", Arrays.asList(hindi, english, tamil, bengali));
        countryLanguagesMap.put("United States 🇺🇸", Arrays.asList(english, spanish));
        countryLanguagesMap.put("United Kingdom 🇬🇧", Arrays.asList(english));
        countryLanguagesMap.put("Australia 🇦🇺", Arrays.asList(english));
        countryLanguagesMap.put("Canada 🇨🇦", Arrays.asList(english, french));
        countryLanguagesMap.put("Japan 🇯🇵", Arrays.asList(japanese, english));
        countryLanguagesMap.put("China 🇨🇳", Arrays.asList(chinese, english));
        countryLanguagesMap.put("Germany 🇩🇪", Arrays.asList(german, english));
        countryLanguagesMap.put("France 🇫🇷", Arrays.asList(french, english));
        countryLanguagesMap.put("Brazil 🇧🇷", Arrays.asList(portuguese, english));
        countryLanguagesMap.put("Russia 🇷🇺", Arrays.asList(russian, english));
        countryLanguagesMap.put("South Korea 🇰🇷", Arrays.asList(korean, english));
        countryLanguagesMap.put("Italy 🇮🇹", Arrays.asList(italian, english));
        countryLanguagesMap.put("Spain 🇪🇸", Arrays.asList(spanish, english));
        countryLanguagesMap.put("United Arab Emirates 🇦🇪", Arrays.asList(arabic, english));
        countryLanguagesMap.put("Saudi Arabia 🇸🇦", Arrays.asList(arabic, english));
        countryLanguagesMap.put("Singapore 🇸🇬", Arrays.asList(english, tamil, chinese, sinhala));
        countryLanguagesMap.put("Malaysia 🇲🇾", Arrays.asList(english, tamil, chinese));

        allCountries.addAll(countryLanguagesMap.keySet());
        java.util.Collections.sort(allCountries);
    }

    public static List<String> getAllCountries() {
        return allCountries;
    }

    public static List<LanguageItem> getLanguagesForCountry(String country) {
        if (countryLanguagesMap.containsKey(country)) {
            return countryLanguagesMap.get(country);
        }
        return allGlobalLanguages;
    }

    public static List<LanguageItem> getAllGlobalLanguages() {
        return allGlobalLanguages;
    }
}
