package com.aistudio.classroomhub.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AttendanceActivity extends AppCompatActivity {

    private ImageView btnBack, btnCalendar, btnTeacherAttendance;
    private Button tabMarking, tabReport;
    private ScrollView containerMarkingView;
    private View containerReportView;

    private TextView tvDateDisplay, tvOverallPercent;
    private TextView tvSummaryTotalCount, tvSummaryTotalSub;
    private TextView tvSummaryPresentCount, tvSummaryPresentSub;
    private TextView tvSummaryMaleCount, tvSummaryMaleSub;
    private TextView tvSummaryFemaleCount, tvSummaryFemaleSub;

    private TextView tvHeaderMaleSection, tvHeaderFemaleSection;
    private RecyclerView rvMaleStudents, rvFemaleStudents;

    private MaterialCardView cardFilterRange;
    private TextView tvFilterRangeText;
    private RecyclerView rvAttendanceReports;

    private Calendar selectedCalendar = Calendar.getInstance();
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    private List<Student> maleStudentsList = new ArrayList<>();
    private List<Student> femaleStudentsList = new ArrayList<>();

    private AttendanceAdapter maleAdapter;
    private AttendanceAdapter femaleAdapter;
    private ReportAdapter reportAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_attendance);

        initViews();
        setupListeners();
        loadStudentData();
        updateDateView();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        btnCalendar = findViewById(R.id.btnCalendar);
        btnTeacherAttendance = findViewById(R.id.btnTeacherAttendance);

        tabMarking = findViewById(R.id.tabMarking);
        tabReport = findViewById(R.id.tabReport);

        containerMarkingView = findViewById(R.id.containerMarkingView);
        containerReportView = findViewById(R.id.containerReportView);

        tvDateDisplay = findViewById(R.id.tvDateDisplay);
        tvOverallPercent = findViewById(R.id.tvOverallPercent);

        tvSummaryTotalCount = findViewById(R.id.tvSummaryTotalCount);
        tvSummaryTotalSub = findViewById(R.id.tvSummaryTotalSub);
        tvSummaryPresentCount = findViewById(R.id.tvSummaryPresentCount);
        tvSummaryPresentSub = findViewById(R.id.tvSummaryPresentSub);
        tvSummaryMaleCount = findViewById(R.id.tvSummaryMaleCount);
        tvSummaryMaleSub = findViewById(R.id.tvSummaryMaleSub);
        tvSummaryFemaleCount = findViewById(R.id.tvSummaryFemaleCount);
        tvSummaryFemaleSub = findViewById(R.id.tvSummaryFemaleSub);

        tvHeaderMaleSection = findViewById(R.id.tvHeaderMaleSection);
        tvHeaderFemaleSection = findViewById(R.id.tvHeaderFemaleSection);

        rvMaleStudents = findViewById(R.id.rvMaleStudents);
        rvFemaleStudents = findViewById(R.id.rvFemaleStudents);

        cardFilterRange = findViewById(R.id.cardFilterRange);
        tvFilterRangeText = findViewById(R.id.tvFilterRangeText);
        rvAttendanceReports = findViewById(R.id.rvAttendanceReports);

        rvMaleStudents.setLayoutManager(new LinearLayoutManager(this));
        rvFemaleStudents.setLayoutManager(new LinearLayoutManager(this));
        rvAttendanceReports.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setupListeners() {
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());

        if (btnCalendar != null) {
            btnCalendar.setOnClickListener(v -> openDatePicker());
        }

        if (btnTeacherAttendance != null) {
            btnTeacherAttendance.setOnClickListener(v -> {
                TeacherAttendanceModalKt.showTeacherAttendanceDialog(AttendanceActivity.this, null);
            });
        }

        if (tabMarking != null) {
            tabMarking.setOnClickListener(v -> switchTab(true));
        }

        if (tabReport != null) {
            tabReport.setOnClickListener(v -> switchTab(false));
        }

        if (cardFilterRange != null) {
            cardFilterRange.setOnClickListener(v -> {
                Toast.makeText(this, "කාල සීමාව: සියලුම සටහන් පෙන්වයි", Toast.LENGTH_SHORT).show();
            });
        }

        View btnDownloadAttendancePdf = findViewById(R.id.btnDownloadAttendancePdf);
        if (btnDownloadAttendancePdf != null) {
            btnDownloadAttendancePdf.setOnClickListener(v -> {
                String dateStr = dateFormat.format(selectedCalendar.getTime());
                PdfReportExporter.exportAttendancePdf(AttendanceActivity.this, dateStr);
            });
        }
    }

    private void switchTab(boolean isMarking) {
        if (isMarking) {
            containerMarkingView.setVisibility(View.VISIBLE);
            containerReportView.setVisibility(View.GONE);

            tabMarking.setBackgroundTintList(getColorStateList(android.R.color.holo_blue_dark));
            tabMarking.setTextColor(Color.WHITE);

            tabReport.setBackgroundTintList(getColorStateList(android.R.color.transparent));
            tabReport.setTextColor(Color.parseColor("#94A3B8"));
        } else {
            containerMarkingView.setVisibility(View.GONE);
            containerReportView.setVisibility(View.VISIBLE);

            tabMarking.setBackgroundTintList(getColorStateList(android.R.color.transparent));
            tabMarking.setTextColor(Color.parseColor("#94A3B8"));

            tabReport.setBackgroundTintList(getColorStateList(android.R.color.holo_blue_dark));
            tabReport.setTextColor(Color.WHITE);

            refreshReportView();
        }
    }

    private void openDatePicker() {
        DatePickerDialog dialog = new DatePickerDialog(this,
                (view, year, month, dayOfMonth) -> {
                    selectedCalendar.set(Calendar.YEAR, year);
                    selectedCalendar.set(Calendar.MONTH, month);
                    selectedCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDateView();
                },
                selectedCalendar.get(Calendar.YEAR),
                selectedCalendar.get(Calendar.MONTH),
                selectedCalendar.get(Calendar.DAY_OF_MONTH));
        dialog.show();
    }

    private void loadStudentData() {
        maleStudentsList.clear();
        femaleStudentsList.clear();

        List<Student> all = StudentRepository.getStudents();
        for (Student s : all) {
            if ("ගැහැණු".equals(s.getGender())) {
                femaleStudentsList.add(s);
            } else {
                maleStudentsList.add(s);
            }
        }

        tvHeaderMaleSection.setText("පිරිමි ළමුන් (" + maleStudentsList.size() + ")");
        tvHeaderFemaleSection.setText("ගැහැණු ළමුන් (" + femaleStudentsList.size() + ")");

        maleAdapter = new AttendanceAdapter(maleStudentsList);
        femaleAdapter = new AttendanceAdapter(femaleStudentsList);

        rvMaleStudents.setAdapter(maleAdapter);
        rvFemaleStudents.setAdapter(femaleAdapter);
    }

    private boolean isSelectedDateToday() {
        Calendar today = Calendar.getInstance();
        return selectedCalendar.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                selectedCalendar.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR);
    }

    private void updateDateView() {
        String dateStr = dateFormat.format(selectedCalendar.getTime());
        boolean isToday = isSelectedDateToday();
        tvDateDisplay.setText("දිනය: " + dateStr + (isToday ? " (අද දින)" : " (පෙර දින)"));

        refreshAttendanceUI();
    }

    private void refreshAttendanceUI() {
        String dateStr = dateFormat.format(selectedCalendar.getTime());
        Map<String, AttendanceRecord> records = StudentRepository.getAttendanceForDate(dateStr);

        int totalStudents = StudentRepository.getStudents().size();
        int maleTotal = maleStudentsList.size();
        int femaleTotal = femaleStudentsList.size();

        int malePresent = 0, maleAbsent = 0;
        for (Student s : maleStudentsList) {
            AttendanceRecord rec = records.get(s.getId());
            if (rec != null) {
                if (rec.isPresent()) malePresent++;
                else maleAbsent++;
            }
        }

        int femalePresent = 0, femaleAbsent = 0;
        for (Student s : femaleStudentsList) {
            AttendanceRecord rec = records.get(s.getId());
            if (rec != null) {
                if (rec.isPresent()) femalePresent++;
                else femaleAbsent++;
            }
        }

        int totalPresent = malePresent + femalePresent;
        double overallPercent = totalStudents > 0 ? ((double) totalPresent / totalStudents) * 100 : 0.0;

        tvOverallPercent.setText(String.format(Locale.US, "පැමිණීමේ %%: %.1f%%", overallPercent));
        tvSummaryTotalCount.setText(String.valueOf(totalStudents));
        tvSummaryTotalSub.setText("පිරිමි: " + maleTotal + " | ගැහැණු: " + femaleTotal);

        tvSummaryPresentCount.setText(String.valueOf(totalPresent));
        tvSummaryPresentSub.setText(String.format(Locale.US, "ප්‍රතිශතය: %.0f%%", overallPercent));

        tvSummaryMaleCount.setText(malePresent + " පැමිණි");
        tvSummaryMaleSub.setText(maleAbsent + " නොපැමිණි");

        tvSummaryFemaleCount.setText(femalePresent + " පැමිණි");
        tvSummaryFemaleSub.setText(femaleAbsent + " නොපැමිණි");

        if (maleAdapter != null) maleAdapter.notifyDataSetChanged();
        if (femaleAdapter != null) femaleAdapter.notifyDataSetChanged();
    }

    private void refreshReportView() {
        List<Student> allStudents = StudentRepository.getStudents();
        reportAdapter = new ReportAdapter(allStudents);
        rvAttendanceReports.setAdapter(reportAdapter);
    }

    // --- ATTENDANCE ADAPTER ---
    private class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.ViewHolder> {
        private List<Student> list;

        public AttendanceAdapter(List<Student> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_attendance_marking, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Student s = list.get(position);
            holder.tvName.setText(s.getName());

            String sub = (s.getNameWithInitials() != null && !s.getNameWithInitials().isEmpty()) ? s.getNameWithInitials() : s.getName();
            String reg = s.getRollNo() != null ? s.getRollNo() : "";
            holder.tvSub.setText(sub + " (" + reg + ")");

            String dateStr = dateFormat.format(selectedCalendar.getTime());
            Map<String, AttendanceRecord> records = StudentRepository.getAttendanceForDate(dateStr);
            AttendanceRecord record = records.get(s.getId());

            boolean isToday = isSelectedDateToday();
            boolean isMarked = record != null;
            boolean isPresent = record != null && record.isPresent();

            // 1-Hour Lock Logic
            boolean isEditAllowed = true;
            if (!isToday) {
                isEditAllowed = false; // Past dates locked
            } else if (isMarked) {
                long diffMinutes = (System.currentTimeMillis() - record.getMarkedAtMillis()) / (1000 * 60);
                if (diffMinutes >= 60) {
                    isEditAllowed = false; // Locked after 1 hour
                }
            }

            if (!isEditAllowed && isMarked) {
                // Show Locked Badge
                holder.layoutActions.setVisibility(View.GONE);
                holder.tvLockedBadge.setVisibility(View.VISIBLE);
                holder.tvLockedBadge.setText(isPresent ? "Present (Locked)" : "Absent (Locked)");
                holder.tvLockedBadge.setTextColor(Color.parseColor(isPresent ? "#38BDF8" : "#F87171"));
            } else {
                // Interactive Buttons
                holder.layoutActions.setVisibility(View.VISIBLE);
                holder.tvLockedBadge.setVisibility(View.GONE);

                if (isMarked) {
                    if (isPresent) {
                        holder.btnPresent.setBackgroundColor(Color.parseColor("#2563EB"));
                        holder.btnPresent.setTextColor(Color.WHITE);

                        holder.btnAbsent.setBackgroundColor(Color.parseColor("#0F172A"));
                        holder.btnAbsent.setTextColor(Color.parseColor("#EF4444"));
                    } else {
                        holder.btnPresent.setBackgroundColor(Color.parseColor("#0F172A"));
                        holder.btnPresent.setTextColor(Color.parseColor("#3B82F6"));

                        holder.btnAbsent.setBackgroundColor(Color.parseColor("#DC2626"));
                        holder.btnAbsent.setTextColor(Color.WHITE);
                    }
                } else {
                    holder.btnPresent.setBackgroundColor(Color.parseColor("#0F172A"));
                    holder.btnPresent.setTextColor(Color.parseColor("#3B82F6"));

                    holder.btnAbsent.setBackgroundColor(Color.parseColor("#0F172A"));
                    holder.btnAbsent.setTextColor(Color.parseColor("#EF4444"));
                }

                holder.btnPresent.setOnClickListener(v -> {
                    StudentRepository.setAttendance(dateStr, s.getId(), true);
                    refreshAttendanceUI();
                });

                holder.btnAbsent.setOnClickListener(v -> {
                    StudentRepository.setAttendance(dateStr, s.getId(), false);
                    refreshAttendanceUI();
                });
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvSub;
            View layoutActions;
            Button btnPresent, btnAbsent;
            TextView tvLockedBadge;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvStudentFullName);
                tvSub = itemView.findViewById(R.id.tvStudentSubDetail);
                layoutActions = itemView.findViewById(R.id.layoutActions);
                btnPresent = itemView.findViewById(R.id.btnPresent);
                btnAbsent = itemView.findViewById(R.id.btnAbsent);
                tvLockedBadge = itemView.findViewById(R.id.tvLockedBadge);
            }
        }
    }

    // --- REPORT ADAPTER ---
    private class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {
        private List<Student> list;

        public ReportAdapter(List<Student> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_attendance_report, parent, false);
            return new ReportViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
            Student s = list.get(position);
            holder.tvName.setText(s.getName());

            String reg = s.getRollNo() != null ? s.getRollNo() : "REG-0";
            String gender = s.getGender() != null ? s.getGender() : "පිරිමි";
            holder.tvSub.setText(reg + " | " + gender);

            Map<String, Map<String, AttendanceRecord>> allRecords = StudentRepository.getAttendanceRecords();
            int evaluatedDays = 0;
            int presentDays = 0;

            for (Map<String, AttendanceRecord> dayRecords : allRecords.values()) {
                if (dayRecords.containsKey(s.getId())) {
                    evaluatedDays++;
                    AttendanceRecord rec = dayRecords.get(s.getId());
                    if (rec != null && rec.isPresent()) {
                        presentDays++;
                    }
                }
            }

            double percent = evaluatedDays > 0 ? ((double) presentDays / evaluatedDays) * 100 : 0.0;
            holder.tvPercent.setText(String.format(Locale.US, "%.1f%%", percent));
            holder.pbAttendance.setProgress((int) percent);

            if (percent >= 75.0) {
                holder.tvPercent.setTextColor(Color.parseColor("#4ADE80"));
            } else {
                holder.tvPercent.setTextColor(Color.parseColor("#FB923C"));
            }

            holder.tvDaysSummary.setText("දින " + evaluatedDays + " න් " + presentDays + " ක් පැමිණ ඇත");

            // Clicking on a student opens their full year report
            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(AttendanceActivity.this, StudentYearHistoryActivity.class);
                intent.putExtra(StudentYearHistoryActivity.EXTRA_STUDENT_ID, s.getId());
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ReportViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvSub, tvPercent, tvDaysSummary;
            ProgressBar pbAttendance;

            public ReportViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tvReportStudentName);
                tvSub = itemView.findViewById(R.id.tvReportSubDetail);
                tvPercent = itemView.findViewById(R.id.tvAttendancePercent);
                tvDaysSummary = itemView.findViewById(R.id.tvAttendanceDaysSummary);
                pbAttendance = itemView.findViewById(R.id.pbAttendance);
            }
        }
    }
}
