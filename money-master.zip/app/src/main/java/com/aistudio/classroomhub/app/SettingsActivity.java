package com.aistudio.classroomhub.app;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsActivity extends AppCompatActivity {

    private Spinner spCountry;
    private Spinner spLanguage;
    private CheckBox cbShowAllLanguages;
    private MaterialButton btnApplyLanguage;

    private TextView tvHeaderTitle;
    private TextView tvCountryLangTitle;
    private TextView tvCountrySelectDesc;
    private TextView tvCountryLabel;
    private TextView tvLanguageLabel;
    private TextView tvAccountTitle;

    private TextView tvUserName;
    private TextView tvUserEmail;
    private TextView tvUserUid;
    private MaterialButton btnCopyUid;
    private MaterialButton btnSwitchAccount;

    private TextView tvPinTitle;
    private TextView tvEnablePinDesc;
    private SwitchMaterial swEnablePin;
    private MaterialButton btnSetupPin;
    private MaterialButton btnHandoverClass;
    private MaterialButton btnImportClass;
    private ImageView btnBack;

    private EditText etSchoolName;
    private EditText etSchoolAddress;
    private ImageView ivSchoolLogoPreview;
    private MaterialButton btnSelectLogo;
    private MaterialButton btnSaveSchoolDetails;
    private ActivityResultLauncher<Intent> logoPickerLauncher;

    private EditText etAMin, etBMin, etCMin, etSMin;
    private MaterialButton btnSaveGradeSettings;

    private RadioGroup rgTimeFormat;
    private RadioButton rb24Hour, rb12Hour;
    private MaterialButton btnSaveTimeFormat;

    private AppLoadingView loaderPreview;
    private Spinner spLoaderStyle;
    private TextView tvSelectedLoaderName;
    private MaterialButton btnSaveLoaderStyle;

    private List<CountryLanguageData.LanguageItem> currentLanguageList = new ArrayList<>();
    private ArrayAdapter<CountryLanguageData.LanguageItem> languageAdapter;

    private boolean isInitialCountryLoad = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Apply locale
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_settings);

        initLogoPickerLauncher();
        initViews();
        translateSettingsUI();
        setupAccordionCards();
        setupCountryAndLanguagePickers();
        setupUserAccount();
        setupPinSecurity();
        setupClassHandover();
        setupSchoolDetailsHeader();
        setupGradeBoundaries();
        setupTimeFormatSettings();
        setupLoaderStyleSettings();
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppSecurityManager.applyAppLocale(this);
        translateSettingsUI();
    }

    private void initLogoPickerLauncher() {
        logoPickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                        Uri selectedUri = result.getData().getData();
                        saveLogoImageLocally(selectedUri);
                    }
                }
        );
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle);
        tvCountryLangTitle = findViewById(R.id.tvCard1Header);
        tvCountrySelectDesc = findViewById(R.id.tvCountrySelectDesc);
        tvCountryLabel = findViewById(R.id.tvCountryLabel);
        tvLanguageLabel = findViewById(R.id.tvLanguageLabel);

        spCountry = findViewById(R.id.spCountry);
        spLanguage = findViewById(R.id.spLanguage);
        cbShowAllLanguages = findViewById(R.id.cbShowAllLanguages);
        btnApplyLanguage = findViewById(R.id.btnApplyLanguage);

        tvAccountTitle = findViewById(R.id.tvCard2Header);
        tvUserName = findViewById(R.id.tvUserName);
        tvUserEmail = findViewById(R.id.tvUserEmail);
        tvUserUid = findViewById(R.id.tvUserUid);
        btnCopyUid = findViewById(R.id.btnCopyUid);
        btnSwitchAccount = findViewById(R.id.btnSwitchAccount);

        tvPinTitle = findViewById(R.id.tvCard3Header);
        tvEnablePinDesc = findViewById(R.id.tvEnablePinDesc);
        swEnablePin = findViewById(R.id.swEnablePin);
        btnSetupPin = findViewById(R.id.btnSetupPin);

        btnHandoverClass = findViewById(R.id.btnHandoverClass);
        btnImportClass = findViewById(R.id.btnImportClass);

        etSchoolName = findViewById(R.id.etSchoolName);
        etSchoolAddress = findViewById(R.id.etSchoolAddress);
        ivSchoolLogoPreview = findViewById(R.id.ivSchoolLogoPreview);
        btnSelectLogo = findViewById(R.id.btnSelectLogo);
        btnSaveSchoolDetails = findViewById(R.id.btnSaveSchoolDetails);

        etAMin = findViewById(R.id.etAMin);
        etBMin = findViewById(R.id.etBMin);
        etCMin = findViewById(R.id.etCMin);
        etSMin = findViewById(R.id.etSMin);
        btnSaveGradeSettings = findViewById(R.id.btnSaveGradeSettings);

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
    }

    private void translateSettingsUI() {
        if (tvHeaderTitle != null) tvHeaderTitle.setText(AppTranslation.get(this, "settings_title"));
        if (tvCountryLangTitle != null) tvCountryLangTitle.setText("🌐 " + AppTranslation.get(this, "card_lang_country"));
        if (tvCountrySelectDesc != null) tvCountrySelectDesc.setText(AppTranslation.get(this, "select_country_desc"));
        if (tvCountryLabel != null) tvCountryLabel.setText(AppTranslation.get(this, "country"));
        if (tvLanguageLabel != null) tvLanguageLabel.setText(AppTranslation.get(this, "language"));
        if (cbShowAllLanguages != null) cbShowAllLanguages.setText(AppTranslation.get(this, "show_all_languages"));
        if (btnApplyLanguage != null) btnApplyLanguage.setText(AppTranslation.get(this, "save_country_language"));

        if (tvAccountTitle != null) tvAccountTitle.setText("👤 " + AppTranslation.get(this, "card_google_account"));
        if (btnSwitchAccount != null) btnSwitchAccount.setText(AppTranslation.get(this, "switch_account"));

        if (tvPinTitle != null) tvPinTitle.setText("🔒 " + AppTranslation.get(this, "card_pin_security"));
        if (tvEnablePinDesc != null) tvEnablePinDesc.setText(AppTranslation.get(this, "enable_pin_desc"));
        if (btnSetupPin != null) btnSetupPin.setText(AppTranslation.get(this, "setup_pin"));

        TextView tvCard4Header = findViewById(R.id.tvCard4Header);
        if (tvCard4Header != null) tvCard4Header.setText("🔄 " + AppTranslation.get(this, "card_class_handover"));
        TextView tvHandoverDesc = findViewById(R.id.tvHandoverDesc);
        if (tvHandoverDesc != null) tvHandoverDesc.setText(AppTranslation.get(this, "handover_desc"));
        if (btnHandoverClass != null) btnHandoverClass.setText(AppTranslation.get(this, "handover_class_btn"));
        if (btnImportClass != null) btnImportClass.setText(AppTranslation.get(this, "import_class_btn"));

        TextView tvCard5Header = findViewById(R.id.tvCard5Header);
        if (tvCard5Header != null) tvCard5Header.setText("🏫 " + AppTranslation.get(this, "card_school_details"));
        TextView tvSchoolDetailsDesc = findViewById(R.id.tvSchoolDetailsDesc);
        if (tvSchoolDetailsDesc != null) tvSchoolDetailsDesc.setText(AppTranslation.get(this, "school_details_desc"));
        TextView tvSchoolNameLabel = findViewById(R.id.tvSchoolNameLabel);
        if (tvSchoolNameLabel != null) tvSchoolNameLabel.setText(AppTranslation.get(this, "school_name_label"));
        TextView tvSchoolAddressLabel = findViewById(R.id.tvSchoolAddressLabel);
        if (tvSchoolAddressLabel != null) tvSchoolAddressLabel.setText(AppTranslation.get(this, "school_address_label"));
        TextView tvSchoolLogoLabel = findViewById(R.id.tvSchoolLogoLabel);
        if (tvSchoolLogoLabel != null) tvSchoolLogoLabel.setText(AppTranslation.get(this, "school_logo_label"));
        if (btnSelectLogo != null) btnSelectLogo.setText(AppTranslation.get(this, "select_logo"));
        if (btnSaveSchoolDetails != null) btnSaveSchoolDetails.setText(AppTranslation.get(this, "save_school_details"));

        TextView tvCard6Header = findViewById(R.id.tvCard6Header);
        if (tvCard6Header != null) tvCard6Header.setText("🎯 " + AppTranslation.get(this, "card_grade_cutoffs"));
        TextView tvGradeDesc = findViewById(R.id.tvGradeDesc);
        if (tvGradeDesc != null) tvGradeDesc.setText(AppTranslation.get(this, "grade_cutoffs_desc"));
        TextView tvGradeALabel = findViewById(R.id.tvGradeALabel);
        if (tvGradeALabel != null) tvGradeALabel.setText(AppTranslation.get(this, "grade_a_min"));
        TextView tvGradeBLabel = findViewById(R.id.tvGradeBLabel);
        if (tvGradeBLabel != null) tvGradeBLabel.setText(AppTranslation.get(this, "grade_b_min"));
        TextView tvGradeCLabel = findViewById(R.id.tvGradeCLabel);
        if (tvGradeCLabel != null) tvGradeCLabel.setText(AppTranslation.get(this, "grade_c_min"));
        TextView tvGradeSLabel = findViewById(R.id.tvGradeSLabel);
        if (tvGradeSLabel != null) tvGradeSLabel.setText(AppTranslation.get(this, "grade_s_min"));
        TextView tvGradeFNotice = findViewById(R.id.tvGradeFNotice);
        if (tvGradeFNotice != null) tvGradeFNotice.setText(AppTranslation.get(this, "grade_f_notice"));
        if (btnSaveGradeSettings != null) btnSaveGradeSettings.setText(AppTranslation.get(this, "save_grade_boundaries"));
    }

    private void setupCountryAndLanguagePickers() {
        List<String> countries = CountryLanguageData.getAllCountries();
        ArrayAdapter<String> countryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCountry.setAdapter(countryAdapter);

        String savedCountry = AppSecurityManager.getSelectedCountry(this);
        int countryIndex = countries.indexOf(savedCountry);
        if (countryIndex >= 0) {
            spCountry.setSelection(countryIndex);
        }

        languageAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, currentLanguageList);
        languageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spLanguage.setAdapter(languageAdapter);

        spCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateLanguageOptionsForSelectedCountry();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        if (cbShowAllLanguages != null) {
            cbShowAllLanguages.setOnCheckedChangeListener((buttonView, isChecked) -> updateLanguageOptionsForSelectedCountry());
        }

        if (btnApplyLanguage != null) {
            btnApplyLanguage.setOnClickListener(v -> {
                String selectedCountry = (String) spCountry.getSelectedItem();
                CountryLanguageData.LanguageItem selectedLang = (CountryLanguageData.LanguageItem) spLanguage.getSelectedItem();

                if (selectedCountry != null) {
                    AppSecurityManager.setSelectedCountry(SettingsActivity.this, selectedCountry);
                }

                if (selectedLang != null) {
                    AppSecurityManager.setSelectedLanguageCode(SettingsActivity.this, selectedLang.code);
                    AppSecurityManager.applyAppLocale(SettingsActivity.this);

                    String msg = AppTranslation.get(SettingsActivity.this, "saved_success") + " " + selectedLang.name;
                    Toast.makeText(SettingsActivity.this, msg, Toast.LENGTH_SHORT).show();

                    // Re-create to apply UI changes immediately
                    recreate();
                }
            });
        }
    }

    private void updateLanguageOptionsForSelectedCountry() {
        String selectedCountry = (String) spCountry.getSelectedItem();
        boolean showAll = cbShowAllLanguages != null && cbShowAllLanguages.isChecked();

        currentLanguageList.clear();
        if (showAll) {
            currentLanguageList.addAll(CountryLanguageData.getAllGlobalLanguages());
        } else {
            currentLanguageList.addAll(CountryLanguageData.getLanguagesForCountry(selectedCountry));
        }

        languageAdapter.notifyDataSetChanged();

        if (isInitialCountryLoad) {
            // Respect previously saved language if present in list
            String savedLangCode = AppSecurityManager.getSelectedLanguageCode(this);
            int matchedIndex = -1;
            for (int i = 0; i < currentLanguageList.size(); i++) {
                if (currentLanguageList.get(i).code.equals(savedLangCode)) {
                    matchedIndex = i;
                    break;
                }
            }
            if (matchedIndex >= 0) {
                spLanguage.setSelection(matchedIndex);
            } else if (!currentLanguageList.isEmpty()) {
                spLanguage.setSelection(0);
            }
            isInitialCountryLoad = false;
        } else {
            // Automatically select primary language for newly selected country
            CountryLanguageData.LanguageItem primaryItem = CountryLanguageData.getPrimaryLanguageForCountry(selectedCountry);
            int targetIndex = 0;
            for (int i = 0; i < currentLanguageList.size(); i++) {
                if (currentLanguageList.get(i).code.equals(primaryItem.code)) {
                    targetIndex = i;
                    break;
                }
            }
            spLanguage.setSelection(targetIndex);
        }
    }

    private androidx.activity.result.ActivityResultLauncher<String> profilePhotoPicker;

    private void setupUserAccount() {
        SharedPreferences userPrefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        String name = userPrefs.getString(LoginActivity.KEY_USER_NAME, "Educator Account");

        if (tvUserName != null) tvUserName.setText(name);

        FirebaseUser currentUser = null;
        try {
            if (!com.google.firebase.FirebaseApp.getApps(this).isEmpty()) {
                currentUser = FirebaseAuth.getInstance().getCurrentUser();
            }
        } catch (Exception ignored) {}

        String currentUid = currentUser != null ? currentUser.getUid() : "GUEST-USER-88";
        String shortUid = currentUid.length() > 8 ? currentUid.substring(0, 8).toUpperCase() : currentUid.toUpperCase();
        String displayUidTag = "UID: HUB-" + shortUid;

        if (tvUserEmail != null) tvUserEmail.setText(displayUidTag);

        if (tvUserUid != null) {
            tvUserUid.setText(currentUid);
        }

        ImageView imgUserProfile = findViewById(R.id.imgUserProfile);
        MaterialButton btnChangeProfilePhoto = findViewById(R.id.btnChangeProfilePhoto);

        SharedPreferences photoPrefs = getSharedPreferences("user_profile_prefs", MODE_PRIVATE);
        String photoPath = photoPrefs.getString("profile_photo_path", "");

        if (imgUserProfile != null) {
            if (!photoPath.isEmpty() && new java.io.File(photoPath).exists()) {
                android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeFile(photoPath);
                imgUserProfile.setImageBitmap(bmp);
                imgUserProfile.setColorFilter(null);
            } else {
                imgUserProfile.setImageResource(android.R.drawable.ic_menu_myplaces);
            }
        }

        profilePhotoPicker = registerForActivityResult(
            new androidx.activity.result.contract.ActivityResultContracts.GetContent(),
            uri -> {
                if (uri != null) {
                    try {
                        java.io.InputStream inputStream = getContentResolver().openInputStream(uri);
                        java.io.File photoFile = new java.io.File(getFilesDir(), "user_profile_avatar.jpg");
                        java.io.FileOutputStream outputStream = new java.io.FileOutputStream(photoFile);
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = inputStream.read(buffer)) != -1) {
                            outputStream.write(buffer, 0, bytesRead);
                        }
                        outputStream.close();
                        inputStream.close();

                        photoPrefs.edit().putString("profile_photo_path", photoFile.getAbsolutePath()).apply();

                        if (imgUserProfile != null) {
                            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeFile(photoFile.getAbsolutePath());
                            imgUserProfile.setImageBitmap(bmp);
                            imgUserProfile.setColorFilter(null);
                        }
                        Toast.makeText(this, "ප්‍රොෆයිල් ඡායාරූපය සාර්ථකව සුරකින ලදී! (Profile Photo Updated)", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "ඡායාරූපය ලබා ගැනීමට නොහැකි විය: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        );

        if (btnChangeProfilePhoto != null) {
            btnChangeProfilePhoto.setOnClickListener(v -> {
                if (profilePhotoPicker != null) {
                    profilePhotoPicker.launch("image/*");
                }
            });
        }

        if (btnCopyUid != null) {
            final String uidToCopy = currentUid;
            btnCopyUid.setOnClickListener(v -> {
                if (!uidToCopy.isEmpty()) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("School UID", uidToCopy);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(SettingsActivity.this, "UID පිටපත් කරන ලදී! (UID Copied)", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SettingsActivity.this, "ලොග් වී නොමැත (Please login first)", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnSwitchAccount != null) {
            btnSwitchAccount.setOnClickListener(v -> {
                Intent intent = new Intent(SettingsActivity.this, LoginActivity.class);
                startActivity(intent);
            });
        }
    }

    private void setupPinSecurity() {
        boolean isEnabled = AppSecurityManager.isPinEnabled(this);
        if (swEnablePin != null) {
            swEnablePin.setChecked(isEnabled);

            swEnablePin.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    String currentPin = AppSecurityManager.getPinCode(SettingsActivity.this);
                    if (currentPin.isEmpty()) {
                        showSetupPinDialog(true);
                    } else {
                        AppSecurityManager.setPinEnabled(SettingsActivity.this, true);
                        Toast.makeText(SettingsActivity.this, AppTranslation.get(SettingsActivity.this, "pin_security"), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    AppSecurityManager.setPinEnabled(SettingsActivity.this, false);
                }
            });
        }

        if (btnSetupPin != null) {
            btnSetupPin.setOnClickListener(v -> showSetupPinDialog(false));
        }
    }

    private void showSetupPinDialog(boolean forceEnable) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_setup_pin, null);
        EditText etPin = dialogView.findViewById(R.id.etSetupPin);
        Spinner spQuestions = dialogView.findViewById(R.id.spSecurityQuestions);
        EditText etAnswer = dialogView.findViewById(R.id.etSetupAnswer);

        String[] questions = new String[]{
                "What is your first pet's name?",
                "What is your city of birth?",
                "What is your favorite school subject?",
                "What is your favorite teacher's name?"
        };

        ArrayAdapter<String> qAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, questions);
        qAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spQuestions != null) {
            spQuestions.setAdapter(qAdapter);
        }

        String savedPin = AppSecurityManager.getPinCode(this);
        if (etPin != null && !savedPin.isEmpty()) {
            etPin.setText(savedPin);
        }

        String savedAns = AppSecurityManager.getSecurityAnswer(this);
        if (etAnswer != null && !savedAns.isEmpty()) {
            etAnswer.setText(savedAns);
        }

        new AlertDialog.Builder(this)
                .setView(dialogView)
                .setPositiveButton(AppTranslation.get(this, "save"), (dialog, which) -> {
                    String pin = etPin != null ? etPin.getText().toString().trim() : "";
                    String question = spQuestions != null ? (String) spQuestions.getSelectedItem() : questions[0];
                    String answer = etAnswer != null ? etAnswer.getText().toString().trim() : "";

                    if (pin.isEmpty() || pin.length() < 4) {
                        Toast.makeText(SettingsActivity.this, "Please enter at least a 4-digit PIN", Toast.LENGTH_SHORT).show();
                        if (forceEnable && swEnablePin != null) swEnablePin.setChecked(false);
                        return;
                    }

                    if (answer.isEmpty()) {
                        Toast.makeText(SettingsActivity.this, "Please provide an answer to the security question", Toast.LENGTH_SHORT).show();
                        if (forceEnable && swEnablePin != null) swEnablePin.setChecked(false);
                        return;
                    }

                    AppSecurityManager.setPinCode(SettingsActivity.this, pin);
                    AppSecurityManager.setSecurityQuestion(SettingsActivity.this, question);
                    AppSecurityManager.setSecurityAnswer(SettingsActivity.this, answer);
                    AppSecurityManager.setPinEnabled(SettingsActivity.this, true);
                    AppSecurityManager.setPinUnlockedSession(SettingsActivity.this, true);

                    if (swEnablePin != null) swEnablePin.setChecked(true);
                    Toast.makeText(SettingsActivity.this, AppTranslation.get(SettingsActivity.this, "saved_success"), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(AppTranslation.get(this, "cancel"), (dialog, which) -> {
                    if (forceEnable && swEnablePin != null) {
                        swEnablePin.setChecked(AppSecurityManager.isPinEnabled(SettingsActivity.this));
                    }
                })
                .show();
    }

    private void setupSchoolDetailsHeader() {
        SharedPreferences prefs = getSharedPreferences("school_header_prefs", MODE_PRIVATE);
        String name = prefs.getString("school_name", "මධ්‍ය මහා විද්‍යාලය - කොළඹ");
        String address = prefs.getString("school_address", "නො. 123, ගාලු පාර, කොළඹ 03 | දුරකථන: 011-2345678");

        if (etSchoolName != null) etSchoolName.setText(name);
        if (etSchoolAddress != null) etSchoolAddress.setText(address);

        loadLogoPreview();

        if (btnSelectLogo != null) {
            btnSelectLogo.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                if (logoPickerLauncher != null) {
                    logoPickerLauncher.launch(Intent.createChooser(intent, "පාසල් ලාංඡනය තෝරන්න (Select School Logo)"));
                }
            });
        }

        if (btnSaveSchoolDetails != null) {
            btnSaveSchoolDetails.setOnClickListener(v -> {
                String sName = etSchoolName != null ? etSchoolName.getText().toString().trim() : "";
                String sAddress = etSchoolAddress != null ? etSchoolAddress.getText().toString().trim() : "";

                if (sName.isEmpty()) {
                    Toast.makeText(SettingsActivity.this, "කරුණාකර පාසලේ නම ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                    return;
                }

                SharedPreferences.Editor editor = getSharedPreferences("school_header_prefs", MODE_PRIVATE).edit();
                editor.putString("school_name", sName);
                editor.putString("school_address", sAddress);
                editor.apply();

                // Firestore Sync under schools/{uid} and users/{uid}
                try {
                    if (!com.google.firebase.FirebaseApp.getApps(SettingsActivity.this).isEmpty()) {
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        if (user != null && user.getUid() != null) {
                            String uid = user.getUid();
                            Map<String, Object> schoolProfile = new HashMap<>();
                            schoolProfile.put("uid", uid);
                            schoolProfile.put("schoolName", sName);
                            schoolProfile.put("schoolAddress", sAddress);
                            schoolProfile.put("email", user.getEmail() != null ? user.getEmail() : "");
                            schoolProfile.put("updatedAt", System.currentTimeMillis());

                            FirebaseFirestore db = FirebaseFirestore.getInstance();
                            db.collection("schools").document(uid).set(schoolProfile, SetOptions.merge());
                            db.collection("users").document(uid).set(schoolProfile, SetOptions.merge());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                Toast.makeText(SettingsActivity.this, "පාසල් තොරතුරු සාර්ථකව සුරකින ලදී! (School Details Saved)", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void saveLogoImageLocally(Uri imageUri) {
        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            File logoFile = new File(getFilesDir(), "school_logo.png");
            FileOutputStream outputStream = new FileOutputStream(logoFile);

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            outputStream.close();
            inputStream.close();

            SharedPreferences.Editor editor = getSharedPreferences("school_header_prefs", MODE_PRIVATE).edit();
            editor.putString("school_logo_path", logoFile.getAbsolutePath());
            editor.apply();

            loadLogoPreview();
            Toast.makeText(this, "පාසල් ලාංඡනය සාර්ථකව යාවත්කාලීන කරන ලදී!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "ලෝගෝව සුරැකීමට අපොහොසත් විය: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void loadLogoPreview() {
        if (ivSchoolLogoPreview == null) return;
        SharedPreferences prefs = getSharedPreferences("school_header_prefs", MODE_PRIVATE);
        String logoPath = prefs.getString("school_logo_path", "");

        if (!logoPath.isEmpty()) {
            File imgFile = new File(logoPath);
            if (imgFile.exists()) {
                android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                if (bitmap != null) {
                    ivSchoolLogoPreview.setImageBitmap(bitmap);
                    ivSchoolLogoPreview.setColorFilter(null); // Clear tint so image displays in full color
                    return;
                }
            }
        }
        ivSchoolLogoPreview.setImageResource(android.R.drawable.ic_menu_gallery);
    }

    private void setupClassHandover() {
        if (btnHandoverClass != null) {
            btnHandoverClass.setOnClickListener(v -> {
                ClassHandoverModalKt.showClassHandoverDialog(SettingsActivity.this);
            });
        }
        if (btnImportClass != null) {
            btnImportClass.setOnClickListener(v -> {
                ClassHandoverModalKt.showClassHandoverDialog(SettingsActivity.this);
            });
        }
    }

    private void setupGradeBoundaries() {
        if (etAMin != null) etAMin.setText(String.valueOf(GradeBoundaryManager.getAMin(this)));
        if (etBMin != null) etBMin.setText(String.valueOf(GradeBoundaryManager.getBMin(this)));
        if (etCMin != null) etCMin.setText(String.valueOf(GradeBoundaryManager.getCMin(this)));
        if (etSMin != null) etSMin.setText(String.valueOf(GradeBoundaryManager.getSMin(this)));

        if (btnSaveGradeSettings != null) {
            btnSaveGradeSettings.setOnClickListener(v -> {
                try {
                    int a = Integer.parseInt(etAMin.getText().toString().trim());
                    int b = Integer.parseInt(etBMin.getText().toString().trim());
                    int c = Integer.parseInt(etCMin.getText().toString().trim());
                    int s = Integer.parseInt(etSMin.getText().toString().trim());

                    if (a <= b || b <= c || c <= s) {
                        Toast.makeText(SettingsActivity.this, "කරුණාකර නිවැරදි සාමාර්ථ සීමා ඇතුළත් කරන්න (A > B > C > S)", Toast.LENGTH_LONG).show();
                        return;
                    }

                    GradeBoundaryManager.saveBoundaries(SettingsActivity.this, a, b, c, s);
                    Toast.makeText(SettingsActivity.this, "සාමාර්ථ සීමා සාර්ථකව සුරකින ලදී! (Grade Boundaries Saved)", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(SettingsActivity.this, "කරුණාකර සියලුම ලකුණු සීමා නිවැරදි අංක ලෙස ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void setupTimeFormatSettings() {
        rgTimeFormat = findViewById(R.id.rgTimeFormat);
        rb24Hour = findViewById(R.id.rb24Hour);
        rb12Hour = findViewById(R.id.rb12Hour);
        btnSaveTimeFormat = findViewById(R.id.btnSaveTimeFormat);

        boolean is24 = TimeFormatManager.is24HourFormat(this);
        if (rb24Hour != null) rb24Hour.setChecked(is24);
        if (rb12Hour != null) rb12Hour.setChecked(!is24);

        if (btnSaveTimeFormat != null) {
            btnSaveTimeFormat.setOnClickListener(v -> {
                String selectedFormat = (rb12Hour != null && rb12Hour.isChecked()) ? TimeFormatManager.FORMAT_12 : TimeFormatManager.FORMAT_24;
                TimeFormatManager.setTimeFormat(SettingsActivity.this, selectedFormat);
                Toast.makeText(SettingsActivity.this, "කාල ආකෘතිය සාර්ථකව සුරකින ලදී! (Time Format Saved)", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void setupLoaderStyleSettings() {
        loaderPreview = findViewById(R.id.loaderPreview);
        spLoaderStyle = findViewById(R.id.spLoaderStyle);
        tvSelectedLoaderName = findViewById(R.id.tvSelectedLoaderName);
        btnSaveLoaderStyle = findViewById(R.id.btnSaveLoaderStyle);

        LoadingAnimationManager.LoaderStyle[] styles = LoadingAnimationManager.LoaderStyle.values();
        List<String> styleNames = new ArrayList<>();
        for (int i = 0; i < styles.length; i++) {
            styleNames.add((i + 1) + ". " + styles[i].getDisplayName(this));
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, styleNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spLoaderStyle != null) {
            spLoaderStyle.setAdapter(adapter);
        }

        LoadingAnimationManager.LoaderStyle currentStyle = LoadingAnimationManager.getSelectedStyle(this);
        if (spLoaderStyle != null) {
            spLoaderStyle.setSelection(currentStyle.ordinal());
        }
        if (loaderPreview != null) {
            loaderPreview.setLoaderStyle(currentStyle);
        }
        if (tvSelectedLoaderName != null) {
            tvSelectedLoaderName.setText((currentStyle.ordinal() + 1) + ". " + currentStyle.getDisplayName(this));
        }

        if (spLoaderStyle != null) {
            spLoaderStyle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    LoadingAnimationManager.LoaderStyle selected = styles[position];
                    if (loaderPreview != null) {
                        loaderPreview.setLoaderStyle(selected);
                    }
                    if (tvSelectedLoaderName != null) {
                        tvSelectedLoaderName.setText((position + 1) + ". " + selected.getDisplayName(SettingsActivity.this));
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        if (btnSaveLoaderStyle != null) {
            btnSaveLoaderStyle.setOnClickListener(v -> {
                int pos = spLoaderStyle != null ? spLoaderStyle.getSelectedItemPosition() : 0;
                LoadingAnimationManager.LoaderStyle selected = styles[pos];
                LoadingAnimationManager.setSelectedStyle(SettingsActivity.this, selected);
                Toast.makeText(SettingsActivity.this, "ලෝඩර් රටාව සාර්ථකව සුරකින ලදී! (Loader Style Saved)", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void setupAccordionCards() {
        View header1 = findViewById(R.id.headerCard1);
        View content1 = findViewById(R.id.contentCard1);
        ImageView arrow1 = findViewById(R.id.ivCard1Arrow);

        View header2 = findViewById(R.id.headerCard2);
        View content2 = findViewById(R.id.contentCard2);
        ImageView arrow2 = findViewById(R.id.ivCard2Arrow);

        View header3 = findViewById(R.id.headerCard3);
        View content3 = findViewById(R.id.contentCard3);
        ImageView arrow3 = findViewById(R.id.ivCard3Arrow);

        View header4 = findViewById(R.id.headerCard4);
        View content4 = findViewById(R.id.contentCard4);
        ImageView arrow4 = findViewById(R.id.ivCard4Arrow);

        View header5 = findViewById(R.id.headerCard5);
        View content5 = findViewById(R.id.contentCard5);
        ImageView arrow5 = findViewById(R.id.ivCard5Arrow);

        View header6 = findViewById(R.id.headerCard6);
        View content6 = findViewById(R.id.contentCard6);
        ImageView arrow6 = findViewById(R.id.ivCard6Arrow);

        View header7 = findViewById(R.id.headerCard7);
        View content7 = findViewById(R.id.contentCard7);
        ImageView arrow7 = findViewById(R.id.ivCard7Arrow);

        View header8 = findViewById(R.id.headerCard8);
        View content8 = findViewById(R.id.contentCard8);
        ImageView arrow8 = findViewById(R.id.ivCard8Arrow);

        setupToggle(header1, content1, arrow1, true);
        setupToggle(header2, content2, arrow2, false);
        setupToggle(header3, content3, arrow3, false);
        setupToggle(header4, content4, arrow4, false);
        setupToggle(header5, content5, arrow5, false);
        setupToggle(header6, content6, arrow6, false);
        setupToggle(header7, content7, arrow7, false);
        setupToggle(header8, content8, arrow8, false);
    }

    private void setupToggle(View header, View content, ImageView arrow, boolean defaultOpen) {
        if (header == null || content == null || arrow == null) return;

        content.setVisibility(defaultOpen ? View.VISIBLE : View.GONE);
        arrow.setImageResource(defaultOpen ? android.R.drawable.arrow_up_float : android.R.drawable.arrow_down_float);

        header.setOnClickListener(v -> {
            boolean isOpen = content.getVisibility() == View.VISIBLE;
            content.setVisibility(isOpen ? View.GONE : View.VISIBLE);
            arrow.setImageResource(!isOpen ? android.R.drawable.arrow_up_float : android.R.drawable.arrow_down_float);
        });
    }
}
