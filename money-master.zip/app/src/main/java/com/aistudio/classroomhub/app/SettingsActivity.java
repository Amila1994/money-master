package com.aistudio.classroomhub.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SettingsActivity extends AppCompatActivity {

    private Spinner spCountry;
    private Spinner spLanguage;
    private CheckBox cbShowAllLanguages;
    private View btnApplyLanguage;

    private TextView tvUserName;
    private TextView tvUserEmail;
    private View btnSwitchAccount;

    private SwitchMaterial swEnablePin;
    private View btnSetupPin;
    private ImageView btnBack;

    private List<CountryLanguageData.LanguageItem> currentLanguageList = new ArrayList<>();
    private ArrayAdapter<CountryLanguageData.LanguageItem> languageAdapter;

    private final String[] presetQuestions = new String[]{
            "ඔබේ පළමු සුරතලාගේ නම කුමක්ද? (First pet's name)",
            "ඔබ උපන් නගරය කුමක්ද? (City of birth)",
            "ඔබගේ ප්‍රියතම පාසල් විෂය කුමක්ද? (Favorite school subject)",
            "ඔබගේ ප්‍රියතම ගුරුවරයාගේ නම කුමක්ද? (Favorite teacher's name)"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Apply locale
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_settings);

        initViews();
        setupCountryAndLanguagePickers();
        setupUserAccount();
        setupPinSecurity();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        spCountry = findViewById(R.id.spCountry);
        spLanguage = findViewById(R.id.spLanguage);
        cbShowAllLanguages = findViewById(R.id.cbShowAllLanguages);
        btnApplyLanguage = findViewById(R.id.btnApplyLanguage);

        tvUserName = findViewById(R.id.tvUserName);
        tvUserEmail = findViewById(R.id.tvUserEmail);
        btnSwitchAccount = findViewById(R.id.btnSwitchAccount);

        swEnablePin = findViewById(R.id.swEnablePin);
        btnSetupPin = findViewById(R.id.btnSetupPin);

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }
    }

    private void setupCountryAndLanguagePickers() {
        List<String> countries = CountryLanguageData.getAllCountries();
        ArrayAdapter<String> countryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCountry.setAdapter(countryAdapter);

        String savedCountry = AppSecurityManager.getSelectedCountry(this);
        int countryIndex = countries.indexOf(savedCountry);
        if (countryIndex >= 0) {
            spCountry.setSelection(countryIndex);
        }

        languageAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, currentLanguageList);
        languageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spLanguage.setAdapter(languageAdapter);

        spCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateLanguageOptions();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        if (cbShowAllLanguages != null) {
            cbShowAllLanguages.setOnCheckedChangeListener((buttonView, isChecked) -> updateLanguageOptions());
        }

        if (btnApplyLanguage != null) {
            btnApplyLanguage.setOnClickListener(v -> {
                String selectedCountry = (String) spCountry.getSelectedItem();
                CountryLanguageData.LanguageItem selectedLang = (CountryLanguageData.LanguageItem) spLanguage.getSelectedItem();

                if (selectedCountry != null) {
                    AppSecurityManager.setSelectedCountry(SettingsActivity.this, selectedCountry);
                }

                if (selectedLang != null) {
                    AppSecurityManager.setSelectedLanguageCode(SettingsActivity.this, selectedLang.code);
                    AppSecurityManager.applyAppLocale(SettingsActivity.this);
                    Toast.makeText(SettingsActivity.this, "රට සහ භාෂාව සාර්ථකව සුරකින ලදී: " + selectedLang.name, Toast.LENGTH_SHORT).show();

                    // Re-create to apply UI changes immediately
                    recreate();
                }
            });
        }
    }

    private void updateLanguageOptions() {
        String selectedCountry = (String) spCountry.getSelectedItem();
        boolean showAll = cbShowAllLanguages != null && cbShowAllLanguages.isChecked();

        currentLanguageList.clear();
        if (showAll) {
            currentLanguageList.addAll(CountryLanguageData.getAllGlobalLanguages());
        } else {
            currentLanguageList.addAll(CountryLanguageData.getLanguagesForCountry(selectedCountry));
        }

        languageAdapter.notifyDataSetChanged();

        // Select current active language if present in list
        String savedLangCode = AppSecurityManager.getSelectedLanguageCode(this);
        for (int i = 0; i < currentLanguageList.size(); i++) {
            if (currentLanguageList.get(i).code.equals(savedLangCode)) {
                spLanguage.setSelection(i);
                break;
            }
        }
    }

    private void setupUserAccount() {
        SharedPreferences userPrefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        String name = userPrefs.getString(LoginActivity.KEY_USER_NAME, "ගුරු භවතා");
        String email = userPrefs.getString(LoginActivity.KEY_USER_EMAIL, "teacher@gmail.com");

        if (tvUserName != null) tvUserName.setText(name);
        if (tvUserEmail != null) tvUserEmail.setText(email);

        if (btnSwitchAccount != null) {
            btnSwitchAccount.setOnClickListener(v -> {
                Intent intent = new Intent(SettingsActivity.this, LoginActivity.class);
                startActivity(intent);
            });
        }
    }

    private void setupPinSecurity() {
        boolean isEnabled = AppSecurityManager.isPinEnabled(this);
        if (swEnablePin != null) {
            swEnablePin.setChecked(isEnabled);

            swEnablePin.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    String currentPin = AppSecurityManager.getPinCode(SettingsActivity.this);
                    if (currentPin.isEmpty()) {
                        showSetupPinDialog(true);
                    } else {
                        AppSecurityManager.setPinEnabled(SettingsActivity.this, true);
                        Toast.makeText(SettingsActivity.this, "PIN ආරක්ෂාව සක්‍රීය කරන ලදී!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    AppSecurityManager.setPinEnabled(SettingsActivity.this, false);
                    Toast.makeText(SettingsActivity.this, "PIN ආරක්ෂාව අක්‍රීය කරන ලදී!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        if (btnSetupPin != null) {
            btnSetupPin.setOnClickListener(v -> showSetupPinDialog(false));
        }
    }

    private void showSetupPinDialog(boolean forceEnable) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_setup_pin, null);
        EditText etPin = dialogView.findViewById(R.id.etSetupPin);
        Spinner spQuestions = dialogView.findViewById(R.id.spSecurityQuestions);
        EditText etAnswer = dialogView.findViewById(R.id.etSetupAnswer);

        ArrayAdapter<String> qAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, presetQuestions);
        qAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spQuestions != null) {
            spQuestions.setAdapter(qAdapter);
        }

        String savedPin = AppSecurityManager.getPinCode(this);
        if (etPin != null && !savedPin.isEmpty()) {
            etPin.setText(savedPin);
        }

        String savedAns = AppSecurityManager.getSecurityAnswer(this);
        if (etAnswer != null && !savedAns.isEmpty()) {
            etAnswer.setText(savedAns);
        }

        new AlertDialog.Builder(this)
                .setView(dialogView)
                .setPositiveButton("සුරකින්න (Save PIN)", (dialog, which) -> {
                    String pin = etPin != null ? etPin.getText().toString().trim() : "";
                    String question = spQuestions != null ? (String) spQuestions.getSelectedItem() : presetQuestions[0];
                    String answer = etAnswer != null ? etAnswer.getText().toString().trim() : "";

                    if (pin.isEmpty() || pin.length() < 4) {
                        Toast.makeText(SettingsActivity.this, "කරුණාකර අවම වශයෙන් 4-Digit PIN එකක් ලබා දෙන්න", Toast.LENGTH_SHORT).show();
                        if (forceEnable && swEnablePin != null) swEnablePin.setChecked(false);
                        return;
                    }

                    if (answer.isEmpty()) {
                        Toast.makeText(SettingsActivity.this, "කරුණාකර ආරක්ෂිත ප්‍රශ්නයට පිළිතුරක් ලබා දෙන්න", Toast.LENGTH_SHORT).show();
                        if (forceEnable && swEnablePin != null) swEnablePin.setChecked(false);
                        return;
                    }

                    AppSecurityManager.setPinCode(SettingsActivity.this, pin);
                    AppSecurityManager.setSecurityQuestion(SettingsActivity.this, question);
                    AppSecurityManager.setSecurityAnswer(SettingsActivity.this, answer);
                    AppSecurityManager.setPinEnabled(SettingsActivity.this, true);
                    AppSecurityManager.setPinUnlockedSession(SettingsActivity.this, true);

                    if (swEnablePin != null) swEnablePin.setChecked(true);
                    Toast.makeText(SettingsActivity.this, "PIN සහ ආරක්ෂිත ප්‍රශ්නය සාර්ථකව සුරකින ලදී!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("අවලංගුයි", (dialog, which) -> {
                    if (forceEnable && swEnablePin != null) {
                        swEnablePin.setChecked(AppSecurityManager.isPinEnabled(SettingsActivity.this));
                    }
                })
                .show();
    }
}
