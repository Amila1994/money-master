package com.aistudio.classroomhub.app;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class TeacherControlDialogHelper {

    public static void showTeacherControlDialog(@NonNull Context context) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_teacher_control, null);
        dialog.setContentView(view);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT
            );
        }

        TextView tvTeacherCustomUid = view.findViewById(R.id.tvTeacherCustomUid);
        ImageView btnCloseDialog = view.findViewById(R.id.btnCloseDialog);

        EditText etStudentCustomUid = view.findViewById(R.id.etStudentCustomUid);
        MaterialButton btnAddStudentUid = view.findViewById(R.id.btnAddStudentUid);
        LinearLayout layoutAddedStudents = view.findViewById(R.id.layoutAddedStudents);

        SwitchMaterial swHomework = view.findViewById(R.id.swHomework);
        SwitchMaterial swAttendance = view.findViewById(R.id.swAttendance);
        SwitchMaterial swNotes = view.findViewById(R.id.swNotes);
        SwitchMaterial swMarks = view.findViewById(R.id.swMarks);
        SwitchMaterial swChat = view.findViewById(R.id.swChat);
        SwitchMaterial swTimetable = view.findViewById(R.id.swTimetable);

        MaterialButton btnSaveControlSettings = view.findViewById(R.id.btnSaveControlSettings);

        String teacherCustomUid = UserRoleManager.getCustomUid(context);
        tvTeacherCustomUid.setText("Your Teacher/School UID: " + (teacherCustomUid.isEmpty() ? "SCH-0001" : teacherCustomUid));

        // Load existing switch states
        swHomework.setChecked(UserRoleManager.isFeatureEnabledForStudent(context, UserRoleManager.FEATURE_HOMEWORK));
        swAttendance.setChecked(UserRoleManager.isFeatureEnabledForStudent(context, UserRoleManager.FEATURE_ATTENDANCE));
        swNotes.setChecked(UserRoleManager.isFeatureEnabledForStudent(context, UserRoleManager.FEATURE_NOTES));
        swMarks.setChecked(UserRoleManager.isFeatureEnabledForStudent(context, UserRoleManager.FEATURE_MARKS));
        swChat.setChecked(UserRoleManager.isFeatureEnabledForStudent(context, UserRoleManager.FEATURE_CHAT));
        swTimetable.setChecked(UserRoleManager.isFeatureEnabledForStudent(context, UserRoleManager.FEATURE_TIMETABLE));

        btnCloseDialog.setOnClickListener(v -> dialog.dismiss());

        // Fetch existing linked students
        loadLinkedStudents(context, layoutAddedStudents);

        btnAddStudentUid.setOnClickListener(v -> {
            String stdUid = etStudentCustomUid.getText().toString().trim();
            if (stdUid.isEmpty()) {
                Toast.makeText(context, "කරුණාකර Student Custom UID ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                return;
            }
            addStudentByUid(context, stdUid, layoutAddedStudents, etStudentCustomUid);
        });

        btnSaveControlSettings.setOnClickListener(v -> {
            boolean hw = swHomework.isChecked();
            boolean att = swAttendance.isChecked();
            boolean nt = swNotes.isChecked();
            boolean mk = swMarks.isChecked();
            boolean ct = swChat.isChecked();
            boolean tt = swTimetable.isChecked();

            UserRoleManager.setFeatureEnabledForStudent(context, UserRoleManager.FEATURE_HOMEWORK, hw);
            UserRoleManager.setFeatureEnabledForStudent(context, UserRoleManager.FEATURE_ATTENDANCE, att);
            UserRoleManager.setFeatureEnabledForStudent(context, UserRoleManager.FEATURE_NOTES, nt);
            UserRoleManager.setFeatureEnabledForStudent(context, UserRoleManager.FEATURE_MARKS, mk);
            UserRoleManager.setFeatureEnabledForStudent(context, UserRoleManager.FEATURE_CHAT, ct);
            UserRoleManager.setFeatureEnabledForStudent(context, UserRoleManager.FEATURE_TIMETABLE, tt);

            // Sync config to Firestore
            syncConfigToFirestore(context, hw, att, nt, mk, ct, tt);

            Toast.makeText(context, "ශිෂ්‍ය පහසුකම් සුරකින ලදී! (Student Feature Permissions Saved)", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();
    }

    private static void loadLinkedStudents(Context context, LinearLayout layout) {
        if (layout == null) return;
        layout.removeAllViews();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        FirebaseFirestore.getInstance()
                .collection("teachers")
                .document(user.getUid())
                .collection("students")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    layout.removeAllViews();
                    for (DocumentSnapshot doc : queryDocumentSnapshots.getDocuments()) {
                        String customUid = doc.getString("customUid");
                        String name = doc.getString("name");
                        if (name == null || name.isEmpty()) name = "Student (" + customUid + ")";

                        addStudentChipToLayout(context, layout, customUid, name, doc.getId());
                    }
                });
    }

    private static void addStudentByUid(Context context, String stdUid, LinearLayout layout, EditText inputField) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(context, "Please sign in with Google", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(context, "ශිෂ්‍යයා පරීක්ෂා කරමින්...", Toast.LENGTH_SHORT).show();

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("custom_uids").document(stdUid).get().addOnCompleteListener(task -> {
            String stdName = "Student (" + stdUid + ")";
            String stdRealUid = "";
            if (task.isSuccessful() && task.getResult() != null && task.getResult().exists()) {
                DocumentSnapshot doc = task.getResult();
                if (doc.getString("name") != null) stdName = doc.getString("name");
                if (doc.getString("uid") != null) stdRealUid = doc.getString("uid");
            }

            Map<String, Object> studentMap = new HashMap<>();
            studentMap.put("customUid", stdUid);
            studentMap.put("name", stdName);
            studentMap.put("realUid", stdRealUid);
            studentMap.put("addedAt", System.currentTimeMillis());

            db.collection("teachers")
                    .document(user.getUid())
                    .collection("students")
                    .document(stdUid)
                    .set(studentMap, SetOptions.merge())
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(context, "ශිෂ්‍යයා සාර්ථකව එකතු කරන ලදී!", Toast.LENGTH_SHORT).show();
                        if (inputField != null) inputField.setText("");
                        loadLinkedStudents(context, layout);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(context, "Error adding student: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });
    }

    private static void addStudentChipToLayout(Context context, LinearLayout parentLayout, String customUid, String name, String docId) {
        View row = LayoutInflater.from(context).inflate(R.layout.item_linked_student_chip, parentLayout, false);

        TextView tvName = row.findViewById(R.id.tvStudentChipName);
        ImageView btnRemove = row.findViewById(R.id.btnRemoveStudentChip);

        tvName.setText("🎓 " + name + " (" + customUid + ")");

        btnRemove.setOnClickListener(v -> {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            if (user != null) {
                FirebaseFirestore.getInstance()
                        .collection("teachers")
                        .document(user.getUid())
                        .collection("students")
                        .document(docId)
                        .delete()
                        .addOnSuccessListener(aVoid -> {
                            parentLayout.removeView(row);
                            Toast.makeText(context, "ශිෂ්‍යයා ඉවත් කරන ලදී", Toast.LENGTH_SHORT).show();
                        });
            }
        });

        parentLayout.addView(row);
    }

    private static void syncConfigToFirestore(Context context, boolean hw, boolean att, boolean nt, boolean mk, boolean ct, boolean tt) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return;

        Map<String, Object> configMap = new HashMap<>();
        configMap.put(UserRoleManager.FEATURE_HOMEWORK, hw);
        configMap.put(UserRoleManager.FEATURE_ATTENDANCE, att);
        configMap.put(UserRoleManager.FEATURE_NOTES, nt);
        configMap.put(UserRoleManager.FEATURE_MARKS, mk);
        configMap.put(UserRoleManager.FEATURE_CHAT, ct);
        configMap.put(UserRoleManager.FEATURE_TIMETABLE, tt);
        configMap.put("updatedAt", System.currentTimeMillis());

        FirebaseFirestore.getInstance()
                .collection("teachers")
                .document(user.getUid())
                .collection("config")
                .document("student_features")
                .set(configMap, SetOptions.merge());
    }
}
