package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

import java.util.UUID;

public class AdditionsActivity extends AppCompatActivity {

    private ImageView btnBack;
    private MaterialCardView btnAddStudents;
    private MaterialCardView btnAddMyTimeTable;
    private MaterialCardView btnAddAnnouncement;
    private MaterialCardView btnMarkTeacherAttendance;
    private MaterialCardView btnClassHandover;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_additions);

        initViews();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        btnAddStudents = findViewById(R.id.btnAddStudents);
        btnAddMyTimeTable = findViewById(R.id.btnAddMyTimeTable);
        btnAddAnnouncement = findViewById(R.id.btnAddAnnouncement);
        btnMarkTeacherAttendance = findViewById(R.id.btnMarkTeacherAttendance);
        btnClassHandover = findViewById(R.id.btnClassHandover);
    }

    private void setupListeners() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 3D Press Touch Effect
        View.OnTouchListener touch3dEffect = (view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(80).start();
                    break;
            }
            return false;
        };

        if (btnAddStudents != null) btnAddStudents.setOnTouchListener(touch3dEffect);
        if (btnAddMyTimeTable != null) btnAddMyTimeTable.setOnTouchListener(touch3dEffect);
        if (btnAddAnnouncement != null) btnAddAnnouncement.setOnTouchListener(touch3dEffect);
        if (btnMarkTeacherAttendance != null) btnMarkTeacherAttendance.setOnTouchListener(touch3dEffect);

        if (btnAddStudents != null) {
            btnAddStudents.setOnClickListener(v -> showAddStudentDialog());
        }

        if (btnAddMyTimeTable != null) {
            btnAddMyTimeTable.setOnClickListener(v -> {
                Intent intent = new Intent(AdditionsActivity.this, TimetableActivity.class);
                intent.putExtra(TimetableActivity.EXTRA_INITIAL_TAB, "add");
                startActivity(intent);
            });
        }

        if (btnAddAnnouncement != null) {
            btnAddAnnouncement.setOnClickListener(v -> {
                AnnouncementModalKt.showAnnouncementDialog(AdditionsActivity.this, null);
            });
        }

        if (btnMarkTeacherAttendance != null) {
            btnMarkTeacherAttendance.setOnClickListener(v -> {
                TeacherAttendanceModalKt.showTeacherAttendanceDialog(AdditionsActivity.this, null);
            });
        }

        if (btnClassHandover != null) {
            btnClassHandover.setOnTouchListener(touch3dEffect);
            btnClassHandover.setOnClickListener(v -> {
                ClassHandoverModalKt.showClassHandoverDialog(AdditionsActivity.this);
            });
        }
    }

    private void showAddStudentDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_student, null);

        EditText etName = dialogView.findViewById(R.id.etDialogStudentName);
        EditText etInitials = dialogView.findViewById(R.id.etDialogInitials);
        EditText etDob = dialogView.findViewById(R.id.etDialogDob);
        EditText etGender = dialogView.findViewById(R.id.etDialogGender);
        EditText etEthRel = dialogView.findViewById(R.id.etDialogEthRel);
        EditText etBirthCert = dialogView.findViewById(R.id.etDialogBirthCert);

        EditText etRoll = dialogView.findViewById(R.id.etDialogRollNo);
        EditText etGrade = dialogView.findViewById(R.id.etDialogGrade);
        EditText etMedium = dialogView.findViewById(R.id.etDialogMedium);
        EditText etAddress = dialogView.findViewById(R.id.etDialogAddress);

        EditText etFather = dialogView.findViewById(R.id.etDialogFather);
        EditText etFatherPhone = dialogView.findViewById(R.id.etDialogFatherPhone);
        EditText etMother = dialogView.findViewById(R.id.etDialogMother);
        EditText etMotherPhone = dialogView.findViewById(R.id.etDialogMotherPhone);

        EditText etGuardian = dialogView.findViewById(R.id.etDialogGuardian);
        EditText etEmergencyName = dialogView.findViewById(R.id.etDialogEmergencyName);
        EditText etContact = dialogView.findViewById(R.id.etDialogContact);
        EditText etMarks = dialogView.findViewById(R.id.etDialogMarks);

        new AlertDialog.Builder(this)
                .setTitle("Add Students (ළමයා එකතු කරන්න)")
                .setView(dialogView)
                .setPositiveButton("Submit (ලියාපදිංචි කරන්න)", (dialog, which) -> {
                    String name = etName != null ? etName.getText().toString().trim() : "";
                    String regNo = etRoll != null ? etRoll.getText().toString().trim() : "";

                    if (name.isEmpty()) {
                        Toast.makeText(this, "සම්පූර්ණ නම ඇතුලත් කරන්න (Student name required)", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String grade = (etGrade != null && !etGrade.getText().toString().trim().isEmpty()) ? etGrade.getText().toString().trim() : "Grade 10";
                    int marks = 85;
                    if (etMarks != null && !etMarks.getText().toString().trim().isEmpty()) {
                        try {
                            marks = Integer.parseInt(etMarks.getText().toString().trim());
                        } catch (Exception ignored) {}
                    }

                    Student newStudent = new Student(UUID.randomUUID().toString(), name, regNo, grade, marks, true);
                    if (etInitials != null) newStudent.setNameWithInitials(etInitials.getText().toString().trim());
                    if (etDob != null) newStudent.setDob(etDob.getText().toString().trim());
                    if (etGender != null) newStudent.setGender(etGender.getText().toString().trim());
                    if (etEthRel != null) newStudent.setEthnicity(etEthRel.getText().toString().trim());
                    if (etBirthCert != null) newStudent.setBirthCertNo(etBirthCert.getText().toString().trim());
                    if (etMedium != null) newStudent.setMedium(etMedium.getText().toString().trim());
                    if (etAddress != null) newStudent.setPermAddress(etAddress.getText().toString().trim());
                    if (etFather != null) newStudent.setFatherName(etFather.getText().toString().trim());
                    if (etFatherPhone != null) newStudent.setFatherPhone(etFatherPhone.getText().toString().trim());
                    if (etMother != null) newStudent.setMotherName(etMother.getText().toString().trim());
                    if (etMotherPhone != null) newStudent.setMotherPhone(etMotherPhone.getText().toString().trim());
                    if (etGuardian != null) newStudent.setGuardianName(etGuardian.getText().toString().trim());
                    if (etEmergencyName != null) newStudent.setEmergencyName(etEmergencyName.getText().toString().trim());
                    if (etContact != null) newStudent.setEmergencyPhone(etContact.getText().toString().trim());

                    // Save to repository
                    StudentRepository.addStudent(newStudent);

                    Toast.makeText(this, "ළමයා සාර්ථකව පද්ධතියට එකතු කරන ලදී! (" + name + ")", Toast.LENGTH_LONG).show();

                    // Switch automatically to Student Roster screen
                    Intent intent = new Intent(AdditionsActivity.this, StudentListActivity.class);
                    startActivity(intent);
                })
                .setNegativeButton("අවලංගු කරන්න", null)
                .show();
    }
}
