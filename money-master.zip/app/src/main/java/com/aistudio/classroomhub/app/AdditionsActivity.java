package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.card.MaterialCardView;

import java.util.UUID;

public class AdditionsActivity extends AppCompatActivity {

    private ImageView btnBack;
    private MaterialCardView btnAddStudents;
    private MaterialCardView btnAddMyTimeTable;
    private MaterialCardView btnAddAnnouncement;
    private MaterialCardView btnMarkTeacherAttendance;
    private MaterialCardView btnClassHandover;
    private MaterialCardView btnAddReminders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_additions);

        initViews();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        btnAddStudents = findViewById(R.id.btnAddStudents);
        btnAddMyTimeTable = findViewById(R.id.btnAddMyTimeTable);
        btnAddAnnouncement = findViewById(R.id.btnAddAnnouncement);
        btnMarkTeacherAttendance = findViewById(R.id.btnMarkTeacherAttendance);
        btnClassHandover = findViewById(R.id.btnClassHandover);
        btnAddReminders = findViewById(R.id.btnAddReminders);
    }

    private void setupListeners() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        // 3D Press Touch Effect
        View.OnTouchListener touch3dEffect = (view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(80).start();
                    break;
            }
            return false;
        };

        if (btnAddStudents != null) btnAddStudents.setOnTouchListener(touch3dEffect);
        if (btnAddMyTimeTable != null) btnAddMyTimeTable.setOnTouchListener(touch3dEffect);
        if (btnAddAnnouncement != null) btnAddAnnouncement.setOnTouchListener(touch3dEffect);
        if (btnMarkTeacherAttendance != null) btnMarkTeacherAttendance.setOnTouchListener(touch3dEffect);

        if (btnAddStudents != null) {
            btnAddStudents.setOnClickListener(v -> showAddStudentDialog());
        }

        if (btnAddMyTimeTable != null) {
            btnAddMyTimeTable.setOnClickListener(v -> {
                Intent intent = new Intent(AdditionsActivity.this, TimetableActivity.class);
                intent.putExtra(TimetableActivity.EXTRA_INITIAL_TAB, "add");
                startActivity(intent);
            });
        }

        if (btnAddAnnouncement != null) {
            btnAddAnnouncement.setOnClickListener(v -> {
                AnnouncementModalKt.showAnnouncementDialog(AdditionsActivity.this, null);
            });
        }

        if (btnMarkTeacherAttendance != null) {
            btnMarkTeacherAttendance.setOnClickListener(v -> {
                TeacherAttendanceModalKt.showTeacherAttendanceDialog(AdditionsActivity.this, null);
            });
        }

        if (btnClassHandover != null) {
            btnClassHandover.setOnTouchListener(touch3dEffect);
            btnClassHandover.setOnClickListener(v -> {
                ClassHandoverModalKt.showClassHandoverDialog(AdditionsActivity.this);
            });
        }

        if (btnAddReminders != null) {
            btnAddReminders.setOnTouchListener(touch3dEffect);
            btnAddReminders.setOnClickListener(v -> {
                ReminderModalKt.showReminderModal(AdditionsActivity.this);
            });
        }
    }

    private void showAddStudentDialog() {
        AddStudentDialogHelper.showAddStudentDialog(this, new AddStudentDialogHelper.OnStudentAddedListener() {
            @Override
            public void onStudentAdded(Student student) {
                Intent intent = new Intent(AdditionsActivity.this, StudentListActivity.class);
                startActivity(intent);
            }
        });
    }
}
