package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;

public class GradeBoundaryManager {
    private static final String PREF_NAME = "grade_boundary_prefs";
    private static final String KEY_A_MIN = "a_min";
    private static final String KEY_B_MIN = "b_min";
    private static final String KEY_C_MIN = "c_min";
    private static final String KEY_S_MIN = "s_min";

    public static int getAMin(Context context) {
        if (context == null) return 75;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_A_MIN, 75);
    }

    public static int getBMin(Context context) {
        if (context == null) return 65;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_B_MIN, 65);
    }

    public static int getCMin(Context context) {
        if (context == null) return 55;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_C_MIN, 55);
    }

    public static int getSMin(Context context) {
        if (context == null) return 35;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_S_MIN, 35);
    }

    public static void saveBoundaries(Context context, int aMin, int bMin, int cMin, int sMin) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit()
                .putInt(KEY_A_MIN, aMin)
                .putInt(KEY_B_MIN, bMin)
                .putInt(KEY_C_MIN, cMin)
                .putInt(KEY_S_MIN, sMin)
                .apply();
    }

    public static String calculateGrade(Context context, double mark) {
        int a = getAMin(context);
        int b = getBMin(context);
        int c = getCMin(context);
        int s = getSMin(context);

        if (mark >= a) return "A";
        if (mark >= b) return "B";
        if (mark >= c) return "C";
        if (mark >= s) return "S";
        return "F";
    }

    public static String calculateGrade(double mark, int a, int b, int c, int s) {
        if (mark >= a) return "A";
        if (mark >= b) return "B";
        if (mark >= c) return "C";
        if (mark >= s) return "S";
        return "F";
    }
}
