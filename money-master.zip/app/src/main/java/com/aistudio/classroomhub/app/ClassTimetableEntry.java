package com.aistudio.classroomhub.app;

import java.util.Locale;

public class ClassTimetableEntry {
    private String id;
    private String day; // 'සඳුදා', 'අඟහරුවාදා', 'බදාදා', 'බ්‍රහස්පතින්දා', 'සිකුරාදා'
    private String periodName; // '1 වන කාලඡේදය'
    private int startHour;
    private int startMinute;
    private int endHour;
    private int endMinute;
    private String subject;
    private String teacherName;
    private String roomNo;

    public ClassTimetableEntry(String id, String day, String periodName, int startHour, int startMinute,
                               int endHour, int endMinute, String subject, String teacherName, String roomNo) {
        this.id = id;
        this.day = day;
        this.periodName = periodName;
        this.startHour = startHour;
        this.startMinute = startMinute;
        this.endHour = endHour;
        this.endMinute = endMinute;
        this.subject = subject;
        this.teacherName = teacherName;
        this.roomNo = roomNo != null ? roomNo : "ප්‍රධාන පන්ති කාමරය";
    }

    public String getId() {
        return id;
    }

    public String getDay() {
        return day;
    }

    public String getPeriodName() {
        return periodName;
    }

    public int getStartHour() {
        return startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public int getEndHour() {
        return endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public String getSubject() {
        return subject;
    }

    public String getTeacherName() {
        return teacherName;
    }

    public String getRoomNo() {
        return roomNo;
    }

    public int getStartMinutesOfDay() {
        return startHour * 60 + startMinute;
    }

    public int getEndMinutesOfDay() {
        return endHour * 60 + endMinute;
    }

    public String getFormattedTimeRange() {
        return String.format(Locale.US, "%02d:%02d - %02d:%02d",
                startHour, startMinute, endHour, endMinute);
    }
}
