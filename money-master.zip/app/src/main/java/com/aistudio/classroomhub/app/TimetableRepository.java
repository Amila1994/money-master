package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TimetableRepository {

    private static final List<TimetableEntry> entries = new ArrayList<>();

    static {
        initSampleTimetableData();
    }

    private static void initSampleTimetableData() {
        if (!entries.isEmpty()) return;

        // Monday (සඳුදා)
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "පරිච්ඡේදය 4 - වර්ගජ සමීකරණ"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "විද්‍යාව", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "රසායනික බන්ධන"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "නිදහස් කාලඡේදය", "Staff Room", "Room 01", "නිදහස් (Free)", "ප්‍රශ්න පත්‍ර පරීක්ෂාව"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ඉංග්‍රීසි", "Grade 9-B", "Hall 05", "නියෝජන (Relief)", "නියෝජන රාජකාරිය"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "5 වන කාලඡේදය", 10, 50, 11, 30, "ගණිතය", "Grade 11-C", "Hall 08", "ප්‍රධාන විෂය", "ත්‍රිකෝණමිතිය"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සඳුදා", "6 වන කාලඡේදය", 11, 30, 12, 10, "තොරතුරු තාක්ෂණය", "Grade 10-A", "Lab 01", "ප්‍රධාන විෂය", "පරිගණක ජාලකරණය"));

        // Tuesday (අඟහරුවාදා)
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "Grade 11-C", "Hall 08", "ප්‍රධාන විෂය", "සමාචාර ශ්‍රේණි"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "ගණිතය", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "ජ්‍යාමිතිය"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "සිංහල", "Grade 8-A", "Hall 03", "නියෝජන (Relief)", "නියෝජන රාජකාරිය"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "නිදහස් කාලඡේදය", "Staff Room", "Room 01", "නිදහස් (Free)", ""));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "අඟහරුවාදා", "5 වන කාලඡේදය", 10, 50, 11, 30, "විද්‍යාව", "Grade 10-B", "Lab 02", "ප්‍රධාන විෂය", "විද්‍යුත් චුම්භකත්වය"));

        // Wednesday (බදාදා)
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බදාදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "තොරතුරු තාක්ෂණය", "Grade 11-A", "Lab 01", "ප්‍රධාන විෂය", "C++ Programming"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බදාදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "ගණිතය", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "වර්ගමූල"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බදාදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "ඉතිහාසය", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "ලංකා ඉතිහාසය"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බදාදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ගණිතය", "Grade 9-A", "Hall 04", "නියෝජන (Relief)", ""));

        // Thursday (බ්‍රහස්පතින්දා)
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "සම්භාවිතාව"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "2 වන කාලඡේදය", 8, 30, 9, 10, "නිදහස් කාලඡේදය", "Staff Room", "Room 01", "නිදහස් (Free)", ""));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "3 වන කාලඡේදය", 9, 10, 9, 50, "විද්‍යාව", "Grade 11-C", "Hall 08", "ප්‍රධාන විෂය", "ශාක පටක"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "බ්‍රහස්පතින්දා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ගණිතය", "Grade 11-C", "Hall 08", "ප්‍රධාන විෂය", "සංඛ්‍යානය"));

        // Friday (සිකුරාදා)
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "1 වන කාලඡේදය", 7, 50, 8, 30, "ගණිතය", "Grade 10-A", "Hall 02", "ප්‍රධාන විෂය", "සතිඅන්ත පුනරීක්ෂණ"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "2 වන කාලඡේදය", 8, 30, 9, 10, "තොරතුරු තාක්ෂණය", "Grade 10-A", "Lab 01", "ප්‍රධාන විෂය", "Web Design"));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "3 වන කාලඡේදය", 9, 10, 9, 50, "නිදහස් කාලඡේදය", "Staff Room", "Room 01", "නිදහස් (Free)", ""));
        entries.add(new TimetableEntry(UUID.randomUUID().toString(), "සිකුරාදා", "4 වන කාලඡේදය", 9, 50, 10, 30, "ගණිතය", "Grade 10-B", "Hall 03", "නියෝජන (Relief)", "නියෝජන කාලඡේදය"));
    }

    public static List<TimetableEntry> getEntries() {
        return entries;
    }

    public static List<TimetableEntry> getEntriesForDay(String day) {
        List<TimetableEntry> result = new ArrayList<>();
        for (TimetableEntry e : entries) {
            if (e.getDay().equalsIgnoreCase(day)) {
                result.add(e);
            }
        }
        return result;
    }

    public static void addEntry(TimetableEntry entry) {
        entries.add(entry);
    }

    public static void removeEntry(String id) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getId().equals(id)) {
                entries.remove(i);
                break;
            }
        }
    }
}
