package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TimetableRepository {

    private static final List<TimetableEntry> entries = new ArrayList<>();

    static {
        initSampleTimetableData();
    }

    private static void initSampleTimetableData() {
        // Start with an empty user-configured timetable.
    }

    public static List<TimetableEntry> getEntries() {
        return entries;
    }

    public static List<TimetableEntry> getEntriesForDay(String day) {
        List<TimetableEntry> result = new ArrayList<>();
        for (TimetableEntry e : entries) {
            if (e.getDay().equalsIgnoreCase(day)) {
                result.add(e);
            }
        }
        return result;
    }

    public static void addEntry(TimetableEntry entry) {
        entries.add(entry);
    }

    public static void removeEntry(String id) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getId().equals(id)) {
                entries.remove(i);
                break;
            }
        }
    }
}
