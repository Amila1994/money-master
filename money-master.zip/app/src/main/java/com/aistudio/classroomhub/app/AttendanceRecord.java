package com.aistudio.classroomhub.app;

public class AttendanceRecord {
    private boolean isPresent;
    private long markedAtMillis;

    public AttendanceRecord(boolean isPresent, long markedAtMillis) {
        this.isPresent = isPresent;
        this.markedAtMillis = markedAtMillis;
    }

    public boolean isPresent() {
        return isPresent;
    }

    public void setPresent(boolean present) {
        isPresent = present;
    }

    public long getMarkedAtMillis() {
        return markedAtMillis;
    }

    public void setMarkedAtMillis(long markedAtMillis) {
        this.markedAtMillis = markedAtMillis;
    }
}
