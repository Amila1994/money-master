package com.aistudio.classroomhub.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HandoverRecord(
    val fileId: String,
    val senderName: String,
    val recipientEmail: String,
    val className: String,
    val timestamp: String,
    val isImported: Boolean = false
)

object ClassHandoverHistoryStore {
    private const val PREF_NAME = "class_handover_history_pref"
    private const val KEY_RECORDS = "records_json"

    fun getRecords(context: Context): List<HandoverRecord> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_RECORDS, null) ?: return emptyList()
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<HandoverRecord>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    HandoverRecord(
                        fileId = obj.optString("fileId"),
                        senderName = obj.optString("senderName"),
                        recipientEmail = obj.optString("recipientEmail"),
                        className = obj.optString("className"),
                        timestamp = obj.optString("timestamp"),
                        isImported = obj.optBoolean("isImported", false)
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addRecord(context: Context, record: HandoverRecord) {
        val current = getRecords(context).toMutableList()
        current.add(0, record)
        saveRecords(context, current)
    }

    private fun saveRecords(context: Context, records: List<HandoverRecord>) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val array = JSONArray()
        for (r in records) {
            val obj = JSONObject()
            obj.put("fileId", r.fileId)
            obj.put("senderName", r.senderName)
            obj.put("recipientEmail", r.recipientEmail)
            obj.put("className", r.className)
            obj.put("timestamp", r.timestamp)
            obj.put("isImported", r.isImported)
            array.put(obj)
        }
        prefs.edit().putString(KEY_RECORDS, array.toString()).apply()
    }
}
