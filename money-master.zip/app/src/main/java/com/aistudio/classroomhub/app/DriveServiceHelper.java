package com.aistudio.classroomhub.app;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.api.client.http.ByteArrayContent;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class DriveServiceHelper {

    private final Executor mExecutor = Executors.newSingleThreadExecutor();
    private final Drive mDriveService;

    public DriveServiceHelper(Drive driveService) {
        this.mDriveService = driveService;
    }

    // 1. Data JSON එකක් විදිහට Google Drive එකට Save / Backup කිරීම
    public Task<String> saveDataToDrive(String fileName, String jsonContent) {
        return Tasks.call(mExecutor, () -> {
            // පරණ File එකක් තියෙනවාදැයි පරීක්ෂා කිරීම
            FileList files = mDriveService.files().list()
                    .setSpaces("appDataFolder")
                    .setQ("name = '" + fileName + "'")
                    .execute();

            File metadata = new File()
                    .setName(fileName)
                    .setParents(Collections.singletonList("appDataFolder"));

            ByteArrayContent contentStream = new ByteArrayContent("application/json", jsonContent.getBytes());

            if (files.getFiles().isEmpty()) {
                // අලුතින්ම Save කිරීම
                File googleFile = mDriveService.files().create(metadata, contentStream).execute();
                return googleFile.getId();
            } else {
                // දැනට තියෙන File එක Update කිරීම
                String fileId = files.getFiles().get(0).getId();
                mDriveService.files().update(fileId, null, contentStream).execute();
                return fileId;
            }
        });
    }

    // 2. Google Drive එකෙන් Data Restore / Download කර ගැනීම
    public Task<String> readDataFromDrive(String fileName) {
        return Tasks.call(mExecutor, () -> {
            FileList files = mDriveService.files().list()
                    .setSpaces("appDataFolder")
                    .setQ("name = '" + fileName + "'")
                    .execute();

            if (files.getFiles().isEmpty()) {
                return null; // Backup එකක් නැත
            }

            String fileId = files.getFiles().get(0).getId();
            InputStream is = mDriveService.files().get(fileId).executeMediaAsInputStream();
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            return stringBuilder.toString();
        });
    }
}
