package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class StudentRepository {
    private static final List<Student> students = new ArrayList<>();
    // Date string (YYYY-MM-DD) -> Map<Student ID, AttendanceRecord>
    private static final Map<String, Map<String, AttendanceRecord>> attendanceRecords = new HashMap<>();

    static {
        initDefaultSampleData();
    }

    private static void initDefaultSampleData() {
        if (!students.isEmpty()) return;

        Student s1 = new Student(UUID.randomUUID().toString(), "කමල්සිරි ආනන්ද පෙරේරා", "REG-101", "Grade 10", 88, true);
        s1.setNameWithInitials("K.A. Perera");
        s1.setGender("පිරිමි");
        students.add(s1);

        Student s2 = new Student(UUID.randomUUID().toString(), "නිමල් සුනිල් සිල්වා", "REG-102", "Grade 10", 92, true);
        s2.setNameWithInitials("N.S. Silva");
        s2.setGender("පිරිමි");
        students.add(s2);

        Student s3 = new Student(UUID.randomUUID().toString(), "අමල් දිසානායක", "REG-103", "Grade 10", 75, true);
        s3.setNameWithInitials("A. Dissanayake");
        s3.setGender("පිරිමි");
        students.add(s3);

        Student s4 = new Student(UUID.randomUUID().toString(), "චාමර විජේසිංහ", "REG-104", "Grade 10", 81, true);
        s4.setNameWithInitials("C. Wijesinghe");
        s4.setGender("පිරිමි");
        students.add(s4);

        Student s5 = new Student(UUID.randomUUID().toString(), "නෙත්මි මධුෂානි ගුණවර්ධන", "REG-201", "Grade 10", 95, true);
        s5.setNameWithInitials("N.M. Gunawardhana");
        s5.setGender("ගැහැණු");
        students.add(s5);

        Student s6 = new Student(UUID.randomUUID().toString(), "කාව්‍යා සෙනෙවිරත්න", "REG-202", "Grade 10", 89, true);
        s6.setNameWithInitials("K. Seneviratne");
        s6.setGender("ගැහැණු");
        students.add(s6);

        Student s7 = new Student(UUID.randomUUID().toString(), "ඉනෝකා කුමාරි රණසිංහ", "REG-203", "Grade 10", 84, true);
        s7.setNameWithInitials("I.K. Ranasinghe");
        s7.setGender("ගැහැණු");
        students.add(s7);

        // Add some sample past attendance records for 2026
        long now = System.currentTimeMillis();
        String[] dates = {"2026-07-27", "2026-07-26", "2026-07-25", "2026-07-24", "2026-07-23"};
        for (String d : dates) {
            Map<String, AttendanceRecord> dayMap = new HashMap<>();
            for (Student s : students) {
                boolean present = (s.getId().hashCode() + d.hashCode()) % 5 != 0;
                dayMap.put(s.getId(), new AttendanceRecord(present, now - 86400000L * 2));
            }
            attendanceRecords.put(d, dayMap);
        }
    }

    public static List<Student> getStudents() {
        return students;
    }

    public static Student getStudentById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    public static void addStudent(Student student) {
        students.add(0, student);
    }

    public static void removeStudent(Student student) {
        students.remove(student);
    }

    public static void clear() {
        students.clear();
        attendanceRecords.clear();
    }

    public static Map<String, Map<String, AttendanceRecord>> getAttendanceRecords() {
        return attendanceRecords;
    }

    public static Map<String, AttendanceRecord> getAttendanceForDate(String dateStr) {
        if (!attendanceRecords.containsKey(dateStr)) {
            attendanceRecords.put(dateStr, new HashMap<>());
        }
        return attendanceRecords.get(dateStr);
    }

    public static void setAttendance(String dateStr, String studentId, boolean isPresent) {
        Map<String, AttendanceRecord> dayMap = getAttendanceForDate(dateStr);
        AttendanceRecord existing = dayMap.get(studentId);
        long timestamp = existing != null ? existing.getMarkedAtMillis() : System.currentTimeMillis();
        dayMap.put(studentId, new AttendanceRecord(isPresent, timestamp));
    }
}
