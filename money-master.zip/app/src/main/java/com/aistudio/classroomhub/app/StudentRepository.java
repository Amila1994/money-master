package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class StudentRepository {
    private static final List<Student> students = new ArrayList<>();
    // Date string (YYYY-MM-DD) -> Map<Student ID, AttendanceRecord>
    private static final Map<String, Map<String, AttendanceRecord>> attendanceRecords = new HashMap<>();

    static {
        initDefaultSampleData();
    }

    private static void initDefaultSampleData() {
        if (!students.isEmpty()) return;

        // Grade 10-A (2026) Students
        Student s1 = new Student(UUID.randomUUID().toString(), "කමල්සිරි ආනන්ද පෙරේරා", "REG-101", "Grade 10-A", 88, true);
        s1.setNameWithInitials("K.A. Perera");
        s1.setGender("පිරිමි");
        s1.setClassId("class_10a_2026");
        s1.setFatherName("ඒ. පෙරේරා මහතා");
        s1.setFatherPhone("0771234567");
        s1.setMotherName("කේ. එම්. පෙරේරා මහත්මිය");
        s1.setMotherPhone("0719876543");
        s1.setEmergencyPhone("0112345678");
        students.add(s1);

        Student s2 = new Student(UUID.randomUUID().toString(), "නිමල් සුනිල් සිල්වා", "REG-102", "Grade 10-A", 92, true);
        s2.setNameWithInitials("N.S. Silva");
        s2.setGender("පිරිමි");
        s2.setClassId("class_10a_2026");
        s2.setFatherName("එස්. සිල්වා මහතා");
        s2.setFatherPhone("0701112233");
        s2.setMotherPhone("0782223344");
        students.add(s2);

        Student s3 = new Student(UUID.randomUUID().toString(), "අමල් දිසානායක", "REG-103", "Grade 10-A", 75, true);
        s3.setNameWithInitials("A. Dissanayake");
        s3.setGender("පිරිමි");
        s3.setClassId("class_10a_2026");
        s3.setFatherPhone("0753334455");
        students.add(s3);

        Student s4 = new Student(UUID.randomUUID().toString(), "චාමර විජේසිංහ", "REG-104", "Grade 10-A", 81, true);
        s4.setNameWithInitials("C. Wijesinghe");
        s4.setGender("පිරිමි");
        s4.setClassId("class_10a_2026");
        s4.setFatherPhone("0724445566");
        students.add(s4);

        Student s5 = new Student(UUID.randomUUID().toString(), "නෙත්මි මධුෂානි ගුණවර්ධන", "REG-201", "Grade 10-A", 95, true);
        s5.setNameWithInitials("N.M. Gunawardhana");
        s5.setGender("ගැහැණු");
        s5.setClassId("class_10a_2026");
        s5.setFatherName("ආර්. ගුණවර්ධන මහතා");
        s5.setFatherPhone("0765554433");
        s5.setEmergencyPhone("0776665544");
        students.add(s5);

        Student s6 = new Student(UUID.randomUUID().toString(), "කාව්‍යා සෙනෙවිරත්න", "REG-202", "Grade 10-A", 89, true);
        s6.setNameWithInitials("K. Seneviratne");
        s6.setGender("ගැහැණු");
        s6.setClassId("class_10a_2026");
        students.add(s6);

        Student s7 = new Student(UUID.randomUUID().toString(), "ඉනෝකා කුමාරි රණසිංහ", "REG-203", "Grade 10-A", 84, true);
        s7.setNameWithInitials("I.K. Ranasinghe");
        s7.setGender("ගැහැණු");
        s7.setClassId("class_10a_2026");
        students.add(s7);

        // Grade 11-B (2027) Students
        Student s8 = new Student(UUID.randomUUID().toString(), "සහන් මධුශංක", "REG-301", "Grade 11-B", 91, true);
        s8.setNameWithInitials("S. Madushanka");
        s8.setGender("පිරිමි");
        s8.setClassId("class_11b_2027");
        students.add(s8);

        Student s9 = new Student(UUID.randomUUID().toString(), "රුවන් චතුරංග", "REG-302", "Grade 11-B", 85, true);
        s9.setNameWithInitials("R. Chathuranga");
        s9.setGender("පිරිමි");
        s9.setClassId("class_11b_2027");
        students.add(s9);

        Student s10 = new Student(UUID.randomUUID().toString(), "දිනුකා හංසනී", "REG-303", "Grade 11-B", 96, true);
        s10.setNameWithInitials("D. Hansani");
        s10.setGender("ගැහැණු");
        s10.setClassId("class_11b_2027");
        students.add(s10);

        // Grade 9-C (2025 - Archived) Students
        Student s11 = new Student(UUID.randomUUID().toString(), "කසුන් තරංග", "REG-001", "Grade 9-C", 78, false);
        s11.setNameWithInitials("K. Tharanga");
        s11.setGender("පිරිමි");
        s11.setClassId("class_9c_2025");
        students.add(s11);

        Student s12 = new Student(UUID.randomUUID().toString(), "සචිනි ප්‍රබෝධිනී", "REG-002", "Grade 9-C", 88, false);
        s12.setNameWithInitials("S. Prabodhini");
        s12.setGender("ගැහැණු");
        s12.setClassId("class_9c_2025");
        students.add(s12);

        // Add some sample past attendance records for 2026
        long now = System.currentTimeMillis();
        String[] dates = {"2026-07-27", "2026-07-26", "2026-07-25", "2026-07-24", "2026-07-23"};
        for (String d : dates) {
            Map<String, AttendanceRecord> dayMap = new HashMap<>();
            for (Student s : students) {
                boolean present = (s.getId().hashCode() + d.hashCode()) % 5 != 0;
                dayMap.put(s.getId(), new AttendanceRecord(present, now - 86400000L * 2));
            }
            attendanceRecords.put(d, dayMap);
        }
    }

    public static List<Student> getStudents() {
        ClassModel active = ClassRepository.getActiveClass();
        String activeClassId = active != null ? active.getId() : "class_10a_2026";
        return getStudentsForClass(activeClassId);
    }

    public static List<Student> getStudentsForClass(String classId) {
        List<Student> result = new ArrayList<>();
        for (Student s : students) {
            if (s.getClassId().equals(classId)) {
                result.add(s);
            }
        }
        return result;
    }

    public static List<Student> getAllStudents() {
        return students;
    }

    public static Student getStudentById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    public static void addStudent(Student student) {
        if (student.getClassId() == null || student.getClassId().isEmpty()) {
            ClassModel active = ClassRepository.getActiveClass();
            if (active != null) {
                student.setClassId(active.getId());
                student.setGrade(active.getClassName());
            }
        }
        students.add(0, student);
    }

    public static void removeStudent(Student student) {
        students.remove(student);
    }

    public static void clear() {
        students.clear();
        attendanceRecords.clear();
    }

    public static Map<String, Map<String, AttendanceRecord>> getAttendanceRecords() {
        return attendanceRecords;
    }

    public static Map<String, AttendanceRecord> getAttendanceForDate(String dateStr) {
        if (!attendanceRecords.containsKey(dateStr)) {
            attendanceRecords.put(dateStr, new HashMap<>());
        }
        return attendanceRecords.get(dateStr);
    }

    public static void setAttendance(String dateStr, String studentId, boolean isPresent) {
        Map<String, AttendanceRecord> dayMap = getAttendanceForDate(dateStr);
        AttendanceRecord existing = dayMap.get(studentId);
        long timestamp = existing != null ? existing.getMarkedAtMillis() : System.currentTimeMillis();
        dayMap.put(studentId, new AttendanceRecord(isPresent, timestamp));
    }
}
