package com.aistudio.classroomhub.app;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ExamActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TabLayout tabLayout;
    private FrameLayout tabContainer;

    private View viewTab1;
    private View viewTab2;
    private View viewTab3;

    // Tab 1 UI
    private RecyclerView rvStudentSubjects;
    private StudentSubjectAdapter studentSubjectAdapter;

    // Tab 2 UI
    private Spinner spExamType;
    private RecyclerView rvMarkEntry;
    private MarkEntryAdapter markEntryAdapter;

    // Tab 3 UI
    private TextView tvCurrentExamTitle;
    private TextView tvSummarySubtitle;
    private RecyclerView rvRankings;
    private RankingAdapter rankingAdapter;
    private LinearLayout llSubjectHighLowContainer;
    private Spinner spChartType;
    private ChartVisualizerView chartVisualizerView;

    private String currentExamType = "1 වන වාර විභාගය";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam);

        btnBack = findViewById(R.id.btnBack);
        tabLayout = findViewById(R.id.tabLayout);
        tabContainer = findViewById(R.id.tabContainer);

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        }

        setupTabs();
        loadTabViews();
        selectTab(0);
    }

    private void setupTabs() {
        tabLayout.addTab(tabLayout.newTab().setText("ශිෂ්‍යයන් & විෂයන්"));
        tabLayout.addTab(tabLayout.newTab().setText("ඉක්මන් ලකුණු"));
        tabLayout.addTab(tabLayout.newTab().setText("ප්‍රතිඵල & ප්‍රස්ථාර (12)"));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                selectTab(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void loadTabViews() {
        LayoutInflater inflater = LayoutInflater.from(this);
        viewTab1 = inflater.inflate(R.layout.tab_students_subjects, tabContainer, false);
        viewTab2 = inflater.inflate(R.layout.tab_fast_mark_entry, tabContainer, false);
        viewTab3 = inflater.inflate(R.layout.tab_results_analytics, tabContainer, false);

        initTab1();
        initTab2();
        initTab3();
    }

    private void selectTab(int position) {
        tabContainer.removeAllViews();
        if (position == 0) {
            tabContainer.addView(viewTab1);
            if (studentSubjectAdapter != null) studentSubjectAdapter.notifyDataSetChanged();
        } else if (position == 1) {
            tabContainer.addView(viewTab2);
            if (markEntryAdapter != null) markEntryAdapter.notifyDataSetChanged();
        } else {
            tabContainer.addView(viewTab3);
            refreshTab3Data();
        }
    }

    // ==========================================
    // TAB 1: Student & Subject Enrollment
    // ==========================================
    private void initTab1() {
        rvStudentSubjects = viewTab1.findViewById(R.id.rvStudentSubjects);
        rvStudentSubjects.setLayoutManager(new LinearLayoutManager(this));
        studentSubjectAdapter = new StudentSubjectAdapter();
        rvStudentSubjects.setAdapter(studentSubjectAdapter);
    }

    private class StudentSubjectAdapter extends RecyclerView.Adapter<StudentSubjectAdapter.ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exam_student_subject, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Student student = StudentRepository.getStudents().get(position);
            holder.tvStudentName.setText(student.getName());
            holder.tvStudentRollNo.setText((student.getRollNo() != null ? student.getRollNo() : "") + " | " + student.getGrade());

            List<String> enrolled = ExamRepository.getStudentSubjects(student.getId());
            holder.tvEnrolledSubjects.setText("ලියාපදිංචි විෂයයන්: " + String.join(", ", enrolled));

            View.OnClickListener clickListener = v -> showEditSubjectsDialog(student);
            holder.itemView.setOnClickListener(clickListener);
            holder.btnEditSubjects.setOnClickListener(clickListener);
        }

        @Override
        public int getItemCount() {
            return StudentRepository.getStudents().size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvStudentName, tvStudentRollNo, tvEnrolledSubjects;
            ImageView btnEditSubjects;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvStudentName = itemView.findViewById(R.id.tvStudentName);
                tvStudentRollNo = itemView.findViewById(R.id.tvStudentRollNo);
                tvEnrolledSubjects = itemView.findViewById(R.id.tvEnrolledSubjects);
                btnEditSubjects = itemView.findViewById(R.id.btnEditSubjects);
            }
        }
    }

    private void showEditSubjectsDialog(Student student) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_subjects, null);
        TextView tvTitle = dialogView.findViewById(R.id.tvDialogStudentTitle);
        EditText etCustomSub = dialogView.findViewById(R.id.etCustomSubject);
        View btnAddSub = dialogView.findViewById(R.id.btnAddSubject);
        LinearLayout llCheckboxContainer = dialogView.findViewById(R.id.llCheckboxContainer);

        if (tvTitle != null) {
            tvTitle.setText(student.getName() + " - විෂයන් තෝරන්න");
        }

        List<String> currentEnrolled = new ArrayList<>(ExamRepository.getStudentSubjects(student.getId()));
        Map<String, CheckBox> checkBoxMap = new java.util.LinkedHashMap<>();

        Runnable populateCheckboxes = new Runnable() {
            @Override
            public void run() {
                llCheckboxContainer.removeAllViews();
                checkBoxMap.clear();

                for (String sub : ExamRepository.ALL_SUBJECTS) {
                    CheckBox cb = new CheckBox(ExamActivity.this);
                    cb.setText(sub);
                    cb.setTextColor(0xFFFFFFFF);
                    cb.setTextSize(14);
                    cb.setPadding(12, 12, 12, 12);
                    boolean isChecked = currentEnrolled.contains(sub);
                    cb.setChecked(isChecked);

                    llCheckboxContainer.addView(cb);
                    checkBoxMap.put(sub, cb);
                }
            }
        };

        populateCheckboxes.run();

        if (btnAddSub != null) {
            btnAddSub.setOnClickListener(v -> {
                String newSubName = etCustomSub.getText().toString().trim();
                if (newSubName.isEmpty()) {
                    Toast.makeText(ExamActivity.this, "කරුණාකර විෂයයේ නම ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                    return;
                }
                ExamRepository.addSubjectToMasterList(newSubName);
                if (!currentEnrolled.contains(newSubName)) {
                    currentEnrolled.add(newSubName);
                }

                etCustomSub.setText("");
                populateCheckboxes.run();
                Toast.makeText(ExamActivity.this, "'" + newSubName + "' විෂයයන් අතරට එකතු කරන ලදී!", Toast.LENGTH_SHORT).show();
            });
        }

        new AlertDialog.Builder(this)
                .setView(dialogView)
                .setPositiveButton("Save (සුරකින්න)", (dialog, which) -> {
                    List<String> selected = new ArrayList<>();
                    for (Map.Entry<String, CheckBox> entry : checkBoxMap.entrySet()) {
                        if (entry.getValue().isChecked()) {
                            selected.add(entry.getKey());
                        }
                    }
                    ExamRepository.setStudentSubjects(student.getId(), selected);

                    // Instant reflection across tabs
                    if (studentSubjectAdapter != null) studentSubjectAdapter.notifyDataSetChanged();
                    if (markEntryAdapter != null) markEntryAdapter.notifyDataSetChanged();
                    refreshTab3Data();

                    Toast.makeText(ExamActivity.this, "විෂයයන් සාර්ථකව සුරකින ලදී!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("අවලංගුයි", null)
                .show();
    }

    // ==========================================
    // TAB 2: Fast Mark Entry
    // ==========================================
    private void initTab2() {
        spExamType = viewTab2.findViewById(R.id.spExamType);
        rvMarkEntry = viewTab2.findViewById(R.id.rvMarkEntry);
        View btnSave = viewTab2.findViewById(R.id.btnSaveMarks);

        String[] examTypes = new String[]{"1 වන වාර විභාගය", "2 වන වාර විභාගය", "3 වන වාර විභාගය", "ඒකක පරීක්ෂණය"};
        ArrayAdapter<String> examAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, examTypes);
        examAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spExamType.setAdapter(examAdapter);

        spExamType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentExamType = examTypes[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        rvMarkEntry.setLayoutManager(new LinearLayoutManager(this));
        markEntryAdapter = new MarkEntryAdapter();
        rvMarkEntry.setAdapter(markEntryAdapter);

        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                Toast.makeText(this, "ලකුණු සාර්ථකව සුරකින ලදී!", Toast.LENGTH_SHORT).show();
                markEntryAdapter.notifyDataSetChanged();
            });
        }
    }

    private class MarkEntryAdapter extends RecyclerView.Adapter<MarkEntryAdapter.ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exam_mark_entry, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Student student = StudentRepository.getStudents().get(position);
            holder.tvStudentTitle.setText(student.getName() + " (" + (student.getRollNo() != null ? student.getRollNo() : "") + ")");

            holder.llSubjectsContainer.removeAllViews();
            List<String> subjects = ExamRepository.getStudentSubjects(student.getId());
            Map<String, Double> marks = ExamRepository.getStudentMarks(student.getId());

            for (String sub : subjects) {
                LinearLayout row = new LinearLayout(ExamActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, 8, 0, 8);

                TextView tvSubName = new TextView(ExamActivity.this);
                tvSubName.setText(sub);
                tvSubName.setTextColor(0xFFFFFFFF);
                tvSubName.setTextSize(14);
                tvSubName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));

                EditText etMark = new EditText(ExamActivity.this);
                etMark.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                etMark.setHint("0-100");
                etMark.setTextColor(0xFF38BDF8);
                etMark.setTextSize(14);
                etMark.setBackgroundResource(android.R.drawable.edit_text);
                etMark.setPadding(16, 8, 16, 8);
                etMark.setMinimumWidth(160);

                Double val = marks.get(sub);
                if (val != null) {
                    etMark.setText(String.format("%.0f", val));
                }

                etMark.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        try {
                            double m = Double.parseDouble(s.toString().trim());
                            ExamRepository.setStudentMark(student.getId(), sub, m);
                        } catch (Exception ignored) {}
                    }

                    @Override
                    public void afterTextChanged(Editable s) {}
                });

                row.addView(tvSubName);
                row.addView(etMark);
                holder.llSubjectsContainer.addView(row);
            }
        }

        @Override
        public int getItemCount() {
            return StudentRepository.getStudents().size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvStudentTitle;
            LinearLayout llSubjectsContainer;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvStudentTitle = itemView.findViewById(R.id.tvStudentTitle);
                llSubjectsContainer = itemView.findViewById(R.id.llSubjectsContainer);
            }
        }
    }

    // ==========================================
    // TAB 3: Results & 12 Charts Analytics
    // ==========================================
    private void initTab3() {
        tvCurrentExamTitle = viewTab3.findViewById(R.id.tvCurrentExamTitle);
        tvSummarySubtitle = viewTab3.findViewById(R.id.tvSummarySubtitle);
        rvRankings = viewTab3.findViewById(R.id.rvRankings);
        llSubjectHighLowContainer = viewTab3.findViewById(R.id.llSubjectHighLowContainer);
        spChartType = viewTab3.findViewById(R.id.spChartType);
        chartVisualizerView = viewTab3.findViewById(R.id.chartVisualizerView);

        rvRankings.setLayoutManager(new LinearLayoutManager(this));
        rankingAdapter = new RankingAdapter();
        rvRankings.setAdapter(rankingAdapter);

        // Setup 12 Charts Dropdown
        String[] chartNames = new String[]{
                "1. Bar Chart (ලකුණු බාර්)",
                "2. Line Chart (වර්ධන රේඛා)",
                "3. Pie Chart (සාමාර්ථ ප්‍රතිශත)",
                "4. Doughnut Chart (විෂය බෙදී යාම)",
                "5. Radar Chart (සාපේක්ෂ දක්ෂතා)",
                "6. Polar Area Chart (විෂය ලකුණු)",
                "7. Scatter Chart (ලකුණු විග්‍රහය)",
                "8. Bubble Chart (සංසන්දනාත්මක)",
                "9. Stacked Bar Chart (එකතු කළ බාර්)",
                "10. Area Chart (ක්ෂේත්‍ර ප්‍රස්ථාරය)",
                "11. Funnel Chart (ශ්‍රේණිගත කිරීම්)",
                "12. Gauge Chart (මධ්‍යන්‍ය දර්ශකය)"
        };

        ArrayAdapter<String> chartAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, chartNames);
        chartAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spChartType.setAdapter(chartAdapter);

        spChartType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (chartVisualizerView != null) {
                    chartVisualizerView.setChartType(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void refreshTab3Data() {
        if (tvCurrentExamTitle != null) {
            tvCurrentExamTitle.setText("විභාගය: " + currentExamType);
        }

        List<ExamRepository.StudentExamResult> ranked = ExamRepository.getRankedResults();
        double totalClassAvg = 0.0;
        for (ExamRepository.StudentExamResult r : ranked) {
            totalClassAvg += r.averageMarks;
        }
        double classAvg = ranked.isEmpty() ? 0.0 : totalClassAvg / ranked.size();

        if (tvSummarySubtitle != null) {
            tvSummarySubtitle.setText("මුළු ශිෂ්‍යයන්: " + ranked.size() + " | පන්තියේ මධ්‍යන්‍යය: " + String.format("%.1f%%", classAvg));
        }

        if (rankingAdapter != null) {
            rankingAdapter.updateData(ranked);
        }

        // Populate High/Low per Subject
        if (llSubjectHighLowContainer != null) {
            llSubjectHighLowContainer.removeAllViews();
            List<ExamRepository.SubjectStat> stats = ExamRepository.getSubjectStats();

            for (ExamRepository.SubjectStat stat : stats) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackgroundColor(0xFF1E293B);
                card.setPadding(16, 12, 16, 12);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, 8);
                card.setLayoutParams(lp);

                TextView tvSubHeader = new TextView(this);
                tvSubHeader.setText(stat.subject);
                tvSubHeader.setTextColor(0xFF38BDF8);
                tvSubHeader.setTextSize(14);
                tvSubHeader.setTypeface(null, android.graphics.Typeface.BOLD);

                TextView tvHigh = new TextView(this);
                tvHigh.setText("වැඩිම: " + (stat.highestStudentName != null ? stat.highestStudentName : "-") + " (" + String.format("%.0f", stat.highestMark) + ")");
                tvHigh.setTextColor(0xFF4ADE80);
                tvHigh.setTextSize(12);

                TextView tvLow = new TextView(this);
                tvLow.setText("අඩුම: " + (stat.lowestStudentName != null ? stat.lowestStudentName : "-") + " (" + String.format("%.0f", stat.lowestMark) + ")");
                tvLow.setTextColor(0xFFF43F5E);
                tvLow.setTextSize(12);

                card.addView(tvSubHeader);
                card.addView(tvHigh);
                card.addView(tvLow);
                llSubjectHighLowContainer.addView(card);
            }
        }

        if (chartVisualizerView != null) {
            chartVisualizerView.invalidate();
        }
    }

    private class RankingAdapter extends RecyclerView.Adapter<RankingAdapter.ViewHolder> {

        private List<ExamRepository.StudentExamResult> list = new ArrayList<>();

        public void updateData(List<ExamRepository.StudentExamResult> newList) {
            this.list = newList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exam_result_card, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ExamRepository.StudentExamResult res = list.get(position);
            holder.tvRankBadge.setText("#" + res.rank);
            holder.tvStudentNameRank.setText(res.student.getName());
            holder.tvResultSummary.setText(String.format("එකතුව: %.0f | මධ්‍යන්‍යය: %.1f%%", res.totalMarks, res.averageMarks));

            StringBuilder breakdown = new StringBuilder();
            for (Map.Entry<String, Double> entry : res.marks.entrySet()) {
                String g = ExamRepository.calculateGrade(entry.getValue());
                if (breakdown.length() > 0) breakdown.append(" | ");
                breakdown.append(entry.getKey()).append(": ").append(String.format("%.0f", entry.getValue())).append(" (").append(g).append(")");
            }
            holder.tvGradesBreakdown.setText(breakdown.toString());

            if (res.progressGrowth >= 0) {
                holder.tvProgressGrowth.setText(String.format("+%.0f 📈", res.progressGrowth));
                holder.tvProgressGrowth.setTextColor(0xFF4ADE80);
            } else {
                holder.tvProgressGrowth.setText(String.format("%.0f 📉", res.progressGrowth));
                holder.tvProgressGrowth.setTextColor(0xFFF43F5E);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvRankBadge, tvStudentNameRank, tvResultSummary, tvGradesBreakdown, tvProgressGrowth;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvRankBadge = itemView.findViewById(R.id.tvRankBadge);
                tvStudentNameRank = itemView.findViewById(R.id.tvStudentNameRank);
                tvResultSummary = itemView.findViewById(R.id.tvResultSummary);
                tvGradesBreakdown = itemView.findViewById(R.id.tvGradesBreakdown);
                tvProgressGrowth = itemView.findViewById(R.id.tvProgressGrowth);
            }
        }
    }
}
