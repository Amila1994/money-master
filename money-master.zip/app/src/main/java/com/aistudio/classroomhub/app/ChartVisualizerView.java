package com.aistudio.classroomhub.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChartVisualizerView extends View {

    private int chartType = 0; // 0 to 11
    private Paint paint;
    private Paint textPaint;
    private Path path;
    private RectF rectF;

    private final int[] colors = new int[]{
            Color.parseColor("#38BDF8"), // Cyan
            Color.parseColor("#4ADE80"), // Green
            Color.parseColor("#FACC15"), // Yellow
            Color.parseColor("#F43F5E"), // Red
            Color.parseColor("#A855F7"), // Purple
            Color.parseColor("#FB923C")  // Orange
    };

    public ChartVisualizerView(Context context) {
        super(context);
        init();
    }

    public ChartVisualizerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ChartVisualizerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(28f);
        path = new Path();
        rectF = new RectF();
    }

    public void setChartType(int type) {
        this.chartType = type;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();
        int height = getHeight();

        if (width <= 0 || height <= 0) return;

        List<ExamRepository.StudentExamResult> ranked = ExamRepository.getRankedResults();
        List<ExamRepository.SubjectStat> stats = ExamRepository.getSubjectStats();

        switch (chartType) {
            case 0:
                drawBarChart(canvas, width, height, ranked);
                break;
            case 1:
                drawLineChart(canvas, width, height, ranked);
                break;
            case 2:
                drawPieChart(canvas, width, height, ranked);
                break;
            case 3:
                drawDoughnutChart(canvas, width, height, stats);
                break;
            case 4:
                drawRadarChart(canvas, width, height, stats);
                break;
            case 5:
                drawPolarAreaChart(canvas, width, height, stats);
                break;
            case 6:
                drawScatterChart(canvas, width, height, ranked);
                break;
            case 7:
                drawBubbleChart(canvas, width, height, ranked);
                break;
            case 8:
                drawStackedBarChart(canvas, width, height, ranked);
                break;
            case 9:
                drawAreaChart(canvas, width, height, ranked);
                break;
            case 10:
                drawFunnelChart(canvas, width, height, ranked);
                break;
            case 11:
            default:
                drawGaugeChart(canvas, width, height, ranked);
                break;
        }
    }

    // 0. Bar Chart
    private void drawBarChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        int count = Math.min(ranked.size(), 6);
        if (count == 0) return;

        float paddingLeft = 60f;
        float paddingBottom = 60f;
        float chartW = w - paddingLeft - 40f;
        float chartH = h - paddingBottom - 40f;

        // Axis
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#334155"));
        paint.setStrokeWidth(3f);
        canvas.drawLine(paddingLeft, 20f, paddingLeft, h - paddingBottom, paint);
        canvas.drawLine(paddingLeft, h - paddingBottom, w - 20f, h - paddingBottom, paint);

        float barWidth = chartW / (count * 1.8f);
        float spacing = barWidth * 0.8f;

        for (int i = 0; i < count; i++) {
            ExamRepository.StudentExamResult res = ranked.get(i);
            float ratio = (float) (res.averageMarks / 100.0);
            float barH = chartH * ratio;

            float left = paddingLeft + spacing / 2 + i * (barWidth + spacing);
            float top = (h - paddingBottom) - barH;
            float right = left + barWidth;
            float bottom = h - paddingBottom;

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors[i % colors.length]);
            rectF.set(left, top, right, bottom);
            canvas.drawRoundRect(rectF, 12f, 12f, paint);

            textPaint.setTextSize(22f);
            textPaint.setColor(Color.WHITE);
            String label = res.student.getName().split(" ")[0];
            if (label.length() > 5) label = label.substring(0, 5);
            canvas.drawText(label, left, h - 20f, textPaint);

            textPaint.setColor(colors[i % colors.length]);
            canvas.drawText(String.format("%.0f%%", res.averageMarks), left, top - 10f, textPaint);
        }
    }

    // 1. Line Chart
    private void drawLineChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        int count = Math.min(ranked.size(), 6);
        if (count < 2) return;

        float paddingLeft = 60f;
        float paddingBottom = 60f;
        float chartW = w - paddingLeft - 40f;
        float chartH = h - paddingBottom - 40f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#334155"));
        paint.setStrokeWidth(3f);
        canvas.drawLine(paddingLeft, 20f, paddingLeft, h - paddingBottom, paint);
        canvas.drawLine(paddingLeft, h - paddingBottom, w - 20f, h - paddingBottom, paint);

        float stepX = chartW / (count - 1);
        path.reset();

        for (int i = 0; i < count; i++) {
            ExamRepository.StudentExamResult res = ranked.get(i);
            float x = paddingLeft + i * stepX;
            float y = (h - paddingBottom) - (chartH * (float) (res.averageMarks / 100.0));

            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);

            // Points
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.parseColor("#38BDF8"));
            canvas.drawCircle(x, y, 10f, paint);

            textPaint.setTextSize(22f);
            textPaint.setColor(Color.WHITE);
            canvas.drawText(String.format("%.0f", res.averageMarks), x - 15f, y - 15f, textPaint);
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#38BDF8"));
        paint.setStrokeWidth(6f);
        canvas.drawPath(path, paint);
    }

    // 2. Pie Chart
    private void drawPieChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        // Grade Distribution A, B, C, S, F
        Map<String, Integer> gradeCount = new HashMap<>();
        gradeCount.put("A", 0); gradeCount.put("B", 0); gradeCount.put("C", 0); gradeCount.put("S", 0); gradeCount.put("F", 0);

        int total = 0;
        for (ExamRepository.StudentExamResult r : ranked) {
            for (Double m : r.marks.values()) {
                String g = GradeBoundaryManager.calculateGrade(getContext(), m);
                gradeCount.put(g, gradeCount.get(g) + 1);
                total++;
            }
        }
        if (total == 0) return;

        float size = Math.min(w, h) * 0.7f;
        float cx = w / 2f;
        float cy = h / 2f;
        rectF.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2);

        float startAngle = -90f;
        String[] grades = new String[]{"A", "B", "C", "S", "F"};

        for (int i = 0; i < grades.length; i++) {
            String g = grades[i];
            int count = gradeCount.get(g);
            float sweepAngle = (count / (float) total) * 360f;

            if (sweepAngle > 0) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(colors[i % colors.length]);
                canvas.drawArc(rectF, startAngle, sweepAngle, true, paint);

                // Label
                float midAngle = (float) Math.toRadians(startAngle + sweepAngle / 2);
                float labelX = (float) (cx + (size / 3) * Math.cos(midAngle));
                float labelY = (float) (cy + (size / 3) * Math.sin(midAngle));

                textPaint.setTextSize(24f);
                textPaint.setColor(Color.parseColor("#0F172A"));
                textPaint.setFakeBoldText(true);
                canvas.drawText(g + " (" + count + ")", labelX - 20f, labelY + 8f, textPaint);

                startAngle += sweepAngle;
            }
        }
    }

    // 3. Doughnut Chart
    private void drawDoughnutChart(Canvas canvas, int w, int h, List<ExamRepository.SubjectStat> stats) {
        if (stats.isEmpty()) return;

        float size = Math.min(w, h) * 0.75f;
        float cx = w / 2f;
        float cy = h / 2f;
        rectF.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2);

        float totalAvg = 0;
        for (ExamRepository.SubjectStat s : stats) totalAvg += s.averageMark;

        float startAngle = -90f;
        for (int i = 0; i < stats.size(); i++) {
            ExamRepository.SubjectStat s = stats.get(i);
            float sweepAngle = (float) ((s.averageMark / totalAvg) * 360f);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors[i % colors.length]);
            canvas.drawArc(rectF, startAngle, sweepAngle, true, paint);

            startAngle += sweepAngle;
        }

        // Inner Hole for Doughnut
        paint.setColor(Color.parseColor("#1E293B"));
        canvas.drawCircle(cx, cy, size * 0.35f, paint);

        textPaint.setTextSize(28f);
        textPaint.setColor(Color.parseColor("#38BDF8"));
        textPaint.setFakeBoldText(true);
        canvas.drawText("විෂයයන්", cx - 45f, cy + 10f, textPaint);
    }

    // 4. Radar Chart
    private void drawRadarChart(Canvas canvas, int w, int h, List<ExamRepository.SubjectStat> stats) {
        int n = Math.max(stats.size(), 3);
        float cx = w / 2f;
        float cy = h / 2f;
        float radius = Math.min(w, h) * 0.35f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#334155"));
        paint.setStrokeWidth(2f);

        // Concentric Polygons
        for (int level = 1; level <= 3; level++) {
            float r = radius * (level / 3f);
            path.reset();
            for (int i = 0; i < n; i++) {
                double angle = Math.toRadians(i * (360.0 / n) - 90);
                float x = (float) (cx + r * Math.cos(angle));
                float y = (float) (cy + r * Math.sin(angle));
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            path.close();
            canvas.drawPath(path, paint);
        }

        // Radar Web Lines & Data Polygon
        path.reset();
        for (int i = 0; i < n; i++) {
            double angle = Math.toRadians(i * (360.0 / n) - 90);
            float x = (float) (cx + radius * Math.cos(angle));
            float y = (float) (cy + radius * Math.sin(angle));
            canvas.drawLine(cx, cy, x, y, paint);

            double avg = i < stats.size() ? stats.get(i).averageMark : 70.0;
            float dataR = radius * (float) (avg / 100.0);
            float dataX = (float) (cx + dataR * Math.cos(angle));
            float dataY = (float) (cy + dataR * Math.sin(angle));

            if (i == 0) path.moveTo(dataX, dataY);
            else path.lineTo(dataX, dataY);

            textPaint.setTextSize(20f);
            textPaint.setColor(Color.WHITE);
            String label = i < stats.size() ? stats.get(i).subject : "Sub " + i;
            canvas.drawText(label, x - 25f, y + 10f, textPaint);
        }
        path.close();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#5038BDF8"));
        canvas.drawPath(path, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#38BDF8"));
        paint.setStrokeWidth(4f);
        canvas.drawPath(path, paint);
    }

    // 5. Polar Area Chart
    private void drawPolarAreaChart(Canvas canvas, int w, int h, List<ExamRepository.SubjectStat> stats) {
        int n = Math.max(stats.size(), 3);
        float cx = w / 2f;
        float cy = h / 2f;
        float maxRadius = Math.min(w, h) * 0.38f;
        float angleStep = 360f / n;

        float startAngle = -90f;
        for (int i = 0; i < n; i++) {
            double avg = i < stats.size() ? stats.get(i).averageMark : 70.0;
            float r = maxRadius * (float) (avg / 100.0);

            rectF.set(cx - r, cy - r, cx + r, cy + r);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors[i % colors.length]);
            paint.setAlpha(180);
            canvas.drawArc(rectF, startAngle, angleStep, true, paint);

            startAngle += angleStep;
        }
    }

    // 6. Scatter Chart
    private void drawScatterChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        float paddingLeft = 60f;
        float paddingBottom = 60f;
        float chartW = w - paddingLeft - 40f;
        float chartH = h - paddingBottom - 40f;

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#334155"));
        paint.setStrokeWidth(3f);
        canvas.drawLine(paddingLeft, 20f, paddingLeft, h - paddingBottom, paint);
        canvas.drawLine(paddingLeft, h - paddingBottom, w - 20f, h - paddingBottom, paint);

        for (int i = 0; i < ranked.size(); i++) {
            ExamRepository.StudentExamResult r = ranked.get(i);
            float x = paddingLeft + (i + 1) * (chartW / (ranked.size() + 1));
            float y = (h - paddingBottom) - (chartH * (float) (r.averageMarks / 100.0));

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors[i % colors.length]);
            canvas.drawCircle(x, y, 14f, paint);

            textPaint.setTextSize(20f);
            textPaint.setColor(Color.WHITE);
            canvas.drawText("#" + r.rank, x - 10f, y - 18f, textPaint);
        }
    }

    // 7. Bubble Chart
    private void drawBubbleChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        float paddingLeft = 60f;
        float paddingBottom = 60f;
        float chartW = w - paddingLeft - 40f;
        float chartH = h - paddingBottom - 40f;

        for (int i = 0; i < Math.min(ranked.size(), 5); i++) {
            ExamRepository.StudentExamResult r = ranked.get(i);
            float x = paddingLeft + (i + 1) * (chartW / 6f);
            float y = (h - paddingBottom) - (chartH * (float) (r.averageMarks / 100.0));
            float radius = 25f + (float) (r.totalMarks / 15.0);

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors[i % colors.length]);
            paint.setAlpha(160);
            canvas.drawCircle(x, y, radius, paint);

            textPaint.setTextSize(22f);
            textPaint.setColor(Color.WHITE);
            canvas.drawText(r.student.getName().split(" ")[0], x - 20f, y + 6f, textPaint);
        }
    }

    // 8. Stacked Bar Chart
    private void drawStackedBarChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        int count = Math.min(ranked.size(), 5);
        if (count == 0) return;

        float paddingLeft = 60f;
        float paddingBottom = 60f;
        float chartW = w - paddingLeft - 40f;
        float chartH = h - paddingBottom - 40f;

        float barWidth = chartW / (count * 1.8f);
        float spacing = barWidth * 0.8f;

        for (int i = 0; i < count; i++) {
            ExamRepository.StudentExamResult res = ranked.get(i);
            float left = paddingLeft + spacing / 2 + i * (barWidth + spacing);
            float right = left + barWidth;
            float currentBottom = h - paddingBottom;

            int subIndex = 0;
            for (Double mark : res.marks.values()) {
                float segmentH = (chartH * 0.2f) * (float) (mark / 100.0);
                float top = currentBottom - segmentH;

                paint.setStyle(Paint.Style.FILL);
                paint.setColor(colors[subIndex % colors.length]);
                rectF.set(left, top, right, currentBottom);
                canvas.drawRect(rectF, paint);

                currentBottom = top;
                subIndex++;
            }
        }
    }

    // 9. Area Chart
    private void drawAreaChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        int count = Math.min(ranked.size(), 6);
        if (count < 2) return;

        float paddingLeft = 60f;
        float paddingBottom = 60f;
        float chartW = w - paddingLeft - 40f;
        float chartH = h - paddingBottom - 40f;

        float stepX = chartW / (count - 1);
        path.reset();

        float firstX = paddingLeft;
        float firstY = (h - paddingBottom) - (chartH * (float) (ranked.get(0).averageMarks / 100.0));
        path.moveTo(firstX, firstY);

        for (int i = 1; i < count; i++) {
            float x = paddingLeft + i * stepX;
            float y = (h - paddingBottom) - (chartH * (float) (ranked.get(i).averageMarks / 100.0));
            path.lineTo(x, y);
        }

        // Close Path for Area Fill
        float lastX = paddingLeft + (count - 1) * stepX;
        path.lineTo(lastX, h - paddingBottom);
        path.lineTo(firstX, h - paddingBottom);
        path.close();

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.parseColor("#6038BDF8"));
        canvas.drawPath(path, paint);
    }

    // 10. Funnel Chart
    private void drawFunnelChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        // Grade Tiers A, B, C, S, F
        int[] counts = new int[]{0, 0, 0, 0, 0};
        String[] tiers = new String[]{"A Tier", "B Tier", "C Tier", "S Tier", "F Tier"};

        int aMin = GradeBoundaryManager.getAMin(getContext());
        int bMin = GradeBoundaryManager.getBMin(getContext());
        int cMin = GradeBoundaryManager.getCMin(getContext());
        int sMin = GradeBoundaryManager.getSMin(getContext());

        for (ExamRepository.StudentExamResult r : ranked) {
            for (Double m : r.marks.values()) {
                if (m >= aMin) counts[0]++;
                else if (m >= bMin) counts[1]++;
                else if (m >= cMin) counts[2]++;
                else if (m >= sMin) counts[3]++;
                else counts[4]++;
            }
        }

        float topW = w * 0.75f;
        float cy = 30f;
        float stageH = (h - 60f) / 5f;

        for (int i = 0; i < 5; i++) {
            float currentW = topW * (1.0f - i * 0.15f);
            float nextW = topW * (1.0f - (i + 1) * 0.15f);

            float cx = w / 2f;
            path.reset();
            path.moveTo(cx - currentW / 2, cy);
            path.lineTo(cx + currentW / 2, cy);
            path.lineTo(cx + nextW / 2, cy + stageH - 5f);
            path.lineTo(cx - nextW / 2, cy + stageH - 5f);
            path.close();

            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors[i % colors.length]);
            canvas.drawPath(path, paint);

            textPaint.setTextSize(22f);
            textPaint.setColor(Color.WHITE);
            canvas.drawText(tiers[i] + ": " + counts[i], cx - 40f, cy + stageH / 2 + 5f, textPaint);

            cy += stageH;
        }
    }

    // 11. Gauge Chart
    private void drawGaugeChart(Canvas canvas, int w, int h, List<ExamRepository.StudentExamResult> ranked) {
        double totalAvg = 0;
        for (ExamRepository.StudentExamResult r : ranked) totalAvg += r.averageMarks;
        double overallAvg = ranked.isEmpty() ? 75.0 : totalAvg / ranked.size();

        float size = Math.min(w, h) * 0.8f;
        float cx = w / 2f;
        float cy = h * 0.75f;
        rectF.set(cx - size / 2, cy - size / 2, cx + size / 2, cy + size / 2);

        // Arc Background
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(30f);
        paint.setColor(Color.parseColor("#334155"));
        canvas.drawArc(rectF, 180f, 180f, false, paint);

        // Progress Arc
        float sweep = (float) ((overallAvg / 100.0) * 180f);
        paint.setColor(Color.parseColor("#38BDF8"));
        canvas.drawArc(rectF, 180f, sweep, false, paint);

        // Needle
        double needleAngle = Math.toRadians(180 + sweep);
        float nx = (float) (cx + (size * 0.38f) * Math.cos(needleAngle));
        float ny = (float) (cy + (size * 0.38f) * Math.sin(needleAngle));

        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.parseColor("#FACC15"));
        paint.setStrokeWidth(8f);
        canvas.drawLine(cx, cy, nx, ny, paint);

        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(cx, cy, 14f, paint);

        textPaint.setTextSize(36f);
        textPaint.setColor(Color.WHITE);
        textPaint.setFakeBoldText(true);
        canvas.drawText(String.format("මධ්‍යන්‍යය: %.1f%%", overallAvg), cx - 110f, cy + 50f, textPaint);
    }
}
