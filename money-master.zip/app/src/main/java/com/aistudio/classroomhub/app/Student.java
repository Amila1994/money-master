package com.aistudio.classroomhub.app;

public class Student {
    private String id;
    private String name;
    private String nameWithInitials;
    private String rollNo;
    private String grade;
    private String classId;
    private int marks;
    private boolean isPresent;

    private String dob;
    private String gender;
    private String placeOfBirth;
    private String ethnicity;
    private String religion;
    private String birthCertNo;
    private String medium;
    private String permAddress;
    private String fatherName;
    private String fatherNic;
    private String fatherPhone;
    private String motherName;
    private String motherNic;
    private String motherPhone;
    private String guardianName;
    private String emergencyName;
    private String emergencyRelation;
    private String emergencyPhone;

    public Student(String id, String name, String rollNo, String grade, int marks, boolean isPresent) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.grade = grade;
        this.marks = marks;
        this.isPresent = isPresent;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameWithInitials() {
        return nameWithInitials;
    }

    public void setNameWithInitials(String nameWithInitials) {
        this.nameWithInitials = nameWithInitials;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getClassId() {
        return classId != null ? classId : "class_10a_2026";
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public boolean isPresent() {
        return isPresent;
    }

    public void setPresent(boolean present) {
        isPresent = present;
    }

    public String getDob() { return dob; }
    public void setDob(String dob) { this.dob = dob; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getPlaceOfBirth() { return placeOfBirth; }
    public void setPlaceOfBirth(String placeOfBirth) { this.placeOfBirth = placeOfBirth; }

    public String getEthnicity() { return ethnicity; }
    public void setEthnicity(String ethnicity) { this.ethnicity = ethnicity; }

    public String getReligion() { return religion; }
    public void setReligion(String religion) { this.religion = religion; }

    public String getBirthCertNo() { return birthCertNo; }
    public void setBirthCertNo(String birthCertNo) { this.birthCertNo = birthCertNo; }

    public String getMedium() { return medium; }
    public void setMedium(String medium) { this.medium = medium; }

    public String getPermAddress() { return permAddress; }
    public void setPermAddress(String permAddress) { this.permAddress = permAddress; }

    public String getFatherName() { return fatherName; }
    public void setFatherName(String fatherName) { this.fatherName = fatherName; }

    public String getFatherNic() { return fatherNic; }
    public void setFatherNic(String fatherNic) { this.fatherNic = fatherNic; }

    public String getFatherPhone() { return fatherPhone; }
    public void setFatherPhone(String fatherPhone) { this.fatherPhone = fatherPhone; }

    public String getMotherName() { return motherName; }
    public void setMotherName(String motherName) { this.motherName = motherName; }

    public String getMotherNic() { return motherNic; }
    public void setMotherNic(String motherNic) { this.motherNic = motherNic; }

    public String getMotherPhone() { return motherPhone; }
    public void setMotherPhone(String motherPhone) { this.motherPhone = motherPhone; }

    public String getGuardianName() { return guardianName; }
    public void setGuardianName(String guardianName) { this.guardianName = guardianName; }

    public String getEmergencyName() { return emergencyName; }
    public void setEmergencyName(String emergencyName) { this.emergencyName = emergencyName; }

    public String getEmergencyRelation() { return emergencyRelation; }
    public void setEmergencyRelation(String emergencyRelation) { this.emergencyRelation = emergencyRelation; }

    public String getEmergencyPhone() { return emergencyPhone; }
    public void setEmergencyPhone(String emergencyPhone) { this.emergencyPhone = emergencyPhone; }

    public String getGradeBadge() {
        if (marks >= 90) return marks + "% (A+)";
        if (marks >= 80) return marks + "% (A)";
        if (marks >= 70) return marks + "% (B)";
        if (marks >= 60) return marks + "% (C)";
        if (marks >= 50) return marks + "% (D)";
        return marks + "% (F)";
    }
}
