package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.aistudio.classroomhub.app.db.AppDatabase;
import com.aistudio.classroomhub.app.db.BackupEntity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

public class DataBackupManager {

    private static final String TAG = "DataBackupManager";
    private static final String LOCAL_BACKUP_FILE = "classroom_master_local.json";
    public static final String PREFS_SYNC = "ClassroomHubSyncPrefs";
    public static final String KEY_LAST_SYNC_TIME = "last_sync_time";
    public static final String KEY_IS_RESTORED = "is_data_restored_v2";

    /**
     * Serializes all current app data into a comprehensive JSON string.
     */
    public static String exportAllDataToJson(Context context) {
        try {
            JSONObject root = new JSONObject();
            root.put("version", 2);
            root.put("timestamp", System.currentTimeMillis());

            // 1. Classes & Active Class
            JSONArray classesArray = new JSONArray();
            List<ClassModel> classList = ClassRepository.getClasses();
            for (ClassModel c : classList) {
                JSONObject obj = new JSONObject();
                obj.put("id", c.getId());
                obj.put("className", c.getClassName());
                obj.put("academicYear", c.getAcademicYear());
                obj.put("role", c.getRole());
                obj.put("isArchived", c.isArchived());
                classesArray.put(obj);
            }
            root.put("classes", classesArray);

            ClassModel active = ClassRepository.getActiveClass();
            root.put("activeClassId", active != null ? active.getId() : "");

            // 2. Students List & Details
            JSONArray studentsArray = new JSONArray();
            List<Student> allStudents = StudentRepository.getAllStudents();
            for (Student s : allStudents) {
                JSONObject obj = new JSONObject();
                obj.put("id", s.getId());
                obj.put("name", s.getName());
                obj.put("rollNo", s.getRollNo());
                obj.put("grade", s.getGrade());
                obj.put("marks", s.getMarks());
                obj.put("present", s.isPresent());
                obj.put("classId", s.getClassId());

                if (s.getNameWithInitials() != null) obj.put("nameWithInitials", s.getNameWithInitials());
                if (s.getDob() != null) obj.put("dob", s.getDob());
                if (s.getGender() != null) obj.put("gender", s.getGender());
                if (s.getPlaceOfBirth() != null) obj.put("placeOfBirth", s.getPlaceOfBirth());
                if (s.getEthnicity() != null) obj.put("ethnicity", s.getEthnicity());
                if (s.getReligion() != null) obj.put("religion", s.getReligion());
                if (s.getBirthCertNo() != null) obj.put("birthCertNo", s.getBirthCertNo());
                if (s.getMedium() != null) obj.put("medium", s.getMedium());
                if (s.getPermAddress() != null) obj.put("permAddress", s.getPermAddress());

                if (s.getFatherName() != null) obj.put("fatherName", s.getFatherName());
                if (s.getFatherNic() != null) obj.put("fatherNic", s.getFatherNic());
                if (s.getFatherPhone() != null) obj.put("fatherPhone", s.getFatherPhone());
                if (s.getMotherName() != null) obj.put("motherName", s.getMotherName());
                if (s.getMotherNic() != null) obj.put("motherNic", s.getMotherNic());
                if (s.getMotherPhone() != null) obj.put("motherPhone", s.getMotherPhone());
                if (s.getGuardianName() != null) obj.put("guardianName", s.getGuardianName());

                if (s.getEmergencyName() != null) obj.put("emergencyName", s.getEmergencyName());
                if (s.getEmergencyRelation() != null) obj.put("emergencyRelation", s.getEmergencyRelation());
                if (s.getEmergencyPhone() != null) obj.put("emergencyPhone", s.getEmergencyPhone());

                studentsArray.put(obj);
            }
            root.put("students", studentsArray);

            // 3. Attendance Records
            JSONObject attendanceObj = new JSONObject();
            Map<String, Map<String, AttendanceRecord>> attendanceMap = StudentRepository.getAttendanceRecords();
            for (Map.Entry<String, Map<String, AttendanceRecord>> dateEntry : attendanceMap.entrySet()) {
                JSONObject dateRecords = new JSONObject();
                for (Map.Entry<String, AttendanceRecord> sEntry : dateEntry.getValue().entrySet()) {
                    JSONObject recObj = new JSONObject();
                    recObj.put("isPresent", sEntry.getValue().isPresent());
                    recObj.put("markedAt", sEntry.getValue().getMarkedAtMillis());
                    dateRecords.put(sEntry.getKey(), recObj);
                }
                attendanceObj.put(dateEntry.getKey(), dateRecords);
            }
            root.put("attendance", attendanceObj);

            // 4. Exam Data (Subjects & Marks)
            JSONArray customSubjectsArray = new JSONArray();
            for (String sub : ExamRepository.ALL_SUBJECTS) {
                customSubjectsArray.put(sub);
            }
            root.put("allSubjects", customSubjectsArray);

            JSONObject studentMarksObj = new JSONObject();
            JSONObject studentSubjectsObj = new JSONObject();
            JSONObject previousTotalsObj = new JSONObject();

            for (Student s : allStudents) {
                String sid = s.getId();
                // Marks
                Map<String, Double> marks = ExamRepository.getStudentMarks(sid);
                if (marks != null && !marks.isEmpty()) {
                    JSONObject marksMapObj = new JSONObject();
                    for (Map.Entry<String, Double> me : marks.entrySet()) {
                        marksMapObj.put(me.getKey(), me.getValue());
                    }
                    studentMarksObj.put(sid, marksMapObj);
                }
                // Selected subjects
                List<String> subjects = ExamRepository.getStudentSubjects(sid);
                if (subjects != null && !subjects.isEmpty()) {
                    JSONArray subsArray = new JSONArray();
                    for (String sub : subjects) subsArray.put(sub);
                    studentSubjectsObj.put(sid, subsArray);
                }
                // Previous total
                double prevTotal = ExamRepository.getPreviousExamTotal(sid);
                previousTotalsObj.put(sid, prevTotal);
            }
            root.put("studentMarks", studentMarksObj);
            root.put("studentSubjects", studentSubjectsObj);
            root.put("previousExamTotals", previousTotalsObj);

            // 5. Timetable Entries
            JSONArray timetableArray = new JSONArray();
            List<ClassTimetableEntry> ttEntries = ClassTimetableRepository.getEntries();
            for (ClassTimetableEntry tte : ttEntries) {
                JSONObject obj = new JSONObject();
                obj.put("id", tte.getId());
                obj.put("day", tte.getDay());
                obj.put("periodName", tte.getPeriodName());
                obj.put("startHour", tte.getStartHour());
                obj.put("startMinute", tte.getStartMinute());
                obj.put("endHour", tte.getEndHour());
                obj.put("endMinute", tte.getEndMinute());
                obj.put("subject", tte.getSubject());
                obj.put("teacherName", tte.getTeacherName());
                obj.put("roomNo", tte.getRoomNo());
                timetableArray.put(obj);
            }
            root.put("timetable", timetableArray);

            // 6. Grade Cutoffs
            if (context != null) {
                JSONObject cutoffs = new JSONObject();
                cutoffs.put("A", GradeBoundaryManager.getAMin(context));
                cutoffs.put("B", GradeBoundaryManager.getBMin(context));
                cutoffs.put("C", GradeBoundaryManager.getCMin(context));
                cutoffs.put("S", GradeBoundaryManager.getSMin(context));
                root.put("gradeCutoffs", cutoffs);
            }

            return root.toString(2);
        } catch (Exception e) {
            Log.e(TAG, "Error exporting data to JSON", e);
            return "{}";
        }
    }

    /**
     * Saves local data state to Room Database and local storage file (Offline-First).
     */
    public static void saveLocalState(Context context) {
        if (context == null) return;
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                String jsonStr = exportAllDataToJson(context);
                if (jsonStr == null || jsonStr.trim().isEmpty() || jsonStr.equals("{}")) return;

                // 1. Save to Room Database
                BackupEntity entity = new BackupEntity(1, jsonStr, System.currentTimeMillis(), false);
                AppDatabase.getInstance(context).backupDao().insertOrUpdateBackup(entity);

                // 2. Save to internal file cache
                File file = new File(context.getFilesDir(), LOCAL_BACKUP_FILE);
                try (FileOutputStream fos = new FileOutputStream(file)) {
                    fos.write(jsonStr.getBytes());
                }

                Log.d(TAG, "Local state saved successfully to Room & file.");
            } catch (Exception e) {
                Log.e(TAG, "Failed to save local state", e);
            }
        });
    }

    /**
     * Restores local state from Room Database or local file cache.
     */
    public static boolean loadLocalState(Context context) {
        if (context == null) return false;
        try {
            // 1. Try reading from Room Database
            BackupEntity backup = AppDatabase.getInstance(context).backupDao().getBackup();
            if (backup != null && backup.jsonContent != null && !backup.jsonContent.isEmpty()) {
                return restoreDataFromJson(context, backup.jsonContent);
            }

            // 2. Fallback to local internal file
            File file = new File(context.getFilesDir(), LOCAL_BACKUP_FILE);
            if (file.exists()) {
                StringBuilder sb = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                }
                String jsonStr = sb.toString();
                if (!jsonStr.isEmpty()) {
                    return restoreDataFromJson(context, jsonStr);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to load local state", e);
        }
        return false;
    }

    /**
     * Parses JSON backup and hydrates all application repositories & Room DB state.
     */
    public static boolean restoreDataFromJson(Context context, String jsonStr) {
        if (jsonStr == null || jsonStr.trim().isEmpty() || jsonStr.equals("{}")) {
            return false;
        }

        try {
            JSONObject root = new JSONObject(jsonStr);

            // 1. Restore Classes
            if (root.has("classes")) {
                JSONArray classesArray = root.getJSONArray("classes");
                List<ClassModel> newClasses = new ArrayList<>();
                for (int i = 0; i < classesArray.length(); i++) {
                    JSONObject obj = classesArray.getJSONObject(i);
                    String id = obj.optString("id", "class_" + i);
                    String className = obj.optString("className", "Grade 10");
                    String academicYear = obj.optString("academicYear", "2026");
                    String role = obj.optString("role", "Class Teacher");
                    boolean isArchived = obj.optBoolean("isArchived", false);

                    newClasses.add(new ClassModel(id, className, academicYear, role, isArchived));
                }

                if (!newClasses.isEmpty()) {
                    // Re-populate ClassRepository
                    for (ClassModel c : newClasses) {
                        ClassRepository.addClass(c);
                    }
                    if (root.has("activeClassId")) {
                        ClassRepository.setActiveClassById(root.getString("activeClassId"));
                    }
                }
            }

            // 2. Restore Students
            if (root.has("students")) {
                JSONArray studentsArray = root.getJSONArray("students");
                StudentRepository.clear();

                for (int i = 0; i < studentsArray.length(); i++) {
                    JSONObject obj = studentsArray.getJSONObject(i);
                    String id = obj.optString("id", java.util.UUID.randomUUID().toString());
                    String name = obj.optString("name", "Student");
                    String rollNo = obj.optString("rollNo", "01");
                    String grade = obj.optString("grade", "Grade 10");
                    int marks = obj.optInt("marks", 0);
                    boolean present = obj.optBoolean("present", true);

                    Student student = new Student(id, name, rollNo, grade, marks, present);
                    if (obj.has("classId")) student.setClassId(obj.getString("classId"));
                    if (obj.has("nameWithInitials")) student.setNameWithInitials(obj.getString("nameWithInitials"));
                    if (obj.has("dob")) student.setDob(obj.getString("dob"));
                    if (obj.has("gender")) student.setGender(obj.getString("gender"));
                    if (obj.has("placeOfBirth")) student.setPlaceOfBirth(obj.getString("placeOfBirth"));
                    if (obj.has("ethnicity")) student.setEthnicity(obj.getString("ethnicity"));
                    if (obj.has("religion")) student.setReligion(obj.getString("religion"));
                    if (obj.has("birthCertNo")) student.setBirthCertNo(obj.getString("birthCertNo"));
                    if (obj.has("medium")) student.setMedium(obj.getString("medium"));
                    if (obj.has("permAddress")) student.setPermAddress(obj.getString("permAddress"));
                    if (obj.has("fatherName")) student.setFatherName(obj.getString("fatherName"));
                    if (obj.has("fatherNic")) student.setFatherNic(obj.getString("fatherNic"));
                    if (obj.has("fatherPhone")) student.setFatherPhone(obj.getString("fatherPhone"));
                    if (obj.has("motherName")) student.setMotherName(obj.getString("motherName"));
                    if (obj.has("motherNic")) student.setMotherNic(obj.getString("motherNic"));
                    if (obj.has("motherPhone")) student.setMotherPhone(obj.getString("motherPhone"));
                    if (obj.has("guardianName")) student.setGuardianName(obj.getString("guardianName"));
                    if (obj.has("emergencyName")) student.setEmergencyName(obj.getString("emergencyName"));
                    if (obj.has("emergencyRelation")) student.setEmergencyRelation(obj.getString("emergencyRelation"));
                    if (obj.has("emergencyPhone")) student.setEmergencyPhone(obj.getString("emergencyPhone"));

                    StudentRepository.addStudent(student);
                }
            }

            // 3. Restore Attendance
            if (root.has("attendance")) {
                JSONObject attendanceObj = root.getJSONObject("attendance");
                Iterator<String> dateKeys = attendanceObj.keys();
                while (dateKeys.hasNext()) {
                    String dateStr = dateKeys.next();
                    JSONObject studentRecords = attendanceObj.getJSONObject(dateStr);
                    Iterator<String> studentIdKeys = studentRecords.keys();

                    while (studentIdKeys.hasNext()) {
                        String sId = studentIdKeys.next();
                        JSONObject recObj = studentRecords.getJSONObject(sId);
                        boolean isPresent = recObj.optBoolean("isPresent", true);
                        StudentRepository.setAttendance(dateStr, sId, isPresent);
                    }
                }
            }

            // 4. Restore Exam Subjects & Marks
            if (root.has("allSubjects")) {
                JSONArray subArray = root.getJSONArray("allSubjects");
                for (int i = 0; i < subArray.length(); i++) {
                    ExamRepository.addSubjectToMasterList(subArray.getString(i));
                }
            }

            if (root.has("studentSubjects")) {
                JSONObject subjectsObj = root.getJSONObject("studentSubjects");
                Iterator<String> sKeys = subjectsObj.keys();
                while (sKeys.hasNext()) {
                    String sId = sKeys.next();
                    JSONArray arr = subjectsObj.getJSONArray(sId);
                    List<String> list = new ArrayList<>();
                    for (int i = 0; i < arr.length(); i++) list.add(arr.getString(i));
                    ExamRepository.setStudentSubjects(sId, list);
                }
            }

            if (root.has("studentMarks")) {
                JSONObject marksObj = root.getJSONObject("studentMarks");
                Iterator<String> sKeys = marksObj.keys();
                while (sKeys.hasNext()) {
                    String sId = sKeys.next();
                    JSONObject mapObj = marksObj.getJSONObject(sId);
                    Iterator<String> subKeys = mapObj.keys();
                    while (subKeys.hasNext()) {
                        String sub = subKeys.next();
                        double mark = mapObj.optDouble(sub, 0.0);
                        ExamRepository.setStudentMark(sId, sub, mark);
                    }
                }
            }

            // 5. Restore Timetable Entries
            if (root.has("timetable")) {
                JSONArray ttArray = root.getJSONArray("timetable");
                ClassTimetableRepository.getEntries().clear();
                for (int i = 0; i < ttArray.length(); i++) {
                    JSONObject obj = ttArray.getJSONObject(i);
                    String id = obj.optString("id", java.util.UUID.randomUUID().toString());
                    String day = obj.optString("day", "සඳුදා");
                    String periodName = obj.optString("periodName", "1 වන කාලඡේදය");
                    int startHour = obj.optInt("startHour", 8);
                    int startMinute = obj.optInt("startMinute", 0);
                    int endHour = obj.optInt("endHour", 8);
                    int endMinute = obj.optInt("endMinute", 40);
                    String subject = obj.optString("subject", "ගණිතය");
                    String teacherName = obj.optString("teacherName", "ගුරුතුමා");
                    String roomNo = obj.optString("roomNo", "ප්‍රධාන පන්ති කාමරය");

                    ClassTimetableRepository.addEntry(new ClassTimetableEntry(id, day, periodName, startHour, startMinute, endHour, endMinute, subject, teacherName, roomNo));
                }
            }

            // 6. Restore Grade Cutoffs
            if (root.has("gradeCutoffs") && context != null) {
                JSONObject cutoffs = root.getJSONObject("gradeCutoffs");
                GradeBoundaryManager.saveBoundaries(
                        context,
                        cutoffs.optInt("A", 75),
                        cutoffs.optInt("B", 65),
                        cutoffs.optInt("C", 50),
                        cutoffs.optInt("S", 35)
                );
            }

            // Save refreshed data state into local Room Database asynchronously
            if (context != null) {
                Executors.newSingleThreadExecutor().execute(() -> {
                    try {
                        BackupEntity entity = new BackupEntity(1, jsonStr, System.currentTimeMillis(), true);
                        AppDatabase.getInstance(context).backupDao().insertOrUpdateBackup(entity);
                    } catch (Exception ignored) {}
                });
            }

            Log.d(TAG, "Full app data restored successfully from JSON.");
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Failed to parse and restore data from JSON", e);
            return false;
        }
    }
}
