package com.aistudio.classroomhub.app;

public class ClassModel {
    private String id;
    private String className;
    private String academicYear;
    private String role;
    private boolean isArchived;

    public ClassModel(String id, String className, String academicYear, String role, boolean isArchived) {
        this.id = id;
        this.className = className;
        this.academicYear = academicYear;
        this.role = role;
        this.isArchived = isArchived;
    }

    public String getId() {
        return id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public boolean isArchived() {
        return isArchived;
    }

    public void setArchived(boolean archived) {
        isArchived = archived;
    }

    public String getDisplayName() {
        if (isArchived) {
            return className + " (" + academicYear + " - Archived)";
        }
        return className + " (" + academicYear + ")";
    }

    public String getBadgeText() {
        return "Active Class: " + className + " | Academic Year: " + academicYear + " | Role: " + role;
    }
}
