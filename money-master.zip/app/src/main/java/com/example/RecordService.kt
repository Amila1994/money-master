package com.example

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import androidx.core.app.NotificationCompat
import com.example.data.AppDatabase
import com.example.data.CallRecord
import com.example.data.CallRecordRepository
import com.example.data.CallType
import com.example.recording.CallAudioRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

data class ActiveRecordingState(
    val isRecording: Boolean = false,
    val phoneNumber: String = "",
    val contactName: String = "",
    val callType: CallType = CallType.INCOMING,
    val startTimeMillis: Long = 0
)

class RecordService : Service() {

    private lateinit var recorder: CallAudioRecorder
    private lateinit var repository: CallRecordRepository
    private val serviceScope = CoroutineScope(Dispatchers.IO)
    private var timerJob: Job? = null

    companion object {
        const val CHANNEL_ID = "call_recorder_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_RECORDING = "com.example.action.START_RECORDING"
        const val ACTION_STOP_RECORDING = "com.example.action.STOP_RECORDING"

        const val EXTRA_PHONE_NUMBER = "extra_phone_number"
        const val EXTRA_CONTACT_NAME = "extra_contact_name"
        const val EXTRA_CALL_TYPE = "extra_call_type"

        private val _activeRecordingState = MutableStateFlow(ActiveRecordingState())
        val activeRecordingState: StateFlow<ActiveRecordingState> = _activeRecordingState.asStateFlow()

        fun startRecording(context: Context, phoneNumber: String, contactName: String = "", callType: CallType = CallType.INCOMING) {
            val intent = Intent(context, RecordService::class.java).apply {
                action = ACTION_START_RECORDING
                putExtra(EXTRA_PHONE_NUMBER, phoneNumber)
                putExtra(EXTRA_CONTACT_NAME, contactName)
                putExtra(EXTRA_CALL_TYPE, callType.name)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopRecording(context: Context) {
            val intent = Intent(context, RecordService::class.java).apply {
                action = ACTION_STOP_RECORDING
            }
            context.startService(intent)
        }
    }

    override fun getAttributionTag(): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            "call_recorder"
        } else {
            super.getAttributionTag()
        }
    }

    override fun onCreate() {
        super.onCreate()
        recorder = CallAudioRecorder(this)
        repository = CallRecordRepository(AppDatabase.getDatabase(this).callRecordDao())
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_RECORDING -> {
                stopRecordingInternal()
            }
            else -> {
                val phoneNumber = intent?.getStringExtra("PHONE_NUMBER") 
                    ?: intent?.getStringExtra(EXTRA_PHONE_NUMBER) 
                    ?: "Unknown"
                val contactName = intent?.getStringExtra(EXTRA_CONTACT_NAME) ?: ""
                val callTypeStr = intent?.getStringExtra(EXTRA_CALL_TYPE) ?: CallType.INCOMING.name
                val callType = try { CallType.valueOf(callTypeStr) } catch (e: Exception) { CallType.INCOMING }

                startRecordingInternal(phoneNumber, contactName, callType)
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecordingInternal(phoneNumber: String, contactName: String, callType: CallType) {
        val resolvedContactName = if (contactName.isNotBlank()) {
            contactName
        } else {
            getContactNameOrNumber(this, phoneNumber)
        }

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, RecordService::class.java).apply {
            action = ACTION_STOP_RECORDING
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val displayName = resolvedContactName.ifBlank { phoneNumber }
        val initialNotification = buildNotification(displayName, "00:00", pendingIntent, stopPendingIntent)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    initialNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    initialNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, initialNotification)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(NOTIFICATION_ID, initialNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
                } else {
                    startForeground(NOTIFICATION_ID, initialNotification)
                }
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
        }

        val prefs = getSharedPreferences(CallReceiver.PREF_NAME, Context.MODE_PRIVATE)
        val audioFormat = prefs.getString("pref_audio_format", "AAC") ?: "AAC"
        val audioSource = prefs.getString("pref_audio_source", "Microphone") ?: "Microphone"

        val file = recorder.startRecording(phoneNumber, format = audioFormat, source = audioSource)
        val startTime = System.currentTimeMillis()

        _activeRecordingState.value = ActiveRecordingState(
            isRecording = true,
            phoneNumber = phoneNumber,
            contactName = resolvedContactName,
            callType = callType,
            startTimeMillis = startTime
        )

        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (_activeRecordingState.value.isRecording) {
                val elapsedMillis = (System.currentTimeMillis() - startTime).coerceAtLeast(0)
                val totalSecs = elapsedMillis / 1000
                val minutes = totalSecs / 60
                val seconds = totalSecs % 60
                val timerString = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

                val notificationManager = getSystemService(NotificationManager::class.java)
                val updatedNotification = buildNotification(displayName, timerString, pendingIntent, stopPendingIntent)
                try {
                    notificationManager?.notify(NOTIFICATION_ID, updatedNotification)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(1000L)
            }
        }
    }

    private fun buildNotification(
        displayName: String,
        timerString: String,
        pendingIntent: PendingIntent,
        stopPendingIntent: PendingIntent
    ): android.app.Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Recording Call • $timerString")
            .setContentText("Auto Call Recorder is recording call with $displayName")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .addAction(R.drawable.ic_launcher_foreground, "Stop Recording", stopPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun getContactNameOrNumber(context: Context, phoneNumber: String): String {
        if (phoneNumber == "Unknown" || phoneNumber.isBlank()) return ""

        var foundName = ""
        val uri = Uri.withAppendedPath(
            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
            Uri.encode(phoneNumber)
        )
        val projection = arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME)

        try {
            val cursor: Cursor? = context.contentResolver.query(uri, projection, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        foundName = it.getString(nameIndex) ?: ""
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return foundName
    }

    private fun stopRecordingInternal() {
        timerJob?.cancel()
        timerJob = null

        val currentState = _activeRecordingState.value
        val result = recorder.stopRecording()

        if (result != null && currentState.isRecording) {
            val record = CallRecord(
                phoneNumber = currentState.phoneNumber,
                contactName = currentState.contactName,
                callType = currentState.callType,
                timestamp = currentState.startTimeMillis,
                durationSeconds = result.durationSeconds,
                filePath = result.file.absolutePath,
                fileSizeBytes = result.sizeBytes
            )

            serviceScope.launch {
                repository.insert(record)
            }
        }

        _activeRecordingState.value = ActiveRecordingState(isRecording = false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Call Recorder Service Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notification channel for active call recording service"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (_activeRecordingState.value.isRecording) {
            stopRecordingInternal()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
