package com.example;

public class Student {
    private String id;
    private String name;
    private String rollNo;
    private String grade;
    private int marks;
    private boolean isPresent;

    public Student(String id, String name, String rollNo, String grade, int marks, boolean isPresent) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.grade = grade;
        this.marks = marks;
        this.isPresent = isPresent;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public boolean isPresent() {
        return isPresent;
    }

    public void setPresent(boolean present) {
        isPresent = present;
    }

    public String getGradeBadge() {
        if (marks >= 90) return marks + "% (A+)";
        if (marks >= 80) return marks + "% (A)";
        if (marks >= 70) return marks + "% (B)";
        if (marks >= 60) return marks + "% (C)";
        if (marks >= 50) return marks + "% (D)";
        return marks + "% (F)";
    }
}
