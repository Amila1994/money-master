package com.example

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Canvas
import androidx.compose.ui.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class MasterReportActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                MasterReportScreen(onBack = { finish() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MasterReportScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var selectedCalendar by remember { mutableStateOf(Calendar.getInstance()) }
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    var selectedDateStr by remember { mutableStateOf(dateFormat.format(selectedCalendar.time)) }

    var totalStudents by remember { mutableIntStateOf(0) }
    var totalTeachers by remember { mutableIntStateOf(0) }
    var presentStudents by remember { mutableIntStateOf(0) }
    var presentTeachers by remember { mutableIntStateOf(0) }
    
    val absentStudents = maxOf(0, totalStudents - presentStudents)
    val absentTeachers = maxOf(0, totalTeachers - presentTeachers)

    var schoolName by remember { mutableStateOf("Haddaththawa") }
    var isLoading by remember { mutableStateOf(false) }

    val email = remember { FirebaseAuth.getInstance().currentUser?.email ?: "amilalasantha940703@gmail.com" }
    val db = remember { FirebaseFirestore.getInstance() }

    // Fetch data whenever date changes
    LaunchedEffect(selectedDateStr) {
        isLoading = true
        db.collection("schools").document(email).get()
            .addOnSuccessListener { doc ->
                if (doc != null && doc.exists()) {
                    schoolName = doc.getString("name") ?: "Haddaththawa"
                    totalStudents = doc.getLong("studentCount")?.toInt() ?: 0
                }
                
                // Fetch teachers count
                db.collection("schools").document(email).collection("teachers").get()
                    .addOnSuccessListener { teachersQuery ->
                        totalTeachers = teachersQuery.size()
                        
                        // Fetch attendance
                        db.collection("schools").document(email).collection("attendance").document(selectedDateStr).get()
                            .addOnSuccessListener { attDoc ->
                                if (attDoc != null && attDoc.exists()) {
                                    presentStudents = attDoc.getLong("presentStudents")?.toInt() ?: 0
                                    presentTeachers = attDoc.getLong("presentTeachers")?.toInt() ?: 0
                                } else {
                                    presentStudents = 0
                                    presentTeachers = 0
                                }
                                isLoading = false
                            }
                            .addOnFailureListener {
                                isLoading = false
                            }
                    }
                    .addOnFailureListener {
                        isLoading = false
                    }
            }
            .addOnFailureListener {
                isLoading = false
            }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("විදුහල්පති සමස්ත සාරාංශය (Master Report)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // School banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = schoolName,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "සමස්ත වාර්තාකරණ සහ කළමනාකරණ පද්ධතිය",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Date Picker Block
                OutlinedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("පෙරදසුන් දිනය (Selected Date):", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(selectedDateStr, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        
                        Button(
                            onClick = {
                                val year = selectedCalendar.get(Calendar.YEAR)
                                val month = selectedCalendar.get(Calendar.MONTH)
                                val day = selectedCalendar.get(Calendar.DAY_OF_MONTH)
                                DatePickerDialog(context, { _, y, m, d ->
                                    val newCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, y)
                                        set(Calendar.MONTH, m)
                                        set(Calendar.DAY_OF_MONTH, d)
                                    }
                                    selectedCalendar = newCal
                                    selectedDateStr = dateFormat.format(newCal.time)
                                }, year, month, day).show()
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.CalendarToday, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("දිනය වෙනස් කරන්න")
                        }
                    }
                }

                if (isLoading) {
                    Box(modifier = Modifier.height(200.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    // Totals block
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("ලියාපදිංචි එකතුව (Registered Totals)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("මුළු සිසුන් සංඛ්‍යාව (Total Students):", style = MaterialTheme.typography.bodyMedium)
                                Text(totalStudents.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            Divider(color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.1f))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("මුළු ගුරුවරුන් සංඛ්‍යාව (Total Teachers):", style = MaterialTheme.typography.bodyMedium)
                                Text(totalTeachers.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Attendance details card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("පැමිණීමේ විස්තරය (Attendance Details)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("🟢 පැමිණි සිසුන් (Present Students):", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF2E7D32))
                                Text(presentStudents.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("🔴 නොපැමිණි සිසුන් (Absent Students):", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFC62828))
                                Text(absentStudents.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            }
                            
                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("🟢 පැමිණි ගුරුවරුන් (Present Teachers):", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF2E7D32))
                                Text(presentTeachers.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("🔴 නොපැමිණි ගුරුවරුන් (Absent Teachers):", style = MaterialTheme.typography.bodyMedium, color = Color(0xFFC62828))
                                Text(absentTeachers.toString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            }
                        }
                    }

                    // Action Button
                    Button(
                        onClick = {
                            generateMasterPdfReport(
                                context = context,
                                schoolName = schoolName,
                                dateStr = selectedDateStr,
                                totalStudents = totalStudents,
                                totalTeachers = totalTeachers,
                                presentStudents = presentStudents,
                                absentStudents = absentStudents,
                                presentTeachers = presentTeachers,
                                absentTeachers = absentTeachers
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("සමස්ත PDF වාර්තාව බාගත කරන්න", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun generateMasterPdfReport(
    context: Context,
    schoolName: String,
    dateStr: String,
    totalStudents: Int,
    totalTeachers: Int,
    presentStudents: Int,
    absentStudents: Int,
    presentTeachers: Int,
    absentTeachers: Int
) {
    val pdfDocument = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 size in points
    val page = pdfDocument.startPage(pageInfo)
    val canvas = page.canvas

    val titlePaint = Paint().apply {
        color = android.graphics.Color.parseColor("#1A365D")
        textSize = 18f
        isFakeBoldText = true
        isAntiAlias = true
    }
    
    val subtitlePaint = Paint().apply {
        color = android.graphics.Color.parseColor("#2B6CB0")
        textSize = 13f
        isFakeBoldText = true
        isAntiAlias = true
    }

    val bodyPaint = Paint().apply {
        color = android.graphics.Color.parseColor("#2D3748")
        textSize = 10f
        isAntiAlias = true
    }

    val boldBodyPaint = Paint().apply {
        color = android.graphics.Color.parseColor("#1A202C")
        textSize = 10f
        isFakeBoldText = true
        isAntiAlias = true
    }

    val borderPaint = Paint().apply {
        color = android.graphics.Color.parseColor("#CBD5E0")
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    val headerBgPaint = Paint().apply {
        color = android.graphics.Color.parseColor("#E2E8F0")
        style = Paint.Style.FILL
    }

    var y = 60f

    // Header Title
    canvas.drawText("MASTER EXECUTIVE ATTENDANCE & SUMMARY REPORT", 50f, y, titlePaint)
    y += 30f
    canvas.drawText("School / ආයතනය: $schoolName", 50f, y, subtitlePaint)
    y += 20f
    canvas.drawText("Report Date / වාර්තාගත දිනය: $dateStr", 50f, y, bodyPaint)
    y += 35f

    // Table Header
    canvas.drawRect(50f, y, 545f, y + 25f, headerBgPaint)
    canvas.drawRect(50f, y, 545f, y + 25f, borderPaint)
    canvas.drawText("Category (කාණ්ඩය)", 60f, y + 17f, boldBodyPaint)
    canvas.drawText("Total (මුළු)", 220f, y + 17f, boldBodyPaint)
    canvas.drawText("Present (පැමිණි)", 340f, y + 17f, boldBodyPaint)
    canvas.drawText("Absent (නොපැමිණි)", 450f, y + 17f, boldBodyPaint)
    y += 25f

    // Row 1: Students
    canvas.drawRect(50f, y, 545f, y + 25f, borderPaint)
    canvas.drawText("Students (සිසුන්)", 60f, y + 17f, bodyPaint)
    canvas.drawText(totalStudents.toString(), 220f, y + 17f, bodyPaint)
    canvas.drawText(presentStudents.toString(), 340f, y + 17f, bodyPaint)
    canvas.drawText(absentStudents.toString(), 450f, y + 17f, bodyPaint)
    y += 25f

    // Row 2: Teachers
    canvas.drawRect(50f, y, 545f, y + 25f, borderPaint)
    canvas.drawText("Teachers (ගුරුවරුන්)", 60f, y + 17f, bodyPaint)
    canvas.drawText(totalTeachers.toString(), 220f, y + 17f, bodyPaint)
    canvas.drawText(presentTeachers.toString(), 340f, y + 17f, bodyPaint)
    canvas.drawText(absentTeachers.toString(), 450f, y + 17f, bodyPaint)
    y += 45f

    // Summary Section
    canvas.drawText("Executive Summary & Observations / සාරාංශය", 50f, y, subtitlePaint)
    y += 25f
    val studentAttendanceRate = if (totalStudents > 0) (presentStudents * 100 / totalStudents) else 0
    val teacherAttendanceRate = if (totalTeachers > 0) (presentTeachers * 100 / totalTeachers) else 0
    canvas.drawText("• Student Attendance Rate (සිසුන් පැමිණීමේ ප්‍රතිශතය): $studentAttendanceRate%", 60f, y, bodyPaint)
    y += 20f
    canvas.drawText("• Teacher Attendance Rate (ගුරු පැමිණීමේ ප්‍රතිශතය): $teacherAttendanceRate%", 60f, y, bodyPaint)
    y += 20f
    canvas.drawText("• Report Status: Generated & Authenticated via Master PIN Verification", 60f, y, bodyPaint)
    y += 60f

    // Signatures
    canvas.drawLine(50f, y, 200f, y, borderPaint)
    canvas.drawLine(395f, y, 545f, y, borderPaint)
    y += 15f
    canvas.drawText("Class Teacher's Signature", 50f, y, bodyPaint)
    canvas.drawText("Principal's Signature", 405f, y, bodyPaint)

    pdfDocument.finishPage(page)

    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    val file = File(downloadsDir, "Master_Report_${dateStr.replace("-", "_")}.pdf")
    try {
        pdfDocument.writeTo(FileOutputStream(file))
        Toast.makeText(context, "සමස්ත PDF වාර්තාව Downloads ෆෝල්ඩරයට බාගත විය!", Toast.LENGTH_LONG).show()
    } catch (e: IOException) {
        Toast.makeText(context, "බාගත කිරීම අසාර්ථකයි: ${e.message}", Toast.LENGTH_LONG).show()
    } finally {
        pdfDocument.close()
    }
}
