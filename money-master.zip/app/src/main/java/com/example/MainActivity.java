package com.example;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning;
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {

    private ImageView ivPreview;
    private View layoutAuth;
    private View layoutPreview;

    private Bitmap rawBitmap;
    private Bitmap filteredBitmap;
    private Bitmap finalDisplayBitmap;
    private Canvas canvas;

    // 🎯 Register launchers at class-level
    private final ActivityResultLauncher<String> pickPhotoLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri) {
                    if (uri != null) {
                        try {
                            InputStream inputStream = getContentResolver().openInputStream(uri);
                            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                            if (inputStream != null) {
                                inputStream.close();
                            }
                            if (bitmap != null) {
                                loadBitmapIntoWorkspace(bitmap);
                            }
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Photo Import Failed: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
    );

    private final ActivityResultLauncher<String> pickPDFLauncher = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri uri) {
                    if (uri != null) {
                        renderPDFFirstPage(uri);
                    }
                }
            }
    );

    private final ActivityResultLauncher<IntentSenderRequest> scannerLauncher = registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(),
            new ActivityResultCallback<androidx.activity.result.ActivityResult>() {
                @Override
                public void onActivityResult(androidx.activity.result.ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        GmsDocumentScanningResult scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.getData());
                        if (scanResult != null) {
                            List<GmsDocumentScanningResult.Page> pages = scanResult.getPages();
                            if (pages != null && !pages.isEmpty()) {
                                Uri imageUri = pages.get(0).getImageUri();
                                try {
                                    InputStream inputStream = getContentResolver().openInputStream(imageUri);
                                    Bitmap scannedBitmap = BitmapFactory.decodeStream(inputStream);
                                    if (inputStream != null) {
                                        inputStream.close();
                                    }
                                    if (scannedBitmap != null) {
                                        loadBitmapIntoWorkspace(scannedBitmap);
                                    }
                                } catch (Exception e) {
                                    Toast.makeText(MainActivity.this, "Scanning Failed: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI Components initialization
        ivPreview = findViewById(R.id.ivPreview);
        layoutAuth = findViewById(R.id.layoutAuth);
        if (layoutAuth == null) {
            layoutAuth = findViewById(android.R.id.content);
        }
        layoutPreview = findViewById(R.id.layoutPreview);
        if (layoutPreview == null) {
            layoutPreview = findViewById(android.R.id.content);
        }

        Button btnScan = findViewById(R.id.btnScan);
        Button btnImportPhoto = findViewById(R.id.btnImportPhoto);
        Button btnImportPDF = findViewById(R.id.btnImportPDF);
        Button btnSaveAndShare = findViewById(R.id.btnSaveAndShare);
        Button btnBack = findViewById(R.id.btnBack);

        // 🔒 [FEATURE 1 ACTIVATED] Strict In-Display Fingerprint Lock on Start
        checkAndTriggerBiometricAuth();

        // 📸 Google ML Kit Scanner Implementation
        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GmsDocumentScannerOptions options = new GmsDocumentScannerOptions.Builder()
                        .setGalleryImportAllowed(true)
                        .setPageLimit(1)
                        .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_BASE_WITH_FILTER)
                        .build();

                GmsDocumentScanning.getClient(options)
                        .getStartScanIntent(MainActivity.this)
                        .addOnSuccessListener(new com.google.android.gms.tasks.OnSuccessListener<android.content.IntentSender>() {
                            @Override
                            public void onSuccess(android.content.IntentSender intentSender) {
                                try {
                                    scannerLauncher.launch(new IntentSenderRequest.Builder(intentSender).build());
                                } catch (Exception e) {
                                    Toast.makeText(MainActivity.this, "Failed to launch scanner: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .addOnFailureListener(new com.google.android.gms.tasks.OnFailureListener() {
                            @Override
                            public void onFailure(Exception e) {
                                Toast.makeText(MainActivity.this, "ML Kit Scanner Error: " + e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                            }
                        });
            }
        });

        btnImportPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickPhotoLauncher.launch("image/*");
            }
        });

        btnImportPDF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickPDFLauncher.launch("application/pdf");
            }
        });

        btnSaveAndShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (finalDisplayBitmap != null) {
                    saveAndShareImage(finalDisplayBitmap);
                } else {
                    Toast.makeText(MainActivity.this, "No image to save!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutPreview.setVisibility(View.GONE);
                layoutAuth.setVisibility(View.VISIBLE);
                rawBitmap = null;
                filteredBitmap = null;
                finalDisplayBitmap = null;
                canvas = null;
            }
        });

        // 🧽 [FEATURE 2 ACTIVATED] Strict Line-Boundary Eraser Touch Handler
        ivPreview.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN && finalDisplayBitmap != null) {
                    int x = (int) (event.getX() * (finalDisplayBitmap.getWidth() / (float) ivPreview.getWidth()));
                    int y = (int) (event.getY() * (finalDisplayBitmap.getHeight() / (float) ivPreview.getHeight()));

                    if (x >= 0 && x < finalDisplayBitmap.getWidth() && y >= 0 && y < finalDisplayBitmap.getHeight()) {
                        eraseConnectedComponent(x, y);
                    }
                }
                return true;
            }
        });
    }

    // 🔒 Strict Biometric Prompt implementation (Only registered finger can open)
    private void checkAndTriggerBiometricAuth() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(MainActivity.this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    Toast.makeText(MainActivity.this, "Welcome to CamScanner Pro! 👑", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    Toast.makeText(MainActivity.this, "Fingerprint verification failed. Access Denied! ❌", Toast.LENGTH_SHORT).show();
                    finish(); // Closes the app securely if the finger is incorrect
                }

                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    Toast.makeText(MainActivity.this, "Security Error: " + errString, Toast.LENGTH_SHORT).show();
                    finish();
                }
            });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Secure Vault Gate")
                .setSubtitle("Place your registered finger on the sensor")
                .setNegativeButtonText("Exit")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void loadBitmapIntoWorkspace(Bitmap bitmap) {
        rawBitmap = bitmap;
        filteredBitmap = applyMagicProFilter(rawBitmap);
        finalDisplayBitmap = filteredBitmap.copy(Bitmap.Config.ARGB_8888, true);

        layoutAuth.setVisibility(View.GONE);
        layoutPreview.setVisibility(View.VISIBLE);

        canvas = new Canvas(finalDisplayBitmap);
        ivPreview.setImageBitmap(finalDisplayBitmap);
        Toast.makeText(this, "Ready to Edit! 🧽", Toast.LENGTH_SHORT).show();
    }

    private void renderPDFFirstPage(Uri uri) {
        try {
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
            if (pfd != null) {
                PdfRenderer renderer = new PdfRenderer(pfd);
                if (renderer.getPageCount() > 0) {
                    PdfRenderer.Page page = renderer.openPage(0);
                    Bitmap bitmap = Bitmap.createBitmap(page.getWidth() * 2, page.getHeight() * 2, Bitmap.Config.ARGB_8888);
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    loadBitmapIntoWorkspace(bitmap);
                    page.close();
                }
                renderer.close();
                pfd.close();
            }
        } catch (Exception e) {
            Toast.makeText(this, "PDF Render Error: " + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // 🧽 Strict Boundary Eraser (Flood Fill)
    private void eraseConnectedComponent(int startX, int startY) {
        int targetColor = finalDisplayBitmap.getPixel(startX, startY);
        if (targetColor == Color.WHITE) return;

        int replacementColor = Color.WHITE;
        int width = finalDisplayBitmap.getWidth();
        int height = finalDisplayBitmap.getHeight();
        int tolerance = 15;

        int targetR = Color.red(targetColor);
        int targetG = Color.green(targetColor);
        int targetB = Color.blue(targetColor);

        Queue<Point> queue = new LinkedList<>();
        boolean[][] visited = new boolean[width][height];

        queue.add(new Point(startX, startY));
        visited[startX][startY] = true;

        while (!queue.isEmpty()) {
            Point p = queue.remove();
            finalDisplayBitmap.setPixel(p.x, p.y, replacementColor);

            int[] dx = {1, -1, 0, 0};
            int[] dy = {0, 0, 1, -1};

            for (int i = 0; i < 4; i++) {
                int nx = p.x + dx[i];
                int ny = p.y + dy[i];

                if (nx >= 0 && nx < width && ny >= 0 && ny < height && !visited[nx][ny]) {
                    int currentColor = finalDisplayBitmap.getPixel(nx, ny);
                    int r = Color.red(currentColor);
                    int g = Color.green(currentColor);
                    int b = Color.blue(currentColor);

                    if (Math.abs(r - targetR) < tolerance &&
                            Math.abs(g - targetG) < tolerance &&
                            Math.abs(b - targetB) < tolerance &&
                            currentColor != Color.WHITE) {

                        queue.add(new Point(nx, ny));
                        visited[nx][ny] = true;
                    }
                }
            }
        }
        ivPreview.setImageBitmap(finalDisplayBitmap);
    }

    private Bitmap applyMagicProFilter(Bitmap input) {
        int width = input.getWidth();
        int height = input.getHeight();
        Bitmap output = Bitmap.createBitmap(width, height, input.getConfig());
        int[] pixels = new int[width * height];
        input.getPixels(pixels, 0, width, 0, 0, width, height);

        for (int i = 0; i < pixels.length; i++) {
            int color = pixels[i];
            int r = Color.red(color);
            int g = Color.green(color);
            int b = Color.blue(color);
            int luminance = (int) (0.299 * r + 0.587 * g + 0.114 * b);

            if (luminance > 165) {
                pixels[i] = Color.WHITE;
            } else {
                pixels[i] = Color.rgb(Math.max(0, (int) (r * 0.4)), Math.max(0, (int) (g * 0.4)), Math.max(0, (int) (b * 0.6)));
            }
        }
        output.setPixels(pixels, 0, width, 0, 0, width, height) ;
        return output;
    }

    // 💾 Scoped MediaStore Storage Engine for Android - saves to Pictures/CamScannerPro
    private void saveAndShareImage(Bitmap bitmap) {
        String fileName = "CamScannerPro_" + System.currentTimeMillis() + ".jpg";
        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/CamScannerPro");
        }

        try {
            Uri contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            Uri imageUri = getContentResolver().insert(contentUri, contentValues);

            if (imageUri != null) {
                OutputStream outputStream = getContentResolver().openOutputStream(imageUri);
                if (outputStream != null) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                    outputStream.close();
                }
                Toast.makeText(this, "Saved to Gallery! 💾", Toast.LENGTH_SHORT).show();

                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("image/jpeg");
                shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(shareIntent, "Share Document via..."));
            }
        } catch (Exception e) {
            Toast.makeText(this, "Save Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
