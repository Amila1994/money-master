package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.School
import com.example.model.ChatMessage
import com.example.repository.SchoolRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SchoolViewModel(private val repository: SchoolRepository = SchoolRepository()) : ViewModel() {

    private val _schools = MutableStateFlow<List<School>>(emptyList())
    val schools: StateFlow<List<School>> = _schools

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedType = MutableStateFlow("All")
    val selectedType: StateFlow<String> = _selectedType

    private val _sortType = MutableStateFlow("Name (A-Z)")
    val sortType: StateFlow<String> = _sortType

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading

    val isUsingFirestore: StateFlow<Boolean> = repository.isUsingFirestore

    // Computed flow filtering and sorting schools based on user input
    val filteredSchools: StateFlow<List<School>> = combine(
        _schools, _searchQuery, _selectedType, _sortType
    ) { schoolList, query, type, sort ->
        var list = schoolList

        // 1. Filter by search query (name or address or email)
        if (query.isNotBlank()) {
            list = list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.address.contains(query, ignoreCase = true) ||
                it.email.contains(query, ignoreCase = true)
            }
        }

        // 2. Filter by type
        if (type != "All") {
            list = list.filter { it.schoolType.equals(type, ignoreCase = true) }
        }

        // 3. Sort
        when (sort) {
            "Name (A-Z)" -> list.sortedBy { it.name }
            "Name (Z-A)" -> list.sortedByDescending { it.name }
            "Students (High to Low)" -> list.sortedByDescending { it.studentCount }
            "Students (Low to High)" -> list.sortedBy { it.studentCount }
            "Year Established" -> list.sortedBy { it.establishedYear }
            else -> list.sortedBy { it.name }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadSchools()
    }

    fun loadSchools() {
        _isLoading.value = true
        repository.getSchools { schoolList, errorMsg ->
            _schools.value = schoolList
            _isLoading.value = false
            if (errorMsg != null) {
                _statusMessage.value = errorMsg
            }
        }
    }

    fun addSchool(school: School) {
        _isLoading.value = true
        repository.addSchool(school) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = if (errorMsg != null) errorMsg else "School added successfully!"
                loadSchools()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to add school."
            }
        }
    }

    fun updateSchool(school: School) {
        _isLoading.value = true
        repository.updateSchool(school) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = if (errorMsg != null) errorMsg else "School updated successfully!"
                loadSchools()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to update school."
            }
        }
    }

    fun deleteSchool(schoolId: String) {
        _isLoading.value = true
        repository.deleteSchool(schoolId) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = if (errorMsg != null) errorMsg else "School deleted successfully!"
                loadSchools()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to delete school."
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedType(type: String) {
        _selectedType.value = type
    }

    fun setSortType(sort: String) {
        _sortType.value = sort
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    private val _activeChatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val activeChatMessages: StateFlow<List<ChatMessage>> = _activeChatMessages

    private var chatListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null

    fun startChatListener(schoolId: String, schoolEmail: String) {
        chatListenerRegistration?.remove()
        _activeChatMessages.value = emptyList()
        chatListenerRegistration = repository.listenToChats(schoolId, schoolEmail) { messages ->
            _activeChatMessages.value = messages
        }
    }

    fun stopChatListener() {
        chatListenerRegistration?.remove()
        chatListenerRegistration = null
        _activeChatMessages.value = emptyList()
    }

    fun sendChatMessage(schoolId: String, schoolEmail: String, text: String) {
        if (text.isBlank()) return
        val message = ChatMessage(
            sender = "admin",
            text = text,
            timestamp = com.google.firebase.Timestamp.now()
        )
        repository.sendChatMessage(schoolId, schoolEmail, message) { success, errorMsg ->
            if (errorMsg != null) {
                _statusMessage.value = errorMsg
            }
        }
    }
}
