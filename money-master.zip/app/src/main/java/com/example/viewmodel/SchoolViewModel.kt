package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.School
import com.example.model.ChatMessage
import com.example.repository.SchoolRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SchoolViewModel(private val repository: SchoolRepository = SchoolRepository()) : ViewModel() {

    private val _schools = MutableStateFlow<List<School>>(emptyList())
    val schools: StateFlow<List<School>> = _schools

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedType = MutableStateFlow("All")
    val selectedType: StateFlow<String> = _selectedType

    private val _sortType = MutableStateFlow("Name (A-Z)")
    val sortType: StateFlow<String> = _sortType

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading

    val isUsingFirestore: StateFlow<Boolean> = repository.isUsingFirestore

    // Computed flow filtering and sorting schools based on user input
    val filteredSchools: StateFlow<List<School>> = combine(
        _schools, _searchQuery, _selectedType, _sortType
    ) { schoolList, query, type, sort ->
        var list = schoolList

        // 1. Filter by search query (name or address or email)
        if (query.isNotBlank()) {
            list = list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.address.contains(query, ignoreCase = true) ||
                it.email.contains(query, ignoreCase = true)
            }
        }

        // 2. Filter by type
        if (type != "All") {
            list = list.filter { it.schoolType.equals(type, ignoreCase = true) }
        }

        // 3. Sort
        when (sort) {
            "Name (A-Z)" -> list.sortedBy { it.name }
            "Name (Z-A)" -> list.sortedByDescending { it.name }
            "Students (High to Low)" -> list.sortedByDescending { it.studentCount }
            "Students (Low to High)" -> list.sortedBy { it.studentCount }
            "Year Established" -> list.sortedBy { it.establishedYear }
            else -> list.sortedBy { it.name }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        loadSchools()
        startLiveNoticeListener()
    }

    fun loadSchools() {
        _isLoading.value = true
        repository.getSchools { schoolList, errorMsg ->
            _schools.value = schoolList
            _isLoading.value = false
            if (errorMsg != null) {
                _statusMessage.value = errorMsg
            }
        }
    }

    fun addSchool(school: School) {
        _isLoading.value = true
        repository.addSchool(school) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = if (errorMsg != null) errorMsg else "School added successfully!"
                loadSchools()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to add school."
            }
        }
    }

    fun updateSchool(school: School) {
        _isLoading.value = true
        repository.updateSchool(school) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = if (errorMsg != null) errorMsg else "School updated successfully!"
                loadSchools()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to update school."
            }
        }
    }

    fun deleteSchool(schoolId: String) {
        _isLoading.value = true
        repository.deleteSchool(schoolId) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = if (errorMsg != null) errorMsg else "School deleted successfully!"
                loadSchools()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to delete school."
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedType(type: String) {
        _selectedType.value = type
    }

    fun setSortType(sort: String) {
        _sortType.value = sort
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    private val _activeChatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val activeChatMessages: StateFlow<List<ChatMessage>> = _activeChatMessages

    private val _partnerPresence = MutableStateFlow<String>("offline")
    val partnerPresence: StateFlow<String> = _partnerPresence

    private val _activeTicketCallStatus = MutableStateFlow<String>("IDLE")
    val activeTicketCallStatus: StateFlow<String> = _activeTicketCallStatus

    private val _activeTicketVideoCallAllowed = MutableStateFlow<Boolean>(false)
    val activeTicketVideoCallAllowed: StateFlow<Boolean> = _activeTicketVideoCallAllowed

    private val _activeTicketCallerRole = MutableStateFlow<String>("")
    val activeTicketCallerRole: StateFlow<String> = _activeTicketCallerRole

    private val _activeTicketId = MutableStateFlow<String>("")
    val activeTicketId: StateFlow<String> = _activeTicketId

    private var chatListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null
    private var presenceListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null
    private var ticketListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null

    fun startChatListener(schoolId: String, schoolEmail: String) {
        chatListenerRegistration?.remove()
        _activeChatMessages.value = emptyList()
        chatListenerRegistration = repository.listenToChats(schoolId, schoolEmail) { messages ->
            _activeChatMessages.value = messages
        }
        
        ticketListenerRegistration?.remove()
        _activeTicketCallStatus.value = "IDLE"
        _activeTicketVideoCallAllowed.value = false
        _activeTicketCallerRole.value = ""
        _activeTicketId.value = ""

        ticketListenerRegistration = repository.listenToActiveTicket(schoolEmail) { data ->
            if (data != null) {
                _activeTicketCallStatus.value = data["callStatus"] as? String ?: "IDLE"
                _activeTicketVideoCallAllowed.value = data["videoCallAllowed"] as? Boolean ?: false
                _activeTicketCallerRole.value = data["callerRole"] as? String ?: ""
                _activeTicketId.value = data["ticketId"] as? String ?: ""
            } else {
                _activeTicketCallStatus.value = "IDLE"
                _activeTicketVideoCallAllowed.value = false
                _activeTicketCallerRole.value = ""
                _activeTicketId.value = ""
            }
        }
        
        // Also register admin presence as online when chat is active
        if (schoolEmail.isNotBlank()) {
            repository.setUserPresence(schoolEmail, "admin", "online")
            startPartnerPresenceListener(schoolEmail)
        }
    }

    fun stopChatListener(schoolEmail: String) {
        chatListenerRegistration?.remove()
        chatListenerRegistration = null
        _activeChatMessages.value = emptyList()
        
        ticketListenerRegistration?.remove()
        ticketListenerRegistration = null
        _activeTicketCallStatus.value = "IDLE"
        _activeTicketVideoCallAllowed.value = false
        _activeTicketCallerRole.value = ""
        _activeTicketId.value = ""
        
        stopPartnerPresenceListener()
        if (schoolEmail.isNotBlank()) {
            repository.setUserPresence(schoolEmail, "admin", "offline")
        }
    }

    fun startSchoolCall(schoolEmail: String) {
        repository.startSchoolCall(schoolEmail) { success, errorMsg ->
            if (!success && errorMsg != null) {
                _statusMessage.value = errorMsg
            }
        }
    }

    fun updateCallStatus(schoolEmail: String, callStatus: String, callerRole: String = "") {
        repository.updateCallStatus(schoolEmail, callStatus, callerRole) { success, errorMsg ->
            if (!success && errorMsg != null) {
                _statusMessage.value = errorMsg
            }
        }
    }

    private fun startPartnerPresenceListener(schoolEmail: String) {
        presenceListenerRegistration?.remove()
        _partnerPresence.value = "offline"
        presenceListenerRegistration = repository.listenToPartnerPresence(schoolEmail, "school") { status ->
            _partnerPresence.value = status
        }
    }

    private fun stopPartnerPresenceListener() {
        presenceListenerRegistration?.remove()
        presenceListenerRegistration = null
        _partnerPresence.value = "offline"
    }

    fun sendChatMessage(schoolId: String, schoolEmail: String, text: String) {
        if (text.isBlank()) return
        val message = ChatMessage(
            sender = "admin",
            text = text,
            timestamp = com.google.firebase.Timestamp.now()
        )
        repository.sendChatMessage(schoolId, schoolEmail, message) { success, errorMsg ->
            if (errorMsg != null) {
                _statusMessage.value = errorMsg
            }
        }
    }

    fun closeCaseAndClearChat(schoolEmail: String, onComplete: () -> Unit) {
        _isLoading.value = true
        repository.closeCaseAndClearChat(schoolEmail) { success, errorMsg ->
            _isLoading.value = false
            if (success) {
                _statusMessage.value = "Case closed and chat history cleared successfully."
                onComplete()
            } else {
                _statusMessage.value = errorMsg ?: "Failed to close case."
            }
        }
    }

    fun grantVideoCallAccess(schoolEmail: String, allow: Boolean) {
        repository.grantVideoCallAccess(schoolEmail, allow) { success, errorMsg ->
            if (success) {
                _statusMessage.value = if (allow) "Video call access granted!" else "Video call access suspended."
            } else {
                _statusMessage.value = errorMsg ?: "Failed to update video call access."
            }
        }
    }

    private val _noticeText = MutableStateFlow("")
    val noticeText: StateFlow<String> = _noticeText

    private val _isNoticeActive = MutableStateFlow(false)
    val isNoticeActive: StateFlow<Boolean> = _isNoticeActive

    private var noticeListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null

    fun startLiveNoticeListener() {
        noticeListenerRegistration?.remove()
        noticeListenerRegistration = repository.listenToLiveNotice { text, isActive ->
            _noticeText.value = text ?: ""
            _isNoticeActive.value = isActive
        }
    }

    fun publishNotice(text: String) {
        repository.publishNotice(text) { success, errorMsg ->
            if (success) {
                _statusMessage.value = "Notice published successfully!"
            } else {
                _statusMessage.value = errorMsg ?: "Failed to publish notice."
            }
        }
    }

    fun clearNotice() {
        repository.clearNotice { success, errorMsg ->
            if (success) {
                _statusMessage.value = "Notice cleared successfully."
            } else {
                _statusMessage.value = errorMsg ?: "Failed to clear notice."
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        noticeListenerRegistration?.remove()
        chatListenerRegistration?.remove()
        presenceListenerRegistration?.remove()
        ticketListenerRegistration?.remove()
    }
}
