package com.example;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {

    public interface OnStudentActionListener {
        void onToggleAttendance(Student student);
        void onDeleteStudent(Student student);
    }

    private List<Student> studentList;
    private OnStudentActionListener listener;

    public StudentAdapter(List<Student> studentList, OnStudentActionListener listener) {
        this.studentList = studentList;
        this.listener = listener;
    }

    public void updateList(List<Student> newList) {
        this.studentList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student_card, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = studentList.get(position);
        holder.bind(student, listener);
    }

    @Override
    public int getItemCount() {
        return studentList != null ? studentList.size() : 0;
    }

    static class StudentViewHolder extends RecyclerView.ViewHolder {
        TextView tvStudentInitial, tvStudentName, tvRollNoGrade, tvMarksBadge, tvAttendanceStatus;
        MaterialButton btnToggleAttendance;
        ImageButton btnDeleteStudent;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStudentInitial = itemView.findViewById(R.id.tvStudentInitial);
            tvStudentName = itemView.findViewById(R.id.tvStudentName);
            tvRollNoGrade = itemView.findViewById(R.id.tvRollNoGrade);
            tvMarksBadge = itemView.findViewById(R.id.tvMarksBadge);
            tvAttendanceStatus = itemView.findViewById(R.id.tvAttendanceStatus);
            btnToggleAttendance = itemView.findViewById(R.id.btnToggleAttendance);
            btnDeleteStudent = itemView.findViewById(R.id.btnDeleteStudent);
        }

        public void bind(final Student student, final OnStudentActionListener listener) {
            if (student.getName() != null && !student.getName().isEmpty()) {
                tvStudentInitial.setText(String.valueOf(student.getName().charAt(0)).toUpperCase());
            } else {
                tvStudentInitial.setText("S");
            }

            tvStudentName.setText(student.getName());
            tvRollNoGrade.setText("Roll #" + student.getRollNo() + " • " + student.getGrade());
            tvMarksBadge.setText(student.getGradeBadge());

            if (student.isPresent()) {
                tvAttendanceStatus.setText("Status: Present Today");
                tvAttendanceStatus.setTextColor(0xFF059669);
                btnToggleAttendance.setText("Mark Absent");
            } else {
                tvAttendanceStatus.setText("Status: Absent Today");
                tvAttendanceStatus.setTextColor(0xFFDC2626);
                btnToggleAttendance.setText("Mark Present");
            }

            btnToggleAttendance.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onToggleAttendance(student);
                }
            });

            btnDeleteStudent.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeleteStudent(student);
                }
            });
        }
    }
}
