package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.data.AppDatabase
import com.example.data.LoanRepository
import com.example.ui.LoanViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PinSecurityScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.Language
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.android.billingclient.api.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.example.utils.GoogleDriveService

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: LoanViewModel
    private var mInterstitialAd: InterstitialAd? = null
    private var isAdLoading = false
    private val countdownSeconds = mutableStateOf(45)
    private var adTimerJob: kotlinx.coroutines.Job? = null
    private var adsWatchedCount: Int = 0

    private lateinit var billingClient: BillingClient
    private var isBillingSetupComplete = false

    private val googleSignInLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
            if (account != null) {
                viewModel.setGoogleDriveConnected(true)
                Toast.makeText(this, "✓ Google Drive connected successfully!", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "❌ Google Sign-In failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val purchasesUpdatedListener = PurchasesUpdatedListener { billingResult, purchases ->
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                handlePurchase(purchase)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize WebView directories and Google Mobile Ads SDK on a background thread
        Thread {
            try {
                createWebViewCacheDirs()
                com.google.android.gms.ads.MobileAds.initialize(this) {
                    createWebViewCacheDirs()
                    runOnUiThread {
                        loadInterstitialAd()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
        
        // Initialize local database and repository
        val database = AppDatabase.getDatabase(this)
        val repository = LoanRepository(database.loanDao())
        
        // Instantiate the ViewModel
        viewModel = androidx.lifecycle.ViewModelProvider(this, LoanViewModel.Factory(repository, this))[LoanViewModel::class.java]

        billingClient = BillingClient.newBuilder(this)
            .setListener(purchasesUpdatedListener)
            .enablePendingPurchases()
            .build()

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    isBillingSetupComplete = true
                    queryPurchases()
                }
            }

            override fun onBillingServiceDisconnected() {
                isBillingSetupComplete = false
            }
        })

        startAdTimer(viewModel)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val isBlocked by viewModel.isBlockedFromFreeFeatures.collectAsState()
                val lang by viewModel.currentLanguage.collectAsState()
                val savedPin by viewModel.savedPin.collectAsState()
                val isUnlocked by viewModel.isAppUnlocked.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    if (savedPin == null || !isUnlocked) {
                        PinSecurityScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    } else {
                        DashboardScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding),
                            countdownSeconds = countdownSeconds.value,
                            onWatchAdClick = {
                                playInterstitialAd()
                                countdownSeconds.value = 45
                            },
                            onBuyPackageClick = { pkgName, price ->
                                purchasePremiumPackage(pkgName, price)
                            },
                            onDriveConnectClick = {
                                connectGoogleDrive()
                            },
                            onDriveBackupClick = {
                                backupToGoogleDrive()
                            },
                            onDriveRestoreClick = {
                                restoreFromGoogleDrive()
                            }
                        )
                    }
                }
            }
        }
    }

    private fun startAdTimer(viewModel: LoanViewModel) {
        adTimerJob?.cancel()
        adTimerJob = lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
                while (true) {
                    delay(1000)
                    val isPremium = viewModel.isPremiumUser.value
                    if (!isPremium) {
                        if (countdownSeconds.value > 0) {
                            countdownSeconds.value -= 1
                        } else {
                            // Automatically play ad
                            playInterstitialAd()
                            countdownSeconds.value = 45
                        }
                    } else {
                        countdownSeconds.value = 45
                    }
                    viewModel.refreshAccessState()
                }
            }
        }
    }

    private fun loadInterstitialAd() {
        if (mInterstitialAd != null || isAdLoading) return
        isAdLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAd = null
                    isAdLoading = false
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd
                    isAdLoading = false
                }
            }
        )
    }

    fun playInterstitialAd(onAdDismissed: () -> Unit = {}) {
        val ad = mInterstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    mInterstitialAd = null
                    loadInterstitialAd()
                    
                    // Increment watched ad counts and check access
                    adsWatchedCount++
                    val currentCount = viewModel.watchedAdsToday.value
                    val success = viewModel.incrementWatchedAds()
                    if (success) {
                        val adNum = currentCount + 1
                        val lang = viewModel.currentLanguage.value
                        if (adNum == 25) {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "🎉 Congratulations! You watched all 25 ads today. All features unlocked for 2 days!" else "🎉 සුභ පැතුම්! ඔබ අද දිනට ඇඩ්ස් 25ම බලා අවසන්. දින 2කට සියලු විශේෂාංග නොමිලේ!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "📺 Watched ad ($adNum/25). You have 45s of TEMPORARY ACCESS!" else "📺 ඇඩ් එකක් නැරඹුවා. ($adNum/25). ඔබට තත්පර 45ක තාවකාලික ප්‍රවේශයක් ඇත!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    checkAccess()
                    
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                    mInterstitialAd = null
                    loadInterstitialAd()
                    
                    // Fallback on show failure
                    adsWatchedCount++
                    val currentCount = viewModel.watchedAdsToday.value
                    val success = viewModel.incrementWatchedAds()
                    if (success) {
                        val adNum = currentCount + 1
                        val lang = viewModel.currentLanguage.value
                        if (adNum == 25) {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "🎉 Congratulations! You watched all 25 ads today. All features unlocked for 2 days!" else "🎉 සුභ පැතුම්! ඔබ අද දිනට ඇඩ්ස් 25ම බලා අවසන්. දින 2කට සියලු විශේෂාංග නොමිලේ!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "📺 Watched ad ($adNum/25). You have 45s of TEMPORARY ACCESS!" else "📺 ඇඩ් එකක් නැරඹුවා. ($adNum/25). ඔබට තත්පර 45ක තාවකාලික ප්‍රවේශයක් ඇත!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    checkAccess()
                    
                    onAdDismissed()
                }
            }
            ad.show(this)
        } else {
            loadInterstitialAd()
            
            // Fallback if ad is not loaded yet
            adsWatchedCount++
            val currentCount = viewModel.watchedAdsToday.value
            val success = viewModel.incrementWatchedAds()
            if (success) {
                val adNum = currentCount + 1
                val lang = viewModel.currentLanguage.value
                if (adNum == 25) {
                    Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "🎉 Congratulations! You watched all 25 ads today. All features unlocked for 2 days!" else "🎉 සුභ පැතුම්! ඔබ අද දිනට ඇඩ්ස් 25ම බලා අවසන්. දින 2කට සියලු විශේෂාංග නොමිලේ!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "📺 Watched ad ($adNum/25). You have 45s of TEMPORARY ACCESS!" else "📺 ඇඩ් එකක් නැරඹුවා. ($adNum/25). ඔබට තත්පර 45ක තාවකාලික ප්‍රවේශයක් ඇත!", Toast.LENGTH_SHORT).show()
                }
            }
            checkAccess()
            
            onAdDismissed()
        }
    }

    private fun checkAccess() {
        val isPremium = viewModel.isPremiumUser.value
        val daysSinceLastStreak = viewModel.getDaysSinceLastStreak()
        val adsToday = viewModel.watchedAdsToday.value
        val lastAdSec = viewModel.getLastAdSecondsAgo()

        val accessStatus = when {
            isPremium -> "FULL_ACCESS"
            daysSinceLastStreak <= 2 -> "FULL_ACCESS"
            adsToday >= 25 -> "FULL_ACCESS"
            lastAdSec <= 45 -> "TEMPORARY_ACCESS"
            else -> "RESTRICTED"
        }
        
        android.util.Log.d("MoneyMaster", "Access check performed: Status = $accessStatus")
    }

    private fun createWebViewCacheDirs() {
        try {
            val webViewCacheDirJs = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/js")
            val webViewCacheDirWasm = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/wasm")
            if (!webViewCacheDirJs.exists()) {
                webViewCacheDirJs.mkdirs()
            }
            if (!webViewCacheDirWasm.exists()) {
                webViewCacheDirWasm.mkdirs()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun purchasePremiumPackage(packageName: String, price: Double) {
        if (!isBillingSetupComplete) {
            Toast.makeText(this, "Payment system initializing... Redirecting to secure checkout.", Toast.LENGTH_LONG).show()
            try {
                val url = "https://checkout.moneymaster.com/pay?package=" + java.net.URLEncoder.encode(packageName, "UTF-8") + "&price=" + price
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return
        }

        val productId = when {
            packageName.contains("Promo", ignoreCase = true) || packageName.contains("පළමු", ignoreCase = true) -> "promo_monthly_package"
            packageName.contains("6 Month", ignoreCase = true) || packageName.contains("මාස 6", ignoreCase = true) -> "six_months_package"
            else -> "annual_package"
        }

        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && productDetailsList.isNotEmpty()) {
                val productDetails = productDetailsList[0]
                val productDetailsParamsList = listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(productDetails)
                        .build()
                )
                val billingFlowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList)
                    .build()
                
                billingClient.launchBillingFlow(this, billingFlowParams)
            } else {
                runOnUiThread {
                    Toast.makeText(this, "Google Play Billing product not configured in Play Console. Redirecting to secure checkout...", Toast.LENGTH_LONG).show()
                    try {
                        val url = "https://checkout.moneymaster.com/pay?package=" + java.net.URLEncoder.encode(packageName, "UTF-8") + "&price=" + price
                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                        startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    private fun queryPurchases() {
        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()
        billingClient.queryPurchasesAsync(params) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                for (purchase in purchases) {
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        runOnUiThread {
                            viewModel.setPremiumUser(true)
                        }
                    }
                }
            }
        }
        
        val inAppParams = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()
        billingClient.queryPurchasesAsync(inAppParams) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                for (purchase in purchases) {
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        runOnUiThread {
                            viewModel.setPremiumUser(true)
                        }
                    }
                }
            }
        }
    }

    private fun handlePurchase(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
            if (!purchase.isAcknowledged) {
                val acknowledgePurchaseParams = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                billingClient.acknowledgePurchase(acknowledgePurchaseParams) { billingResult ->
                    if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                        runOnUiThread {
                            viewModel.setPremiumUser(true)
                            Toast.makeText(this, "✓ Purchase acknowledged! All features are now unlocked.", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } else {
                viewModel.setPremiumUser(true)
            }
        }
    }

    fun connectGoogleDrive() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope("https://www.googleapis.com/auth/drive.appdata"))
            .build()
        val client = GoogleSignIn.getClient(this, gso)
        client.signOut().addOnCompleteListener {
            googleSignInLauncher.launch(client.signInIntent)
        }
    }

    fun backupToGoogleDrive() {
        Toast.makeText(this, "Uploading backup database to Google Drive AppData folder...", Toast.LENGTH_SHORT).show()
        GoogleDriveService.uploadBackup(this) { success, msg ->
            runOnUiThread {
                if (success) {
                    Toast.makeText(this, "✓ $msg", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "❌ $msg", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun restoreFromGoogleDrive() {
        Toast.makeText(this, "Restoring database from Google Drive AppData folder...", Toast.LENGTH_SHORT).show()
        GoogleDriveService.restoreBackup(this) { success, msg ->
            runOnUiThread {
                if (success) {
                    Toast.makeText(this, "✓ $msg", Toast.LENGTH_LONG).show()
                    recreate()
                } else {
                    Toast.makeText(this, "❌ $msg", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
