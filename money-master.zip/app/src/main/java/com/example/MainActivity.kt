package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.data.AppDatabase
import com.example.data.LoanRepository
import com.example.ui.LoanViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PinSecurityScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.Language
import com.example.utils.GoogleDriveService
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: LoanViewModel
    private var mInterstitialAd: InterstitialAd? = null
    private var isAdLoading = false
    private val countdownSeconds = mutableStateOf(45)
    private var adTimerJob: kotlinx.coroutines.Job? = null
    private var adsWatchedCount: Int = 0

    private val googleSignInLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
            if (account != null) {
                viewModel.setGoogleDriveConnected(true)
                Toast.makeText(this, "✓ Google Drive Connected as: ${account.email}", Toast.LENGTH_LONG).show()
            } else {
                viewModel.setGoogleDriveConnected(false)
                Toast.makeText(this, "❌ Google Drive Connection Failed (No Account)", Toast.LENGTH_SHORT).show()
            }
        } catch (e: com.google.android.gms.common.api.ApiException) {
            e.printStackTrace()
            viewModel.setGoogleDriveConnected(false)
            val statusCode = e.statusCode
            val statusMessage = when (statusCode) {
                10 -> "DEVELOPER_ERROR: Mismatch in package name or SHA-1 fingerprint. Your build's SHA-1 is B0:04:CF:2F:10:21:70:C5:AF:72:52:7B:81:0F:52:63:A4:AD:A3:B1. Please update your Google Developer Console with this exact fingerprint registered under package 'com.aistudio.moneymaster.qyxtbw'."
                12500 -> "SIGN_IN_FAILED: Unspecified sign-in error. Often caused by Google Play Services configuration or network."
                12501 -> "SIGN_IN_CANCELLED: The sign-in flow was cancelled by the user."
                7 -> "NETWORK_ERROR: A network error occurred. Please check your internet connection."
                8 -> "INTERNAL_ERROR: An internal Google Play Services error occurred."
                else -> "Error code $statusCode: ${e.localizedMessage ?: "Unknown Error"}"
            }
            if (statusCode == 12501) {
                Toast.makeText(this, "❌ Sign-In Cancelled", Toast.LENGTH_SHORT).show()
            } else {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Google Connection Error")
                    .setMessage(statusMessage)
                    .setPositiveButton("OK", null)
                    .show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            viewModel.setGoogleDriveConnected(false)
            Toast.makeText(this, "❌ Connection Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createWebViewCacheDirs()

        // Initialize WebView directories and Google Mobile Ads SDK on a background thread
        Thread {
            try {
                createWebViewCacheDirs()
                com.google.android.gms.ads.MobileAds.initialize(this) {
                    createWebViewCacheDirs()
                    runOnUiThread {
                        loadInterstitialAd()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
        
        // Initialize local database and repository
        val database = AppDatabase.getDatabase(this)
        val repository = LoanRepository(database.loanDao())
        
        // Instantiate the ViewModel
        viewModel = androidx.lifecycle.ViewModelProvider(this, LoanViewModel.Factory(repository, this))[LoanViewModel::class.java]

        val lastAccount = com.google.android.gms.auth.api.signin.GoogleSignIn.getLastSignedInAccount(this)
        if (lastAccount != null) {
            viewModel.setGoogleDriveConnected(true)
        }

        // Schedule Transaction Cleanup Worker daily
        val cleanupRequest = androidx.work.PeriodicWorkRequestBuilder<com.example.workers.TransactionCleanupWorker>(
            1, java.util.concurrent.TimeUnit.DAYS
        ).build()
        androidx.work.WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "TransactionCleanupWork",
            androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            cleanupRequest
        )

        // Request SEND_SMS permission gracefully at startup
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            androidx.core.app.ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.SEND_SMS), 101)
        }

        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
                launch {
                    viewModel.isPremiumUser.collect {
                        checkAndManageTimer()
                    }
                }
                launch {
                    viewModel.watchedAdsToday.collect {
                        checkAndManageTimer()
                    }
                }
            }
        }

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val isBlocked by viewModel.isBlockedFromFreeFeatures.collectAsState()
                val lang by viewModel.currentLanguage.collectAsState()
                val savedPin by viewModel.savedPin.collectAsState()
                val isUnlocked by viewModel.isAppUnlocked.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    if (savedPin == null || !isUnlocked) {
                        PinSecurityScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    } else {
                        DashboardScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding),
                            countdownSeconds = countdownSeconds.value,
                            onWatchAdClick = {
                                playInterstitialAd()
                                countdownSeconds.value = 45
                            },
                            onBuyPackageClick = { pkgName, price ->
                                purchasePremiumPackage(pkgName, price)
                            },
                            onDriveConnectClick = {
                                connectGoogleDrive()
                            },
                            onDriveBackupClick = {
                                backupToGoogleDrive()
                            },
                            onDriveRestoreClick = {
                                restoreFromGoogleDrive()
                            }
                        )
                    }
                }
            }
        }
    }

    private fun getAdsWatchedCount(): Int {
        return viewModel.watchedAdsToday.value
    }

    private fun checkPremiumPackage(): Boolean {
        return viewModel.isPremiumUser.value
    }

    private fun stopAdTimer() {
        adTimerJob?.cancel()
        adTimerJob = null
    }

    private fun showAd() {
        if (countdownSeconds.value > 0) {
            countdownSeconds.value -= 1
        } else {
            // Automatically play ad
            playInterstitialAd()
            countdownSeconds.value = 45
        }
    }

    private fun checkAndManageTimer() {
        val adsWatchedCount = getAdsWatchedCount()
        val isPremiumUser = checkPremiumPackage()
        
        if (isPremiumUser || adsWatchedCount >= 25) {
            stopAdTimer()
        } else {
            if (adTimerJob == null || adTimerJob?.isActive == false) {
                startAdTimer(viewModel)
            }
        }
    }

    private fun startAdTimer(viewModel: LoanViewModel) {
        adTimerJob?.cancel()
        adTimerJob = lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(androidx.lifecycle.Lifecycle.State.STARTED) {
                while (true) {
                    delay(1000)
                    
                    // SharedPreferences හෝ Database එකෙන් Ads බැලූ ගණන සහ Package එක ගත්තා යැයි සිතන්න
                    val adsWatchedCount = getAdsWatchedCount() // දැනට බලපු ගණන
                    val isPremiumUser = checkPremiumPackage() // පැකේජ් එකක් අරන්ද කියලා

                    // ටයිමර් එක ඇතුළේ මේ condition එක දාන්න
                    if (isPremiumUser || adsWatchedCount >= 25) {
                        // පැකේජ් එකක් ගෙන තිබේ නම් හෝ ඇඩ්ස් 25ම බලා තිබේ නම් ටයිමර් එක නවත්වන්න
                        stopAdTimer() 
                    } else {
                        // නැත්නම් අනිවාර්යයෙන්ම ඇඩ් එක ප්ලේ කරන්න
                        showAd()
                    }
                    
                    viewModel.refreshAccessState()
                }
            }
        }
    }

    private fun loadInterstitialAd() {
        if (mInterstitialAd != null || isAdLoading) return
        isAdLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAd = null
                    isAdLoading = false
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd
                    isAdLoading = false
                }
            }
        )
    }

    fun playInterstitialAd(onAdDismissed: () -> Unit = {}) {
        val ad = mInterstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    mInterstitialAd = null
                    loadInterstitialAd()
                    
                    // Increment watched ad counts and check access
                    adsWatchedCount++
                    val currentCount = viewModel.watchedAdsToday.value
                    val success = viewModel.incrementWatchedAds()
                    if (success) {
                        val adNum = currentCount + 1
                        val lang = viewModel.currentLanguage.value
                        if (adNum == 25) {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "🎉 Congratulations! You watched all 25 ads today. All features unlocked for 2 days!" else "🎉 සුභ පැතුම්! ඔබ අද දිනට ඇඩ්ස් 25ම බලා අවසන්. දින 2කට සියලු විශේෂාංග නොමිලේ!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "📺 Watched ad ($adNum/25). You have 45s of TEMPORARY ACCESS!" else "📺 ඇඩ් එකක් නැරඹුවා. ($adNum/25). ඔබට තත්පර 45ක තාවකාලික ප්‍රවේශයක් ඇත!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    checkAccess()
                    
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                    mInterstitialAd = null
                    loadInterstitialAd()
                    
                    // Fallback on show failure
                    adsWatchedCount++
                    val currentCount = viewModel.watchedAdsToday.value
                    val success = viewModel.incrementWatchedAds()
                    if (success) {
                        val adNum = currentCount + 1
                        val lang = viewModel.currentLanguage.value
                        if (adNum == 25) {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "🎉 Congratulations! You watched all 25 ads today. All features unlocked for 2 days!" else "🎉 සුභ පැතුම්! ඔබ අද දිනට ඇඩ්ස් 25ම බලා අවසන්. දින 2කට සියලු විශේෂාංග නොමිලේ!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "📺 Watched ad ($adNum/25). You have 45s of TEMPORARY ACCESS!" else "📺 ඇඩ් එකක් නැරඹුවා. ($adNum/25). ඔබට තත්පර 45ක තාවකාලික ප්‍රවේශයක් ඇත!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    checkAccess()
                    
                    onAdDismissed()
                }
            }
            ad.show(this)
        } else {
            loadInterstitialAd()
            
            // Fallback if ad is not loaded yet
            adsWatchedCount++
            val currentCount = viewModel.watchedAdsToday.value
            val success = viewModel.incrementWatchedAds()
            if (success) {
                val adNum = currentCount + 1
                val lang = viewModel.currentLanguage.value
                if (adNum == 25) {
                    Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "🎉 Congratulations! You watched all 25 ads today. All features unlocked for 2 days!" else "🎉 සුභ පැතුම්! ඔබ අද දිනට ඇඩ්ස් 25ම බලා අවසන්. දින 2කට සියලු විශේෂාංග නොමිලේ!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, if (lang == Language.ENGLISH) "📺 Watched ad ($adNum/25). You have 45s of TEMPORARY ACCESS!" else "📺 ඇඩ් එකක් නැරඹුවා. ($adNum/25). ඔබට තත්පර 45ක තාවකාලික ප්‍රවේශයක් ඇත!", Toast.LENGTH_SHORT).show()
                }
            }
            checkAccess()
            
            onAdDismissed()
        }
    }

    private fun checkAccess() {
        val isPremium = viewModel.isPremiumUser.value
        val daysSinceLastStreak = viewModel.getDaysSinceLastStreak()
        val adsToday = viewModel.watchedAdsToday.value
        val lastAdSec = viewModel.getLastAdSecondsAgo()

        val accessStatus = when {
            isPremium -> "FULL_ACCESS"
            daysSinceLastStreak <= 2 -> "FULL_ACCESS"
            adsToday >= 25 -> "FULL_ACCESS"
            lastAdSec <= 45 -> "TEMPORARY_ACCESS"
            else -> "RESTRICTED"
        }
        
        android.util.Log.d("MoneyMaster", "Access check performed: Status = $accessStatus")
    }

    private fun createWebViewCacheDirs() {
        try {
            val webViewCacheDirJs = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/js")
            val webViewCacheDirWasm = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/wasm")
            if (!webViewCacheDirJs.exists()) {
                webViewCacheDirJs.mkdirs()
            }
            if (!webViewCacheDirWasm.exists()) {
                webViewCacheDirWasm.mkdirs()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun purchasePremiumPackage(packageName: String, price: Double) {
        Toast.makeText(this, "Redirecting to secure checkout...", Toast.LENGTH_LONG).show()
        try {
            val url = "https://checkout.moneymaster.com/pay?package=" + java.net.URLEncoder.encode(packageName, "UTF-8") + "&price=" + price
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            startActivity(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun connectGoogleDrive() {
        val gsoBuilder = com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(com.google.android.gms.common.api.Scope(com.google.api.services.drive.DriveScopes.DRIVE_APPDATA))

        val resId = resources.getIdentifier("default_web_client_id", "string", packageName)
        val customResId = resources.getIdentifier("google_web_client_id", "string", packageName)
        val webClientId = when {
            resId != 0 -> getString(resId)
            customResId != 0 -> getString(customResId)
            else -> ""
        }
        if (webClientId.isNotEmpty()) {
            gsoBuilder.requestIdToken(webClientId)
        }

        val gso = gsoBuilder.build()
        val googleSignInClient = com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(this, gso)
        googleSignInLauncher.launch(googleSignInClient.signInIntent)
    }

    fun backupToGoogleDrive() {
        Toast.makeText(this, "Uploading backup database to Google Drive AppData folder...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            GoogleDriveService.uploadBackup(this@MainActivity) { success, msg ->
                runOnUiThread {
                    if (success) {
                        Toast.makeText(this@MainActivity, "✓ $msg", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this@MainActivity, "❌ $msg", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    fun restoreFromGoogleDrive() {
        Toast.makeText(this, "Restoring database from Google Drive AppData folder...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            GoogleDriveService.restoreBackup(this@MainActivity) { success, msg ->
                runOnUiThread {
                    if (success) {
                        Toast.makeText(this@MainActivity, "✓ $msg", Toast.LENGTH_LONG).show()
                        recreate()
                    } else {
                        Toast.makeText(this@MainActivity, "❌ $msg", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
}
