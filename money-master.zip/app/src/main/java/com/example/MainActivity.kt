package com.example

import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import com.example.data.Document
import com.example.data.DocumentRepository
import com.example.ui.ActiveScreen
import com.example.ui.DocumentViewModel
import com.example.ui.theme.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.foundation.Image

class MainActivity : ComponentActivity() {
    private var viewModelReference: DocumentViewModel? = null

    // ★ Magic Pro Enhanced Scanner Filter
    fun applyMagicProFilter(input: android.graphics.Bitmap): android.graphics.Bitmap {
        val width = input.width
        val height = input.height
        val output = android.graphics.Bitmap.createBitmap(width, height, input.config ?: android.graphics.Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)
        input.getPixels(pixels, 0, width, 0, 0, width, height)

        for (i in pixels.indices) {
            val color = pixels[i]
            val r = android.graphics.Color.red(color)
            val g = android.graphics.Color.green(color)
            val b = android.graphics.Color.blue(color)
            val luminance = (0.299 * r + 0.587 * g + 0.114 * b).toInt()

            if (luminance > 165) {
                pixels[i] = android.graphics.Color.WHITE
            } else {
                pixels[i] = android.graphics.Color.rgb(
                    Math.max(0, (r * 0.4).toInt()), 
                    Math.max(0, (g * 0.4).toInt()), 
                    Math.max(0, (b * 0.6).toInt())
                )
            }
        }
        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }

    // 🧽 AI Connected-Component Object Eraser (Flood Fill System)
    fun eraseConnectedComponent(bitmap: android.graphics.Bitmap, startX: Int, startY: Int): android.graphics.Bitmap {
        val finalDisplayBitmap = bitmap.copy(android.graphics.Bitmap.Config.ARGB_8888, true)
        val targetColor = finalDisplayBitmap.getPixel(startX, startY)
        if (targetColor == android.graphics.Color.WHITE) return finalDisplayBitmap

        val replacementColor = android.graphics.Color.WHITE
        val width = finalDisplayBitmap.width
        val height = finalDisplayBitmap.height
        val tolerance = 15 // 🛑 රේඛා වෙන් කර හඳුනාගන්නා දැඩි සීමාව

        val targetR = android.graphics.Color.red(targetColor)
        val targetG = android.graphics.Color.green(targetColor)
        val targetB = android.graphics.Color.blue(targetColor)

        val queue: java.util.Queue<android.graphics.Point> = java.util.LinkedList()
        val visited = Array(width) { BooleanArray(height) }

        queue.add(android.graphics.Point(startX, startY))
        visited[startX][startY] = true

        while (!queue.isEmpty()) {
            val p = queue.remove()
            finalDisplayBitmap.setPixel(p.x, p.y, replacementColor)

            val dx = intArrayOf(1, -1, 0, 0)
            val dy = intArrayOf(0, 0, 1, -1)

            for (i in 0..3) {
                val nx = p.x + dx[i]
                val ny = p.y + dy[i]

                if (nx in 0 until width && ny in 0 until height && !visited[nx][ny]) {
                    val currentColor = finalDisplayBitmap.getPixel(nx, ny)
                    val r = android.graphics.Color.red(currentColor)
                    val g = android.graphics.Color.green(currentColor)
                    val b = android.graphics.Color.blue(currentColor)

                    if (Math.abs(r - targetR) < tolerance && 
                        Math.abs(g - targetG) < tolerance && 
                        Math.abs(b - targetB) < tolerance && 
                        currentColor != android.graphics.Color.WHITE) {
                        
                        queue.add(android.graphics.Point(nx, ny))
                        visited[nx][ny] = true
                    }
                }
            }
        }
        return finalDisplayBitmap
    }

    // 📸 Google ML Kit Document Scanner Activity Result Launcher
    private val scannerLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val scanResult = com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            scanResult?.let { gmsResult ->
                val pages = gmsResult.pages
                if (!pages.isNullOrEmpty()) {
                    val imageUri = pages[0].imageUri
                    try {
                        val inputStream = contentResolver.openInputStream(imageUri)
                        val rawBitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                        inputStream?.close()
                        rawBitmap?.let { b ->
                            val filtered = applyMagicProFilter(b)
                            viewModelReference?.loadBitmapIntoWorkspace(filtered)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }

                    val timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                    val scanTitle = "ML Kit Scan $timestamp"
                    viewModelReference?.setScannedTitle(scanTitle)
                    viewModelReference?.setScannedNotes("Document page successfully digitized using Google ML Kit Scanner API. Total pages: ${pages.size}")
                    viewModelReference?.navigateTo(ActiveScreen.CROP_ENHANCE)
                    Toast.makeText(this, "Document scanned successfully!", Toast.LENGTH_LONG).show()
                }
            }
        } else {
            Toast.makeText(this, "Scan cancelled or failed", Toast.LENGTH_SHORT).show()
        }
    }

    // 🖼️ Pick Photo Launcher
    private val pickPhotoLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        uri?.let {
            try {
                val inputStream = contentResolver.openInputStream(it)
                val rawBitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                rawBitmap?.let { b ->
                    val filtered = applyMagicProFilter(b)
                    viewModelReference?.loadBitmapIntoWorkspace(filtered)
                    val timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                    viewModelReference?.setScannedTitle("Imported Photo $timestamp")
                    viewModelReference?.setScannedNotes("Imported digital camera scan ready for classification.")
                    viewModelReference?.navigateTo(ActiveScreen.CROP_ENHANCE)
                    Toast.makeText(this, "Photo Imported Successfully", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Import Failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 📄 Pick PDF Launcher
    private val pickPDFLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        uri?.let {
            try {
                val pfd = contentResolver.openFileDescriptor(it, "r")
                if (pfd != null) {
                    val renderer = android.graphics.pdf.PdfRenderer(pfd)
                    if (renderer.pageCount > 0) {
                        val page = renderer.openPage(0)
                        val width = page.width
                        val height = page.height
                        val rawBitmap = android.graphics.Bitmap.createBitmap(width * 2, height * 2, android.graphics.Bitmap.Config.ARGB_8888)
                        page.render(rawBitmap, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        renderer.close()
                        pfd.close()
                        
                        val filtered = applyMagicProFilter(rawBitmap)
                        viewModelReference?.loadBitmapIntoWorkspace(filtered)
                        val timestamp = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                        viewModelReference?.setScannedTitle("Imported PDF $timestamp")
                        viewModelReference?.setScannedNotes("Imported PDF document pages ready for encryption.")
                        viewModelReference?.navigateTo(ActiveScreen.CROP_ENHANCE)
                        Toast.makeText(this, "PDF Imported Successfully", Toast.LENGTH_SHORT).show()
                    } else {
                        renderer.close()
                        pfd.close()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this, "PDF Render Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun startMlKitScanner(category: String) {
        val options = com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(100)
            .setScannerMode(com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_BASE_WITH_FILTER)
            .build()

        com.google.mlkit.vision.documentscanner.GmsDocumentScanning.getClient(options)
            .getStartScanIntent(this)
            .addOnSuccessListener { intentSender ->
                try {
                    scannerLauncher.launch(
                        androidx.activity.result.IntentSenderRequest.Builder(intentSender).build()
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "Failed to launch scanner: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "ML Kit Scanner Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                // Fallback to simulated scan if ML Kit/Google Play Services are not available on the device/emulator
                viewModelReference?.let { vm ->
                    vm.setScannedCategory(category)
                    vm.setScannedTitle("Scan " + java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date()))
                    vm.navigateTo(ActiveScreen.CROP_ENHANCE)
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()

        // Create repository and viewmodel with clean Constructor Injection
        val repository = DocumentRepository(this)
        val viewModelFactory = DocumentViewModel.Factory(repository)

        setContent {
            MyApplicationTheme {
                val viewModel: DocumentViewModel by viewModels { viewModelFactory }
                viewModelReference = viewModel
                val isLocked by viewModel.isLocked.collectAsStateWithLifecycle()
                val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
                val showOwnerIntroDialog by viewModel.showOwnerIntroDialog.collectAsStateWithLifecycle()

                if (showOwnerIntroDialog) {
                    AlertDialog(
                        onDismissRequest = { viewModel.dismissOwnerIntroDialog() },
                        confirmButton = {
                            Button(
                                onClick = { viewModel.dismissOwnerIntroDialog() },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("dismiss_owner_intro")
                            ) {
                                Text("Start Scanning", color = DeepDarkBg, fontWeight = FontWeight.Bold)
                            }
                        },
                        title = {
                            Text(
                                text = "🚀 Welcome to CamScanner Pro",
                                color = AccentTeal,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        text = {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "👑 App Owner -: Amila Lasantha",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "📧 Email -: amilalasantha940703@gmail.com",
                                    color = TextGray,
                                    fontSize = 13.sp
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(Color(0xFF333333))
                                )
                                Text(
                                    text = "Status: Licensed Premium Pro Activated\n(★ Magic Pro Engine Ready)",
                                    color = AccentTeal.copy(alpha = 0.9f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    lineHeight = 18.sp
                                )
                            }
                        },
                        containerColor = SurfaceDark,
                        shape = RoundedCornerShape(20.dp),
                        properties = androidx.compose.ui.window.DialogProperties(
                            dismissOnBackPress = false,
                            dismissOnClickOutside = false
                        )
                    )
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DeepDarkBg),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DeepDarkBg)
                    ) {
                        AnimatedContent(
                            targetState = if (isLocked) ActiveScreen.LOCK else activeScreen,
                            transitionSpec = {
                                fadeIn(animationSpec = tween(220)) togetherWith
                                        fadeOut(animationSpec = tween(220))
                            },
                            label = "screen_transition"
                        ) { targetScreen ->
                            when (targetScreen) {
                                ActiveScreen.LOCK -> ScreenLock(viewModel)
                                ActiveScreen.DASHBOARD -> ScreenDashboard(viewModel)
                                ActiveScreen.SCAN -> ScreenScan(viewModel)
                                ActiveScreen.CROP_ENHANCE -> ScreenCropEnhance(viewModel)
                                ActiveScreen.DETAIL -> ScreenDetail(viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenLock(viewModel: DocumentViewModel) {
    var passwordInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var showBiometricScan by remember { mutableStateOf(false) }
    var biometricScanState by remember { mutableStateOf("Scanning...") }

    val isUnlockError by viewModel.isUnlockError.collectAsStateWithLifecycle()
    val savedPassword by viewModel.savedPassword.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Biometric Unlock Simulation Flow
    LaunchedEffect(showBiometricScan) {
        if (showBiometricScan) {
            biometricScanState = "සංවේදකය ස්පර්ශ කරන්න\n(Place finger on sensor)"
            delay(1200)
            biometricScanState = "මුද්‍රාව සත්‍යාපනය කරමින්...\n(Verifying fingerprint...)"
            delay(1000)
            biometricScanState = "සත්‍යාපනය සාර්ථකයි!\n(Verification Successful!)"
            delay(500)
            showBiometricScan = false
            viewModel.unlock(savedPassword) // Unlock with the real saved password
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepDarkBg)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            // App Brand Icon - Sleek geometric scanner logo
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(AccentTeal.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                    .border(1.dp, AccentTeal.copy(alpha = 0.2f), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Outer custom bracket lines
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .border(3.dp, AccentTeal, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Document cross diagonal scan line
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        drawLine(
                            color = AccentTeal,
                            start = Offset(0f, 0f),
                            end = Offset(size.width, size.height),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = AccentTeal.copy(alpha = 0.5f),
                            start = Offset(0f, size.height),
                            end = Offset(size.width, 0f),
                            strokeWidth = 2f
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.DocumentScanner,
                        contentDescription = "Scanner",
                        tint = AccentTeal.copy(alpha = 0.9f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Header Section
            Text(
                text = "CamScanner Pro",
                color = Color.White,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = (-0.5).sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )

            Text(
                text = stringResource(id = R.string.secure_gate_subtitle),
                color = TextGray,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 2.dp)
            )

            Text(
                text = "ENTER SECURE PASSWORD",
                color = TextGray.copy(alpha = 0.6f),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 36.dp)
            )

            // Password Field Container with floating label simulation
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
            ) {
                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it },
                    label = { Text("Password", color = AccentTeal, fontWeight = FontWeight.SemiBold) },
                    placeholder = { Text("••••••••", color = TextDarkGray) },
                    visualTransformation = if (isPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Toggle password visibility",
                                tint = TextGray
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("etPassword"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentTeal,
                        unfocusedBorderColor = Color(0xFF333333),
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark,
                        focusedLabelColor = AccentTeal,
                        unfocusedLabelColor = TextGray
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
            }

            // 💡 Password Hint: Starts with 'S/' followed by 6 digits
            Text(
                text = "💡 Password Hint: Starts with 'S/' followed by 6 digits",
                color = Color(0xFFFFB300),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 20.dp).testTag("password_hint")
            )

            // Error message helper
            AnimatedVisibility(
                visible = isUnlockError,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Text(
                    text = "වැරදි මුරපදයකි! නැවත උත්සාහ කරන්න\n(Incorrect password! Try again)",
                    color = Color.Red,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // Unlock Button with drop-shadow vibe
            Button(
                onClick = {
                    viewModel.unlock(passwordInput)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btnUnlock"),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = stringResource(id = R.string.unlock_button),
                    color = DeepDarkBg,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Forgot Password Link
            TextButton(
                onClick = {
                    Toast.makeText(
                        context,
                        "භාවිතය සඳහා සහය: පෙරනිමි මුරපදය S/680746 වේ.\n(Help: Default password is S/680746.)",
                        Toast.LENGTH_LONG
                    ).show()
                }
            ) {
                Text(
                    text = "Forgot Password?",
                    color = AccentTeal,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Bottom Biometric Unlock Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { showBiometricScan = true }
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .border(1.dp, Color(0xFF333333), CircleShape)
                        .background(SurfaceDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Biometric Scan",
                        tint = AccentTeal,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "USE BIOMETRIC UNLOCK",
                    color = TextGray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Biometric Scanning Overlay
        AnimatedVisibility(
            visible = showBiometricScan,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.85f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, AccentTeal.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Pulsing Biometric/Fingerprint indicator
                        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                        val scale by infiniteTransition.animateFloat(
                            initialValue = 0.9f,
                            targetValue = 1.1f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(1000, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "scale"
                        )

                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .background(AccentTeal.copy(alpha = 0.1f), CircleShape)
                                .border(1.dp, AccentTeal.copy(alpha = scale), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = "Scanning...",
                                tint = AccentTeal,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Text(
                            text = biometricScanState,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        TextButton(onClick = { showBiometricScan = false }) {
                            Text(
                                text = "අවලංගු කරන්න (Cancel)",
                                color = TextGray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenDashboard(viewModel: DocumentViewModel) {
    val documents by viewModel.filteredDocuments.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val savedPassword by viewModel.savedPassword.collectAsStateWithLifecycle()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var oldPasswordInput by remember { mutableStateOf("") }
    var newPasswordInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    val categories = listOf("All", "Receipt", "Invoice", "Contract", "Personal", "Other")

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Shield",
                            tint = AccentTeal,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SECURE VAULT",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Vault Settings",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = { viewModel.lockVault() },
                        modifier = Modifier.testTag("lock_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock Vault",
                            tint = AccentTeal
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = DeepDarkBg
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(ActiveScreen.SCAN) },
                containerColor = AccentTeal,
                contentColor = DeepDarkBg,
                shape = CircleShape,
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("scan_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Scan New Document",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        containerColor = DeepDarkBg
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DeepDarkBg)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextGray
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = TextGray
                            )
                        }
                    }
                },
                placeholder = { Text("සොයන්න (Search documents...)", color = TextDarkGray, fontSize = 14.sp) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("search_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = AccentTeal,
                    unfocusedBorderColor = SurfaceDark,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark
                ),
                shape = RoundedCornerShape(24.dp)
            )

            // 📥 Import Options (Dashboard) - පාස්වර්ඩ් එක ගැහුවාම විතරක් වැඩ කරයි
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.setScannedCategory("Personal")
                        pickPhotoLauncher.launch("image/*")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("btnImportPhoto")
                ) {
                    Text("🖼️ Import Photo", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        viewModel.setScannedCategory("Contract")
                        pickPDFLauncher.launch("application/pdf")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("btnImportPDF")
                ) {
                    Text("📄 Import PDF", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Category Horizontal Scroll List
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory == category
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) AccentTeal else SurfaceDark)
                            .border(
                                1.dp,
                                if (isSelected) AccentTeal else TextDarkGray,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { viewModel.setSelectedCategory(category) }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("chip_$category")
                    ) {
                        Text(
                            text = category,
                            color = if (isSelected) DeepDarkBg else Color.White,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            // Document Count Indicator
            Text(
                text = "${documents.size} SCANNED DOCUMENTS SECURED",
                color = AccentTeal,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            // Main List Section
            if (documents.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentPasteSearch,
                        contentDescription = "Empty Vault",
                        tint = TextDarkGray,
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "ආරක්ෂිත ලේඛන කිසිවක් නැත",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "No secure documents found. Press the camera button below to scan your first receipt, contract, or note.",
                        color = TextGray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(documents, key = { it.id }) { doc ->
                        DocumentItemCard(doc = doc, onClick = { viewModel.selectDocument(doc) })
                    }
                }
            }
        }
    }

    // Settings Password Change Dialog
    if (showSettingsDialog) {
        AlertDialog(
            onDismissRequest = {
                showSettingsDialog = false
                oldPasswordInput = ""
                newPasswordInput = ""
            },
            title = {
                Text(
                    text = "මුරපදය වෙනස් කරන්න\n(Change Vault Password)",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Your private vault is securely protected. Update your access PIN below.",
                        color = TextGray,
                        fontSize = 13.sp
                    )

                    OutlinedTextField(
                        value = oldPasswordInput,
                        onValueChange = { oldPasswordInput = it },
                        label = { Text("වත්මන් මුරපදය (Current PIN)", color = TextGray) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentTeal
                        )
                    )

                    OutlinedTextField(
                        value = newPasswordInput,
                        onValueChange = { newPasswordInput = it },
                        label = { Text("නව මුරපදය (New PIN)", color = TextGray) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentTeal
                        )
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (oldPasswordInput == savedPassword) {
                            if (newPasswordInput.trim().isNotEmpty()) {
                                viewModel.updatePassword(newPasswordInput.trim())
                                Toast.makeText(context, "මුරපදය සාර්ථකව වෙනස් කරන ලදී!\n(Password updated successfully!)", Toast.LENGTH_SHORT).show()
                                showSettingsDialog = false
                                oldPasswordInput = ""
                                newPasswordInput = ""
                            } else {
                                Toast.makeText(context, "නව මුරපදය හිස් විය නොහැක\n(New password cannot be empty)", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "වත්මන් මුරපදය වැරදියි!\n(Incorrect current PIN!)", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("සුරකින්න (Save PIN)", color = AccentTeal, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text("අවලංගු කරන්න (Cancel)", color = TextGray)
                }
            },
            containerColor = SurfaceDark
        )
    }
}

@Composable
fun DocumentItemCard(doc: Document, onClick: () -> Unit) {
    val categoryIcon = when (doc.category.lowercase()) {
        "receipt" -> Icons.Default.ReceiptLong
        "invoice" -> Icons.Default.Description
        "contract" -> Icons.Default.Assignment
        "personal" -> Icons.Default.Badge
        else -> Icons.Default.FilePresent
    }

    val formattedDate = remember(doc.dateMillis) {
        val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
        sdf.format(java.util.Date(doc.dateMillis))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("doc_item_${doc.id}"),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, TextDarkGray.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Icon background circle
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(AccentTeal.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                    .border(1.dp, AccentTeal.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = categoryIcon,
                    contentDescription = doc.category,
                    tint = AccentTeal,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text Info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = doc.title,
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Box(
                        modifier = Modifier
                            .background(AccentTeal.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = doc.filterApplied,
                            color = AccentTeal,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = doc.notes.ifEmpty { "No extra details added." },
                    color = TextGray,
                    fontSize = 13.sp,
                    maxLines = 1,
                    modifier = Modifier.padding(end = 8.dp)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = "Date",
                        tint = TextDarkGray,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = formattedDate,
                        color = TextGray,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.Category,
                        contentDescription = "Category",
                        tint = TextDarkGray,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = doc.category,
                        color = TextGray,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open Details",
                tint = TextDarkGray,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun ScreenScan(viewModel: DocumentViewModel) {
    val context = LocalContext.current
    var flashOn by remember { mutableStateOf(false) }
    var gridOn by remember { mutableStateOf(true) }
    var selectedCat by remember { mutableStateOf("Receipt") }

    val scanCategories = listOf("Receipt", "Invoice", "Contract", "Personal", "Other")

    // Pulsing Scanning Line Animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_line")
    val lineOffsetFraction by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "line_offset"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Camera Viewport Simulation
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Render a dark grid matching viewfinder overlays
            if (gridOn) {
                val gridAlpha = 0.2f
                // Vertical lines
                drawLine(Color.White, Offset(width / 3, 0f), Offset(width / 3, height), strokeWidth = 1f, alpha = gridAlpha)
                drawLine(Color.White, Offset(width * 2 / 3, 0f), Offset(width * 2 / 3, height), strokeWidth = 1f, alpha = gridAlpha)
                // Horizontal lines
                drawLine(Color.White, Offset(0f, height / 3), Offset(width, height / 3), strokeWidth = 1f, alpha = gridAlpha)
                drawLine(Color.White, Offset(0f, height * 2 / 3), Offset(width, height * 2 / 3), strokeWidth = 1f, alpha = gridAlpha)
            }

            // Draw scanning boundaries
            val scanRectWidth = width * 0.85f
            val scanRectHeight = height * 0.55f
            val left = (width - scanRectWidth) / 2
            val top = (height - scanRectHeight) / 2
            val right = left + scanRectWidth
            val bottom = top + scanRectHeight

            // Draw semi-transparent background overlay outside scanning rectangle
            drawRect(Color.Black.copy(alpha = 0.5f), Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(width, top))
            drawRect(Color.Black.copy(alpha = 0.5f), Offset(0f, bottom), size = androidx.compose.ui.geometry.Size(width, height - bottom))
            drawRect(Color.Black.copy(alpha = 0.5f), Offset(0f, top), size = androidx.compose.ui.geometry.Size(left, scanRectHeight))
            drawRect(Color.Black.copy(alpha = 0.5f), Offset(right, top), size = androidx.compose.ui.geometry.Size(width - right, scanRectHeight))

            // Draw bounding rect corners (Green edge detection)
            val cornerSize = 40f
            val thickness = 6f
            val cornerColor = AccentTeal

            // Top-Left corner
            drawLine(cornerColor, Offset(left, top), Offset(left + cornerSize, top), strokeWidth = thickness)
            drawLine(cornerColor, Offset(left, top), Offset(left, top + cornerSize), strokeWidth = thickness)

            // Top-Right corner
            drawLine(cornerColor, Offset(right, top), Offset(right - cornerSize, top), strokeWidth = thickness)
            drawLine(cornerColor, Offset(right, top), Offset(right, top + cornerSize), strokeWidth = thickness)

            // Bottom-Left corner
            drawLine(cornerColor, Offset(left, bottom), Offset(left + cornerSize, bottom), strokeWidth = thickness)
            drawLine(cornerColor, Offset(left, bottom), Offset(left, bottom - cornerSize), strokeWidth = thickness)

            // Bottom-Right corner
            drawLine(cornerColor, Offset(right, bottom), Offset(right - cornerSize, bottom), strokeWidth = thickness)
            drawLine(cornerColor, Offset(right, bottom), Offset(right, bottom - cornerSize), strokeWidth = thickness)

            // Moving Lasers scan line inside scanner frame
            val currentLaserY = top + (scanRectHeight * lineOffsetFraction)
            drawLine(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color.Transparent, AccentTeal, Color.Transparent)
                ),
                start = Offset(left, currentLaserY),
                end = Offset(right, currentLaserY),
                strokeWidth = 4f
            )
        }

        // Top HUD Overlay controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateTo(ActiveScreen.DASHBOARD) },
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    .testTag("scan_back_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(
                    onClick = { flashOn = !flashOn },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (flashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash Toggle",
                        tint = if (flashOn) AccentTeal else Color.White
                    )
                }

                IconButton(
                    onClick = { gridOn = !gridOn },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(
                        imageVector = if (gridOn) Icons.Default.GridOn else Icons.Default.GridOff,
                        contentDescription = "Grid Toggle",
                        tint = if (gridOn) AccentTeal else Color.White
                    )
                }
            }
        }

        // Bottom Scanner Control Panel
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color.Black.copy(alpha = 0.85f))
                .padding(bottom = 24.dp)
        ) {
            // Scanner alignment guidance text
            Text(
                text = "ලියවිල්ල රාමුව තුලට පෙළගස්වන්න\n(Align paper inside boundary box)",
                color = AccentTeal,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            )

            // Horizontal Document category slider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 20.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                scanCategories.forEach { category ->
                    val isSelected = selectedCat == category
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) AccentTeal else SurfaceDark)
                            .clickable { selectedCat = category }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = category.uppercase(),
                            color = if (isSelected) DeepDarkBg else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Capture Trigger Button Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Main Trigger Button
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(AccentTeal)
                        .clickable {
                            viewModel.setScannedCategory(selectedCat)
                            val mainActivity = context as? MainActivity
                            if (mainActivity != null) {
                                mainActivity.startMlKitScanner(selectedCat)
                            } else {
                                viewModel.setScannedTitle("Scan " + java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date()))
                                viewModel.navigateTo(ActiveScreen.CROP_ENHANCE)
                            }
                        }
                        .testTag("shutter_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Camera,
                        contentDescription = "Capture Document",
                        tint = DeepDarkBg,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }
    }
}

data class DrawStroke(
    val points: List<Offset>,
    val color: Color,
    val strokeWidth: Float,
    val isErase: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenCropEnhance(viewModel: DocumentViewModel) {
    val scannedTitle by viewModel.scannedTitle.collectAsStateWithLifecycle()
    val scannedNotes by viewModel.scannedNotes.collectAsStateWithLifecycle()
    val scannedCategory by viewModel.scannedCategory.collectAsStateWithLifecycle()
    val scannedFilter by viewModel.scannedFilter.collectAsStateWithLifecycle()
    val isOcrLoading by viewModel.isOcrLoading.collectAsStateWithLifecycle()

    var useAiOcr by remember { mutableStateOf(true) }
    var showAdvancedPreview by remember { mutableStateOf(false) }
    val filters = listOf("Original", "Magic Color", "B&W", "Grayscale")
    val context = LocalContext.current

    if (isOcrLoading) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepDarkBg)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    modifier = Modifier.size(80.dp),
                    color = AccentTeal,
                    strokeWidth = 6.dp
                )
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Processing",
                    tint = AccentTeal,
                    modifier = Modifier.size(32.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "ලේඛනය සකසමින් පවතී...",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (useAiOcr) "AI Smart OCR Engine running analysis on document structure and extracts searchable text contents..." 
                       else "Applying digital filters and local OCR encryption formats...",
                color = TextGray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("ENHANCE SCAN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.navigateTo(ActiveScreen.SCAN) }) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepDarkBg)
                )
            },
            containerColor = DeepDarkBg
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(DeepDarkBg)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Paper Preview Box simulating auto crop overlay
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceDark)
                        .border(BorderStroke(1.dp, TextDarkGray))
                        .clickable { showAdvancedPreview = true }
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Draw a simulated paper sheet inside crop margins
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Draggable border simulation
                        val path = androidx.compose.ui.graphics.Path().apply {
                            moveTo(w * 0.15f, h * 0.12f)
                            lineTo(w * 0.85f, h * 0.18f)
                            lineTo(w * 0.82f, h * 0.88f)
                            lineTo(w * 0.18f, h * 0.82f)
                            close()
                        }
                        // Draw simulated document canvas surface
                        drawPath(path, Color.White)

                        // Draw crop alignment points (teal hollow circles)
                        val r = 12f
                        drawCircle(AccentTeal, r, Offset(w * 0.15f, h * 0.12f))
                        drawCircle(AccentTeal, r, Offset(w * 0.85f, h * 0.18f))
                        drawCircle(AccentTeal, r, Offset(w * 0.82f, h * 0.88f))
                        drawCircle(AccentTeal, r, Offset(w * 0.18f, h * 0.82f))
                    }

                    // Content layout overlay in paper representation
                    Column(
                        modifier = Modifier
                            .fillMaxSize(0.6f)
                            .align(Alignment.Center),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "[ ${scannedCategory.uppercase()} DETECTED ]",
                            color = Color.DarkGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Icon(
                            imageVector = Icons.Default.DocumentScanner,
                            contentDescription = "Alignment",
                            tint = AccentTealDark,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "Auto-Crop Applied ✓",
                            color = AccentTealDark,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Tappable help prompt badge
                    Text(
                        text = "🔍 Tap to Zoom & Preview",
                        color = AccentTeal,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                            .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                // 📸 Advanced Zoom Preview & Retake Panel (ස්කෑන් කළ පසු පෙනෙන කොටස)
                if (showAdvancedPreview) {
                    AlertDialog(
                        onDismissRequest = { showAdvancedPreview = false },
                        confirmButton = {},
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🔍 Document Preview Workspace",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                IconButton(onClick = { showAdvancedPreview = false }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                                }
                            }
                        },
                        text = {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Select edit mode below. Touch & draw to erase or write.",
                                    color = TextGray,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                var scale by remember { mutableStateOf(1f) }
                                var offset by remember { mutableStateOf(Offset.Zero) }
                                var workspaceMode by remember { mutableStateOf("View") } // "View", "Erase", "Sign"
                                val strokes = remember { mutableStateListOf<DrawStroke>() }
                                var showSignatureOptions by remember { mutableStateOf(false) }
                                var signatureMode by remember { mutableStateOf("Draw") } // "Draw", "Scan"
                                var scanSignatureOffset by remember { mutableStateOf(Offset(50f, 150f)) }
                                var isWatermarkEnabled by remember { mutableStateOf(true) }
                                var watermarkText by remember { mutableStateOf("Amila Lasantha") }
                                var isHeaderErased by remember { mutableStateOf(false) }
                                var isTitleErased by remember { mutableStateOf(false) }
                                var isNotesErased by remember { mutableStateOf(false) }
                                var isDividerErased by remember { mutableStateOf(false) }
                                var isFooterErased by remember { mutableStateOf(false) }
                                var isWatermarkErased by remember { mutableStateOf(false) }

                                // 🛠️ Filters & Tools Toolbar (btnModeView, btnFilterMagic, btnFilterBW, btnModeErase, btnModeSign)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(bottom = 12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { workspaceMode = "View" },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (workspaceMode == "View") AccentTeal else Color(0xFF333333),
                                            contentColor = if (workspaceMode == "View") DeepDarkBg else Color.White
                                        ),
                                        modifier = Modifier
                                            .height(38.dp)
                                            .testTag("btnModeView"),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("🔍 Zoom/View", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { viewModel.setScannedFilter("Magic Color") },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (scannedFilter == "Magic Color") Color(0xFF00796B) else Color(0xFF333333),
                                            contentColor = Color.White
                                        ),
                                        modifier = Modifier
                                            .height(38.dp)
                                            .testTag("btnFilterMagic"),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("★ Magic Pro", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { viewModel.setScannedFilter("B&W") },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (scannedFilter == "B&W") Color(0xFF00796B) else Color(0xFF333333),
                                            contentColor = Color.White
                                        ),
                                        modifier = Modifier
                                            .height(38.dp)
                                            .testTag("btnFilterBW"),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("🔳 High-Q B&W", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { workspaceMode = "Erase" },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (workspaceMode == "Erase") AccentTeal else Color(0xFF333333),
                                            contentColor = if (workspaceMode == "Erase") DeepDarkBg else Color.White
                                        ),
                                        modifier = Modifier
                                            .height(38.dp)
                                            .testTag("btnModeErase"),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("🧽 AI Erase", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { workspaceMode = "SmartErase" },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (workspaceMode == "SmartErase") AccentTeal else Color(0xFF333333),
                                            contentColor = if (workspaceMode == "SmartErase") DeepDarkBg else Color.White
                                        ),
                                        modifier = Modifier
                                            .height(38.dp)
                                            .testTag("btnModeSmartErase"),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("✨ Smart Erase", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = { showSignatureOptions = true },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (workspaceMode == "Sign") AccentTeal else Color(0xFF333333),
                                            contentColor = if (workspaceMode == "Sign") DeepDarkBg else Color.White
                                        ),
                                        modifier = Modifier
                                            .height(38.dp)
                                            .testTag("btnModeSign"),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                                    ) {
                                        Text("✍️ Add Sign", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // 🛡️ Watermark On/Off Switch
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(start = 4.dp, end = 4.dp)
                                    ) {
                                        Switch(
                                            checked = isWatermarkEnabled,
                                            onCheckedChange = { isWatermarkEnabled = it },
                                            modifier = Modifier.testTag("switchWatermark"),
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = AccentTeal,
                                                checkedTrackColor = AccentTeal.copy(alpha = 0.5f),
                                                uncheckedThumbColor = Color.Gray,
                                                uncheckedTrackColor = Color(0xFF333333)
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "🛡️ Watermark",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                         )
                                    }

                                    // ✍️ Custom Watermark Text Field
                                    BasicTextField(
                                        value = watermarkText,
                                        onValueChange = { watermarkText = it },
                                        textStyle = androidx.compose.ui.text.TextStyle(
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium
                                        ),
                                        modifier = Modifier
                                            .width(120.dp)
                                            .height(34.dp)
                                            .testTag("etWatermarkText")
                                            .background(Color(0xFF333333), RoundedCornerShape(8.dp))
                                            .border(1.dp, Color(0xFF555555), RoundedCornerShape(8.dp)),
                                        singleLine = true,
                                        decorationBox = { innerTextField ->
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(horizontal = 8.dp),
                                                contentAlignment = Alignment.CenterStart
                                            ) {
                                                if (watermarkText.isEmpty()) {
                                                    Text("Text...", color = Color(0xFF777777), fontSize = 11.sp)
                                                }
                                                innerTextField()
                                            }
                                        }
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(300.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.Black)
                                        .border(BorderStroke(1.dp, Color(0xFF333333)), RoundedCornerShape(12.dp))
                                        .pointerInput(workspaceMode) {
                                            if (workspaceMode == "View") {
                                                detectTransformGestures { _, pan, zoom, _ ->
                                                    scale = (scale * zoom).coerceIn(1f, 5f)
                                                    offset = if (scale == 1f) Offset.Zero else offset + pan
                                                }
                                            }
                                        }
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    // High Fidelity simulated paper sheet (Magic Pro Contrast Filter applied)
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        shape = RoundedCornerShape(4.dp),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = scale,
                                                scaleY = scale,
                                                translationX = offset.x,
                                                translationY = offset.y
                                            )
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .pointerInput(workspaceMode, signatureMode) {
                                                    if (workspaceMode == "SmartErase") {
                                                        detectTapGestures { tapOffset ->
                                                            var strokeTapped = false
                                                            val tapThreshold = 30f // pixels
                                                            val strokeToErase = strokes.find { stroke ->
                                                                stroke.points.any { pt ->
                                                                    val dx = pt.x - tapOffset.x
                                                                    val dy = pt.y - tapOffset.y
                                                                    (dx * dx + dy * dy) < (tapThreshold * tapThreshold)
                                                                }
                                                            }
                                                            if (strokeToErase != null) {
                                                                // 🧽 AI Connected-Component Object Eraser (Flood Fill System)
                                                                val connectedList = mutableSetOf<DrawStroke>()
                                                                val queue = java.util.LinkedList<DrawStroke>()
                                                                queue.add(strokeToErase)
                                                                connectedList.add(strokeToErase)
                                                                
                                                                val connectionThreshold = 40f
                                                                while (!queue.isEmpty()) {
                                                                    val current = queue.poll()
                                                                    if (current != null) {
                                                                        for (stroke in strokes) {
                                                                            if (stroke !in connectedList) {
                                                                                val isConnected = current.points.any { p1 ->
                                                                                    stroke.points.any { p2 ->
                                                                                        val dx = p1.x - p2.x
                                                                                        val dy = p1.y - p2.y
                                                                                        (dx * dx + dy * dy) < (connectionThreshold * connectionThreshold)
                                                                                    }
                                                                                }
                                                                                if (isConnected) {
                                                                                    connectedList.add(stroke)
                                                                                    queue.add(stroke)
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                strokes.removeAll(connectedList)
                                                                strokeTapped = true
                                                                Toast.makeText(context, "AI Connected-Component Object Erased! 🧽 / ඇඳීම මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                            }

                                                            if (!strokeTapped) {
                                                                val relativeY = tapOffset.y / size.height
                                                                val dx = tapOffset.x - (size.width / 2f)
                                                                val dy = tapOffset.y - (size.height / 2f)
                                                                val distToCenter = Math.sqrt((dx * dx + dy * dy).toDouble())
                                                                if (isWatermarkEnabled && watermarkText.isNotEmpty() && distToCenter < (size.width / 3f) && !isWatermarkErased) {
                                                                    isWatermarkErased = true
                                                                    Toast.makeText(context, "Watermark Erased! / දිය සලකුණ මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                                } else {
                                                                    when {
                                                                        relativeY < 0.12f -> {
                                                                            if (!isHeaderErased) {
                                                                                isHeaderErased = true
                                                                                Toast.makeText(context, "Header Erased! / ශීර්ෂය මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                                            }
                                                                        }
                                                                        relativeY >= 0.12f && relativeY < 0.16f -> {
                                                                            if (!isDividerErased) {
                                                                                isDividerErased = true
                                                                                Toast.makeText(context, "Divider Erased! / බෙදුම් රේඛාව මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                                            }
                                                                        }
                                                                        relativeY >= 0.16f && relativeY < 0.24f -> {
                                                                            if (!isTitleErased) {
                                                                                isTitleErased = true
                                                                                Toast.makeText(context, "Title Erased! / මාතෘකාව මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                                            }
                                                                        }
                                                                        relativeY >= 0.24f && relativeY < 0.40f -> {
                                                                            if (!isNotesErased) {
                                                                                isNotesErased = true
                                                                                Toast.makeText(context, "Notes Erased! / සටහන් මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                                            }
                                                                        }
                                                                        relativeY >= 0.40f -> {
                                                                            if (!isFooterErased) {
                                                                                isFooterErased = true
                                                                                Toast.makeText(context, "Footer Info Erased! / පාදකය මැකී ගියේය!", Toast.LENGTH_SHORT).show()
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else if (workspaceMode == "Erase" || (workspaceMode == "Sign" && signatureMode == "Draw")) {
                                                        detectDragGestures(
                                                            onDragStart = { startOffset ->
                                                                val currentStroke = DrawStroke(
                                                                    points = listOf(startOffset),
                                                                    color = if (workspaceMode == "Erase") Color.White else Color(0xFF0055FF),
                                                                    strokeWidth = if (workspaceMode == "Erase") 32f else 8f,
                                                                    isErase = workspaceMode == "Erase"
                                                                )
                                                                strokes.add(currentStroke)
                                                            },
                                                            onDrag = { change, dragAmount ->
                                                                change.consume()
                                                                if (strokes.isNotEmpty()) {
                                                                    val last = strokes.last()
                                                                    strokes[strokes.size - 1] = last.copy(
                                                                        points = last.points + (last.points.last() + dragAmount)
                                                                    )
                                                                }
                                                            }
                                                        )
                                                    }
                                                }
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(12.dp)
                                            ) {
                                                if (!isHeaderErased) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "CAMSCANNER PRO DIGITAL ENGINE",
                                                            color = Color(0xAA00BFA5),
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                        Text(
                                                            text = scannedCategory.uppercase(),
                                                            color = Color.Gray,
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    }
                                                } else {
                                                    Spacer(modifier = Modifier.height(10.dp))
                                                }

                                                if (!isDividerErased) {
                                                    HorizontalDivider(
                                                        color = Color.LightGray,
                                                        thickness = 1.dp,
                                                        modifier = Modifier.padding(vertical = 4.dp)
                                                    )
                                                } else {
                                                    Spacer(modifier = Modifier.height(9.dp))
                                                }

                                                Spacer(modifier = Modifier.height(4.dp))

                                                if (!isTitleErased) {
                                                    Text(
                                                        text = "TITLE: $scannedTitle",
                                                        color = Color.Black,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        fontFamily = FontFamily.Monospace
                                                    )
                                                } else {
                                                    Spacer(modifier = Modifier.height(14.dp))
                                                }
                                                
                                                if (scannedNotes.isNotEmpty() && !isNotesErased) {
                                                    Spacer(modifier = Modifier.height(2.dp))
                                                    Text(
                                                        text = "NOTES: $scannedNotes",
                                                        color = Color.DarkGray,
                                                        fontSize = 8.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        lineHeight = 11.sp
                                                    )
                                                } else if (scannedNotes.isNotEmpty() && isNotesErased) {
                                                    Spacer(modifier = Modifier.height(13.dp))
                                                }

                                                Spacer(modifier = Modifier.height(10.dp))

                                                if (!isFooterErased) {
                                                    val filterInfoText = if (scannedFilter == "B&W") {
                                                        "--- [🔳 HIGH-Q B&W FILTER ACTIVE] ---\n" +
                                                        "• Textures and grayscales converted to binary monochrome\n" +
                                                        "• Sharp edge rendering with threshold optimization\n" +
                                                        "• Background noise and low-contrast elements removed\n" +
                                                        "• Ideal for photocopying and high-density printing\n" +
                                                        "-------------------------------------\n" +
                                                        "Status: High-Q B&W Document Generated"
                                                     } else {
                                                        "--- [★ MAGIC PRO FILTER ACTIVE] ---\n" +
                                                        "• High luminance backdrop normalized to #FFFFFF\n" +
                                                        "• Ink lines enhanced to deep dark/blue tones\n" +
                                                        "• Shadows, paper creases & wrinkles wiped out\n" +
                                                        "• AI OCR extraction active for digital vault copy\n" +
                                                        "-------------------------------------\n" +
                                                        "Status: High Fidelity Scan Ready for Secure Vault"
                                                     }
                                                    Text(
                                                        text = filterInfoText,
                                                        color = Color.DarkGray,
                                                        fontSize = 8.sp,
                                                        fontFamily = FontFamily.Monospace,
                                                        lineHeight = 11.sp
                                                    )
                                                }
                                            }

                                            if (isWatermarkEnabled && watermarkText.isNotEmpty() && !isWatermarkErased) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .padding(24.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = watermarkText.uppercase(),
                                                        color = Color(0x1C00BFA5),
                                                        fontSize = 24.sp,
                                                        fontWeight = FontWeight.Black,
                                                        fontFamily = FontFamily.Monospace,
                                                        modifier = Modifier
                                                            .graphicsLayer(rotationZ = -30f)
                                                            .testTag("watermarkTextDisplay")
                                                    )
                                                }
                                            }

                                            // ✍️ Overlay Canvas drawing erasures & signatures
                                            Canvas(modifier = Modifier.fillMaxSize()) {
                                                strokes.forEach { stroke ->
                                                    if (stroke.points.size > 1) {
                                                        val path = androidx.compose.ui.graphics.Path().apply {
                                                            val first = stroke.points.first()
                                                            moveTo(first.x, first.y)
                                                            for (i in 1 until stroke.points.size) {
                                                                val pt = stroke.points[i]
                                                                lineTo(pt.x, pt.y)
                                                            }
                                                        }
                                                        drawPath(
                                                            path = path,
                                                            color = stroke.color,
                                                            style = Stroke(
                                                                width = stroke.strokeWidth,
                                                                cap = StrokeCap.Round,
                                                                join = StrokeJoin.Round
                                                            )
                                                        )
                                                    }
                                                }
                                            }

                                            if (workspaceMode == "Sign" && signatureMode == "Scan") {
                                                Box(
                                                    modifier = Modifier
                                                        .offset(
                                                            x = scanSignatureOffset.x.dp,
                                                            y = scanSignatureOffset.y.dp
                                                        )
                                                        .pointerInput(Unit) {
                                                            detectDragGestures(
                                                                onDrag = { change, dragAmount ->
                                                                    change.consume()
                                                                    scanSignatureOffset = scanSignatureOffset + dragAmount
                                                                }
                                                            )
                                                        }
                                                        .background(Color(0x220055FF), RoundedCornerShape(4.dp))
                                                        .border(1.dp, Color(0xFF0055FF), RoundedCornerShape(4.dp))
                                                        .padding(8.dp)
                                                ) {
                                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                        Text(
                                                            text = "Amila Lasantha",
                                                            color = Color(0xFF001188),
                                                            fontSize = 16.sp,
                                                            fontFamily = FontFamily.Cursive,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        Text(
                                                            text = "Scan Signature Overlay",
                                                            color = Color(0xFF0055FF),
                                                            fontSize = 6.sp,
                                                            fontFamily = FontFamily.Monospace
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (showSignatureOptions) {
                                    AlertDialog(
                                        onDismissRequest = { showSignatureOptions = false },
                                        title = { Text("Add Signature", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                                        text = {
                                            Column(
                                                verticalArrangement = Arrangement.spacedBy(12.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        signatureMode = "Draw"
                                                        workspaceMode = "Sign"
                                                        showSignatureOptions = false
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                                                    modifier = Modifier.fillMaxWidth().height(44.dp)
                                                ) {
                                                    Text("✍️ Draw Signature", color = DeepDarkBg, fontWeight = FontWeight.Bold)
                                                }
                                                Button(
                                                    onClick = {
                                                        signatureMode = "Scan"
                                                        workspaceMode = "Sign"
                                                        showSignatureOptions = false
                                                        Toast.makeText(context, "Scan signature mode", Toast.LENGTH_SHORT).show()
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333)),
                                                    modifier = Modifier.fillMaxWidth().height(44.dp)
                                                ) {
                                                    Text("📷 Scan Signature", color = Color.White, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        },
                                        confirmButton = {},
                                        containerColor = SurfaceDark,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                }

                                if (strokes.isNotEmpty() || isHeaderErased || isTitleErased || isNotesErased || isDividerErased || isFooterErased || isWatermarkErased) {
                                    TextButton(
                                        onClick = {
                                            strokes.clear()
                                            isHeaderErased = false
                                            isTitleErased = false
                                            isNotesErased = false
                                            isDividerErased = false
                                            isFooterErased = false
                                            isWatermarkErased = false
                                        }
                                    ) {
                                        Text("🧹 Reset Document & Drawings", color = AccentTeal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                if (scale > 1f) {
                                    TextButton(
                                        onClick = {
                                            scale = 1f
                                            offset = Offset.Zero
                                        }
                                    ) {
                                        Text("Reset Zoom", color = AccentTeal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // btnRetake
                                    Button(
                                        onClick = {
                                            showAdvancedPreview = false
                                            viewModel.navigateTo(ActiveScreen.SCAN)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("btnRetake"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Retake", tint = Color.White, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("🔄 Retake", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // btnSaveAndShare
                                    Button(
                                        onClick = {
                                            viewModel.saveScannedDocument(useAiOcr) { savedDoc ->
                                                val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(android.content.Intent.EXTRA_SUBJECT, savedDoc.title)
                                                    putExtra(
                                                        android.content.Intent.EXTRA_TEXT,
                                                        "--- CAMSCANNER PRO SECURE DOCUMENT ---\n\n" +
                                                                "Title: ${savedDoc.title}\n" +
                                                                "Category: ${savedDoc.category}\n" +
                                                                "Notes: ${savedDoc.notes}\n\n" +
                                                                "=== DIGITAL TRANSCRIPTION ===\n\n" +
                                                                savedDoc.textContent
                                                    )
                                                }
                                                context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Scanned Magic Pro Document..."))
                                            }
                                            showAdvancedPreview = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("btnSaveAndShare"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(imageVector = Icons.Default.Share, contentDescription = "Save and Share", tint = DeepDarkBg, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("💾 Save & Share", color = DeepDarkBg, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        },
                        containerColor = SurfaceDark,
                        shape = RoundedCornerShape(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Filter Select Section
                Text("Select Enhancing Filter:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filters.forEach { filter ->
                        val isSel = scannedFilter == filter
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) AccentTeal.copy(alpha = 0.2f) else SurfaceDark)
                                .border(1.dp, if (isSel) AccentTeal else TextDarkGray, RoundedCornerShape(8.dp))
                                .clickable { viewModel.setScannedFilter(filter) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = filter,
                                color = if (isSel) AccentTeal else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Form Details
                Text("Scan Details:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))

                // Title Input
                OutlinedTextField(
                    value = scannedTitle,
                    onValueChange = { viewModel.setScannedTitle(it) },
                    label = { Text("ලේඛන මාතෘකාව (Document Title)", color = TextGray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentTeal,
                        unfocusedBorderColor = SurfaceDark,
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("etTitle")
                )

                // Notes input (helpful details about invoice or receipt)
                OutlinedTextField(
                    value = scannedNotes,
                    onValueChange = { viewModel.setScannedNotes(it) },
                    label = { Text("විස්තරය / සටහන (Notes & Key details...)", color = TextGray) },
                    placeholder = { Text("e.g. Bought groceries at supermarket, Invoice from dev vendor...", color = TextDarkGray) },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentTeal,
                        unfocusedBorderColor = SurfaceDark,
                        focusedContainerColor = SurfaceDark,
                        unfocusedContainerColor = SurfaceDark
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .testTag("etNotes")
                )

                // Gemini AI OCR Toggle Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(AccentTeal.copy(alpha = 0.1f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Feature",
                                tint = AccentTeal,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Gemini AI OCR Engine",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Generates high fidelity digital transcripts, summarizes key items and invoices automatically.",
                                color = TextGray,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = useAiOcr,
                            onCheckedChange = { useAiOcr = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DeepDarkBg,
                                checkedTrackColor = AccentTeal,
                                uncheckedThumbColor = TextGray,
                                uncheckedTrackColor = SurfaceDark
                            ),
                            modifier = Modifier.testTag("switch_ai_ocr")
                        )
                    }
                }

                // Process and save button
                Button(
                    onClick = {
                        viewModel.saveScannedDocument(useAiOcr)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btnSave"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save",
                            tint = DeepDarkBg,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "සුරකින්න (Save To Secure Vault)",
                            color = DeepDarkBg,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenDetail(viewModel: DocumentViewModel) {
    val doc by viewModel.selectedDocument.collectAsStateWithLifecycle()
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    if (doc == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepDarkBg),
            contentAlignment = Alignment.Center
        ) {
            Text("No document selected.", color = Color.White)
        }
        return
    }

    val document = doc!!
    val formattedDate = remember(document.dateMillis) {
        val sdf = java.text.SimpleDateFormat("EEEE, MMM dd, yyyy - hh:mm a", java.util.Locale.getDefault())
        sdf.format(java.util.Date(document.dateMillis))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(document.category.uppercase(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, fontFamily = FontFamily.Monospace) },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(ActiveScreen.DASHBOARD) },
                        modifier = Modifier.testTag("detail_back")
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.deleteDocument(document.id)
                            Toast.makeText(context, "ලේඛනය මකා දමන ලදී!\n(Document deleted from vault!)", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("delete_button")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Document", tint = Color.Red)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepDarkBg)
            )
        },
        containerColor = DeepDarkBg
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(DeepDarkBg)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Document Header Panel
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = document.title,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Scanned Date: $formattedDate",
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(AccentTeal.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Category: ${document.category}",
                                color = AccentTeal,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Enhancement: ${document.filterApplied}",
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // User Notes Section
            if (document.notes.isNotEmpty()) {
                Text(
                    text = "සටහන් (User Notes):",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp)
                ) {
                    Text(
                        text = document.notes,
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            // High Fidelity Digitized Paper Canvas
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ලියවිලි පෙළ පිටපත (Digital Transcription):",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(document.textContent))
                            Toast.makeText(context, "පිටපත් කරගන්නා ලදී!\n(Copied transcription to clipboard!)", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy text", tint = AccentTeal, modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = {
                            Toast.makeText(context, "MOCK SHARE: Sharing transcript via secure protocols...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share text", tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Document paper replica
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, Color(0xFFDDDDDD)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Document Header / Watermark design
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CAMSCANNER PRO DIGITAL VAULT",
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "AES-256",
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    HorizontalDivider(
                        color = Color.LightGray,
                        thickness = 1.dp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    // Actual Transcription text rendered beautifully in Mono
                    Text(
                        text = document.textContent,
                        color = Color(0xFF222222),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
