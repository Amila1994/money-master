package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.data.AppDatabase
import com.example.data.LoanRepository
import com.example.ui.LoanViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PinSecurityScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.Language
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private var mInterstitialAd: InterstitialAd? = null
    private var isAdLoading = false
    private val countdownSeconds = mutableStateOf(45)
    private var adTimerJob: kotlinx.coroutines.Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize WebView directories and Google Mobile Ads SDK on a background thread
        Thread {
            try {
                createWebViewCacheDirs()
                com.google.android.gms.ads.MobileAds.initialize(this) {
                    createWebViewCacheDirs()
                    runOnUiThread {
                        loadInterstitialAd()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
        
        // Initialize local database and repository
        val database = AppDatabase.getDatabase(this)
        val repository = LoanRepository(database.loanDao())
        
        // Instantiate the ViewModel
        val viewModel: LoanViewModel by viewModels {
            LoanViewModel.Factory(repository, this)
        }

        startAdTimer(viewModel)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val isBlocked by viewModel.isBlockedFromFreeFeatures.collectAsState()
                val lang by viewModel.currentLanguage.collectAsState()
                val savedPin by viewModel.savedPin.collectAsState()
                val isUnlocked by viewModel.isAppUnlocked.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    if (savedPin == null || !isUnlocked) {
                        PinSecurityScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    } else {
                        DashboardScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding),
                            countdownSeconds = countdownSeconds.value,
                            onWatchAdClick = {
                                showInterstitialAd {
                                    viewModel.incrementWatchedAds()
                                }
                                countdownSeconds.value = 45
                            }
                        )
                    }
                }
            }
        }
    }

    private fun startAdTimer(viewModel: LoanViewModel) {
        adTimerJob?.cancel()
        adTimerJob = lifecycleScope.launch {
            while (true) {
                delay(1000)
                val isPremium = viewModel.isPremiumUser.value
                if (!isPremium) {
                    if (countdownSeconds.value > 0) {
                        countdownSeconds.value -= 1
                    } else {
                        // Automatically play ad
                        showInterstitialAd {
                            viewModel.incrementWatchedAds()
                        }
                        countdownSeconds.value = 45
                    }
                } else {
                    countdownSeconds.value = 45
                }
            }
        }
    }

    private fun loadInterstitialAd() {
        if (mInterstitialAd != null || isAdLoading) return
        isAdLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this, "ca-app-pub-3940256099942544/1033173712", adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    mInterstitialAd = null
                    isAdLoading = false
                }

                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    mInterstitialAd = interstitialAd
                    isAdLoading = false
                }
            }
        )
    }

    private fun showInterstitialAd(onAdDismissed: () -> Unit = {}) {
        val ad = mInterstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    mInterstitialAd = null
                    loadInterstitialAd()
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                    mInterstitialAd = null
                    loadInterstitialAd()
                    onAdDismissed()
                }
            }
            ad.show(this)
        } else {
            loadInterstitialAd()
            onAdDismissed()
        }
    }

    private fun createWebViewCacheDirs() {
        try {
            val webViewCacheDirJs = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/js")
            val webViewCacheDirWasm = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/wasm")
            if (!webViewCacheDirJs.exists()) {
                webViewCacheDirJs.mkdirs()
            }
            if (!webViewCacheDirWasm.exists()) {
                webViewCacheDirWasm.mkdirs()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
