package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.data.AppDatabase
import com.example.data.LoanRepository
import com.example.ui.LoanViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PinSecurityScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize WebView directories and Google Mobile Ads SDK on a background thread to prevent blocking the Main Thread
        Thread {
            try {
                createWebViewCacheDirs()
                com.google.android.gms.ads.MobileAds.initialize(this) {
                    createWebViewCacheDirs()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
        
        // Initialize local database and repository
        val database = AppDatabase.getDatabase(this)
        val repository = LoanRepository(database.loanDao())
        
        // Instantiate the ViewModel
        val viewModel: LoanViewModel by viewModels {
            LoanViewModel.Factory(repository, this)
        }

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val savedPin by viewModel.savedPin.collectAsState()
                val isUnlocked by viewModel.isAppUnlocked.collectAsState()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    if (savedPin == null || !isUnlocked) {
                        PinSecurityScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    } else {
                        DashboardScreen(
                            viewModel = viewModel,
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }

    private fun createWebViewCacheDirs() {
        try {
            val webViewCacheDirJs = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/js")
            val webViewCacheDirWasm = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/wasm")
            if (!webViewCacheDirJs.exists()) {
                webViewCacheDirJs.mkdirs()
            }
            if (!webViewCacheDirWasm.exists()) {
                webViewCacheDirWasm.mkdirs()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
