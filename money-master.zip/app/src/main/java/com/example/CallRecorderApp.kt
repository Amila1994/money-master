package com.example

import android.app.Application
import android.os.Build

class CallRecorderApp : Application() {

    override fun getAttributionTag(): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            "call_recorder"
        } else {
            super.getAttributionTag()
        }
    }
}
