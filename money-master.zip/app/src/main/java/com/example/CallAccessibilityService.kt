package com.example

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class CallAccessibilityService : AccessibilityService() {

    override fun getAttributionTag(): String? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            "call_recorder"
        } else {
            super.getAttributionTag()
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // System Stream Events Capture
    }

    override fun onInterrupt() {}
}
