package com.example

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.model.ChatMessage
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import io.agora.rtc.IRtcEngineEventHandler
import io.agora.rtc.RtcEngine
import io.agora.rtc.video.VideoCanvas
import io.agora.rtc.video.VideoEncoderConfiguration

class AdminChatActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var viewPresenceDot: View
    private lateinit var rvChatMessages: RecyclerView
    private lateinit var etMessageInput: EditText
    private lateinit var btnSendMessage: Button
    private lateinit var btnVideoCall: Button
    private lateinit var btnAttachFile: ImageButton
    private lateinit var layoutVideoContainer: View
    private lateinit var remoteVideoContainer: FrameLayout
    private lateinit var localVideoContainer: FrameLayout
    private lateinit var btnEndCall: Button
    private lateinit var layoutIncomingCall: View
    private lateinit var btnDeclineCall: Button
    private lateinit var btnAnswerCall: Button
    private lateinit var btnToggleCallAccess: android.widget.Switch
    private lateinit var btnAdminAudioCall: Button
    private lateinit var btnAdminVideoCall: Button

    private var schoolEmail: String = "amilalasantha940703@gmail.com"
    private var currentTicketId: String = ""
    private var mRtcEngine: RtcEngine? = null
    private lateinit var chatAdapter: ChatAdapter
    private val messagesList = mutableListOf<ChatMessage>()
    private var ticketListener: com.google.firebase.firestore.ListenerRegistration? = null
    private var ringtone: android.media.Ringtone? = null

    // Agora channel configuration
    private val AGORA_APP_ID = "c4e26b154e784372842dbd1e8fa3ec95"

    private val rtcEventHandler = object : IRtcEngineEventHandler() {
        override fun onUserJoined(uid: Int, elapsed: Int) {
            runOnUiThread {
                setupRemoteVideo(uid)
            }
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            runOnUiThread {
                onRemoteUserLeft()
            }
        }

        override fun onError(err: Int) {
            Log.e("Agora", "RtcEngine Error: $err")
        }
    }

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val mimeType = contentResolver.getType(it) ?: ""
            val fileType = if (mimeType.contains("pdf")) "pdf" else "image"
            uploadAndSendFile(it, fileType, currentTicketId)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_chat)

        db = FirebaseFirestore.getInstance()
        viewPresenceDot = findViewById(R.id.viewPresenceDot)
        rvChatMessages = findViewById(R.id.rvChatMessages)
        etMessageInput = findViewById(R.id.etMessageInput)
        btnSendMessage = findViewById(R.id.btnSendMessage)
        btnVideoCall = findViewById(R.id.btnVideoCall)
        btnAttachFile = findViewById(R.id.btnAttachFile)
        layoutVideoContainer = findViewById(R.id.layoutVideoContainer)
        remoteVideoContainer = findViewById(R.id.remote_video_view_container)
        localVideoContainer = findViewById(R.id.local_video_view_container)
        btnEndCall = findViewById(R.id.btnEndCall)
        layoutIncomingCall = findViewById(R.id.layoutIncomingCall)
        btnDeclineCall = findViewById(R.id.btnDeclineCall)
        btnAnswerCall = findViewById(R.id.btnAnswerCall)
        btnToggleCallAccess = findViewById(R.id.btnToggleCallAccess)
        btnAdminAudioCall = findViewById(R.id.btnAdminAudioCall)
        btnAdminVideoCall = findViewById(R.id.btnAdminVideoCall)

        // Set up recycler view
        chatAdapter = ChatAdapter(messagesList)
        rvChatMessages.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        rvChatMessages.adapter = chatAdapter

        // Intent එක හරහා බලාගන්නා පාසලේ email එක ලබා ගැනීම
        schoolEmail = intent.getStringExtra("SCHOOL_EMAIL") ?: "amilalasantha940703@gmail.com"

        // ඇඩ්මින් ඇතුල් වන විට ඔන්ලයින් වීම
        setUserOnline(schoolEmail, "admin")

        // අදාළ පාසල සජීවීව ඔන්ලයින්ද කියා බලා සිටීම (Partner = school)
        listenToPartnerPresence(schoolEmail, "school", viewPresenceDot)

        // දැනට විවෘතව පවතින ටිකට් පත්රය සජීවීව නිරීක්ෂණය කිරීම (Real-time SnapshotListener)
        ticketListener = db.collection("support_tickets")
            .whereEqualTo("schoolEmail", schoolEmail)
            .whereEqualTo("status", "OPEN")
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e("AdminChatActivity", "Error listening to active ticket", error)
                    return@addSnapshotListener
                }

                if (snapshots != null && !snapshots.isEmpty) {
                    val doc = snapshots.documents[0]
                    val newTicketId = doc.id
                    
                    if (currentTicketId != newTicketId) {
                        currentTicketId = newTicketId
                        listenToMessages(currentTicketId)
                        // කියවා නැති මැසේජ් බැලීම සහ සලකුණු ඉවත් කිරීම
                        db.collection("support_tickets").document(currentTicketId).update("adminUnreadCount", 0)
                    }

                    // Sync switch state with database
                    val videoCallAllowed = doc.getBoolean("videoCallAllowed") ?: false
                    btnToggleCallAccess.setOnCheckedChangeListener(null)
                    btnToggleCallAccess.isChecked = videoCallAllowed
                    btnToggleCallAccess.setOnCheckedChangeListener { _, isChecked ->
                        grantVideoCallAccess(currentTicketId, isChecked)
                    }

                    val callStatus = doc.getString("callStatus") ?: "IDLE"
                    val callerRole = doc.getString("callerRole") ?: ""
                    
                    handleIncomingCallState(callStatus, callerRole)
                } else {
                    createAutoTicket()
                }
            }

        // Initialize Agora RtcEngine
        initAgoraEngine()

        // 👑 🔒 Admin Authority Control Switch directly sets onCheckedChangeListener (fallback)
        btnToggleCallAccess.setOnCheckedChangeListener { _, isChecked ->
            grantVideoCallAccess(currentTicketId, isChecked)
        }

        // ඇඩ්මින් විසින් ලබාගන්නා කෝල්ස් (Authority On වී තිබිය යුතුය)
        btnAdminAudioCall.setOnClickListener {
            startAdminCall("AUDIO")
        }

        btnAdminVideoCall.setOnClickListener {
            startAdminCall("VIDEO")
        }

        // වීඩියෝ කෝල් බටන් එක එබූ විට
        btnVideoCall.setOnClickListener {
            startAgoraVideoCall()
        }

        // ඇටෑච්මන්ට් බටන් එක එබූ විට
        btnAttachFile.setOnClickListener {
            openFilePicker()
        }

        // පණිවිඩයක් යැවීමේ බටන් එක එබූ විට
        btnSendMessage.setOnClickListener {
            sendMessage()
        }

        // කෝල් එක විසන්ධි කිරීමේ බටන් එක එබූ විට
        btnEndCall.setOnClickListener {
            leaveChannel()
        }

        // Answer & Decline බටන්ස්
        btnDeclineCall.setOnClickListener {
            declineIncomingCall()
        }

        btnAnswerCall.setOnClickListener {
            answerIncomingCall()
        }
    }

    private fun initAgoraEngine() {
        try {
            mRtcEngine = RtcEngine.create(baseContext, AGORA_APP_ID, rtcEventHandler)
        } catch (e: Exception) {
            Log.e("Agora", "Engine creation failed: ${e.message}")
        }
    }

    private fun startAgoraVideoCall() {
        if (mRtcEngine == null) {
            Toast.makeText(this, "Agora Engine not initialized!", Toast.LENGTH_SHORT).show()
            return
        }
        // Enable video
        mRtcEngine?.enableVideo()

        // ⚡ Low-Data Option: VD_320x240 @ 15 FPS
        val config = VideoEncoderConfiguration(
            VideoEncoderConfiguration.VD_320x240,
            VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15,
            VideoEncoderConfiguration.STANDARD_BITRATE,
            VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_FIXED_PORTRAIT
        )
        mRtcEngine?.setVideoEncoderConfiguration(config)

        // Show video layout
        layoutVideoContainer.visibility = View.VISIBLE

        // Local video preview setup
        val localCanvasView = RtcEngine.CreateRendererView(baseContext)
        localVideoContainer.removeAllViews()
        localVideoContainer.addView(localCanvasView)
        mRtcEngine?.setupLocalVideo(VideoCanvas(localCanvasView, VideoCanvas.RENDER_MODE_HIDDEN, 0))

        // Join channel using the currentTicketId as channelName
        val channelName = if (currentTicketId.isNotEmpty()) currentTicketId else "school_master_support_channel"
        mRtcEngine?.joinChannel(null, channelName, "Extra Optional Data", 0)

        // Start CallBackgroundService for foreground support call persistence
        try {
            val serviceIntent = Intent(this, CallBackgroundService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            Log.e("AdminChatActivity", "Failed to start CallBackgroundService", e)
        }

        // Give call access inside firebase
        grantVideoCallAccess(currentTicketId, true)
    }

    private fun setupRemoteVideo(uid: Int) {
        val remoteCanvasView = RtcEngine.CreateRendererView(baseContext)
        remoteVideoContainer.removeAllViews()
        remoteVideoContainer.addView(remoteCanvasView)
        mRtcEngine?.setupRemoteVideo(VideoCanvas(remoteCanvasView, VideoCanvas.RENDER_MODE_HIDDEN, uid))
    }

    private fun onRemoteUserLeft() {
        remoteVideoContainer.removeAllViews()
        Toast.makeText(this, "User disconnected", Toast.LENGTH_SHORT).show()
    }

    private fun leaveChannel() {
        mRtcEngine?.leaveChannel()
        layoutVideoContainer.visibility = View.GONE
        remoteVideoContainer.removeAllViews()
        localVideoContainer.removeAllViews()

        // Stop CallBackgroundService
        try {
            val serviceIntent = Intent(this, CallBackgroundService::class.java)
            stopService(serviceIntent)
        } catch (e: Exception) {
            Log.e("AdminChatActivity", "Failed to stop CallBackgroundService", e)
        }

        grantVideoCallAccess(currentTicketId, false)
        if (currentTicketId.isNotEmpty()) {
            db.collection("support_tickets").document(currentTicketId)
                .update(mapOf(
                    "callStatus" to "IDLE",
                    "callerRole" to ""
                ))
        }
    }

    private fun openFilePicker() {
        filePickerLauncher.launch("*/*")
    }

    private fun sendMessage() {
        val text = etMessageInput.text.toString().trim()
        if (text.isEmpty()) return
        if (currentTicketId.isEmpty()) {
            Toast.makeText(this, "No active support case open to send message!", Toast.LENGTH_SHORT).show()
            return
        }

        val msg = hashMapOf(
            "sender" to "admin",
            "text" to text,
            "type" to "text",
            "fileUrl" to "",
            "timestamp" to FieldValue.serverTimestamp()
        )

        db.collection("support_tickets").document(currentTicketId).collection("messages")
            .add(msg)
            .addOnSuccessListener {
                etMessageInput.text.clear()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun listenToMessages(ticketId: String) {
        db.collection("support_tickets").document(ticketId).collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("AdminChatActivity", "Listen failed", error)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    messagesList.clear()
                    for (doc in snapshot.documents) {
                        val sender = doc.getString("sender") ?: ""
                        val text = doc.getString("text") ?: ""
                        val type = doc.getString("type") ?: "text"
                        val fileUrl = doc.getString("fileUrl") ?: ""
                        val timestamp = doc.getTimestamp("timestamp")
                        messagesList.add(ChatMessage(doc.id, sender, text, timestamp, type, fileUrl))
                    }
                    chatAdapter.updateMessages(messagesList)
                    if (messagesList.isNotEmpty()) {
                        rvChatMessages.scrollToPosition(messagesList.size - 1)
                    }
                }
            }
    }

    // 2. [Admin App සඳහා] ඇප් එකේ Chat එකට ඇතුල් වන විට Online කිරීම
    private fun setUserOnline(email: String, role: String) {
        val status = hashMapOf<String, Any>(
            "${role}_status" to "online"
        )
        db.collection("presence").document(email).set(status, SetOptions.merge())
    }

    // 2. [Admin App සඳහා] Chat එකෙන් ඉවත් වන විට Offline කිරීම
    private fun setUserOffline(email: String, role: String) {
        val status = hashMapOf<String, Any>(
            "${role}_status" to "offline"
        )
        db.collection("presence").document(email).set(status, SetOptions.merge())
    }

    // 2. [Admin App සඳහා] පාසල Online ද කියා Live බලාගන්නා ආකාරය
    private fun listenToPartnerPresence(partnerEmail: String, partnerRole: String, dotView: View) {
        db.collection("presence").document(partnerEmail)
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null && snapshot.exists()) {
                    val status = snapshot.getString("${partnerRole}_status")
                    if ("online" == status) {
                        dotView.setBackgroundResource(android.R.color.holo_green_light) // Green Dot
                    } else {
                        dotView.setBackgroundResource(android.R.color.holo_red_dark) // Red Dot
                    }
                }
            }
    }

    // 3. [Admin App සඳහා] 🗑️ Admin විසින් Case එක Close කළ විට මුළු Chat එකම Delete වී යාම
    private fun closeCaseAndClearChat(ticketId: String) {
        if (ticketId.isEmpty()) return

        // 1. ටිකට් එක ඇතුළේ ඇති messages sub-collection එක මුලින්ම මකා දැමීම
        db.collection("support_tickets").document(ticketId).collection("messages")
            .get().addOnSuccessListener { querySnapshot ->
                for (doc in querySnapshot.documents) {
                    doc.reference.delete()
                }
                // 2. ප්රධාන ටිකට් පත්රය පද්ධතියෙන් ඉවත් කිරීම (එවිට චැට් බොක්ස් එක හිස් වේ)
                db.collection("support_tickets").document(ticketId).delete()
                    .addOnSuccessListener {
                        Toast.makeText(this, "Case Solved! Chat History Cleared.", Toast.LENGTH_SHORT).show()
                        finish() // චැට් එකෙන් පිටතට පැමිණීම
                    }
            }
    }

    // 4. [Admin App සඳහා] 📷 📄 File Sharing ලොජික් එක (Sender = admin)
    private fun uploadAndSendFile(fileUri: Uri, fileType: String, ticketId: String) {
        if (ticketId.isEmpty()) return
        val storageRef = FirebaseStorage.getInstance().reference.child("chat_files/${System.currentTimeMillis()}")
        storageRef.putFile(fileUri).addOnSuccessListener {
            storageRef.downloadUrl.addOnSuccessListener { uri ->
                val msg = hashMapOf(
                    "sender" to "admin", // Admin ලෙස වෙන් කළා
                    "text" to "",
                    "type" to fileType,
                    "fileUrl" to uri.toString(),
                    "timestamp" to FieldValue.serverTimestamp()
                )

                db.collection("support_tickets").document(ticketId).collection("messages").add(msg)
            }
        }
    }

    // 4. [Admin App සඳහා] 👑 Admin විසින් School ඇප් එකට Call Access ලබා දීම හෝ නැවත හැරවීම
    private fun grantVideoCallAccess(ticketId: String, allow: Boolean) {
        if (ticketId.isEmpty()) return
        db.collection("support_tickets").document(ticketId)
            .update("videoCallAllowed", allow)
            .addOnSuccessListener {
                Toast.makeText(this, "Call Access Status Updated!", Toast.LENGTH_SHORT).show()
            }
    }

    private fun startAdminCall(type: String) {
        if (currentTicketId.isEmpty()) {
            Toast.makeText(this, "No active support session!", Toast.LENGTH_SHORT).show()
            return
        }
        val callData = hashMapOf<String, Any>(
            "callStatus" to "RINGING",
            "callerRole" to "admin",
            "callType" to type
        )

        db.collection("support_tickets").document(currentTicketId).update(callData)
            .addOnSuccessListener {
                val intent = Intent(this, CallBackgroundService::class.java).apply {
                    putExtra("CHANNEL_NAME", currentTicketId)
                    putExtra("CALL_TYPE", type)
                }
                startService(intent)
                startAgoraVideoCall()
                Toast.makeText(this, "Calling School...", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to call: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun handleIncomingCallState(callStatus: String, callerRole: String) {
        when (callStatus) {
            "RINGING" -> {
                if (callerRole == "school") {
                    layoutIncomingCall.visibility = View.VISIBLE
                    startRingtone()
                }
            }
            "CONNECTED" -> {
                stopRingtone()
                layoutIncomingCall.visibility = View.GONE
            }
            "IDLE" -> {
                stopRingtone()
                layoutIncomingCall.visibility = View.GONE
                if (layoutVideoContainer.visibility == View.VISIBLE) {
                    leaveChannel()
                }
            }
        }
    }

    private fun createAutoTicket() {
        val newTicket = hashMapOf(
            "schoolEmail" to schoolEmail,
            "status" to "OPEN",
            "videoCallAllowed" to true,
            "callStatus" to "IDLE",
            "callerRole" to "",
            "timestamp" to FieldValue.serverTimestamp()
        )
        db.collection("support_tickets").add(newTicket)
            .addOnSuccessListener { docRef ->
                currentTicketId = docRef.id
                listenToMessages(currentTicketId)
                Toast.makeText(this, "Active Support Session Initialized!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e("AdminChatActivity", "Failed to auto-create support ticket", e)
            }
    }

    private fun declineIncomingCall() {
        stopRingtone()
        if (currentTicketId.isNotEmpty()) {
            db.collection("support_tickets").document(currentTicketId)
                .update(mapOf(
                    "callStatus" to "IDLE",
                    "callerRole" to ""
                ))
                .addOnSuccessListener {
                    layoutIncomingCall.visibility = View.GONE
                    Toast.makeText(this, "Call Declined", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun answerIncomingCall() {
        stopRingtone()
        if (currentTicketId.isNotEmpty()) {
            db.collection("support_tickets").document(currentTicketId)
                .update(mapOf(
                    "callStatus" to "CONNECTED",
                    "callerRole" to "school"
                ))
                .addOnSuccessListener {
                    layoutIncomingCall.visibility = View.GONE
                    startAgoraVideoCall()
                }
        }
    }

    private fun startRingtone() {
        if (ringtone == null) {
            val notificationUri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE)
            ringtone = android.media.RingtoneManager.getRingtone(applicationContext, notificationUri)
        }
        if (ringtone?.isPlaying == false) {
            ringtone?.play()
        }
    }

    private fun stopRingtone() {
        if (ringtone?.isPlaying == true) {
            ringtone?.stop()
        }
    }

    override fun onStop() {
        super.onStop()
        // ඇප් එකෙන් පිටවන විට ඇඩ්මින් Offline කිරීම
        setUserOffline(schoolEmail, "admin")
    }

    override fun onDestroy() {
        super.onDestroy()
        ticketListener?.remove()
        stopRingtone()
        RtcEngine.destroy()
    }
}

class ChatAdapter(private var messages: List<ChatMessage>) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {
    class ChatViewHolder(val view: View) : RecyclerView.ViewHolder(view) {
        val textMessage: TextView = view.findViewById(1)
        val textSender: TextView = view.findViewById(2)
        val textTime: TextView = view.findViewById(3)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val context = parent.context
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 8, 16, 8)
        }

        val senderTv = TextView(context).apply {
            id = 2
            textSize = 11f
            setTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        container.addView(senderTv)

        val messageTv = TextView(context).apply {
            id = 1
            textSize = 15f
            setTextColor(Color.BLACK)
            setPadding(12, 8, 12, 8)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = 4
                bottomMargin = 4
            }
        }
        container.addView(messageTv)

        val timeTv = TextView(context).apply {
            id = 3
            textSize = 10f
            setTextColor(Color.LTGRAY)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        container.addView(timeTv)

        return ChatViewHolder(container)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val msg = messages[position]
        holder.textSender.text = if (msg.sender == "admin") "Admin" else "School"

        if (msg.type == "image") {
            holder.textMessage.text = "📷 Photo: Click to view file"
        } else if (msg.type == "pdf") {
            holder.textMessage.text = "📄 PDF: Click to view document"
        } else {
            holder.textMessage.text = msg.text
        }

        val gravity = if (msg.sender == "admin") Gravity.END else Gravity.START
        (holder.view as LinearLayout).gravity = gravity

        val bubbleBg = if (msg.sender == "admin") {
            GradientDrawable().apply {
                setColor(Color.parseColor("#E1F5FE"))
                cornerRadius = 16f
            }
        } else {
            GradientDrawable().apply {
                setColor(Color.parseColor("#F5F5F5"))
                cornerRadius = 16f
            }
        }
        holder.textMessage.background = bubbleBg
        holder.textMessage.layoutParams = (holder.textMessage.layoutParams as LinearLayout.LayoutParams).apply {
            this.gravity = gravity
        }
        holder.textSender.layoutParams = (holder.textSender.layoutParams as LinearLayout.LayoutParams).apply {
            this.gravity = gravity
        }
        holder.textTime.layoutParams = (holder.textTime.layoutParams as LinearLayout.LayoutParams).apply {
            this.gravity = gravity
        }

        val dateStr = msg.timestamp?.toDate()?.toString() ?: ""
        holder.textTime.text = dateStr
    }

    override fun getItemCount() = messages.size

    fun updateMessages(newMessages: List<ChatMessage>) {
        messages = newMessages
        notifyDataSetChanged()
    }
}
