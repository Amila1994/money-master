package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [SchoolConfig::class, ClassConfig::class, Subject::class, Student::class],
    version = 3,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class SchoolDatabase : RoomDatabase() {
    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile
        private var INSTANCE: SchoolDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): SchoolDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SchoolDatabase::class.java,
                    "school_database"
                )
                .fallbackToDestructiveMigration()
                .addCallback(SchoolDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class SchoolDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    val dao = database.schoolDao()
                    
                    // Prepopulate school config with general settings
                    dao.insertSchoolConfig(
                        SchoolConfig(
                            schoolName = "A / ANANDA COLLEGE",
                            examType = "1st Term Examination 2026",
                            academicYear = "2026"
                        )
                    )

                    // Prepopulate default ClassConfigs
                    val defaultClasses = listOf(
                        ClassConfig(className = "10-A", classTeacher = "Mr. Asela Perera"),
                        ClassConfig(className = "10-B", classTeacher = "Mrs. Deepani Silva")
                    )
                    defaultClasses.forEach { dao.insertClassConfig(it) }

                    // Prepopulate default subjects per class
                    val defaultSubjects = listOf(
                        Subject(name = "Mathematics", passMark = 35, className = "10-A"),
                        Subject(name = "Science", passMark = 35, className = "10-A"),
                        Subject(name = "History", passMark = 35, className = "10-A"),
                        
                        Subject(name = "Mathematics", passMark = 35, className = "10-B"),
                        Subject(name = "English", passMark = 40, className = "10-B"),
                        Subject(name = "Sinhala", passMark = 35, className = "10-B")
                    )
                    defaultSubjects.forEach { dao.insertSubject(it) }

                    // Prepopulate default students per class
                    val defaultStudents = listOf(
                        Student(
                            studentId = "ST001",
                            studentName = "Kamal Perera",
                            marks = mapOf(
                                "Mathematics" to 85,
                                "Science" to 78,
                                "History" to 45
                            ),
                            className = "10-A"
                        ),
                        Student(
                            studentId = "ST002",
                            studentName = "Nimal Silva",
                            marks = mapOf(
                                "Mathematics" to 92,
                                "Science" to 88,
                                "History" to 95
                            ),
                            className = "10-A"
                        ),
                        Student(
                            studentId = "ST003",
                            studentName = "Saman Kumari",
                            marks = mapOf(
                                "Mathematics" to 40,
                                "English" to 55,
                                "Sinhala" to 60
                            ),
                            className = "10-B"
                        ),
                        Student(
                            studentId = "ST004",
                            studentName = "Ruwan Gamage",
                            marks = mapOf(
                                "Mathematics" to 65,
                                "English" to 32,
                                "Sinhala" to 50
                            ),
                            className = "10-B"
                        )
                    )
                    defaultStudents.forEach { dao.insertStudent(it) }
                }
            }
        }
    }
}
