package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey val studentId: String,
    val studentName: String,
    val marks: Map<String, Int>, // Subject Name -> Mark
    val className: String = "10-A",
    val photoBytes: ByteArray? = null,
    val dob: String = "",
    val gender: String = "Male",
    val address: String = "",
    val guardian: String = "",
    val phone: String = ""
)
