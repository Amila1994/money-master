package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class CallType {
    INCOMING,
    OUTGOING,
    MISSED
}

@Entity(tableName = "call_records")
data class CallRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phoneNumber: String,
    val contactName: String = "",
    val callType: CallType,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0,
    val filePath: String = "",
    val fileSizeBytes: Long = 0,
    val isFavorite: Boolean = false,
    val notes: String = "",
    val audioFormat: String = "AAC"
)
