package com.example.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromMap(map: Map<String, Int>?): String {
        if (map == null) return ""
        return map.entries.joinToString(",") { "${it.key}:${it.value}" }
    }

    @TypeConverter
    fun toMap(string: String?): Map<String, Int> {
        if (string.isNullOrEmpty()) return emptyMap()
        return string.split(",").associate {
            val parts = it.split(":")
            if (parts.size == 2) {
                parts[0] to (parts[1].toIntOrNull() ?: 0)
            } else {
                "" to 0
            }
        }.filterKeys { it.isNotEmpty() }
    }
}
