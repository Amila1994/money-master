package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "class_configs")
data class ClassConfig(
    @PrimaryKey val className: String,
    val classTeacher: String
)
