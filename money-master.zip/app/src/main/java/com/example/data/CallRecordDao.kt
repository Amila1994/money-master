package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CallRecordDao {

    @Query("SELECT * FROM call_records ORDER BY timestamp DESC")
    fun getAllRecordings(): Flow<List<CallRecord>>

    @Query("SELECT * FROM call_records WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoriteRecordings(): Flow<List<CallRecord>>

    @Query("SELECT * FROM call_records WHERE id = :id")
    suspend fun getRecordingById(id: Long): CallRecord?

    @Query("SELECT * FROM call_records WHERE phoneNumber LIKE '%' || :query || '%' OR contactName LIKE '%' || :query || '%' OR notes LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchRecordings(query: String): Flow<List<CallRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(record: CallRecord): Long

    @Update
    suspend fun updateRecording(record: CallRecord)

    @Delete
    suspend fun deleteRecording(record: CallRecord)

    @Query("UPDATE call_records SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE call_records SET notes = :notes WHERE id = :id")
    suspend fun updateNotes(id: Long, notes: String)

    @Query("DELETE FROM call_records WHERE id = :id")
    suspend fun deleteById(id: Long)
}
