package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "school_config")
data class SchoolConfig(
    @PrimaryKey val id: Int = 1,
    val schoolName: String = "A/Ananda College",
    val gradeClass: String = "10-A",
    val classTeacher: String = "Mr. Asela Perera",
    val examType: String = "1st Term Examination 2026",
    val academicYear: String = "2026",
    val schoolPhotoBytes: ByteArray? = null,
    val noticeText: String = ""
)
