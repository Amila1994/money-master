package com.example.data

import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import com.example.BuildConfig

@JsonClass(generateAdapter = true)
data class Part(val text: String)

@JsonClass(generateAdapter = true)
data class Content(val parts: List<Part>)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(val contents: List<Content>)

@JsonClass(generateAdapter = true)
data class Candidate(val content: Content)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(val candidates: List<Candidate>?)

interface GeminiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiHelper {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://generativelanguage.googleapis.com/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val service = retrofit.create(GeminiService::class.java)

    suspend fun generateOcrText(title: String, category: String, notes: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return generateMockOcr(title, category, notes)
        }

        val prompt = """
            You are CamScanner Pro's OCR & document analysis system. The user scanned a document.
            Document Title: $title
            Document Category: $category
            User Notes: $notes
            
            Generate a highly detailed, realistic, formatted ASCII/Markdown plain-text OCR transcription of what this document actually looks like (e.g. including store/company name, mock address, dates, reference IDs, itemized list of values/prices, total sums, and signatures if appropriate).
            Make it look authentic and professional, utilizing clean spaces and structure.
            At the end of the transcription, add a distinct line "----- AI SUMMARY -----" followed by a short 2-3 sentence smart executive summary of this document.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(prompt))))
        )

        return try {
            val response = service.generateContent(apiKey, request)
            val extracted = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            extracted ?: "Could not extract text. Please try again."
        } catch (e: Exception) {
            "Failed to connect to Gemini API: ${e.localizedMessage}\n\nHere is a local simulated OCR transcription:\n\n" +
                    generateMockOcr(title, category, notes)
        }
    }

    private fun generateMockOcr(title: String, category: String, notes: String): String {
        val currentDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        return when (category) {
            "Receipt" -> """
                ========================================
                            MOCK REVENUE CO.
                         123 INNOVATION BLVD
                ========================================
                DATE: $currentDate         TIME: 14:32:05
                TRANS: #984372          CASHIER: DEEP-G
                ----------------------------------------
                DOCUMENT: $title
                NOTES: $notes
                
                ITEMS INVOICED:
                01  SECURE VAULT APP               ${'$'}49.99
                02  OCR ANALYZER ACCESS            ${'$'}12.50
                03  CLOUD CLONE PRO                 ${'$'}9.99
                ----------------------------------------
                SUBTOTAL                           ${'$'}72.48
                TAX (8.25%)                         ${'$'}5.98
                TOTAL                              ${'$'}78.46
                ========================================
                PAID VIA: SECURE ACC / DEBIT
                CARD NO: ************4829
                
                [SIGNATURE VERIFIED]
                ========================================
                ----- AI SUMMARY -----
                This receipt documents the purchase of secure vault services, OCR access, and cloud cloning features on $currentDate. The total invoice value is ${'$'}78.46, paid securely via credit card.
            """.trimIndent()

            "Invoice" -> """
                ========================================
                            INVOICE FOR SERVICES
                ========================================
                INVOICE NO: INV-2026-401
                DATE: $currentDate
                DUE DATE: ${currentDate.substring(0, 4)}-08-04
                
                FROM:
                CamScanner Pro Labs Ltd.
                colombo, Sri Lanka
                
                TO:
                Secure Vault User
                
                DESCRIPTION:
                - Document Title: $title
                - User Notes: $notes
                
                LINE ITEMS:
                ----------------------------------------
                1. Professional Digital Scan & Archive   ${'$'}150.00
                2. Sinhalese Gate Encryption Engine      ${'$'}200.00
                ----------------------------------------
                TOTAL DUE:                               ${'$'}350.00
                ========================================
                Thank you for your business!
                
                ----- AI SUMMARY -----
                Invoice INV-2026-401 issued by CamScanner Pro Labs for scanning and Sinhalese gate encryption setup. Total amount outstanding is ${'$'}350.00, due within 30 days.
            """.trimIndent()

            else -> """
                ========================================
                          SECURE DOCUMENT VAULT
                ========================================
                DOC ID: CS-${(100000..999999).random()}
                TIMESTAMP: $currentDate 09:47 AM
                CATEGORY: $category
                TITLE: $title
                
                ----------------------------------------
                NOTES PROVIDED:
                $notes
                
                ----------------------------------------
                OCR VERIFICATION CODE: SEC-9943A
                ENCRYPTION STRENGTH: AES-256 BIT
                STATUS: ENCRYPTED AND STORED SECURELY
                ========================================
                
                ----- AI SUMMARY -----
                This record contains secure archive contents for "$title" classified under "$category". The document has been successfully encrypted with AES-256 standards and stored in the secure CamScanner vault.
            """.trimIndent()
        }
    }
}
