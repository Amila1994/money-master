package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val dateMillis: Long = System.currentTimeMillis(),
    val notes: String = "",
    val textContent: String = "",
    val imageResName: String = "",
    val filterApplied: String = "Magic Color"
)

@Entity(tableName = "vault_settings")
data class VaultSetting(
    @PrimaryKey val key: String,
    val value: String
)

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY dateMillis DESC")
    fun getAllDocuments(): Flow<List<Document>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: Document)

    @Query("DELETE FROM documents WHERE id = :id")
    suspend fun deleteDocumentById(id: Int)

    @Query("SELECT * FROM documents WHERE id = :id LIMIT 1")
    suspend fun getDocumentById(id: Int): Document?
}

@Dao
interface SettingDao {
    @Query("SELECT * FROM vault_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): VaultSetting?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSetting(setting: VaultSetting)
}

@Database(entities = [Document::class, VaultSetting::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun documentDao(): DocumentDao
    abstract fun settingDao(): SettingDao
}
