package com.example.data

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.flow.Flow

class DocumentRepository(context: Context) {
    private val database: AppDatabase = Room.databaseBuilder(
        context.applicationContext,
        AppDatabase::class.java,
        "camscanner_pro_db"
    )
    .fallbackToDestructiveMigration()
    .build()

    private val documentDao = database.documentDao()
    private val settingDao = database.settingDao()

    val allDocuments: Flow<List<Document>> = documentDao.getAllDocuments()

    suspend fun insertDocument(document: Document) {
        documentDao.insertDocument(document)
    }

    suspend fun deleteDocumentById(id: Int) {
        documentDao.deleteDocumentById(id)
    }

    suspend fun getDocumentById(id: Int): Document? {
        return documentDao.getDocumentById(id)
    }

    suspend fun getSetting(key: String): String? {
        return settingDao.getSetting(key)?.value
    }

    suspend fun saveSetting(key: String, value: String) {
        settingDao.saveSetting(VaultSetting(key, value))
    }
}
