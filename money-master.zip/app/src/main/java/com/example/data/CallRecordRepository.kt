package com.example.data

import kotlinx.coroutines.flow.Flow

class CallRecordRepository(private val dao: CallRecordDao) {

    val allRecordings: Flow<List<CallRecord>> = dao.getAllRecordings()
    val favoriteRecordings: Flow<List<CallRecord>> = dao.getFavoriteRecordings()

    fun searchRecordings(query: String): Flow<List<CallRecord>> {
        return if (query.isBlank()) dao.getAllRecordings() else dao.searchRecordings(query)
    }

    suspend fun insert(record: CallRecord): Long = dao.insertRecording(record)

    suspend fun update(record: CallRecord) = dao.updateRecording(record)

    suspend fun delete(record: CallRecord) = dao.deleteRecording(record)

    suspend fun deleteById(id: Long) = dao.deleteById(id)

    suspend fun toggleFavorite(id: Long, currentStatus: Boolean) {
        dao.updateFavorite(id, !currentStatus)
    }

    suspend fun updateNotes(id: Long, notes: String) {
        dao.updateNotes(id, notes)
    }

    suspend fun getById(id: Long): CallRecord? = dao.getRecordingById(id)
}
