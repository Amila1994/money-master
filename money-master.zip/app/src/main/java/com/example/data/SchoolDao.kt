package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {
    // School Config
    @Query("SELECT * FROM school_config WHERE id = 1 LIMIT 1")
    fun getSchoolConfig(): Flow<SchoolConfig?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchoolConfig(config: SchoolConfig)

    // Class Configs
    @Query("SELECT * FROM class_configs ORDER BY className ASC")
    fun getAllClassConfigs(): Flow<List<ClassConfig>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClassConfig(classConfig: ClassConfig)

    @Delete
    suspend fun deleteClassConfig(classConfig: ClassConfig)

    @Query("DELETE FROM class_configs")
    suspend fun clearAllClassConfigs()

    // Subjects
    @Query("SELECT * FROM subjects ORDER BY id ASC")
    fun getAllSubjects(): Flow<List<Subject>>

    @Query("SELECT * FROM subjects WHERE className = :className ORDER BY id ASC")
    fun getSubjectsForClass(className: String): Flow<List<Subject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: Subject)

    @Delete
    suspend fun deleteSubject(subject: Subject)

    @Query("DELETE FROM subjects WHERE className = :className")
    suspend fun clearSubjectsForClass(className: String)

    @Query("DELETE FROM subjects")
    suspend fun clearAllSubjects()

    // Students
    @Query("SELECT * FROM students ORDER BY studentId ASC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE className = :className ORDER BY studentId ASC")
    fun getStudentsForClass(className: String): Flow<List<Student>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("DELETE FROM students WHERE className = :className")
    suspend fun clearStudentsForClass(className: String)

    @Query("DELETE FROM students")
    suspend fun clearAllStudents()

    // Users (Teacher Login & Account Registration)
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUser(email: String): User?

    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)
}
