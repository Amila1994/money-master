package com.example.data

import kotlinx.coroutines.flow.Flow

class SchoolRepository(private val schoolDao: SchoolDao) {
    val schoolConfig: Flow<SchoolConfig?> = schoolDao.getSchoolConfig()
    val allClassConfigs: Flow<List<ClassConfig>> = schoolDao.getAllClassConfigs()
    val allSubjects: Flow<List<Subject>> = schoolDao.getAllSubjects()
    val allStudents: Flow<List<Student>> = schoolDao.getAllStudents()

    suspend fun updateSchoolConfig(config: SchoolConfig) {
        schoolDao.insertSchoolConfig(config)
    }

    // Class Configurations
    suspend fun insertClassConfig(classConfig: ClassConfig) {
        schoolDao.insertClassConfig(classConfig)
    }

    suspend fun deleteClassConfig(classConfig: ClassConfig) {
        schoolDao.deleteClassConfig(classConfig)
    }

    suspend fun clearAllClassConfigs() {
        schoolDao.clearAllClassConfigs()
    }

    // Subjects
    fun getSubjectsForClass(className: String): Flow<List<Subject>> {
        return schoolDao.getSubjectsForClass(className)
    }

    suspend fun addSubject(name: String, passMark: Int = 35, className: String = "10-A") {
        schoolDao.insertSubject(Subject(name = name, passMark = passMark, className = className))
    }

    suspend fun removeSubject(subject: Subject) {
        schoolDao.deleteSubject(subject)
    }

    suspend fun clearSubjectsForClass(className: String) {
        schoolDao.clearSubjectsForClass(className)
    }

    suspend fun clearAllSubjects() {
        schoolDao.clearAllSubjects()
    }

    // Students
    fun getStudentsForClass(className: String): Flow<List<Student>> {
        return schoolDao.getStudentsForClass(className)
    }

    suspend fun insertStudent(student: Student) {
        schoolDao.insertStudent(student)
    }

    suspend fun deleteStudent(student: Student) {
        schoolDao.deleteStudent(student)
    }

    suspend fun clearStudentsForClass(className: String) {
        schoolDao.clearStudentsForClass(className)
    }

    suspend fun clearAllStudents() {
        schoolDao.clearAllStudents()
    }
}
