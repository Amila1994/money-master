package com.example.repository

import android.util.Log
import com.example.model.School
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SchoolRepository {
    private var firestore: FirebaseFirestore? = null
    private val _isUsingFirestore = MutableStateFlow(false)
    val isUsingFirestore: StateFlow<Boolean> = _isUsingFirestore

    // Clean initial pre-populated mock data for fallback/offline use
    private val localSchools = mutableListOf(
        School(
            id = "school_1",
            name = "Colombo Royal College",
            address = "Rajakeeya Mawatha, Colombo 07",
            phone = "011-2695551",
            email = "info@royalcollege.lk",
            studentCount = 8200,
            schoolType = "Public",
            establishedYear = 1835,
            status = "Active",
            isLocked = false,
            isSubscribed = true
        ),
        School(
            id = "school_2",
            name = "Trinity College Kandy",
            address = "Trinity Mawatha, Kandy",
            phone = "081-2234297",
            email = "principal@trinitycollege.lk",
            studentCount = 3100,
            schoolType = "Private",
            establishedYear = 1872,
            status = "Active",
            isLocked = true,
            isSubscribed = false
        ),
        School(
            id = "school_3",
            name = "St. Thomas' College",
            address = "Galle Road, Mount Lavinia",
            phone = "011-2712256",
            email = "info@stc.lk",
            studentCount = 3500,
            schoolType = "Private",
            establishedYear = 1851,
            status = "Active",
            isLocked = false,
            isSubscribed = true
        ),
        School(
            id = "school_4",
            name = "Ananda College",
            address = "Ananda Mawatha, Colombo 10",
            phone = "011-2695503",
            email = "admin@ananda.sch.lk",
            studentCount = 7500,
            schoolType = "Public",
            establishedYear = 1886,
            status = "Active",
            isLocked = false,
            isSubscribed = false
        ),
        School(
            id = "school_5",
            name = "Gateway International",
            address = "Parliament Road, Rajagiriya",
            phone = "011-2886010",
            email = "gise@gateway.lk",
            studentCount = 1800,
            schoolType = "International",
            establishedYear = 1997,
            status = "Active",
            isLocked = true,
            isSubscribed = true
        )
    )

    init {
        try {
            // Attempt to initialize Firebase Firestore
            firestore = FirebaseFirestore.getInstance()
            _isUsingFirestore.value = true
            Log.d("SchoolRepository", "Firebase Firestore initialized successfully!")
        } catch (e: Exception) {
            _isUsingFirestore.value = false
            Log.w("SchoolRepository", "Firebase Firestore initialization failed. Falling back to local offline mode. Error: ${e.message}")
        }
    }

    fun getSchools(onResult: (List<School>, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value) {
            fs.collection("schools")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("SchoolRepository", "Error fetching schools from Firestore", error)
                        // On error, fall back to current local in-memory data
                        onResult(localSchools.toList(), "Firestore Error: ${error.localizedMessage}. Loaded from cache.")
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        val schoolsList = mutableListOf<School>()
                        for (doc in snapshot.documents) {
                            try {
                                val id = doc.id
                                val name = doc.getString("name") ?: ""
                                val address = doc.getString("address") ?: ""
                                val phone = doc.getString("phone") ?: ""
                                val email = doc.getString("email") ?: ""
                                val studentCount = doc.getLong("studentCount")?.toInt() ?: 0
                                val schoolType = doc.getString("schoolType") ?: "Public"
                                val establishedYear = doc.getLong("establishedYear")?.toInt() ?: 2000
                                val status = doc.getString("status") ?: "Active"
                                val isLocked = doc.getBoolean("isLocked") ?: false
                                val isSubscribed = doc.getBoolean("isSubscribed") ?: false

                                schoolsList.add(
                                    School(
                                        id = id,
                                        name = name,
                                        address = address,
                                        phone = phone,
                                        email = email,
                                        studentCount = studentCount,
                                        schoolType = schoolType,
                                        establishedYear = establishedYear,
                                        status = status,
                                        isLocked = isLocked,
                                        isSubscribed = isSubscribed
                                    )
                                )
                            } catch (e: Exception) {
                                Log.e("SchoolRepository", "Error parsing school document ${doc.id}", e)
                            }
                        }
                        // Update our local cache in case we go offline
                        if (schoolsList.isNotEmpty()) {
                            localSchools.clear()
                            localSchools.addAll(schoolsList)
                        }
                        onResult(schoolsList, null)
                    } else {
                        onResult(localSchools.toList(), "Empty Firestore database. Showing local sample list.")
                    }
                }
        } else {
            // Offline mode / Fallback
            onResult(localSchools.toList(), "Running in Offline Mode (Firebase not initialized). Changes saved locally.")
        }
    }

    fun addSchool(school: School, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value) {
            val schoolMap = hashMapOf(
                "name" to school.name,
                "address" to school.address,
                "phone" to school.phone,
                "email" to school.email,
                "studentCount" to school.studentCount,
                "schoolType" to school.schoolType,
                "establishedYear" to school.establishedYear,
                "status" to school.status,
                "isLocked" to school.isLocked,
                "isSubscribed" to school.isSubscribed
            )
            val docRef = if (school.email.isNotBlank()) {
                fs.collection("schools").document(school.email)
            } else {
                fs.collection("schools").document()
            }

            docRef.set(schoolMap)
                .addOnSuccessListener {
                    onComplete(true, null)
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "Failed to add school to Firestore", e)
                    // Save locally as fallback
                    val newSchool = school.copy(id = "local_" + System.currentTimeMillis())
                    localSchools.add(newSchool)
                    onComplete(true, "Firestore failed: ${e.localizedMessage}. Saved locally.")
                }
        } else {
            // Local fallback
            val newSchool = school.copy(id = "local_" + System.currentTimeMillis())
            localSchools.add(newSchool)
            onComplete(true, null)
        }
    }

    fun updateSchool(school: School, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value && !school.id.startsWith("local_")) {
            val schoolMap = hashMapOf(
                "name" to school.name,
                "address" to school.address,
                "phone" to school.phone,
                "email" to school.email,
                "studentCount" to school.studentCount,
                "schoolType" to school.schoolType,
                "establishedYear" to school.establishedYear,
                "status" to school.status,
                "isLocked" to school.isLocked,
                "isSubscribed" to school.isSubscribed
            )
            fs.collection("schools").document(school.id)
                .set(schoolMap)
                .addOnSuccessListener {
                    onComplete(true, null)
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "Failed to update school in Firestore", e)
                    // Update locally as fallback
                    val index = localSchools.indexOfFirst { it.id == school.id }
                    if (index != -1) {
                        localSchools[index] = school
                    }
                    onComplete(true, "Firestore failed: ${e.localizedMessage}. Updated locally.")
                }
        } else {
            // Local fallback
            val index = localSchools.indexOfFirst { it.id == school.id }
            if (index != -1) {
                localSchools[index] = school
                onComplete(true, null)
            } else {
                onComplete(false, "School not found in local memory.")
            }
        }
    }

    fun deleteSchool(schoolId: String, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value && !schoolId.startsWith("local_")) {
            fs.collection("schools").document(schoolId)
                .delete()
                .addOnSuccessListener {
                    onComplete(true, null)
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "Failed to delete school from Firestore", e)
                    // Delete locally
                    localSchools.removeAll { it.id == schoolId }
                    onComplete(true, "Firestore failed: ${e.localizedMessage}. Deleted locally.")
                }
        } else {
            // Local fallback
            val removed = localSchools.removeAll { it.id == schoolId }
            if (removed) {
                onComplete(true, null)
            } else {
                onComplete(false, "School not found in local memory.")
            }
        }
    }
}
