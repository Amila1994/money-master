package com.example.repository

import android.util.Log
import com.example.model.School
import com.example.model.ChatMessage
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SchoolRepository {
    private var firestore: FirebaseFirestore? = null
    private val _isUsingFirestore = MutableStateFlow(false)
    val isUsingFirestore: StateFlow<Boolean> = _isUsingFirestore

    private val localChats = mutableMapOf<String, MutableList<ChatMessage>>()

    // Clean initial pre-populated mock data for fallback/offline use
    private val localSchools = mutableListOf(
        School(
            id = "school_1",
            name = "Colombo Royal College",
            address = "Rajakeeya Mawatha, Colombo 07",
            phone = "011-2695551",
            email = "info@royalcollege.lk",
            studentCount = 8200,
            schoolType = "Public",
            establishedYear = 1835,
            status = "Active",
            isLocked = false,
            isSubscribed = true
        ),
        School(
            id = "school_2",
            name = "Trinity College Kandy",
            address = "Trinity Mawatha, Kandy",
            phone = "081-2234297",
            email = "principal@trinitycollege.lk",
            studentCount = 3100,
            schoolType = "Private",
            establishedYear = 1872,
            status = "Active",
            isLocked = true,
            isSubscribed = false
        ),
        School(
            id = "school_3",
            name = "St. Thomas' College",
            address = "Galle Road, Mount Lavinia",
            phone = "011-2712256",
            email = "info@stc.lk",
            studentCount = 3500,
            schoolType = "Private",
            establishedYear = 1851,
            status = "Active",
            isLocked = false,
            isSubscribed = true
        ),
        School(
            id = "school_4",
            name = "Ananda College",
            address = "Ananda Mawatha, Colombo 10",
            phone = "011-2695503",
            email = "admin@ananda.sch.lk",
            studentCount = 7500,
            schoolType = "Public",
            establishedYear = 1886,
            status = "Active",
            isLocked = false,
            isSubscribed = false
        ),
        School(
            id = "school_5",
            name = "Gateway International",
            address = "Parliament Road, Rajagiriya",
            phone = "011-2886010",
            email = "gise@gateway.lk",
            studentCount = 1800,
            schoolType = "International",
            establishedYear = 1997,
            status = "Active",
            isLocked = true,
            isSubscribed = true
        )
    )

    init {
        try {
            // Attempt to initialize Firebase Firestore
            firestore = FirebaseFirestore.getInstance()
            _isUsingFirestore.value = true
            Log.d("SchoolRepository", "Firebase Firestore initialized successfully!")
        } catch (e: Exception) {
            _isUsingFirestore.value = false
            Log.w("SchoolRepository", "Firebase Firestore initialization failed. Falling back to local offline mode. Error: ${e.message}")
        }
    }

    fun getSchools(onResult: (List<School>, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value) {
            fs.collection("schools")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("SchoolRepository", "Error fetching schools from Firestore", error)
                        // On error, fall back to current local in-memory data
                        onResult(localSchools.toList(), "Firestore Error: ${error.localizedMessage}. Loaded from cache.")
                        return@addSnapshotListener
                    }

                    if (snapshot != null) {
                        val schoolsList = mutableListOf<School>()
                        for (doc in snapshot.documents) {
                            try {
                                val id = doc.id
                                val name = doc.getString("name") ?: ""
                                val address = doc.getString("address") ?: ""
                                val phone = doc.getString("phone") ?: ""
                                val email = doc.getString("email") ?: ""
                                val studentCount = doc.getLong("studentCount")?.toInt() ?: 0
                                val schoolType = doc.getString("schoolType") ?: "Public"
                                val establishedYear = doc.getLong("establishedYear")?.toInt() ?: 2000
                                val status = doc.getString("status") ?: "Active"
                                val isLocked = doc.getBoolean("isLocked") ?: false
                                val isSubscribed = doc.getBoolean("isSubscribed") ?: false
                                val subscription_status = doc.getString("subscription_status") ?: "ACTIVE"
                                val master_pin = doc.getString("master_pin") ?: ""
                                val teacher_pin = doc.getString("teacher_pin") ?: ""
                                val subscriptionStartDate = doc.getTimestamp("subscriptionStartDate")
                                val subscriptionEndDate = doc.getTimestamp("subscriptionEndDate")

                                schoolsList.add(
                                    School(
                                        id = id,
                                        name = name,
                                        address = address,
                                        phone = phone,
                                        email = email,
                                        studentCount = studentCount,
                                        schoolType = schoolType,
                                        establishedYear = establishedYear,
                                        status = status,
                                        isLocked = isLocked,
                                        isSubscribed = isSubscribed,
                                        subscription_status = subscription_status,
                                        master_pin = master_pin,
                                        teacher_pin = teacher_pin,
                                        subscriptionStartDate = subscriptionStartDate,
                                        subscriptionEndDate = subscriptionEndDate
                                    )
                                )
                            } catch (e: Exception) {
                                Log.e("SchoolRepository", "Error parsing school document ${doc.id}", e)
                            }
                        }
                        // Update our local cache in case we go offline
                        if (schoolsList.isNotEmpty()) {
                            localSchools.clear()
                            localSchools.addAll(schoolsList)
                        }
                        onResult(schoolsList, null)
                    } else {
                        onResult(localSchools.toList(), "Empty Firestore database. Showing local sample list.")
                    }
                }
        } else {
            // Offline mode / Fallback
            onResult(localSchools.toList(), "Running in Offline Mode (Firebase not initialized). Changes saved locally.")
        }
    }

    fun addSchool(school: School, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value) {
            val schoolMap = hashMapOf(
                "name" to school.name,
                "address" to school.address,
                "phone" to school.phone,
                "email" to school.email,
                "studentCount" to school.studentCount,
                "schoolType" to school.schoolType,
                "establishedYear" to school.establishedYear,
                "status" to school.status,
                "isLocked" to school.isLocked,
                "isSubscribed" to school.isSubscribed,
                "subscription_status" to school.subscription_status,
                "master_pin" to school.master_pin,
                "teacher_pin" to school.teacher_pin,
                "subscriptionStartDate" to school.subscriptionStartDate,
                "subscriptionEndDate" to school.subscriptionEndDate
            )
            val docRef = if (school.email.isNotBlank()) {
                fs.collection("schools").document(school.email)
            } else {
                fs.collection("schools").document()
            }

            docRef.set(schoolMap)
                .addOnSuccessListener {
                    onComplete(true, null)
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "Failed to add school to Firestore", e)
                    // Save locally as fallback
                    val newSchool = school.copy(id = "local_" + System.currentTimeMillis())
                    localSchools.add(newSchool)
                    onComplete(true, "Firestore failed: ${e.localizedMessage}. Saved locally.")
                }
        } else {
            // Local fallback
            val newSchool = school.copy(id = "local_" + System.currentTimeMillis())
            localSchools.add(newSchool)
            onComplete(true, null)
        }
    }

    fun updateSchool(school: School, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value && !school.id.startsWith("local_")) {
            val schoolMap = hashMapOf(
                "name" to school.name,
                "address" to school.address,
                "phone" to school.phone,
                "email" to school.email,
                "studentCount" to school.studentCount,
                "schoolType" to school.schoolType,
                "establishedYear" to school.establishedYear,
                "status" to school.status,
                "isLocked" to school.isLocked,
                "isSubscribed" to school.isSubscribed,
                "subscription_status" to school.subscription_status,
                "master_pin" to school.master_pin,
                "teacher_pin" to school.teacher_pin,
                "subscriptionStartDate" to school.subscriptionStartDate,
                "subscriptionEndDate" to school.subscriptionEndDate
            )
            fs.collection("schools").document(school.id)
                .set(schoolMap)
                .addOnSuccessListener {
                    onComplete(true, null)
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "Failed to update school in Firestore", e)
                    // Update locally as fallback
                    val index = localSchools.indexOfFirst { it.id == school.id }
                    if (index != -1) {
                        localSchools[index] = school
                    }
                    onComplete(true, "Firestore failed: ${e.localizedMessage}. Updated locally.")
                }
        } else {
            // Local fallback
            val index = localSchools.indexOfFirst { it.id == school.id }
            if (index != -1) {
                localSchools[index] = school
                onComplete(true, null)
            } else {
                onComplete(false, "School not found in local memory.")
            }
        }
    }

    fun deleteSchool(schoolId: String, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        if (fs != null && _isUsingFirestore.value && !schoolId.startsWith("local_")) {
            fs.collection("schools").document(schoolId)
                .delete()
                .addOnSuccessListener {
                    onComplete(true, null)
                }
                .addOnFailureListener { e ->
                    Log.e("SchoolRepository", "Failed to delete school from Firestore", e)
                    // Delete locally
                    localSchools.removeAll { it.id == schoolId }
                    onComplete(true, "Firestore failed: ${e.localizedMessage}. Deleted locally.")
                }
        } else {
            // Local fallback
            val removed = localSchools.removeAll { it.id == schoolId }
            if (removed) {
                onComplete(true, null)
            } else {
                onComplete(false, "School not found in local memory.")
            }
        }
    }

    fun listenToChats(schoolId: String, schoolEmail: String, onUpdate: (List<ChatMessage>) -> Unit): com.google.firebase.firestore.ListenerRegistration? {
        val fs = firestore
        val docId = if (schoolEmail.isNotBlank()) schoolEmail else schoolId
        if (fs != null && _isUsingFirestore.value && !docId.startsWith("local_")) {
            if (schoolEmail.isNotBlank()) {
                fs.collection("support_chats").document(schoolEmail)
                    .update("unreadByAdmin", false)
                    .addOnFailureListener {
                        val emptyMap = mapOf("unreadByAdmin" to false)
                        fs.collection("support_chats").document(schoolEmail)
                            .set(emptyMap, com.google.firebase.firestore.SetOptions.merge())
                    }
            }

            val collectionRef = if (schoolEmail.isNotBlank()) {
                fs.collection("support_chats").document(schoolEmail).collection("messages")
            } else {
                fs.collection("schools").document(schoolId).collection("chats")
            }

            return collectionRef
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.ASCENDING)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("SchoolRepository", "Error listening to chats", error)
                        onUpdate(localChats[docId] ?: emptyList())
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val messages = mutableListOf<ChatMessage>()
                        for (doc in snapshot.documents) {
                            val id = doc.id
                            val sender = doc.getString("sender") ?: ""
                            val text = doc.getString("text") ?: ""
                            val timestamp = doc.getTimestamp("timestamp")
                            messages.add(ChatMessage(id, sender, text, timestamp))
                        }
                        onUpdate(messages)
                    }
                }
        } else {
            onUpdate(localChats[docId] ?: emptyList())
            return null
        }
    }

    fun sendChatMessage(schoolId: String, schoolEmail: String, message: ChatMessage, onComplete: (Boolean, String?) -> Unit) {
        val fs = firestore
        val docId = if (schoolEmail.isNotBlank()) schoolEmail else schoolId
        if (fs != null && _isUsingFirestore.value && !docId.startsWith("local_")) {
            val msgMap = mapOf(
                "sender" to message.sender,
                "text" to message.text,
                "timestamp" to (message.timestamp ?: com.google.firebase.Timestamp.now())
            )

            if (schoolEmail.isNotBlank()) {
                val chatDocRef = fs.collection("support_chats").document(schoolEmail)
                chatDocRef.collection("messages")
                    .add(msgMap)
                    .addOnSuccessListener {
                        val lastMsgData = mapOf(
                            "lastMessage" to message.text,
                            "unreadBySchool" to true
                        )
                        chatDocRef.set(lastMsgData, com.google.firebase.firestore.SetOptions.merge())
                        onComplete(true, null)
                    }
                    .addOnFailureListener { e ->
                        Log.e("SchoolRepository", "Failed to send chat message", e)
                        val list = localChats.getOrPut(docId) { mutableListOf() }
                        list.add(message.copy(id = "local_${System.currentTimeMillis()}", timestamp = com.google.firebase.Timestamp.now()))
                        onComplete(true, "Firestore failed: ${e.localizedMessage}. Sent locally.")
                    }
            } else {
                fs.collection("schools").document(schoolId).collection("chats")
                    .add(msgMap)
                    .addOnSuccessListener {
                        onComplete(true, null)
                    }
                    .addOnFailureListener { e ->
                        Log.e("SchoolRepository", "Failed to send chat message", e)
                        val list = localChats.getOrPut(docId) { mutableListOf() }
                        list.add(message.copy(id = "local_${System.currentTimeMillis()}", timestamp = com.google.firebase.Timestamp.now()))
                        onComplete(true, "Firestore failed: ${e.localizedMessage}. Sent locally.")
                    }
            }
        } else {
            val list = localChats.getOrPut(docId) { mutableListOf() }
            list.add(message.copy(id = "local_${System.currentTimeMillis()}", timestamp = com.google.firebase.Timestamp.now()))
            onComplete(true, null)
        }
    }
}
