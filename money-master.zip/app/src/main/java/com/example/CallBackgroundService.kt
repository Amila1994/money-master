package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.firebase.firestore.FirebaseFirestore

class CallBackgroundService : Service() {

    private lateinit var db: FirebaseFirestore
    private val NOTIFICATION_CHANNEL_ID = "call_service_channel"

    override fun onCreate() {
        super.onCreate()
        db = FirebaseFirestore.getInstance()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ticketId = "TICKET_123" // ඔයා පාවිච්චි කරන Ticket ID එක

        // Background එකේ සිට සජීවීව Firebase Firestore එකට සවන් දීම
        db.collection("support_tickets").document(ticketId)
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null && snapshot.exists()) {
                    val status = snapshot.getString("callStatus")
                    val type = snapshot.getString("callType")

                    if ("RINGING" == status) {
                        // කෝල් එකක් ආ සැණින් Screen එක උඩට Popup එකක් ගෙන ඒම
                        showIncomingCallNotification(ticketId, type ?: "AUDIO")
                    }
                }
            }

        // Foreground Service එක ආරම්භ කිරීම (ඇප් එක වසා තිබුණත් වැඩ කිරීමට)
        val notificationBuilder = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Support Service Running")
            .setContentText("Listening for live background updates...")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1001, 
                notificationBuilder.build(), 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(1001, notificationBuilder.build())
        }

        return START_STICKY
    }

    private fun showIncomingCallNotification(channelName: String, callType: String) {
        // කෝල් එක ආවාම Open විය යුතු Screen එක (මෙහි ඔයාගේ Chat activity එකේ නම යොදන්න)
        val notificationIntent = Intent().setClassName(this, "com.example.ui.SchoolChatScreen") 
        notificationIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, 
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val incomingCallNotification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Incoming Support Call")
            .setContentText("You have a live $callType call request.")
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setFullScreenIntent(pendingIntent, true) // 👈 ඇප් එක Close වෙලා තිබුණත් Screen එක මතු කරයි
            .setAutoCancel(true)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(2002, incomingCallNotification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Call Service Channel",
                NotificationManager.IMPORTANCE_HIGH
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
