package com.example.model

data class School(
    val id: String = "",
    val name: String = "",
    val address: String = "",
    val phone: String = "",
    val email: String = "",
    val studentCount: Int = 0,
    val schoolType: String = "Public", // Public, Private, International, Chartered
    val establishedYear: Int = 2000,
    val status: String = "Active", // Active, Inactive, Pending
    val isLocked: Boolean = false,
    val isSubscribed: Boolean = false,
    val subscription_status: String = "ACTIVE",
    val master_pin: String = "",
    val teacher_pin: String = "",
    val subscriptionStartDate: com.google.firebase.Timestamp? = null,
    val subscriptionEndDate: com.google.firebase.Timestamp? = null
)
