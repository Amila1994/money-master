package com.example.model

import com.google.firebase.Timestamp

data class ChatMessage(
    val id: String = "",
    val sender: String = "", // "admin" or "school"
    val text: String = "",
    val timestamp: com.google.firebase.Timestamp? = null
)
