package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.TelephonyManager

class CallReceiver : BroadcastReceiver() {

    companion object {
        const val PREF_NAME = "call_recorder_prefs"
        const val PREF_AUTO_RECORD = "pref_auto_record"

        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var currentPhoneNumber: String? = "Unknown"
    }

    override fun onReceive(context: Context, intent: Intent) {
        // Extract incoming phone number
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        if (!incomingNumber.isNullOrEmpty()) {
            currentPhoneNumber = incomingNumber
        }

        if (intent.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val stateStr = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            
            val state = when (stateStr) {
                TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
                TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
                TelephonyManager.EXTRA_STATE_IDLE -> TelephonyManager.CALL_STATE_IDLE
                else -> TelephonyManager.CALL_STATE_IDLE
            }

            onCallStateChanged(context, state)
        }
    }

    private fun onCallStateChanged(context: Context, state: Int) {
        if (lastState == state) return

        when (state) {
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val isAutoRecordEnabled = prefs.getBoolean(PREF_AUTO_RECORD, true)
                if (isAutoRecordEnabled) {
                    // Pass phone number to RecordService
                    val serviceIntent = Intent(context, RecordService::class.java).apply {
                        putExtra("PHONE_NUMBER", currentPhoneNumber)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                val serviceIntent = Intent(context, RecordService::class.java)
                context.stopService(serviceIntent)
                currentPhoneNumber = "Unknown" // Reset after call ends
            }
        }
        lastState = state
    }
}

