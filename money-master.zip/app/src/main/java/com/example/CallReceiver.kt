package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log

class CallReceiver : BroadcastReceiver() {

    companion object {
        const val PREF_NAME = "call_recorder_prefs"
        const val PREF_AUTO_RECORD = "pref_auto_record"

        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var isIncoming = false
        private var savedNumber: String? = null
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_NEW_OUTGOING_CALL) {
            savedNumber = intent.extras?.getString("android.intent.extra.PHONE_NUMBER")
            return
        }

        val stateStr = intent.extras?.getString(TelephonyManager.EXTRA_STATE)
        val number = intent.extras?.getString(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: savedNumber

        var state = TelephonyManager.CALL_STATE_IDLE
        if (stateStr == TelephonyManager.EXTRA_STATE_RINGING) {
            state = TelephonyManager.CALL_STATE_RINGING
        } else if (stateStr == TelephonyManager.EXTRA_STATE_OFFHOOK) {
            state = TelephonyManager.CALL_STATE_OFFHOOK
        }

        onCallStateChanged(context, state, number)
    }

    private fun onCallStateChanged(context: Context, state: Int, number: String?) {
        if (lastState == state) return

        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                isIncoming = true
                savedNumber = number
            }
            TelephonyManager.CALL_STATE_OFFHOOK -> {
                val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                val isAutoRecordEnabled = prefs.getBoolean(PREF_AUTO_RECORD, true)
                if (isAutoRecordEnabled) {
                    val serviceIntent = Intent(context, RecordService::class.java).apply {
                        putExtra("PHONE_NUMBER", savedNumber ?: number ?: "Unknown")
                    }
                    
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                }
            }
            TelephonyManager.CALL_STATE_IDLE -> {
                if (lastState == TelephonyManager.CALL_STATE_OFFHOOK) {
                    val serviceIntent = Intent(context, RecordService::class.java)
                    context.stopService(serviceIntent)
                }
                isIncoming = false
                savedNumber = null
            }
        }
        lastState = state
    }
}


