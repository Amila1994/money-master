package com.example.ui

data class SchoolChatMessage(
    val id: String = "",
    val sender: String = "",
    val message: String = "",
    val text: String = "",
    val timestamp: com.google.firebase.Timestamp? = null
) {
    val displayMessage: String
        get() = message.ifEmpty { text }
}
