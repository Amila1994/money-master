package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.LoanViewModel
import com.example.ui.theme.*
import com.example.utils.Language
import com.example.utils.LocalizedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PinSecurityScreen(
    viewModel: LoanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val savedPin by viewModel.savedPin.collectAsStateWithLifecycle()
    val savedQuestion by viewModel.savedQuestion.collectAsStateWithLifecycle()
    val savedAnswer by viewModel.savedAnswer.collectAsStateWithLifecycle()

    var isSetupMode by remember(savedPin) { mutableStateOf(savedPin == null) }
    var isResetMode by remember { mutableStateOf(false) }

    // Setup input states
    var setupPin by remember { mutableStateOf("") }
    var setupConfirmPin by remember { mutableStateOf("") }
    var setupAnswer by remember { mutableStateOf("") }

    val questionsSin = remember {
        listOf(
            "ඔබ ඉපදුණු නගරය කුමක්ද?",
            "ඔබේ පළමු සුරතලාගේ නම කුමක්ද?",
            "ඔබේ ප්රියතම පාසල් ගුරුවරයා කවුද?",
            "ඔබේ මවගේ උපන් වර්ෂය කුමක්ද?"
        )
    }

    val questionsEng = remember {
        listOf(
            "What is your birth city?",
            "What is your first pet's name?",
            "Who is your favorite school teacher?",
            "What is your mother's birth year?"
        )
    }

    val questions = if (lang == Language.SINHALA) questionsSin else questionsEng
    var selectedQuestion by remember(lang) { mutableStateOf(questions[0]) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    // Login input states
    var loginPin by remember { mutableStateOf("") }

    // Reset input states
    var resetAnswer by remember { mutableStateOf("") }
    var resetNewPin by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .statusBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState()),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = BorderStroke(1.dp, BorderColor)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (isResetMode) {
                    // --- 3. RESET PIN VIEW ---
                    Text(
                        text = LocalizedText.get("pin_reset_title", lang),
                        color = AccentAmber,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = LocalizedText.get("security_q_label", lang),
                            color = TextGray,
                            fontSize = 12.sp
                        )
                        Text(
                            text = savedQuestion ?: "",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    OutlinedTextField(
                        value = resetAnswer,
                        onValueChange = { resetAnswer = it },
                        placeholder = { Text(LocalizedText.get("security_q_hint", lang), color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor,
                            focusedContainerColor = DarkBg,
                            unfocusedContainerColor = DarkBg
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("reset_security_answer_input")
                    )

                    PinInputField(
                        value = resetNewPin,
                        onValueChange = { resetNewPin = it },
                        hint = LocalizedText.get("enter_new_pin", lang),
                        modifier = Modifier.testTag("reset_new_pin_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                isResetMode = false
                                resetAnswer = ""
                                resetNewPin = ""
                            }
                        ) {
                            Text(LocalizedText.get("back_btn", lang), color = TextGray)
                        }

                        Button(
                            onClick = {
                                val inputAnswer = resetAnswer.trim().lowercase()
                                val targetAnswer = savedAnswer?.trim()?.lowercase() ?: ""
                                if (inputAnswer == targetAnswer && resetNewPin.length == 4) {
                                    viewModel.savePinSecurity(resetNewPin, savedQuestion ?: "", resetAnswer)
                                    isResetMode = false
                                    resetAnswer = ""
                                    resetNewPin = ""
                                    Toast.makeText(context, LocalizedText.get("pin_changed_success", lang), Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, LocalizedText.get("reset_incorrect_error", lang), Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Text(LocalizedText.get("pin_change_btn", lang), fontWeight = FontWeight.Bold)
                        }
                    }

                } else if (isSetupMode) {
                    // --- 1. SETUP PIN VIEW ---
                    Text(
                        text = LocalizedText.get("pin_setup_title", lang),
                        color = AccentAmber,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    PinInputField(
                        value = setupPin,
                        onValueChange = { setupPin = it },
                        hint = LocalizedText.get("enter_new_pin", lang),
                        modifier = Modifier.testTag("setup_new_pin_input")
                    )

                    PinInputField(
                        value = setupConfirmPin,
                        onValueChange = { setupConfirmPin = it },
                        hint = LocalizedText.get("confirm_pin", lang),
                        modifier = Modifier.testTag("setup_confirm_pin_input")
                    )

                    Divider(color = BorderColor, modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = LocalizedText.get("pin_reset_desc", lang),
                        color = TextGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Dropdown for security questions
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkBg)
                                .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                                .clickable { dropdownExpanded = true }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedQuestion,
                                color = Color.White,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Dropdown Menu",
                                tint = AccentAmber
                            )
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .background(CardBg)
                                .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                        ) {
                            questions.forEach { q ->
                                DropdownMenuItem(
                                    text = { Text(q, color = Color.White, fontSize = 13.sp) },
                                    onClick = {
                                        selectedQuestion = q
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = setupAnswer,
                        onValueChange = { setupAnswer = it },
                        placeholder = { Text(LocalizedText.get("security_q_hint", lang), color = TextGray, fontSize = 14.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor,
                            focusedContainerColor = DarkBg,
                            unfocusedContainerColor = DarkBg
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("setup_security_answer_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (setupPin.length == 4 && setupPin == setupConfirmPin && setupAnswer.isNotEmpty()) {
                                viewModel.savePinSecurity(setupPin, selectedQuestion, setupAnswer)
                                isSetupMode = false
                                setupPin = ""
                                setupConfirmPin = ""
                                setupAnswer = ""
                                Toast.makeText(context, LocalizedText.get("pin_saved_success", lang), Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, LocalizedText.get("pin_invalid_error", lang), Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("setup_save_pin_button")
                    ) {
                        Text(LocalizedText.get("save_pin", lang), fontWeight = FontWeight.Bold)
                    }

                } else {
                    // --- 2. LOGIN PIN VIEW ---
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = AccentAmber,
                        modifier = Modifier.size(50.dp)
                    )

                    Text(
                        text = LocalizedText.get("pin_login_title", lang),
                        color = AccentAmber,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = LocalizedText.get("pin_login_desc", lang),
                        color = TextGray,
                        fontSize = 13.sp
                    )

                    PinInputField(
                        value = loginPin,
                        onValueChange = { loginPin = it },
                        hint = LocalizedText.get("pin_enter_hint", lang),
                        modifier = Modifier.testTag("login_pin_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (loginPin == savedPin) {
                                viewModel.setAppUnlocked(true)
                                Toast.makeText(context, if (lang == Language.ENGLISH) "✓ Success!" else "✓ සාර්ථකයි!", Toast.LENGTH_SHORT).show()
                                loginPin = ""
                            } else {
                                Toast.makeText(context, LocalizedText.get("wrong_pin_error", lang), Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("login_submit_button")
                    ) {
                        Text(LocalizedText.get("pin_login_button", lang), fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = LocalizedText.get("forgot_pin", lang),
                        color = TextGray,
                        fontSize = 13.sp,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier
                            .clickable {
                                isResetMode = true
                                loginPin = ""
                            }
                            .testTag("forgot_pin_trigger")
                    )
                }
            }
        }
    }
}

@Composable
fun PinInputField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = {
            if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                onValueChange(it)
            }
        },
        placeholder = { Text(text = hint, color = TextGray, fontSize = 14.sp) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.Number,
            imeAction = ImeAction.Done
        ),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = AccentAmber,
            unfocusedBorderColor = BorderColor,
            focusedContainerColor = DarkBg,
            unfocusedContainerColor = DarkBg
        ),
        shape = RoundedCornerShape(12.dp),
        textStyle = androidx.compose.ui.text.TextStyle(
            fontSize = 18.sp,
            letterSpacing = 8.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        ),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    )
}
