package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PremiumBlue = Color(0xFF1E3A8A)
val PremiumBlueLight = Color(0xFF3B82F6)
val SoftBackground = Color(0xFFF8FAFC)
val SlateDark = Color(0xFF0F172A)
val AccentEmerald = Color(0xFF10B981)
val AccentCrimson = Color(0xFFEF4444)
val AccentAmber = Color(0xFFF59E0B)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

