package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.CallRecord
import com.example.data.CallType
import com.example.recording.PlaybackState
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecordingCard(
    record: CallRecord,
    playbackState: PlaybackState,
    onPlayClick: () -> Unit,
    onPauseClick: () -> Unit,
    onSeek: (Int) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onToggleFavorite: () -> Unit,
    onUpdateNotes: (String) -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isCurrentPlaying = playbackState.currentFilePath == record.filePath && playbackState.isPlaying
    val isCurrentActive = playbackState.currentFilePath == record.filePath

    var showMenu by remember { mutableStateOf(false) }
    var showNotesDialog by remember { mutableStateOf(false) }

    val formattedDate = remember(record.timestamp) {
        val sdf = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
        sdf.format(Date(record.timestamp))
    }

    val formattedDuration = remember(record.durationSeconds) {
        val mins = record.durationSeconds / 60
        val secs = record.durationSeconds % 60
        String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
    }

    val formattedSize = remember(record.fileSizeBytes) {
        if (record.fileSizeBytes > 0) {
            String.format(Locale.getDefault(), "%.1f KB", record.fileSizeBytes / 1024.0)
        } else "Audio file"
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .testTag("recording_card_${record.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentActive) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            }
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Call Type Avatar Icon
                CallAvatarIcon(callType = record.callType)

                Spacer(modifier = Modifier.width(12.dp))

                // Contact & Phone Info
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (record.contactName.isNotBlank()) record.contactName else record.phoneNumber,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (record.contactName.isNotBlank()) {
                        Text(
                            text = record.phoneNumber,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "$formattedDate • $formattedSize",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                // Duration Tag
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = formattedDuration,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                // Favorite Icon
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.testTag("favorite_button_${record.id}")
                ) {
                    Icon(
                        imageVector = if (record.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (record.isFavorite) Color(0xFFE91E63) else MaterialTheme.colorScheme.outline
                    )
                }

                // Overflow Menu
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More Options")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit Note") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                showNotesDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Share Audio") },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                val file = File(record.filePath)
                                if (file.exists()) {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "audio/*"
                                        putExtra(Intent.EXTRA_STREAM, android.net.Uri.fromFile(file))
                                        putExtra(Intent.EXTRA_SUBJECT, "Call Recording with ${record.phoneNumber}")
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Call Recording"))
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete Recording", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showMenu = false
                                onDeleteClick()
                            }
                        )
                    }
                }
            }

            // Optional User Notes
            if (record.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "📝 ${record.notes}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Player Section & Waveform Visualizer
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Play / Pause Button
                IconButton(
                    onClick = {
                        if (isCurrentPlaying) onPauseClick() else onPlayClick()
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                        .testTag("play_pause_button_${record.id}")
                ) {
                    Icon(
                        imageVector = if (isCurrentPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isCurrentPlaying) "Pause" else "Play",
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Waveform Animation / Progress Bar
                Column(modifier = Modifier.weight(1f)) {
                    if (isCurrentActive) {
                        val currentMs = playbackState.currentPositionMs.toFloat()
                        val durationMs = playbackState.durationMs.coerceAtLeast(1).toFloat()
                        val sliderPosition = (currentMs / durationMs).coerceIn(0f, 1f)

                        Slider(
                            value = sliderPosition,
                            onValueChange = { percent ->
                                val targetMs = (percent * durationMs).toInt()
                                onSeek(targetMs)
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.primary,
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(20.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val elapsedSec = playbackState.currentPositionMs / 1000
                            val totalSec = playbackState.durationMs / 1000
                            Text(
                                text = String.format(Locale.getDefault(), "%02d:%02d", elapsedSec / 60, elapsedSec % 60),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = String.format(Locale.getDefault(), "%02d:%02d", totalSec / 60, totalSec % 60),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    } else {
                        // Static wave bars
                        StaticWaveformBars(isAnimating = false)
                    }
                }

                if (isCurrentActive) {
                    Spacer(modifier = Modifier.width(8.dp))
                    SpeedChip(
                        currentSpeed = playbackState.speed,
                        onSpeedSelected = onSpeedChange
                    )
                }
            }
        }
    }

    // Edit Notes Dialog
    if (showNotesDialog) {
        var noteText by remember { mutableStateOf(record.notes) }
        Dialog(onDismissRequest = { showNotesDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "Call Recording Note",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("Add note or details") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("notes_input_field"),
                        maxLines = 3
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row {
                        TextButton(onClick = { showNotesDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(onClick = {
                            onUpdateNotes(noteText)
                            showNotesDialog = false
                        }) {
                            Text("Save")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CallAvatarIcon(callType: CallType) {
    val (bgColor, iconVector, tintColor) = when (callType) {
        CallType.INCOMING -> Triple(
            Color(0xFFE8F5E9),
            Icons.AutoMirrored.Filled.CallReceived,
            Color(0xFF2E7D32)
        )
        CallType.OUTGOING -> Triple(
            Color(0xFFE3F2FD),
            Icons.AutoMirrored.Filled.CallMade,
            Color(0xFF1565C0)
        )
        CallType.MISSED -> Triple(
            Color(0xFFFFEBEE),
            Icons.Default.CallMissed,
            Color(0xFFC62828)
        )
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(bgColor)
    ) {
        Icon(
            imageVector = iconVector,
            contentDescription = callType.name,
            tint = tintColor,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun StaticWaveformBars(isAnimating: Boolean) {
    val transition = rememberInfiniteTransition(label = "waveform")
    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp)
    ) {
        val barHeights = remember { listOf(0.3f, 0.7f, 0.4f, 0.9f, 0.6f, 1.0f, 0.5f, 0.8f, 0.3f, 0.7f, 0.9f, 0.4f, 0.8f, 0.6f, 0.3f) }
        barHeights.forEachIndexed { index, defaultFactor ->
            val scale by if (isAnimating) {
                transition.animateFloat(
                    initialValue = 0.2f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(durationMillis = 400 + (index * 60), easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "bar_$index"
                )
            } else {
                remember { mutableStateOf(defaultFactor) }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height((28 * scale).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = if (isAnimating) 0.8f else 0.35f))
            )
        }
    }
}

@Composable
fun SpeedChip(
    currentSpeed: Float,
    onSpeedSelected: (Float) -> Unit
) {
    val speeds = listOf(1.0f, 1.25f, 1.5f, 2.0f)
    var expanded by remember { mutableStateOf(false) }

    Box {
        Surface(
            onClick = { expanded = true },
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "${currentSpeed}x",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            speeds.forEach { speed ->
                DropdownMenuItem(
                    text = { Text("${speed}x") },
                    onClick = {
                        onSpeedSelected(speed)
                        expanded = false
                    }
                )
            }
        }
    }
}
