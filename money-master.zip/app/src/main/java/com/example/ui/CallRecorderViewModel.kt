package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.CallReceiver
import com.example.RecordService
import com.example.data.AppDatabase
import com.example.data.CallRecord
import com.example.data.CallRecordRepository
import com.example.data.CallType
import com.example.recording.CallAudioPlayer
import com.example.recording.PlaybackState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class FilterType {
    ALL,
    INCOMING,
    OUTGOING,
    FAVORITES
}

data class StorageStats(
    val totalCount: Int = 0,
    val countToday: Int = 0,
    val totalDurationSeconds: Long = 0,
    val totalSizeBytes: Long = 0
)

class CallRecorderViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CallRecordRepository
    val audioPlayer: CallAudioPlayer

    private val prefs = application.getSharedPreferences(CallReceiver.PREF_NAME, Context.MODE_PRIVATE)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _filterType = MutableStateFlow(FilterType.ALL)
    val filterType: StateFlow<FilterType> = _filterType.asStateFlow()

    private val _isAutoRecordEnabled = MutableStateFlow(prefs.getBoolean(CallReceiver.PREF_AUTO_RECORD, true))
    val isAutoRecordEnabled: StateFlow<Boolean> = _isAutoRecordEnabled.asStateFlow()

    private val _selectedAudioFormat = MutableStateFlow("AAC")
    val selectedAudioFormat: StateFlow<String> = _selectedAudioFormat.asStateFlow()

    private val _selectedAudioSource = MutableStateFlow("Microphone")
    val selectedAudioSource: StateFlow<String> = _selectedAudioSource.asStateFlow()

    val playbackState: StateFlow<PlaybackState>

    val activeRecordingState = RecordService.activeRecordingState

    // Filtered recordings combined flow
    val recordingsList: StateFlow<List<CallRecord>>

    // Storage stats summary
    val storageStats: StateFlow<StorageStats>

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CallRecordRepository(database.callRecordDao())
        audioPlayer = CallAudioPlayer(application)
        playbackState = audioPlayer.playbackState

        recordingsList = combine(_searchQuery, _filterType) { query, filter ->
            Pair(query, filter)
        }.flatMapLatest { (query, filter) ->
            if (query.isNotBlank()) {
                repository.searchRecordings(query)
            } else {
                when (filter) {
                    FilterType.FAVORITES -> repository.favoriteRecordings
                    else -> repository.allRecordings
                }
            }
        }.combine(_filterType) { list, filter ->
            when (filter) {
                FilterType.INCOMING -> list.filter { it.callType == CallType.INCOMING }
                FilterType.OUTGOING -> list.filter { it.callType == CallType.OUTGOING }
                else -> list
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        storageStats = repository.allRecordings.combine(MutableStateFlow(System.currentTimeMillis())) { list, now ->
            val startOfDay = now - (now % (24 * 60 * 60 * 1000))
            val todayCount = list.count { it.timestamp >= startOfDay }
            val totalDuration = list.sumOf { it.durationSeconds }
            val totalSize = list.sumOf { it.fileSizeBytes }
            StorageStats(
                totalCount = list.size,
                countToday = todayCount,
                totalDurationSeconds = totalDuration,
                totalSizeBytes = totalSize
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = StorageStats()
        )
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilterType(type: FilterType) {
        _filterType.value = type
    }

    fun toggleAutoRecord(enabled: Boolean) {
        _isAutoRecordEnabled.value = enabled
        prefs.edit().putBoolean(CallReceiver.PREF_AUTO_RECORD, enabled).apply()
    }

    fun setAudioFormat(format: String) {
        _selectedAudioFormat.value = format
    }

    fun setAudioSource(source: String) {
        _selectedAudioSource.value = source
    }

    fun toggleFavorite(record: CallRecord) {
        viewModelScope.launch {
            repository.toggleFavorite(record.id, record.isFavorite)
        }
    }

    fun updateNotes(recordId: Long, notes: String) {
        viewModelScope.launch {
            repository.updateNotes(recordId, notes)
        }
    }

    fun deleteRecording(record: CallRecord) {
        viewModelScope.launch {
            if (record.filePath.isNotBlank()) {
                val file = File(record.filePath)
                if (file.exists()) {
                    file.delete()
                }
            }
            repository.delete(record)
        }
    }

    fun playRecording(filePath: String) {
        audioPlayer.playAudio(filePath)
    }

    fun pausePlayback() {
        audioPlayer.pauseAudio()
    }

    fun seekPlayback(positionMs: Int) {
        audioPlayer.seekTo(positionMs)
    }

    fun setPlaybackSpeed(speed: Float) {
        audioPlayer.setSpeed(speed)
    }

    // Call Simulation
    fun startSimulatedCall(phoneNumber: String, contactName: String, callType: CallType) {
        RecordService.startRecording(
            context = getApplication(),
            phoneNumber = phoneNumber.ifBlank { "+1 (555) 019-2831" },
            contactName = contactName.ifBlank { "Alex Morgan" },
            callType = callType
        )
    }

    fun stopSimulatedCall() {
        RecordService.stopRecording(getApplication())
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stopAudio()
    }
}
