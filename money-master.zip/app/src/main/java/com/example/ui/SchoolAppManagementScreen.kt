package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Environment
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolAppManagementScreen() {
    val context = LocalContext.current
    
    // පන්ති සඳහා දත්ත (States)
    var currentClass by remember { mutableStateOf("10-A") }
    var teacherName by remember { mutableStateOf("Mr. Asela Perera") }
    
    // Input Fields සඳහා States
    var inputClassName by remember { mutableStateOf("") }
    var inputTeacherName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(Color(0xFF231F20)), // ඔයාගේ ඇප් එකේ තියෙන Dark Theme වර්ණය
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // --- 1. පන්ති තෝරන සහ දැනට තියෙන විස්තර පෙන්වන කාඩ් එක ---
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF363031)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🎯 Select Class (වැඩ කිරීමට පන්තිය තෝරන්න):",
                    color = Color(0xFFE5A93C),
                    fontSize = 14.sp
                )
                
                Text(
                    text = "දැනට තෝරාගත් පන්තිය: $currentClass ($teacherName)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                OutlinedTextField(
                    value = inputClassName,
                    onValueChange = { inputClassName = it },
                    label = { Text("පන්තියේ නම (Class Name)", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                OutlinedTextField(
                    value = inputTeacherName,
                    onValueChange = { inputTeacherName = it },
                    label = { Text("පන්තිභාර ගුරුතුමා (Class Teacher)", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // --- 2. පාලක බොත්තම් 3 පතුලෙන්ම පෙන්වීම (Add, Update, Delete Buttons) ---
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF363031)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // ➕ පන්තියක් එකතු කිරීම
                Button(
                    onClick = {
                        if (inputClassName.isNotEmpty()) {
                            currentClass = inputClassName
                            teacherName = inputTeacherName
                            Toast.makeText(context, "අලුත් පන්තියක් එකතු කළා!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)), // කොළ පාට
                    modifier = Modifier.weight(1f).padding(4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("එකතු කරන්න", fontSize = 11.sp, color = Color.White)
                }

                // ✏️ පන්තිය වෙනස් කිරීම
                Button(
                    onClick = {
                        if (inputClassName.isNotEmpty()) {
                            currentClass = inputClassName
                            teacherName = inputTeacherName
                            Toast.makeText(context, "පන්තියේ විස්තර වෙනස් කළා!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5A93C)), // කහ/තැඹිලි පාට
                    modifier = Modifier.weight(1f).padding(4.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("වෙනස් කරන්න", fontSize = 11.sp, color = Color.White)
                }

                // ❌ පන්තිය සම්පූර්ණයෙන්ම මකා දැමීම (Delete Button)
                Button(
                    onClick = {
                        inputClassName = ""
                        inputTeacherName = ""
                        currentClass = "නොමැත"
                        teacherName = "නොමැත"
                        Toast.makeText(context, "පන්තිය සාර්ථකව මකා දැමුවා!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336)), // රතු පාට
                    modifier = Modifier.weight(1f).padding(4.dp)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("මකන්න", fontSize = 11.sp, color = Color.White)
                }
            }
        }
    }
}

// 🎨 වර්ණවත් චාර්ට් 5ක් සමඟ සේව් වන බැක්එන්ඩ් සිස්ටම් එක (Colorful Chart Logic)
fun saveColorfulChartAsImage(
    context: Context,
    school: String,
    clazz: String,
    chartType: String
) {
    val bitmap = Bitmap.createBitmap(800, 1000, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)

    val paint = Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 34f
        isAntiAlias = true
    }

    // Header එක ඇඳීම
    canvas.drawText(school, 50f, 80f, paint.apply { textSize = 40f; isFakeBoldText = true })
    paint.textSize = 28f; paint.isFakeBoldText = false
    canvas.drawText("පන්තිය: $clazz", 50f, 140f, paint)
    canvas.drawText("ප්රස්ථාර වර්ගය: $chartType", 50f, 190f, paint)
    
    paint.color = android.graphics.Color.LTGRAY
    canvas.drawLine(50f, 220f, 750f, 220f, paint)

    // 📊 තෝරාගන්නා චාර්ට් එක අනුව වර්ණවත් හැඩතල ඇඳීම (Multi-Color Rendering)
    when (chartType) {
        "Bar Chart" -> {
            // වර්ණ 3ක බාර් තුනක්
            paint.color = android.graphics.Color.parseColor("#4CAF50") // කොළ
            canvas.drawRect(150f, 400f, 250f, 800f, paint)
            paint.color = android.graphics.Color.parseColor("#FF9800") // තැඹිලි
            canvas.drawRect(350f, 300f, 450f, 800f, paint)
            paint.color = android.graphics.Color.parseColor("#2196F3") // නිල්
            canvas.drawRect(550f, 500f, 650f, 800f, paint)
        }
        "Pie Chart", "Donut Chart" -> {
            val rectF = RectF(200f, 350f, 600f, 750f)
            paint.color = android.graphics.Color.parseColor("#E91E63") // රෝස
            canvas.drawArc(rectF, 0f, 120f, true, paint)
            paint.color = android.graphics.Color.parseColor("#9C27B0") // දම්
            canvas.drawArc(rectF, 120f, 100f, true, paint)
            paint.color = android.graphics.Color.parseColor("#00BCD4") // ටර්කීස්
            canvas.drawArc(rectF, 220f, 140f, true, paint)
            
            if(chartType == "Donut Chart") {
                paint.color = android.graphics.Color.WHITE
                canvas.drawCircle(400f, 550f, 100f, paint) // මැද හිස් කිරීම
            }
        }
        "Line Chart", "Area Chart" -> {
            paint.color = android.graphics.Color.parseColor("#FF5722") // තද රතු
            paint.strokeWidth = 8f
            canvas.drawLine(150f, 600f, 350f, 400f, paint)
            canvas.drawLine(350f, 400f, 550f, 650f, paint)
            canvas.drawLine(550f, 650f, 650f, 300f, paint)
        }
    }

    // ෆෝන් එකේ Downloads ෆෝල්ඩරයට PNG එකක් ලෙස පිටපත් කිරීම
    val filename = "Colorful_${chartType.replace(" ", "")}_${System.currentTimeMillis()}.png"
    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    val file = File(downloadDir, filename)

    try {
        val out = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        out.flush()
        out.close()
        Toast.makeText(context, "වර්ණවත් චාර්ට් එක සේව් වුණා! ($filename)", Toast.LENGTH_LONG).show()
    } catch (e: IOException) {
        Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}
