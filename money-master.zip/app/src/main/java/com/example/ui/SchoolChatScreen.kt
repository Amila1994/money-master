package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import io.agora.rtc.IRtcEngineEventHandler
import io.agora.rtc.RtcEngine
import io.agora.rtc.video.VideoCanvas
import io.agora.rtc.video.VideoEncoderConfiguration
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchoolChatScreen(
    viewModel: MainViewModel,
    selectedLanguage: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val messages by viewModel.supportChatMessages.collectAsState()
    var messageText by remember { mutableStateOf("") }
    val lazyListState = rememberLazyListState()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Video calling states
    var isVideoCallActive by remember { mutableStateOf(false) }
    var localSurfaceView by remember { mutableStateOf<android.view.View?>(null) }
    var remoteSurfaceView by remember { mutableStateOf<android.view.View?>(null) }
    var rtcEngine by remember { mutableStateOf<RtcEngine?>(null) }

    // Audio calling states
    var isAudioCallActive by remember { mutableStateOf(false) }
    val callManager = remember { com.example.utils.PremiumChatCallManager() }

    // Dynamic Permission request flow
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[android.Manifest.permission.CAMERA] ?: false
        val audioGranted = permissions[android.Manifest.permission.RECORD_AUDIO] ?: false
        if (cameraGranted && audioGranted) {
            isVideoCallActive = true
        } else {
            android.widget.Toast.makeText(
                context,
                "Camera and Audio permissions are required for video call.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            isAudioCallActive = true
        } else {
            android.widget.Toast.makeText(
                context,
                "Microphone/Audio permission is required for voice call.",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    // Observe message authority/sending errors
    val chatError by viewModel.supportChatError.collectAsState()
    LaunchedEffect(chatError) {
        chatError?.let { err ->
            android.widget.Toast.makeText(context, err, android.widget.Toast.LENGTH_LONG).show()
            viewModel.supportChatError.value = null
        }
    }

    // Automatically trigger real-time listener when screen is opened
    LaunchedEffect(Unit) {
        viewModel.listenToSupportChat()
    }

    // Auto-scroll to the bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            lazyListState.animateScrollToItem(messages.size - 1)
        }
    }

    // Audio Call Lifecycle management
    if (isAudioCallActive) {
        DisposableEffect(Unit) {
            val channelName = "school_master_support_channel"
            callManager.startAudioOnlyCall(context, channelName)
            onDispose {
                callManager.stopCall()
            }
        }
    }

    // Agora Call Lifecycle management
    if (isVideoCallActive) {
        DisposableEffect(Unit) {
            val appId = "c4e26b154e784372842dbd1e8fa3ec95" // Custom Agora App ID
            val channelName = "school_master_support_channel"

            val handler = object : IRtcEngineEventHandler() {
                override fun onJoinChannelSuccess(channel: String?, uid: Int, elapsed: Int) {
                    android.util.Log.d("AgoraVideoCall", "Joined channel successfully: $channel, uid: $uid")
                }

                override fun onUserJoined(uid: Int, elapsed: Int) {
                    (context as? android.app.Activity)?.runOnUiThread {
                        if (isEmulator()) {
                            val dummyView = android.view.View(context).apply {
                                setBackgroundColor(android.graphics.Color.BLACK)
                            }
                            remoteSurfaceView = dummyView
                        } else {
                            val surfaceView = RtcEngine.CreateTextureView(context)
                            rtcEngine?.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, uid))
                            remoteSurfaceView = surfaceView
                        }
                    }
                }

                override fun onUserOffline(uid: Int, reason: Int) {
                    (context as? android.app.Activity)?.runOnUiThread {
                        remoteSurfaceView = null
                    }
                }
            }

            try {
                val engine = RtcEngine.create(context, appId, handler)
                engine.enableVideo()

                // Set low-data video options (approx 30MB per 10 minutes)
                val config = VideoEncoderConfiguration(
                    VideoEncoderConfiguration.VD_320x240, // 240p
                    VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15, // 15 FPS
                    VideoEncoderConfiguration.STANDARD_BITRATE,
                    VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_FIXED_PORTRAIT
                )
                engine.setVideoEncoderConfiguration(config)

                // Setup local preview
                if (isEmulator()) {
                    val dummyView = android.view.View(context).apply {
                        setBackgroundColor(android.graphics.Color.DKGRAY)
                    }
                    localSurfaceView = dummyView
                } else {
                    val localView = RtcEngine.CreateTextureView(context)
                    engine.setupLocalVideo(VideoCanvas(localView, VideoCanvas.RENDER_MODE_HIDDEN, 0))
                    localSurfaceView = localView
                }

                engine.joinChannel(null, channelName, "", 0)
                rtcEngine = engine
            } catch (e: Exception) {
                e.printStackTrace()
                android.widget.Toast.makeText(context, "Error starting call: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }

            onDispose {
                rtcEngine?.leaveChannel()
                RtcEngine.destroy()
                rtcEngine = null
                localSurfaceView = null
                remoteSurfaceView = null
            }
        }
    }

    val titleText = when (selectedLanguage) {
        "Sinhala" -> "පරිපාලක සහාය කතාබහ"
        "Tamil" -> "நிர்வாகி ஆதரவு அரட்டை"
        else -> "Admin Support Chat"
    }

    val hintText = when (selectedLanguage) {
        "Sinhala" -> "ඇඩ්මින් වෙත පණිවිඩයක් ලියන්න..."
        "Tamil" -> "நிர்வாகிக்கு செய்தி எழுதவும்..."
        else -> "Write a message to admin..."
    }

    val sendButtonText = when (selectedLanguage) {
        "Sinhala" -> "යවන්න"
        "Tamil" -> "அனுப்பு"
        else -> "Send"
    }

    Scaffold(
        modifier = modifier.testTag("school_chat_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = titleText,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "School Master Support Portal",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            viewModel.stopListeningToSupportChat()
                            onBack()
                        },
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val hasAudio = androidx.core.content.ContextCompat.checkSelfPermission(
                                context,
                                android.Manifest.permission.RECORD_AUDIO
                            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                            if (hasAudio) {
                                isAudioCallActive = true
                            } else {
                                audioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier.testTag("btnAudioCall")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Voice Call",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    IconButton(
                        onClick = {
                            val permissionsToRequest = arrayOf(
                                android.Manifest.permission.CAMERA,
                                android.Manifest.permission.RECORD_AUDIO
                            )
                            val hasCamera = androidx.core.content.ContextCompat.checkSelfPermission(
                                context,
                                android.Manifest.permission.CAMERA
                            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                            val hasAudio = androidx.core.content.ContextCompat.checkSelfPermission(
                                context,
                                android.Manifest.permission.RECORD_AUDIO
                            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                            if (hasCamera && hasAudio) {
                                isVideoCallActive = true
                            } else {
                                permissionLauncher.launch(permissionsToRequest)
                            }
                        },
                        modifier = Modifier.testTag("btnVideoCall")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Video Call",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFFAFAFA)) // Conforms to XML android:background="#FAFAFA"
            ) {
                // Message bubble list
                LazyColumn(
                    state = lazyListState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .testTag("rvSchoolChat"), // Conforms to XML rvSchoolChat
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = when (selectedLanguage) {
                                            "Sinhala" -> "තවමත් පණිවිඩ කිසිවක් නැත. ඇඩ්මින් වෙත පණිවිඩයක් යවන්න."
                                            "Tamil" -> "இன்னும் செய்திகள் எதுவும் இல்லை. நிர்வாகிக்கு செய்தி அனுப்பவும்."
                                            else -> "No messages yet. Send a message to the administrator."
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(16.dp),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    } else {
                        items(messages, key = { it.id }) { msg ->
                            ChatBubbleItem(msg = msg)
                        }
                    }
                }

                // Input panel (Conforms to XML layoutInputArea / etSchoolMessage / btnSchoolSend)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("layoutInputArea"),
                    tonalElevation = 4.dp,
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = messageText,
                            onValueChange = { messageText = it },
                            placeholder = {
                                Text(
                                    text = hintText,
                                    fontSize = 14.sp
                                )
                            },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("etSchoolMessage"),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Send
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (messageText.trim().isNotEmpty()) {
                                        val toSend = messageText
                                        messageText = ""
                                        viewModel.sendSupportChatMessage(toSend)
                                        keyboardController?.hide()
                                    }
                                }
                            ),
                            singleLine = false,
                            maxLines = 4
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (messageText.trim().isNotEmpty()) {
                                    val toSend = messageText
                                    messageText = ""
                                    viewModel.sendSupportChatMessage(toSend)
                                    keyboardController?.hide()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2196F3) // Conforms to XML android:backgroundTint="#2196F3"
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btnSchoolSend")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = sendButtonText,
                                modifier = Modifier.size(16.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = sendButtonText,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // Video call overlay
            AnimatedVisibility(
                visible = isVideoCallActive,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                VideoCallOverlay(
                    localSurfaceView = localSurfaceView,
                    remoteSurfaceView = remoteSurfaceView,
                    onEndCall = {
                        isVideoCallActive = false
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Audio call overlay
            AnimatedVisibility(
                visible = isAudioCallActive,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                AudioCallOverlay(
                    selectedLanguage = selectedLanguage,
                    onEndCall = {
                        isAudioCallActive = false
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun AudioCallOverlay(
    selectedLanguage: String,
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.9f))
            .testTag("layoutAudioContainer"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // High-quality Icon
            Surface(
                shape = RoundedCornerShape(100.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(120.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Active Call",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(60.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "School Master Support Call",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "සජීවී හඬ ඇමතුම සම්බන්ධ වෙමින් පවතී..."
                    "Tamil" -> "நேரடி குரல் அழைப்பு இணைக்கிறது..."
                    else -> "Live voice call connecting..."
                },
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "⚡ Data: ~0.5 MB / min",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Red End Call button
            Button(
                onClick = onEndCall,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFF3B30) // Red
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .width(220.dp)
                    .height(48.dp)
                    .testTag("btnEndAudioCall")
            ) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "End Call",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ඇමතුම අවසන් කරන්න"
                        "Tamil" -> "அழைப்பை முடி"
                        else -> "End Call"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun VideoCallOverlay(
    localSurfaceView: android.view.View?,
    remoteSurfaceView: android.view.View?,
    onEndCall: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("layoutVideoContainer")
    ) {
        // Remote video view container (fills screen)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .testTag("remote_video_view_container")
        ) {
            if (remoteSurfaceView != null) {
                AndroidView(
                    factory = { ctx ->
                        android.widget.FrameLayout(ctx).apply {
                            id = android.view.View.generateViewId()
                            (remoteSurfaceView.parent as? android.view.ViewGroup)?.removeView(remoteSurfaceView)
                            addView(remoteSurfaceView)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
                if (isEmulator()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Simulated Video",
                                tint = Color.LightGray,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Remote Video (Simulator)",
                                color = Color.LightGray,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Waiting for other party...",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        if (isEmulator()) {
            Surface(
                color = Color.Black.copy(alpha = 0.7f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(16.dp)
            ) {
                Text(
                    text = "💻 Emulator Mode: Video simulated",
                    color = Color.Yellow,
                    modifier = Modifier.padding(8.dp),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Local video view container (positioned top-right, floating, 120dp x 160dp)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
                .size(width = 120.dp, height = 160.dp)
                .background(Color(0xFF444444), shape = RoundedCornerShape(8.dp))
                .clip(RoundedCornerShape(8.dp))
                .testTag("local_video_view_container")
        ) {
            if (localSurfaceView != null) {
                AndroidView(
                    factory = { ctx ->
                        android.widget.FrameLayout(ctx).apply {
                            id = android.view.View.generateViewId()
                            (localSurfaceView.parent as? android.view.ViewGroup)?.removeView(localSurfaceView)
                            addView(localSurfaceView)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Camera Off",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal
                    )
                }
            }
        }

        // End Call Button
        Button(
            onClick = onEndCall,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFFF3B30) // Red
            ),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 30.dp)
                .testTag("btnEndCall")
        ) {
            Text(
                text = "End Call",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ChatBubbleItem(msg: SchoolChatMessage) {
    val isAdmin = msg.sender.lowercase() == "admin"
    val alignment = if (isAdmin) Alignment.Start else Alignment.End
    val containerColor = if (isAdmin) {
        MaterialTheme.colorScheme.surfaceVariant
    } else {
        MaterialTheme.colorScheme.primaryContainer
    }
    val contentColor = if (isAdmin) {
        MaterialTheme.colorScheme.onSurfaceVariant
    } else {
        MaterialTheme.colorScheme.onPrimaryContainer
    }
    val shape = if (isAdmin) {
        RoundedCornerShape(
            topStart = 0.dp,
            topEnd = 16.dp,
            bottomStart = 16.dp,
            bottomEnd = 16.dp
        )
    } else {
        RoundedCornerShape(
            topStart = 16.dp,
            topEnd = 0.dp,
            bottomStart = 16.dp,
            bottomEnd = 16.dp
        )
    }

    val timeString = remember(msg.timestamp) {
        msg.timestamp?.toDate()?.let {
            SimpleDateFormat("hh:mm a", Locale.getDefault()).format(it)
        } ?: ""
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        if (isAdmin) {
            Text(
                text = "Administrator (School Master)",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 4.dp, bottom = 2.dp)
            )
        }

        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(shape)
                .background(containerColor)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Column {
                Text(
                    text = msg.displayMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = contentColor
                )
                if (timeString.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = timeString,
                        style = MaterialTheme.typography.labelSmall,
                        color = contentColor.copy(alpha = 0.7f),
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }
    }
}

private fun isEmulator(): Boolean {
    val brand = android.os.Build.BRAND
    val device = android.os.Build.DEVICE
    val model = android.os.Build.MODEL
    val product = android.os.Build.PRODUCT
    val hardware = android.os.Build.HARDWARE
    val fingerprint = android.os.Build.FINGERPRINT
    return brand.startsWith("generic") && device.startsWith("generic")
            || model.contains("google_sdk")
            || model.contains("Emulator")
            || model.contains("Android SDK built for x86")
            || hardware.contains("goldfish")
            || hardware.contains("ranchu")
            || product.contains("sdk")
            || product.contains("google_sdk")
            || product.contains("sdk_x86")
            || product.contains("vbox86p")
            || product.contains("emulator")
            || product.contains("simulator")
            || fingerprint.startsWith("generic")
            || fingerprint.startsWith("unknown")
}

