package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrincipalMasterPinSetupScreen(
    viewModel: MainViewModel,
    selectedLanguage: String = "English",
    onSetupComplete: () -> Unit
) {
    val context = LocalContext.current
    var newMasterPin by remember { mutableStateOf("") }
    var confirmMasterPin by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- Header Icon & Title details from the previous layout ---
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(
                    MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.LockOpen,
                contentDescription = "Lock Icon",
                tint = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(32.dp)
            )
        }

        Text(
            text = when (selectedLanguage) {
                "Sinhala" -> "විදුහල්පති PIN අංකය සකසන්න"
                "Tamil" -> "அதிபர் முதன்மை PIN அமைப்பு"
                else -> "Principal Master PIN Setup"
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Text(
            text = when (selectedLanguage) {
                "Sinhala" -> "ඇප් එකෙහි ආරක්ෂාව සඳහා ප්‍රථමයෙන් ගෝලීය විදුහල්පති PIN අංකය (Principal Master PIN) සකසන්න."
                "Tamil" -> "பயன்பாட்டைப் பாதுகாக்க முதலில் அதிபர் முதன்மை PIN ஐ அமைக்கவும்."
                else -> "To secure the application, please set a global Principal Master PIN first."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // 1. New Master PIN Field
        OutlinedTextField(
            value = newMasterPin,
            onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) newMasterPin = it },
            label = {
                Text(
                    when (selectedLanguage) {
                        "Sinhala" -> "නව ප්‍රධාන PIN අංකය"
                        "Tamil" -> "புதிய முதன்மை PIN"
                        else -> "New Master PIN"
                    }
                )
            },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        )

        // 2. Confirm Master PIN Field
        OutlinedTextField(
            value = confirmMasterPin,
            onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirmMasterPin = it },
            label = {
                Text(
                    when (selectedLanguage) {
                        "Sinhala" -> "PIN අංකය තහවුරු කරන්න"
                        "Tamil" -> "PIN ஐ உறுதிப்படுத்தவும்"
                        else -> "Confirm Master PIN"
                    }
                )
            },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 3. 🛠️ ක්රියාත්මක වන ප්රධාන බටන් එක
        Button(
            onClick = {
                // ආරක්ෂිත වැටවල් (Validations)
                if (newMasterPin.length < 4) {
                    val msg = when (selectedLanguage) {
                        "Sinhala" -> "PIN අංකය අවම වශයෙන් ඉලක්කම් 4ක් විය යුතුය!"
                        "Tamil" -> "PIN குறைந்தது 4 இலக்கங்களாக இருக்க வேண்டும்!"
                        else -> "PIN must be at least 4 digits!"
                    }
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    return@Button
                }
                
                if (newMasterPin != confirmMasterPin) {
                    val msg = when (selectedLanguage) {
                        "Sinhala" -> "PIN අංක ගැලපෙන්නේ නැත!"
                        "Tamil" -> "PIN எண்கள் பொருந்தவில்லை!"
                        else -> "PIN numbers do not match!"
                    }
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    return@Button
                }

                isSaving = true
                // ViewModel එක හරහා Firebase එකට සේව් කිරීම
                viewModel.saveInitialMasterPin(newMasterPin) { success ->
                    isSaving = false
                    if (success) {
                        val msg = when (selectedLanguage) {
                            "Sinhala" -> "ප්‍රධාන PIN එක සාර්ථකව සුරකින ලදී!"
                            "Tamil" -> "முதன்மை PIN வெற்றிகரமாக சேமிக்கப்பட்டது!"
                            else -> "Master PIN Saved Successfully!"
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        onSetupComplete() // 🚀 සේව් වුණාම මේ ස්ක්රීන් එක වහලා දාන function එක
                    } else {
                        val msg = when (selectedLanguage) {
                            "Sinhala" -> "PIN එක සුරැකීමට අපොහොසත් විය. අන්තර්ජාල සම්බන්ධතාවය පරීක්ෂා කරන්න."
                            "Tamil" -> "PIN ஐ சேமிக்க முடியவில்லை. இணைய இணைப்பைச் சரிபார்க்கவும்."
                            else -> "Failed to save PIN. Check internet connection."
                        }
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                }
            },
            enabled = !isSaving, // සේව් වෙන අතරතුර බටන් එක disable වේ
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            if (isSaving) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
            } else {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ප්‍රධාන PIN එක සුරකින්න"
                        "Tamil" -> "முதன்மை PIN ஐ சேமி"
                        else -> "Save Master PIN"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
