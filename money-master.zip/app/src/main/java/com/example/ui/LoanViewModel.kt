package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Loan
import com.example.data.LoanRepository
import com.example.data.Payment
import com.example.data.Customer
import com.example.utils.Language
import com.example.utils.LoanCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardSummary(
    val totalLent: Double,
    val totalInterestEarned: Double,
    val totalOutstanding: Double
)

@OptIn(ExperimentalCoroutinesApi::class)
class LoanViewModel(
    private val repository: LoanRepository,
    private val context: android.content.Context
) : ViewModel() {

    private val sharedPrefs = context.getSharedPreferences("money_master_security", android.content.Context.MODE_PRIVATE)
    private val adPrefs = context.getSharedPreferences("money_master_ads_premium", android.content.Context.MODE_PRIVATE)

    // Ad and Premium States
    private val _isPremiumUser = MutableStateFlow(adPrefs.getBoolean("is_premium_user", false))
    private val _watchedAdsToday = MutableStateFlow(adPrefs.getInt("ad_count", 0))
    private val _lastAdTimestamp = MutableStateFlow(adPrefs.getLong("last_ad_timestamp", 0L))

    init {
        checkDailyAdReset()
    }

    fun getDaysSinceLastStreak(): Int {
        val lastDateStr = adPrefs.getString("last_completed_25_ads_date", "") ?: ""
        if (lastDateStr.isEmpty()) return 9999
        try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            val lastDate = sdf.parse(lastDateStr) ?: return 9999
            val currentDate = sdf.parse(getCurrentDateString()) ?: return 9999
            val diffInMillis = currentDate.time - lastDate.time
            val diffInDays = (diffInMillis / (1000 * 60 * 60 * 24)).toInt()
            return if (diffInDays < 0) 0 else diffInDays
        } catch (e: Exception) {
            return 9999
        }
    }

    val isPremiumUser: StateFlow<Boolean> = _isPremiumUser.asStateFlow()

    val watchedAdsToday: StateFlow<Int> = _watchedAdsToday.asStateFlow()

    fun getLastAdSecondsAgo(): Long {
        val lastTime = _lastAdTimestamp.value
        if (lastTime == 0L) return 9999L
        val diffMs = System.currentTimeMillis() - lastTime
        val seconds = diffMs / 1000
        return if (seconds < 0) 0 else seconds
    }

    val isBlockedFromFreeFeatures: StateFlow<Boolean> = combine(_isPremiumUser, _watchedAdsToday) { isPremium, adsCount ->
        !isPremium && adsCount < 25
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), !adPrefs.getBoolean("is_premium_user", false) && adPrefs.getInt("ad_count", 0) < 25)

    fun buyPremiumPackage(packageName: String, price: Double) {
        _isPremiumUser.value = true
        adPrefs.edit().putBoolean("is_premium_user", true).apply()
    }

    fun setPremiumUser(isPremium: Boolean) {
        _isPremiumUser.value = isPremium
        adPrefs.edit().putBoolean("is_premium_user", isPremium).apply()
    }

    private fun getCurrentDateString(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return sdf.format(java.util.Calendar.getInstance().time)
    }

    fun checkDailyAdReset() {
        val currentDate = getCurrentDateString()
        val savedDate = adPrefs.getString("ad_date", "") ?: ""
        if (savedDate != currentDate) {
            adPrefs.edit().apply {
                putString("ad_date", currentDate)
                putInt("ad_count", 0)
                apply()
            }
            _watchedAdsToday.value = 0
        }
    }

    fun incrementWatchedAds(): Boolean {
        checkDailyAdReset()
        if (_watchedAdsToday.value < 25) {
            val newVal = _watchedAdsToday.value + 1
            _watchedAdsToday.value = newVal
            val currentTimestamp = System.currentTimeMillis()
            _lastAdTimestamp.value = currentTimestamp
            
            adPrefs.edit().apply {
                putInt("ad_count", newVal)
                putLong("last_ad_timestamp", currentTimestamp)
                if (newVal == 25) {
                    putString("last_completed_25_ads_date", getCurrentDateString())
                }
                apply()
            }
            return true
        }
        return false
    }

    fun simulateComplete25Ads() {
        _watchedAdsToday.value = 25
        val currentTimestamp = System.currentTimeMillis()
        _lastAdTimestamp.value = currentTimestamp
        
        adPrefs.edit().apply {
            putInt("ad_count", 25)
            putLong("last_ad_timestamp", currentTimestamp)
            putString("last_completed_25_ads_date", getCurrentDateString())
            apply()
        }
    }

    fun simulateResetAds() {
        _watchedAdsToday.value = 0
        _lastAdTimestamp.value = 0L
        adPrefs.edit().apply {
            putInt("ad_count", 0)
            putLong("last_ad_timestamp", 0L)
            remove("last_completed_25_ads_date")
            apply()
        }
    }

    // PIN security configuration
    private val _savedPin = MutableStateFlow<String?>(sharedPrefs.getString("saved_pin", null))
    val savedPin: StateFlow<String?> = _savedPin.asStateFlow()

    private val _savedQuestion = MutableStateFlow<String?>(sharedPrefs.getString("saved_question", null))
    val savedQuestion: StateFlow<String?> = _savedQuestion.asStateFlow()

    private val _savedAnswer = MutableStateFlow<String?>(sharedPrefs.getString("saved_answer", null))
    val savedAnswer: StateFlow<String?> = _savedAnswer.asStateFlow()

    private val _isAppUnlocked = MutableStateFlow(false)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    fun setAppUnlocked(unlocked: Boolean) {
        _isAppUnlocked.value = unlocked
    }

    fun savePinSecurity(pin: String, question: String, answer: String) {
        sharedPrefs.edit().apply {
            putString("saved_pin", pin)
            putString("saved_question", question)
            putString("saved_answer", answer.trim().lowercase())
            apply()
        }
        _savedPin.value = pin
        _savedQuestion.value = question
        _savedAnswer.value = answer.trim().lowercase()
    }

    fun clearPinSecurity() {
        sharedPrefs.edit().apply {
            remove("saved_pin")
            remove("saved_question")
            remove("saved_answer")
            apply()
        }
        _savedPin.value = null
        _savedQuestion.value = null
        _savedAnswer.value = null
        _isAppUnlocked.value = false
    }

    // Language configuration
    private val _currentLanguage = MutableStateFlow(Language.SINHALA)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    // Owner/Admin profile configuration
    private val _ownerName = MutableStateFlow("ණය දෙන පුද්ගලයා (Owner)")
    val ownerName: StateFlow<String> = _ownerName.asStateFlow()

    private val _ownerPhone = MutableStateFlow("0771234567")
    val ownerPhone: StateFlow<String> = _ownerPhone.asStateFlow()

    private val _ownerPhotoUri = MutableStateFlow("")
    val ownerPhotoUri: StateFlow<String> = _ownerPhotoUri.asStateFlow()

    private val _currentCurrency = MutableStateFlow("LKR (Rs.)")
    val currentCurrency: StateFlow<String> = _currentCurrency.asStateFlow()

    fun updateOwnerDetails(name: String, phone: String, photoUri: String, currency: String) {
        _ownerName.value = name
        _ownerPhone.value = phone
        _ownerPhotoUri.value = photoUri
        _currentCurrency.value = currency
        com.example.utils.LocalizedText.selectedCurrencySymbol = when {
            currency.contains("$") -> "$"
            currency.contains("€") -> "€"
            else -> "Rs."
        }
    }

    fun setLanguage(lang: Language) {
        _currentLanguage.value = lang
    }

    // Selected loan ID for detail view / bottom sheet
    private val _selectedLoanId = MutableStateFlow<Int?>(null)
    val selectedLoanId: StateFlow<Int?> = _selectedLoanId.asStateFlow()

    // Flows from database
    val allLoans: StateFlow<List<Loan>> = repository.allLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeLoans: StateFlow<List<Loan>> = repository.activeLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<Payment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCustomers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected loan flow
    val selectedLoan: StateFlow<Loan?> = _selectedLoanId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getLoanById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Payments for selected loan
    val selectedLoanPayments: StateFlow<List<Payment>> = _selectedLoanId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getPaymentsForLoan(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined dashboard summary
    val dashboardSummary: StateFlow<DashboardSummary> = combine(activeLoans, allPayments) { loans, payments ->
        var totalLent = 0.0
        var totalInterest = 0.0
        var totalOutstanding = 0.0

        totalLent = loans.sumOf { it.principalAmount }
        totalInterest = payments.filter { it.type == "Interest" }.sumOf { it.amount }

        loans.forEach { loan ->
            val loanPayments = payments.filter { it.loanId == loan.id }
            val summary = LoanCalculator.calculateLoanSummary(loan, loanPayments)
            totalOutstanding += summary.totalOutstanding
        }

        DashboardSummary(
            totalLent = totalLent,
            totalInterestEarned = totalInterest,
            totalOutstanding = totalOutstanding
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary(0.0, 0.0, 0.0))

    fun toggleLanguage() {
        _currentLanguage.update {
            if (it == Language.ENGLISH) Language.SINHALA else Language.ENGLISH
        }
    }

    fun selectLoan(id: Int?) {
        _selectedLoanId.value = id
    }

    fun addCustomer(
        name: String,
        address: String,
        phone: String,
        nic: String,
        photoUri: String = "",
        nicPhotoUri: String = ""
    ) {
        viewModelScope.launch {
            val customer = Customer(
                name = name,
                address = address,
                phone = phone,
                nic = nic,
                photoUri = photoUri,
                nicPhotoUri = nicPhotoUri
            )
            repository.insertCustomer(customer)
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    fun addLoan(
        customerId: Int? = null,
        name: String,
        phone: String,
        principal: Double,
        rate: Double,
        period: String,
        notes: String,
        startDate: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            val loan = Loan(
                customerId = customerId,
                borrowerName = name,
                borrowerPhone = phone,
                principalAmount = principal,
                interestRate = rate,
                interestPeriod = period,
                startDate = startDate,
                notes = notes,
                isSettled = false
            )
            repository.insertLoan(loan)
        }
    }

    fun recordPayment(loanId: Int, amount: Double, type: String, notes: String, paymentDate: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            val payment = Payment(
                loanId = loanId,
                amount = amount,
                paymentDate = paymentDate,
                type = type,
                notes = notes
            )
            repository.insertPayment(payment)
            
            // If the payment is a full settle, update the loan to settled
            if (type == "Full Settle") {
                _selectedLoanId.value?.let { id ->
                    repository.getLoanById(id).firstOrNull()?.let { loan ->
                        repository.updateLoan(loan.copy(isSettled = true))
                    }
                }
            }
        }
    }

    fun settleLoan(loanId: Int, notes: String = "") {
        viewModelScope.launch {
            repository.getLoanById(loanId).firstOrNull()?.let { loan ->
                // First calculate the remaining principal if any
                val payments = repository.getPaymentsForLoan(loanId).firstOrNull() ?: emptyList()
                val summary = LoanCalculator.calculateLoanSummary(loan, payments)
                
                // Record a payment of type Full Settle for the outstanding balance
                if (summary.totalOutstanding > 0) {
                    repository.insertPayment(
                        Payment(
                            loanId = loanId,
                            amount = summary.totalOutstanding,
                            paymentDate = System.currentTimeMillis(),
                            type = "Full Settle",
                            notes = notes.ifEmpty { "Manual Full Settlement" }
                        )
                    )
                }
                
                repository.updateLoan(loan.copy(isSettled = true))
            }
        }
    }

    fun deleteLoan(loanId: Int) {
        viewModelScope.launch {
            repository.getLoanById(loanId).firstOrNull()?.let { loan ->
                repository.deleteLoan(loan)
                if (_selectedLoanId.value == loanId) {
                    _selectedLoanId.value = null
                }
            }
        }
    }

    class Factory(
        private val repository: LoanRepository,
        private val context: android.content.Context
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoanViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return LoanViewModel(repository, context.applicationContext) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
