package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CallRecorderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val recordings by viewModel.recordingsList.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val filterType by viewModel.filterType.collectAsStateWithLifecycle()
    val isAutoRecordEnabled by viewModel.isAutoRecordEnabled.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val activeRecordingState by viewModel.activeRecordingState.collectAsStateWithLifecycle()
    val storageStats by viewModel.storageStats.collectAsStateWithLifecycle()
    val audioFormat by viewModel.selectedAudioFormat.collectAsStateWithLifecycle()
    val audioSource by viewModel.selectedAudioSource.collectAsStateWithLifecycle()

    var showSettingsSheet by remember { mutableStateOf(false) }
    var showSimulateCallDialog by remember { mutableStateOf(false) }

    // Check runtime permissions
    var hasMicPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var hasPhoneStatePermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
    }
    var hasContactsPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasMicPermission = results[Manifest.permission.RECORD_AUDIO] ?: hasMicPermission
        hasPhoneStatePermission = results[Manifest.permission.READ_PHONE_STATE] ?: hasPhoneStatePermission
        hasContactsPermission = results[Manifest.permission.READ_CONTACTS] ?: hasContactsPermission
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Auto Call Recorder",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSimulateCallDialog = true },
                        modifier = Modifier.testTag("simulate_call_topbar_button")
                    ) {
                        Icon(Icons.Default.PhoneInTalk, contentDescription = "Simulate Call Test", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("settings_topbar_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showSimulateCallDialog = true },
                icon = { Icon(Icons.Default.PhoneInTalk, contentDescription = null) },
                text = { Text("Simulate Call") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("simulate_call_fab")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Permission Notice Banner if needed
            if (!hasMicPermission || !hasPhoneStatePermission || !hasContactsPermission) {
                item {
                    PermissionNoticeBanner(
                        onRequestPermissions = {
                            val perms = mutableListOf(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.READ_CALL_LOG,
                                Manifest.permission.READ_CONTACTS
                            )
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                perms.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permissionLauncher.launch(perms.toTypedArray())
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Auto-Record Status Banner
            item {
                AutoRecordHeroBanner(
                    isAutoRecordEnabled = isAutoRecordEnabled,
                    isCallActive = activeRecordingState.isRecording,
                    activePhoneNumber = activeRecordingState.phoneNumber,
                    onToggle = { viewModel.toggleAutoRecord(it) }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Quick Stats Summary Row
            item {
                StorageStatsRow(stats = storageStats)
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Search Text Field
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search by contact name, phone or notes...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_recordings_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Filter Chips Bar
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = filterType == FilterType.ALL,
                            onClick = { viewModel.setFilterType(FilterType.ALL) },
                            label = { Text("All (${storageStats.totalCount})") },
                            modifier = Modifier.testTag("filter_all_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterType == FilterType.INCOMING,
                            onClick = { viewModel.setFilterType(FilterType.INCOMING) },
                            label = { Text("Incoming") },
                            modifier = Modifier.testTag("filter_incoming_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterType == FilterType.OUTGOING,
                            onClick = { viewModel.setFilterType(FilterType.OUTGOING) },
                            label = { Text("Outgoing") },
                            modifier = Modifier.testTag("filter_outgoing_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterType == FilterType.FAVORITES,
                            onClick = { viewModel.setFilterType(FilterType.FAVORITES) },
                            label = { Text("Favorites") },
                            modifier = Modifier.testTag("filter_favorites_chip")
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Section Header
            item {
                Text(
                    text = when (filterType) {
                        FilterType.ALL -> "Recorded Calls"
                        FilterType.INCOMING -> "Incoming Calls"
                        FilterType.OUTGOING -> "Outgoing Calls"
                        FilterType.FAVORITES -> "Starred Call Recordings"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Empty State
            if (recordings.isEmpty()) {
                item {
                    EmptyRecordingsPlaceholder(
                        isSearching = searchQuery.isNotEmpty(),
                        onSimulateCall = { showSimulateCallDialog = true }
                    )
                }
            } else {
                items(recordings, key = { it.id }) { record ->
                    RecordingCard(
                        record = record,
                        playbackState = playbackState,
                        onPlayClick = { viewModel.playRecording(record.filePath) },
                        onPauseClick = { viewModel.pausePlayback() },
                        onSeek = { position -> viewModel.seekPlayback(position) },
                        onSpeedChange = { speed -> viewModel.setPlaybackSpeed(speed) },
                        onToggleFavorite = { viewModel.toggleFavorite(record) },
                        onUpdateNotes = { notes -> viewModel.updateNotes(record.id, notes) },
                        onDeleteClick = { viewModel.deleteRecording(record) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp)) // Extra padding for FAB
            }
        }
    }

    // Dialogs & Sheets
    if (showSettingsSheet) {
        SettingsSheet(
            isAutoRecordEnabled = isAutoRecordEnabled,
            selectedAudioFormat = audioFormat,
            selectedAudioSource = audioSource,
            onToggleAutoRecord = { viewModel.toggleAutoRecord(it) },
            onAudioFormatSelected = { viewModel.setAudioFormat(it) },
            onAudioSourceSelected = { viewModel.setAudioSource(it) },
            onDismiss = { showSettingsSheet = false }
        )
    }

    if (showSimulateCallDialog || activeRecordingState.isRecording) {
        SimulateCallDialog(
            activeState = activeRecordingState,
            onStartCall = { number, name, type ->
                viewModel.startSimulatedCall(number, name, type)
            },
            onEndCall = { viewModel.stopSimulatedCall() },
            onDismiss = { showSimulateCallDialog = false }
        )
    }
}

@Composable
fun AutoRecordHeroBanner(
    isAutoRecordEnabled: Boolean,
    isCallActive: Boolean,
    activePhoneNumber: String,
    onToggle: (Boolean) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_banner")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCallActive) {
                Color(0xFFD32F2F)
            } else if (isAutoRecordEnabled) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(18.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCallActive) Color.White.copy(alpha = 0.25f)
                        else if (isAutoRecordEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCallActive) Color.White.copy(alpha = pulseAlpha)
                            else if (isAutoRecordEnabled) Color(0xFF2E7D32)
                            else Color.Gray
                        )
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isCallActive) "Recording Active Call..." else if (isAutoRecordEnabled) "Auto Recording Active" else "Auto Recording Paused",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isCallActive) Color.White else if (isAutoRecordEnabled) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (isCallActive) activePhoneNumber else if (isAutoRecordEnabled) "All incoming and outgoing calls recorded automatically" else "Tap toggle to enable background call recording",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isCallActive) Color.White.copy(alpha = 0.8f) else if (isAutoRecordEnabled) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.outline
                )
            }

            if (!isCallActive) {
                Switch(
                    checked = isAutoRecordEnabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("hero_auto_record_switch")
                )
            }
        }
    }
}

@Composable
fun StorageStatsRow(stats: StorageStats) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        StatCard(
            title = "Calls Today",
            value = "${stats.countToday}",
            modifier = Modifier.weight(1f)
        )

        val totalMins = stats.totalDurationSeconds / 60
        StatCard(
            title = "Total Time",
            value = "${totalMins}m",
            modifier = Modifier.weight(1f)
        )

        val sizeMb = String.format(Locale.getDefault(), "%.1f MB", stats.totalSizeBytes / (1024.0 * 1024.0))
        StatCard(
            title = "Storage Used",
            value = sizeMb,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun PermissionNoticeBanner(onRequestPermissions: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(
                Icons.Default.Shield,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Permissions Required",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Text(
                    text = "Microphone and phone state access are required to record phone calls automatically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = onRequestPermissions,
                modifier = Modifier.testTag("grant_permissions_button")
            ) {
                Text("Grant")
            }
        }
    }
}

@Composable
fun EmptyRecordingsPlaceholder(
    isSearching: Boolean,
    onSimulateCall: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp, horizontal = 24.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Mic,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (isSearching) "No recordings match your search" else "No Call Recordings Yet",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (isSearching) "Try searching with a different contact name or phone number" else "Incoming and outgoing calls will appear here automatically, or click below to simulate a test call.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        OutlinedButton(
            onClick = onSimulateCall,
            modifier = Modifier.testTag("empty_state_simulate_button")
        ) {
            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Test Call Simulation")
        }
    }
}
