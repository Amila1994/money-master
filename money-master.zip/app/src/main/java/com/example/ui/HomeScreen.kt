package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.LinearEasing
import com.example.ActiveRecordingState
import com.example.RecordService
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CallRecorderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val recordings by viewModel.recordingsList.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val filterType by viewModel.filterType.collectAsStateWithLifecycle()
    val isAutoRecordEnabled by viewModel.isAutoRecordEnabled.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val activeRecordingState by viewModel.activeRecordingState.collectAsStateWithLifecycle()
    val storageStats by viewModel.storageStats.collectAsStateWithLifecycle()
    val audioFormat by viewModel.selectedAudioFormat.collectAsStateWithLifecycle()
    val audioSource by viewModel.selectedAudioSource.collectAsStateWithLifecycle()

    var showSettingsSheet by remember { mutableStateOf(false) }

    // Check runtime permissions
    var hasMicPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var hasPhoneStatePermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED)
    }
    var hasContactsPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasMicPermission = results[Manifest.permission.RECORD_AUDIO] ?: hasMicPermission
        hasPhoneStatePermission = results[Manifest.permission.READ_PHONE_STATE] ?: hasPhoneStatePermission
        hasContactsPermission = results[Manifest.permission.READ_CONTACTS] ?: hasContactsPermission
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Auto Call Recorder",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier.testTag("settings_topbar_button")
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Permission Notice Banner if needed
            if (!hasMicPermission || !hasPhoneStatePermission || !hasContactsPermission) {
                item {
                    PermissionNoticeBanner(
                        onRequestPermissions = {
                            val perms = mutableListOf(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.READ_PHONE_STATE,
                                Manifest.permission.READ_CALL_LOG,
                                Manifest.permission.READ_CONTACTS,
                                Manifest.permission.PROCESS_OUTGOING_CALLS
                            )
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                perms.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            permissionLauncher.launch(perms.toTypedArray())
                        }
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Live Active Recording Badge & Ticking Timer
            if (activeRecordingState.isRecording) {
                item {
                    RecordingInProgressCard(
                        activeState = activeRecordingState,
                        onStopRecording = { RecordService.stopRecording(context) }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Auto-Record Status Banner
            item {
                AutoRecordHeroBanner(
                    isAutoRecordEnabled = isAutoRecordEnabled,
                    isCallActive = activeRecordingState.isRecording,
                    activePhoneNumber = activeRecordingState.phoneNumber,
                    onToggle = { viewModel.toggleAutoRecord(it) }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Audio Tip for Android 10+
            item {
                SpeakerphoneTipBanner()
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Quick Stats Summary Row
            item {
                StorageStatsRow(stats = storageStats)
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Search Text Field
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search by contact name, phone or notes...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_recordings_input")
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Filter Chips Bar
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = filterType == FilterType.ALL,
                            onClick = { viewModel.setFilterType(FilterType.ALL) },
                            label = { Text("All (${storageStats.totalCount})") },
                            modifier = Modifier.testTag("filter_all_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterType == FilterType.INCOMING,
                            onClick = { viewModel.setFilterType(FilterType.INCOMING) },
                            label = { Text("Incoming") },
                            modifier = Modifier.testTag("filter_incoming_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterType == FilterType.OUTGOING,
                            onClick = { viewModel.setFilterType(FilterType.OUTGOING) },
                            label = { Text("Outgoing") },
                            modifier = Modifier.testTag("filter_outgoing_chip")
                        )
                    }
                    item {
                        FilterChip(
                            selected = filterType == FilterType.FAVORITES,
                            onClick = { viewModel.setFilterType(FilterType.FAVORITES) },
                            label = { Text("Favorites") },
                            modifier = Modifier.testTag("filter_favorites_chip")
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Section Header
            item {
                Text(
                    text = when (filterType) {
                        FilterType.ALL -> "Recorded Calls"
                        FilterType.INCOMING -> "Incoming Calls"
                        FilterType.OUTGOING -> "Outgoing Calls"
                        FilterType.FAVORITES -> "Starred Call Recordings"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            // Empty State
            if (recordings.isEmpty()) {
                item {
                    EmptyRecordingsPlaceholder(
                        isSearching = searchQuery.isNotEmpty()
                    )
                }
            } else {
                items(recordings, key = { it.id }) { record ->
                    RecordingCard(
                        record = record,
                        playbackState = playbackState,
                        onPlayClick = { viewModel.playRecording(record.filePath) },
                        onPauseClick = { viewModel.pausePlayback() },
                        onSeek = { position -> viewModel.seekPlayback(position) },
                        onSpeedChange = { speed -> viewModel.setPlaybackSpeed(speed) },
                        onToggleFavorite = { viewModel.toggleFavorite(record) },
                        onUpdateNotes = { notes -> viewModel.updateNotes(record.id, notes) },
                        onDeleteClick = { viewModel.deleteRecording(record) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Dialogs & Sheets
    if (showSettingsSheet) {
        SettingsSheet(
            isAutoRecordEnabled = isAutoRecordEnabled,
            selectedAudioFormat = audioFormat,
            selectedAudioSource = audioSource,
            onToggleAutoRecord = { viewModel.toggleAutoRecord(it) },
            onAudioFormatSelected = { viewModel.setAudioFormat(it) },
            onAudioSourceSelected = { viewModel.setAudioSource(it) },
            onDismiss = { showSettingsSheet = false }
        )
    }
}

@Composable
fun AutoRecordHeroBanner(
    isAutoRecordEnabled: Boolean,
    isCallActive: Boolean,
    activePhoneNumber: String,
    onToggle: (Boolean) -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_banner")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCallActive) {
                Color(0xFFD32F2F)
            } else if (isAutoRecordEnabled) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(18.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(
                        if (isCallActive) Color.White.copy(alpha = 0.25f)
                        else if (isAutoRecordEnabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(
                            if (isCallActive) Color.White.copy(alpha = pulseAlpha)
                            else if (isAutoRecordEnabled) Color(0xFF2E7D32)
                            else Color.Gray
                        )
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isCallActive) "Recording Active Call..." else if (isAutoRecordEnabled) "Auto Recording Active" else "Auto Recording Paused",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isCallActive) Color.White else if (isAutoRecordEnabled) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (isCallActive) activePhoneNumber else if (isAutoRecordEnabled) "All incoming and outgoing calls recorded automatically" else "Tap toggle to enable background call recording",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isCallActive) Color.White.copy(alpha = 0.8f) else if (isAutoRecordEnabled) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.outline
                )
            }

            if (!isCallActive) {
                Switch(
                    checked = isAutoRecordEnabled,
                    onCheckedChange = onToggle,
                    modifier = Modifier.testTag("hero_auto_record_switch")
                )
            }
        }
    }
}

@Composable
fun StorageStatsRow(stats: StorageStats) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        StatCard(
            title = "Calls Today",
            value = "${stats.countToday}",
            modifier = Modifier.weight(1f)
        )

        val totalMins = stats.totalDurationSeconds / 60
        StatCard(
            title = "Total Time",
            value = "${totalMins}m",
            modifier = Modifier.weight(1f)
        )

        val sizeMb = String.format(Locale.getDefault(), "%.1f MB", stats.totalSizeBytes / (1024.0 * 1024.0))
        StatCard(
            title = "Storage Used",
            value = sizeMb,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        modifier = modifier
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun PermissionNoticeBanner(onRequestPermissions: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(
                Icons.Default.Shield,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Permissions Required",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Text(
                    text = "Microphone and phone state access are required to record phone calls automatically.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = onRequestPermissions,
                modifier = Modifier.testTag("grant_permissions_button")
            ) {
                Text("Grant")
            }
        }
    }
}

@Composable
fun EmptyRecordingsPlaceholder(
    isSearching: Boolean
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp, horizontal = 24.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Mic,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (isSearching) "No recordings match your search" else "No Call Recordings Yet",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (isSearching) "Try searching with a different contact name or phone number" else "Incoming and outgoing calls will appear here automatically when recorded.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun RecordingInProgressCard(
    activeState: ActiveRecordingState,
    onStopRecording: () -> Unit,
    modifier: Modifier = Modifier
) {
    var elapsedSeconds by remember(activeState.isRecording, activeState.startTimeMillis) {
        mutableLongStateOf(0L)
    }

    LaunchedEffect(activeState.isRecording, activeState.startTimeMillis) {
        if (activeState.isRecording) {
            while (isActive) {
                val millis = (System.currentTimeMillis() - activeState.startTimeMillis).coerceAtLeast(0)
                elapsedSeconds = millis / 1000
                delay(1000L)
            }
        }
    }

    val minutes = elapsedSeconds / 60
    val seconds = elapsedSeconds % 60
    val timerText = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)

    val infiniteTransition = rememberInfiniteTransition(label = "rec_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFD32F2F)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("recording_in_progress_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = pulseAlpha))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RECORDING IN PROGRESS",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = 1.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.35f)
                ) {
                    Text(
                        text = timerText,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val displayName = activeState.contactName.ifBlank { activeState.phoneNumber }
            Text(
                text = displayName,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            if (activeState.contactName.isNotBlank() && activeState.phoneNumber.isNotBlank()) {
                Text(
                    text = activeState.phoneNumber,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "${activeState.callType.name.lowercase().replaceFirstChar { it.uppercase() }} Call Recording",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f)
                )

                Button(
                    onClick = onStopRecording,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFFD32F2F)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("stop_live_recording_button")
                ) {
                    Icon(
                        Icons.Default.Stop,
                        contentDescription = "Stop",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Stop Recording", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun SpeakerphoneTipBanner(
    modifier: Modifier = Modifier
) {
    var isDismissed by remember { mutableStateOf(false) }
    if (isDismissed) return

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
            contentColor = MaterialTheme.colorScheme.onTertiaryContainer
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("speakerphone_tip_card")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.VolumeUp,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Speakerphone Recommended",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "On Android 10+, enable Speakerphone during calls so the microphone captures both caller and recipient voices clearly due to Android OS security restrictions.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.85f)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = { isDismissed = true },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "Dismiss Tip",
                    tint = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
