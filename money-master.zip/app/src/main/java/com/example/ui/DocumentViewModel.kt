package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Document
import com.example.data.DocumentRepository
import com.example.data.GeminiHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ActiveScreen {
    LOCK, DASHBOARD, SCAN, CROP_ENHANCE, DETAIL
}

class DocumentViewModel(private val repository: DocumentRepository) : ViewModel() {

    private val _isLocked = MutableStateFlow(true)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _activeScreen = MutableStateFlow(ActiveScreen.LOCK)
    val activeScreen: StateFlow<ActiveScreen> = _activeScreen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    // Raw list of documents from database
    val rawDocuments: StateFlow<List<Document>> = repository.allDocuments
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered documents list for searching and category selection
    val filteredDocuments: StateFlow<List<Document>> = combine(
        rawDocuments,
        _searchQuery,
        _selectedCategory
    ) { docs, query, category ->
        docs.filter { doc ->
            val matchesQuery = doc.title.contains(query, ignoreCase = true) || 
                               doc.notes.contains(query, ignoreCase = true) ||
                               doc.textContent.contains(query, ignoreCase = true)
            val matchesCategory = category == "All" || doc.category.equals(category, ignoreCase = true)
            matchesQuery && matchesCategory
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _selectedDocument = MutableStateFlow<Document?>(null)
    val selectedDocument: StateFlow<Document?> = _selectedDocument.asStateFlow()

    // Temporary state for the document scanning flow
    private val _scannedTitle = MutableStateFlow("")
    val scannedTitle: StateFlow<String> = _scannedTitle.asStateFlow()

    private val _scannedNotes = MutableStateFlow("")
    val scannedNotes: StateFlow<String> = _scannedNotes.asStateFlow()

    private val _scannedCategory = MutableStateFlow("Receipt")
    val scannedCategory: StateFlow<String> = _scannedCategory.asStateFlow()

    private val _scannedFilter = MutableStateFlow("Magic Color")
    val scannedFilter: StateFlow<String> = _scannedFilter.asStateFlow()

    private val _scannedBitmap = MutableStateFlow<android.graphics.Bitmap?>(null)
    val scannedBitmap: StateFlow<android.graphics.Bitmap?> = _scannedBitmap.asStateFlow()

    private val _showAdvancedPreview = MutableStateFlow(false)
    val showAdvancedPreview: StateFlow<Boolean> = _showAdvancedPreview.asStateFlow()

    fun loadBitmapIntoWorkspace(bitmap: android.graphics.Bitmap) {
        _scannedBitmap.value = bitmap
        _showAdvancedPreview.value = true
    }

    fun setShowAdvancedPreview(show: Boolean) {
        _showAdvancedPreview.value = show
    }

    fun updateScannedBitmap(bitmap: android.graphics.Bitmap?) {
        _scannedBitmap.value = bitmap
    }

    private val _isOcrLoading = MutableStateFlow(false)
    val isOcrLoading: StateFlow<Boolean> = _isOcrLoading.asStateFlow()

    private val _isUnlockError = MutableStateFlow(false)
    val isUnlockError: StateFlow<Boolean> = _isUnlockError.asStateFlow()

    private val _savedPassword = MutableStateFlow("S/680746")
    val savedPassword: StateFlow<String> = _savedPassword.asStateFlow()

    private val _showOwnerIntroDialog = MutableStateFlow(false)
    val showOwnerIntroDialog: StateFlow<Boolean> = _showOwnerIntroDialog.asStateFlow()

    fun dismissOwnerIntroDialog() {
        _showOwnerIntroDialog.value = false
    }

    init {
        viewModelScope.launch {
            // Check if we have a saved password in database.
            val password = repository.getSetting("vault_password")
            if (password == null) {
                // Initialize default password
                repository.saveSetting("vault_password", "S/680746")
                _savedPassword.value = "S/680746"
            } else {
                _savedPassword.value = password
            }
        }
    }

    fun setScannedTitle(title: String) { _scannedTitle.value = title }
    fun setScannedNotes(notes: String) { _scannedNotes.value = notes }
    fun setScannedCategory(category: String) { _scannedCategory.value = category }
    fun setScannedFilter(filter: String) { _scannedFilter.value = filter }
    fun setSearchQuery(query: String) { _searchQuery.value = query }
    fun setSelectedCategory(category: String) { _selectedCategory.value = category }

    fun selectDocument(document: Document?) {
        _selectedDocument.value = document
        if (document != null) {
            _activeScreen.value = ActiveScreen.DETAIL
        }
    }

    fun navigateTo(screen: ActiveScreen) {
        if (screen == ActiveScreen.LOCK) {
            _isLocked.value = true
        }
        _activeScreen.value = screen
    }

    fun unlock(passwordInput: String) {
        viewModelScope.launch {
            if (passwordInput == _savedPassword.value) {
                _isLocked.value = false
                _isUnlockError.value = false
                _showOwnerIntroDialog.value = true
                _activeScreen.value = ActiveScreen.DASHBOARD
            } else {
                _isUnlockError.value = true
                delay(1500)
                _isUnlockError.value = false
            }
        }
    }

    fun lockVault() {
        _isLocked.value = true
        _activeScreen.value = ActiveScreen.LOCK
    }

    fun updatePassword(newPass: String) {
        viewModelScope.launch {
            repository.saveSetting("vault_password", newPass)
            _savedPassword.value = newPass
        }
    }

    fun saveScannedDocument(context: android.content.Context, useAiOcr: Boolean, onSaved: ((Document) -> Unit)? = null) {
        viewModelScope.launch {
            _isOcrLoading.value = true
            val title = _scannedTitle.value.ifEmpty { "Scan " + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date()) }
            val category = _scannedCategory.value
            val notes = _scannedNotes.value
            val filter = _scannedFilter.value

            var savedImageFileName = ""
            _scannedBitmap.value?.let { bitmap ->
                try {
                    val fileName = "scan_${System.currentTimeMillis()}.png"
                    val file = java.io.File(context.filesDir, fileName)
                    val fos = java.io.FileOutputStream(file)
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fos)
                    fos.close()
                    savedImageFileName = fileName
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            val extractedText = if (useAiOcr) {
                GeminiHelper.generateOcrText(title, category, notes)
            } else {
                // Simple offline formatted text extraction simulation
                "--- LOCAL OCR ENGINE ACTIVE ---\n\n" +
                        "TITLE: $title\n" +
                        "CATEGORY: $category\n" +
                        "DATE: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}\n" +
                        "--------------------------------\n" +
                        "NOTES & DETAIL TRANSCRIPT:\n" +
                        notes.ifEmpty { "[No readable text found on paper]" } +
                        "\n--------------------------------\n" +
                        "Scan processed offline. Use Gemini AI OCR option for full automated digitization."
            }

            val doc = Document(
                title = title,
                category = category,
                notes = notes,
                textContent = extractedText,
                filterApplied = filter,
                imageResName = savedImageFileName
            )

            repository.insertDocument(doc)
            _isOcrLoading.value = false
            
            // Reset scan state
            _scannedTitle.value = ""
            _scannedNotes.value = ""
            _scannedCategory.value = "Receipt"
            _scannedFilter.value = "Magic Color"
            _scannedBitmap.value = null
            _showAdvancedPreview.value = false
            
            _activeScreen.value = ActiveScreen.DASHBOARD

            onSaved?.invoke(doc)
        }
    }

    fun deleteDocument(id: Int) {
        viewModelScope.launch {
            repository.deleteDocumentById(id)
            if (_selectedDocument.value?.id == id) {
                _selectedDocument.value = null
            }
            _activeScreen.value = ActiveScreen.DASHBOARD
        }
    }

    class Factory(private val repository: DocumentRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DocumentViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return DocumentViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
