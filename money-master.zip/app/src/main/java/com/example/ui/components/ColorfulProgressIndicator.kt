package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun ColorfulProgressIndicator(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    strokeWidth: Dp = 4.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "colorful_loader")
    
    // Smooth infinite rotation
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation_angle"
    )

    val gradientColors = listOf(
        Color(0xFF1E3A8A), // Premium Deep Blue
        Color(0xFF10B981), // Accent Emerald
        Color(0xFFF59E0B), // Accent Amber
        Color(0xFFEF4444), // Accent Crimson
        Color(0xFF3B82F6), // Light Blue
        Color(0xFF1E3A8A)  // Premium Deep Blue
    )

    Canvas(
        modifier = modifier
            .size(size)
            .graphicsLayer { rotationZ = angle }
    ) {
        val sweepGradient = Brush.sweepGradient(
            colors = gradientColors
        )
        
        drawArc(
            brush = sweepGradient,
            startAngle = 0f,
            sweepAngle = 280f,
            useCenter = false,
            style = Stroke(
                width = strokeWidth.toPx(),
                cap = StrokeCap.Round
            ),
            size = Size(width = this.size.width, height = this.size.height)
        )
    }
}
