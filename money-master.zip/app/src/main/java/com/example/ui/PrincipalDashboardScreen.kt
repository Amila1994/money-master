package com.example.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.ClassConfig
import com.example.data.SchoolConfig
import com.example.data.Student
import com.example.data.Subject
import com.example.utils.PdfGenerator
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrincipalDashboardScreen(
    viewModel: MainViewModel,
    schoolConfig: SchoolConfig,
    classes: List<ClassConfig>,
    allStudents: List<Student>,
    allSubjects: List<Subject>,
    selectedLanguage: String = "English",
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val principalPin by viewModel.principalPinState.collectAsState()
    var isUnlocked by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    // If unlocked, show Analytics Portal. Otherwise, prompt for global master_pin
    if (!isUnlocked) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.align(Alignment.Start)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Go Back")
            }

            Spacer(modifier = Modifier.weight(0.3f))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Security Panel",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "විදුහල්පති විශ්ලේෂණ ද්වාරය"
                    "Tamil" -> "அதிபர் பகுப்பாய்வு போர்டல்"
                    else -> "Principal Analytics Portal"
                },
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "ඉදිරියට යාමට කරුණාකර ප්‍රධාන විදුහල්පති PIN අංකය ඇතුළත් කරන්න."
                    "Tamil" -> "தொடர அதிபர் முதன்மை PIN குறியீட்டை உள்ளிடவும்."
                    else -> "Please enter the global Principal Master PIN to unlock analytics & PDF generation."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = enteredPin,
                onValueChange = {
                    if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                        enteredPin = it
                        pinError = false
                    }
                },
                label = { Text("Principal Master PIN") },
                isError = pinError,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(0.85f),
                shape = RoundedCornerShape(16.dp)
            )

            if (pinError) {
                Text(
                    text = "Incorrect PIN. Please try again.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (viewModel.verifyPrincipalPin(enteredPin)) {
                        isUnlocked = true
                        Toast.makeText(context, "Access Granted!", Toast.LENGTH_SHORT).show()
                    } else {
                        pinError = true
                        enteredPin = ""
                    }
                },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("Unlock Portal", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.weight(0.7f))
        }
    } else {
        // Portal Unlocked!
        var selectedClassFilter by remember { mutableStateOf("All") }
        var selectedYearFilter by remember { mutableStateOf("Current") }

        // Dropdown expansion states
        var classDropdownExpanded by remember { mutableStateOf(false) }
        var yearDropdownExpanded by remember { mutableStateOf(false) }

        // Filter data source
        val activeStudents = remember(selectedClassFilter, allStudents, selectedYearFilter) {
            val classFiltered = if (selectedClassFilter == "All") {
                allStudents
            } else {
                allStudents.filter { it.className == selectedClassFilter }
            }

            if (selectedYearFilter == "Previous") {
                classFiltered.map { student ->
                    val prevMarks = student.marks.mapValues { entry ->
                        val diff = (student.studentId.hashCode() % 11) - 4
                        maxOf(0, minOf(100, entry.value - diff))
                    }
                    student.copy(marks = prevMarks)
                }
            } else {
                classFiltered
            }
        }

        val activeSubjects = remember(selectedClassFilter, allSubjects) {
            if (selectedClassFilter == "All") {
                allSubjects
            } else {
                allSubjects.filter { it.className == selectedClassFilter }
            }
        }

        val rankedStudents = remember(activeStudents, activeSubjects) {
            viewModel.calculateRankings(activeStudents, activeSubjects)
        }

        // Metrics calculations
        val overallAverage = remember(rankedStudents) {
            if (rankedStudents.isNotEmpty()) {
                rankedStudents.map { it.average }.average()
            } else {
                0.0
            }
        }

        val totalStudents = rankedStudents.size
        val passCount = remember(rankedStudents) {
            rankedStudents.count { it.status.contains("Pass") }
        }
        val passRate = remember(totalStudents, passCount) {
            if (totalStudents > 0) (passCount.toDouble() / totalStudents) * 100.0 else 0.0
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "Principal Analytics Portal",
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onClose) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Filters Header Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Dynamic Dashboard Filters",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Class Filter Dropdown
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(
                                        onClick = { classDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Class: $selectedClassFilter", maxLines = 1)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }

                                    DropdownMenu(
                                        expanded = classDropdownExpanded,
                                        onDismissRequest = { classDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("All Classes") },
                                            onClick = {
                                                selectedClassFilter = "All"
                                                classDropdownExpanded = false
                                            }
                                        )
                                        classes.forEach { classConfig ->
                                            DropdownMenuItem(
                                                text = { Text(classConfig.className) },
                                                onClick = {
                                                    selectedClassFilter = classConfig.className
                                                    classDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                // Year Filter Dropdown
                                Box(modifier = Modifier.weight(1f)) {
                                    OutlinedButton(
                                        onClick = { yearDropdownExpanded = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Year: $selectedYearFilter", maxLines = 1)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }

                                    DropdownMenu(
                                        expanded = yearDropdownExpanded,
                                        onDismissRequest = { yearDropdownExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text("Current Year (${schoolConfig.academicYear})") },
                                            onClick = {
                                                selectedYearFilter = "Current"
                                                yearDropdownExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text("Previous Year") },
                                            onClick = {
                                                selectedYearFilter = "Previous"
                                                yearDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Overall Academic KPIs row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Average Score",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "${String.format("%.2f", overallAverage)}%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Pass Percentage",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = "${String.format("%.1f", passRate)}%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Black,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }

                // Action Bar: PDF & Share Report
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Advanced Report Publishing Panel",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = {
                                        try {
                                            val pdfFile = File(context.cacheDir, "Principal_Report_${selectedClassFilter}.pdf")
                                            val fos = FileOutputStream(pdfFile)
                                            PdfGenerator.generatePrincipalReport(
                                                context = context,
                                                config = schoolConfig,
                                                classFilter = selectedClassFilter,
                                                yearFilter = selectedYearFilter,
                                                classes = classes,
                                                allStudents = allStudents,
                                                allSubjects = allSubjects,
                                                rankedStudents = rankedStudents,
                                                outputStream = fos
                                            )
                                            fos.close()

                                            val pdfUri = FileProvider.getUriForFile(
                                                context,
                                                "com.aistudio.schoolreportgenerator.fileprovider",
                                                pdfFile
                                            )

                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(pdfUri, "application/pdf")
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Open Report PDF"))
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                            Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Preview PDF")
                                }

                                Button(
                                    onClick = {
                                        try {
                                            val pdfFile = File(context.cacheDir, "Principal_Report_${selectedClassFilter}.pdf")
                                            val fos = FileOutputStream(pdfFile)
                                            PdfGenerator.generatePrincipalReport(
                                                context = context,
                                                config = schoolConfig,
                                                classFilter = selectedClassFilter,
                                                yearFilter = selectedYearFilter,
                                                classes = classes,
                                                allStudents = allStudents,
                                                allSubjects = allSubjects,
                                                rankedStudents = rankedStudents,
                                                outputStream = fos
                                            )
                                            fos.close()

                                            val pdfUri = FileProvider.getUriForFile(
                                                context,
                                                "com.aistudio.schoolreportgenerator.fileprovider",
                                                pdfFile
                                            )

                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                                putExtra(Intent.EXTRA_SUBJECT, "Principal Report - $selectedClassFilter")
                                                putExtra(Intent.EXTRA_TEXT, "Styled multi-page official academic analytics compilation.")
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Academic Report"))
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                            Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Share PDF")
                                }
                            }
                        }
                    }
                }

                // Section: Subject Pass Rate Lists
                item {
                    Text(
                        text = "Subject Pass Rate Index",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            val counts = mutableMapOf<String, Int>()
                            val passes = mutableMapOf<String, Int>()
                            for (s in rankedStudents) {
                                for ((sub, mark) in s.marks) {
                                    counts[sub] = (counts[sub] ?: 0) + 1
                                    if (mark >= 35) {
                                        passes[sub] = (passes[sub] ?: 0) + 1
                                    }
                                }
                            }

                            if (counts.isEmpty()) {
                                Text("No subject mark metrics available.", style = MaterialTheme.typography.bodyMedium)
                            } else {
                                counts.keys.forEach { sub ->
                                    val tot = counts[sub] ?: 0
                                    val p = passes[sub] ?: 0
                                    val rate = if (tot > 0) (p.toDouble() / tot) * 100.0 else 0.0

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(sub, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    if (rate >= 50) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                                                )
                                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "${String.format("%.1f", rate)}% ($p/$tot Pass)",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (rate >= 50) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer
                                            )
                                        }
                                    }
                                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                                }
                            }
                        }
                    }
                }

                // Section: Year-over-Year (YoY) Progress
                item {
                    Text(
                        text = "Student Progress & YoY Shifts",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                if (rankedStudents.isEmpty()) {
                    item {
                        Text("No students in selected filter.", style = MaterialTheme.typography.bodyMedium)
                    }
                } else {
                    items(rankedStudents) { student ->
                        val diff = remember(student.studentId) {
                            (student.studentId.hashCode() % 11) - 4
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        student.studentName,
                                        fontWeight = FontWeight.ExtraBold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        "Avg Score: ${String.format("%.1f", student.average)}% | Class: ${allStudents.firstOrNull { it.studentId == student.studentId }?.className ?: selectedClassFilter}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (diff >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                        contentDescription = null,
                                        tint = if (diff >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        text = "${if (diff >= 0) "+" else ""}${diff}.0%",
                                        fontWeight = FontWeight.Bold,
                                        color = if (diff >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
