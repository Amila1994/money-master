package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherLoginScreen(onLoginSuccess: () -> Unit) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF231F20)) // Dark Theme පසුබිම
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // 🏫 App Header
        Text(
            text = "🏫 School Report & Ranking Portal",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE5A93C), // රන්වන් පැහැය
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        Text(
            text = "Advanced Management System that simplifies teachers' tasks",
            fontSize = 13.sp,
            color = Color.LightGray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // ⛔ [අයින් කරන ලදී] Teacher සහ Register Tabs තිබූ සම්පූර්ණ Row එකම මෙතැනින් ඉවත් කර ඇත.

        // 📧 Email Input Field
        val emailFontSize = when {
            email.length > 30 -> 11.sp
            email.length > 20 -> 13.sp
            else -> 16.sp
        }
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address", color = Color.Gray) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedLabelColor = Color.Gray,
                unfocusedLabelColor = Color.Gray
            ),
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = emailFontSize),
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            shape = RoundedCornerShape(8.dp)
        )

        // 🔒 Password Input Field
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password", color = Color.Gray) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedLabelColor = Color.Gray,
                unfocusedLabelColor = Color.Gray
            ),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
            shape = RoundedCornerShape(8.dp)
        )

        // 🚀 Sign In Button
        Button(
            onClick = {
                if (email.isNotEmpty() && password.isNotEmpty()) {
                    isLoading = true
                    try {
                        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener { task ->
                                isLoading = false
                                if (task.isSuccessful) {
                                    Toast.makeText(context, "සාර්ථකව ලොග් වුණා!", Toast.LENGTH_SHORT).show()
                                    onLoginSuccess()
                                } else {
                                    Toast.makeText(context, "ලොග් වීම අසාර්ථකයි: වැරදි විස්තර හෝ ගිණුම සක්රීය නැත!", Toast.LENGTH_LONG).show()
                                }
                            }
                    } catch (e: Exception) {
                        isLoading = false
                        Toast.makeText(context, "Firebase Initialization Error. Falling back to local check...", Toast.LENGTH_LONG).show()
                        if (email == "teacher@school.com" && password == "password123") {
                            Toast.makeText(context, "සාර්ථකව ලොග් වුණා! (දේශීය ගිණුමෙන්)", Toast.LENGTH_SHORT).show()
                            onLoginSuccess()
                        } else {
                            Toast.makeText(context, "ලොග් වීම අසාර්ථකයි: වැරදි දේශීය ගිණුම් විස්තර!", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    Toast.makeText(context, "කරුණාකර ක්ෂේත්ර සියල්ල පුරවන්න!", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5A93C)),
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(8.dp),
            enabled = !isLoading
        ) {
            if (isLoading) {
                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
            } else {
                Text("Sign In", fontSize = 16.sp, color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
