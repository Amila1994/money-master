package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Environment
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectAnalysisDashboardScreen() {
    val context = LocalContext.current
    
    // 🏫 පාසල් විස්තර සඳහා States
    var schoolName by remember { mutableStateOf("මධ්ය මහා විද්යාලය") }
    var currentClass by remember { mutableStateOf("10-A") }
    var teacherName by remember { mutableStateOf("Mr. Asela Perera") }
    var year by remember { mutableStateOf("2026") }
    var examName by remember { mutableStateOf("පළමු වාර විභාගය") }

    // Input Text Fields සඳහා States
    var inputClassName by remember { mutableStateOf("") }
    var inputTeacherName by remember { mutableStateOf("") }

    // 📊 චාර්ට් වර්ග 5
    val chartTypes = listOf("Bar Chart", "Line Chart", "Pie Chart", "Donut Chart", "Area Chart")
    var selectedChart by remember { mutableStateOf(chartTypes[0]) }
    var dropdownExpanded by remember { mutableStateOf(false) }

    // ⛔ [මඟහැරීම] කලින් තිබූ සියලුම Ads, Restricted සහ Package Check ලොජික් සම්පූර්ණයෙන්ම මෙතැනින් ඉවත් කර ඇත. 
    // දැන් ඕනෑම පරිශීලකයෙකුට සෘජුවම Dashboard එක පාවිච්චි කළ හැක.

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF231F20)) // Dark Theme පසුබිම
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "📊 Subject Analysis Dashboard",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE5A93C),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 📈 Dropdown Menu
        ExposedDropdownMenuBox(
            expanded = dropdownExpanded,
            onExpandedChange = { dropdownExpanded = !dropdownExpanded }
        ) {
            TextField(
                value = selectedChart,
                onValueChange = {},
                readOnly = true,
                label = { Text("චාර්ට් එක තෝරන්න (Select Chart)", color = Color.Gray) },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth().padding(bottom = 12.dp)
            )
            ExposedDropdownMenu(
                expanded = dropdownExpanded,
                onDismissRequest = { dropdownExpanded = false }
            ) {
                chartTypes.forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type) },
                        onClick = {
                            selectedChart = type
                            dropdownExpanded = false
                        }
                    )
                }
            }
        }

        // 🏫 Class Workspace Card
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF363031)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "🎯 පන්තිය කළමනාකරණය (Class Workspace):",
                    color = Color(0xFFE5A93C),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                OutlinedTextField(
                    value = inputClassName,
                    onValueChange = { inputClassName = it },
                    label = { Text("පන්තියේ නම (e.g., 10-C)", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                OutlinedTextField(
                    value = inputTeacherName,
                    onValueChange = { inputTeacherName = it },
                    label = { Text("පන්තිභාර ගුරුතුමා", color = Color.Gray) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 🔘 පාලක බොත්තම් 3 පතුලෙන්ම පෙන්වීම (Add, Update, Delete)
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // ➕ එකතු කරන්න
            Button(
                onClick = {
                    if (inputClassName.isNotEmpty()) {
                        currentClass = inputClassName
                        teacherName = inputTeacherName
                        Toast.makeText(context, "අලුත් පන්තියක් එකතු කළා!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                modifier = Modifier.weight(1f).padding(2.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(2.dp))
                Text("එකතු කරන්න", fontSize = 10.sp, color = Color.White)
            }

            // ✏️ වෙනස් කරන්න
            Button(
                onClick = {
                    if (inputClassName.isNotEmpty()) {
                        currentClass = inputClassName
                        teacherName = inputTeacherName
                        Toast.makeText(context, "පන්තියේ විස්තර වෙනස් කළා!", Toast.LENGTH_SHORT).show()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5A93C)),
                modifier = Modifier.weight(1f).padding(2.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(2.dp))
                Text("වෙනස් කරන්න", fontSize = 10.sp, color = Color.White)
            }

            // ❌ මකන්න
            Button(
                onClick = {
                    inputClassName = ""
                    inputTeacherName = ""
                    currentClass = "නොමැත"
                    teacherName = "නොමැත"
                    Toast.makeText(context, "පන්තිය සාර්ථකව මකා දැමුවා!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336)),
                modifier = Modifier.weight(1f).padding(2.dp),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(2.dp))
                Text("මකන්න", fontSize = 10.sp, color = Color.White)
            }
        }

        // 📥 Download Chart Button
        Button(
            onClick = {
                saveColorfulChartAsImage(context, schoolName, currentClass, teacherName, year, examName, selectedChart)
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5A93C)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("වර්ණවත් චාර්ට් එක Download කරගන්න", fontSize = 15.sp, color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

// 💾 වර්ණවත් චාර්ට් 5 සමඟ සේව් වන සිස්ටම් එක
fun saveColorfulChartAsImage(
    context: Context,
    school: String,
    clazz: String,
    teacher: String,
    yr: String,
    exam: String,
    chartType: String
) {
    val bitmap = Bitmap.createBitmap(800, 1000, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(android.graphics.Color.WHITE)

    val paint = Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 34f
        isAntiAlias = true
    }

    // Header එක ඇඳීම
    canvas.drawText(school, 50f, 80f, paint.apply { textSize = 40f; isFakeBoldText = true })
    paint.textSize = 28f; paint.isFakeBoldText = false
    canvas.drawText("පන්තිය: $clazz", 50f, 140f, paint)
    canvas.drawText("වර්ෂය: $yr", 500f, 140f, paint)
    canvas.drawText("පන්තිභාර ගුරුතුමා: $teacher", 50f, 190f, paint)
    canvas.drawText("විභාගය: $exam", 500f, 190f, paint)
    
    paint.color = android.graphics.Color.GRAY
    canvas.drawLine(50f, 220f, 750f, 220f, paint)

    // චාර්ට් 5 වර්ණවත්ව ඇඳීම
    when (chartType) {
        "Bar Chart" -> {
            paint.color = android.graphics.Color.parseColor("#4CAF50")
            canvas.drawRect(150f, 450f, 250f, 850f, paint)
            paint.color = android.graphics.Color.parseColor("#FF9800")
            canvas.drawRect(350f, 350f, 450f, 850f, paint)
            paint.color = android.graphics.Color.parseColor("#2196F3")
            canvas.drawRect(550f, 550f, 650f, 850f, paint)
        }
        "Pie Chart", "Donut Chart" -> {
            val rectF = RectF(200f, 400f, 600f, 800f)
            paint.color = android.graphics.Color.parseColor("#E91E63")
            canvas.drawArc(rectF, 0f, 140f, true, paint)
            paint.color = android.graphics.Color.parseColor("#9C27B0")
            canvas.drawArc(rectF, 140f, 100f, true, paint)
            paint.color = android.graphics.Color.parseColor("#00BCD4")
            canvas.drawArc(rectF, 240f, 120f, true, paint)
            
            if (chartType == "Donut Chart") {
                paint.color = android.graphics.Color.WHITE
                canvas.drawCircle(400f, 600f, 110f, paint)
            }
        }
        "Line Chart", "Area Chart" -> {
            paint.color = android.graphics.Color.parseColor("#FF5722")
            paint.strokeWidth = 8f
            canvas.drawLine(150f, 650f, 350f, 450f, paint)
            canvas.drawLine(350f, 450f, 550f, 700f, paint)
            canvas.drawLine(550f, 700f, 650f, 350f, paint)
            
            paint.color = android.graphics.Color.parseColor("#3F51B5")
            canvas.drawCircle(150f, 650f, 12f, paint)
            canvas.drawCircle(350f, 450f, 12f, paint)
            canvas.drawCircle(550f, 700f, 12f, paint)
            canvas.drawCircle(650f, 350f, 12f, paint)
        }
    }

    // Downloads ෆෝල්ඩරයට PNG එකක් ලෙස සේව් කිරීම
    val filename = "Colorful_${chartType.replace(" ", "")}_${System.currentTimeMillis()}.png"
    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    val file = File(downloadDir, filename)

    try {
        val out = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        out.flush()
        out.close()
        Toast.makeText(context, "වර්ණවත් චාර්ට් එක සේව් වුණා!", Toast.LENGTH_SHORT).show()
    } catch (e: IOException) {
        Toast.makeText(context, "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}
