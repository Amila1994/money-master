package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = AccentTeal,
    secondary = AccentTealDark,
    tertiary = Pink80,
    background = DeepDarkBg,
    surface = SurfaceDark,
    onPrimary = DeepDarkBg,
    onSecondary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextWhite
  )

private val LightColorScheme =
  lightColorScheme(
    primary = AccentTeal,
    secondary = AccentTealDark,
    tertiary = Pink40,
    background = DeepDarkBg,
    surface = SurfaceDark,
    onPrimary = DeepDarkBg,
    onSecondary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextWhite
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force Dark theme for the secure locker experience
  dynamicColor: Boolean = false, // Disable dynamic colors to preserve our exact custom brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
