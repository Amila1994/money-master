package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = AccentAmber,
    secondary = SoftGold,
    tertiary = EmeraldGreen,
    background = DarkBg,
    surface = CardBg,
    onBackground = TextLight,
    onSurface = TextLight,
    outline = BorderColor
  )

private val LightColorScheme =
  darkColorScheme( // Keep dark scheme even in light mode for consistency with requested design
    primary = AccentAmber,
    secondary = SoftGold,
    tertiary = EmeraldGreen,
    background = DarkBg,
    surface = CardBg,
    onBackground = TextLight,
    onSurface = TextLight,
    outline = BorderColor
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark theme
  dynamicColor: Boolean = false, // Force custom theme colors
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme // Always use our beautiful dark theme


  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
