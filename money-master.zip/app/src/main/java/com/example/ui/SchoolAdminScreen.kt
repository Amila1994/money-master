package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.School
import com.example.model.ChatMessage
import com.example.viewmodel.SchoolViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SchoolAdminScreen(
    viewModel: SchoolViewModel,
    modifier: Modifier = Modifier
) {
    val schools by viewModel.filteredSchools.collectAsState()
    val allSchools by viewModel.schools.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedType by viewModel.selectedType.collectAsState()
    val sortType by viewModel.sortType.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val isUsingFirestore by viewModel.isUsingFirestore.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var selectedSchoolForEdit by remember { mutableStateOf<School?>(null) }
    var showDeleteDialog by remember { mutableStateOf<School?>(null) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var activeChatSchool by remember { mutableStateOf<School?>(null) }

    var showNoticeDialog by remember { mutableStateOf(false) }
    var noticeInputText by remember { mutableStateOf("") }
    val noticeText by viewModel.noticeText.collectAsState()
    val isNoticeActive by viewModel.isNoticeActive.collectAsState()

    // Trigger snackbar on status update
    LaunchedEffect(statusMessage) {
        statusMessage?.let {
            scope.launch {
                snackbarHostState.showSnackbar(it)
                viewModel.clearStatusMessage()
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "School Master",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "Admin Panel",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                            )
                        )
                    }
                },
                actions = {
                    // Sync / Reload button
                    IconButton(
                        onClick = { viewModel.loadSchools() },
                        modifier = Modifier.testTag("reload_button")
                    ) {
                        Icon(
                            imageVector = if (isUsingFirestore) Icons.Default.Wifi else Icons.Default.OfflineBolt,
                            contentDescription = "Sync Connection",
                            tint = if (isUsingFirestore) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedSchoolForEdit = null
                    showAddEditDialog = true
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_school_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add School")
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Connection Mode Banner
            if (!isUsingFirestore) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.errorContainer)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.OfflineBolt,
                            contentDescription = "Offline Mode",
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Running in Local Offline Mode. Data is safe.",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }
            }

            // Stats Section
            SchoolsStatsHeader(schools = allSchools)

            // Live Notice Board Panel
            LiveNoticeBoardPanel(
                noticeText = noticeText,
                isActive = isNoticeActive,
                onPublishClick = {
                    noticeInputText = noticeText
                    showNoticeDialog = true
                },
                onClearClick = {
                    viewModel.clearNotice()
                }
            )

            // Search and Filtering Section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Search field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search by name, address, email...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_schools_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sort & Filters Options
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Sorting menu
                    Box {
                        OutlinedButton(
                            onClick = { sortMenuExpanded = true },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("sort_button")
                        ) {
                            Icon(Icons.Default.Sort, contentDescription = "Sort")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = sortType, style = MaterialTheme.typography.labelLarge)
                        }
                        DropdownMenu(
                            expanded = sortMenuExpanded,
                            onDismissRequest = { sortMenuExpanded = false }
                        ) {
                            listOf(
                                "Name (A-Z)",
                                "Name (Z-A)",
                                "Students (High to Low)",
                                "Students (Low to High)",
                                "Year Established"
                            ).forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option) },
                                    onClick = {
                                        viewModel.setSortType(option)
                                        sortMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "Filter",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Filter Type:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Filter Chips Row
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Public", "Private", "International").forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { viewModel.setSelectedType(type) },
                            label = { Text(type) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.testTag("filter_chip_$type")
                        )
                    }
                }
            }

            // Schools List
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (isLoading && schools.isEmpty()) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .testTag("loading_indicator")
                    )
                } else if (schools.isEmpty()) {
                    // Empty State UI
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp)
                            .testTag("empty_state_view"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "No schools",
                            modifier = Modifier.size(72.dp),
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No Schools Found",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Try refining your search query or add a new school to get started.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(schools, key = { it.id }) { school ->
                            SchoolCard(
                                school = school,
                                onEditClick = {
                                    selectedSchoolForEdit = school
                                    showAddEditDialog = true
                                },
                                onDeleteClick = {
                                    showDeleteDialog = school
                                },
                                onChatClick = {
                                    activeChatSchool = school
                                },
                                onToggleLock = { isLocked ->
                                    viewModel.updateSchool(school.copy(isLocked = isLocked))
                                },
                                onToggleSubscribe = { isSubscribed ->
                                    viewModel.updateSchool(school.copy(isSubscribed = isSubscribed))
                                }
                            )
                        }
                        // Spacer at the end for FAB overlap prevention
                        item {
                            Spacer(modifier = Modifier.height(80.dp))
                        }
                    }
                }
            }
        }
    }

    // Add / Edit School Dialog
    if (showAddEditDialog) {
        AddEditSchoolDialog(
            school = selectedSchoolForEdit,
            onDismiss = { showAddEditDialog = false },
            onConfirm = { school ->
                if (selectedSchoolForEdit == null) {
                    viewModel.addSchool(school)
                } else {
                    viewModel.updateSchool(school)
                }
                showAddEditDialog = false
            },
            onDeleteSchool = { schoolId ->
                viewModel.deleteSchool(schoolId)
            }
        )
    }

    // Delete Confirmation Dialog
    showDeleteDialog?.let { school ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Delete School") },
            text = { Text("Are you sure you want to delete '${school.name}'? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSchool(school.id)
                        showDeleteDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("Cancel")
                }
            },
            modifier = Modifier.testTag("delete_dialog")
        )
    }

    // Chat Dialog
    activeChatSchool?.let { school ->
        ChatDialog(
            school = school,
            viewModel = viewModel,
            onDismiss = { activeChatSchool = null }
        )
    }

    // Publish Notice Dialog
    if (showNoticeDialog) {
        AlertDialog(
            onDismissRequest = { showNoticeDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Publish Live Notice",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Enter the notice text that will be displayed live in the School app's notice board.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = noticeInputText,
                        onValueChange = { noticeInputText = it },
                        placeholder = { Text("Write notice here...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .testTag("notice_input_field"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (noticeInputText.isNotBlank()) {
                            viewModel.publishNotice(noticeInputText.trim())
                            showNoticeDialog = false
                        }
                    },
                    modifier = Modifier.testTag("confirm_publish_notice_button")
                ) {
                    Text("Publish")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showNoticeDialog = false }
                ) {
                    Text("Cancel")
                }
            },
            modifier = Modifier.testTag("publish_notice_dialog")
        )
    }
}

@Composable
fun SchoolsStatsHeader(schools: List<School>) {
    val totalSchools = schools.size
    val totalStudents = schools.sumOf { it.studentCount }
    val avgStudents = if (totalSchools > 0) totalStudents / totalSchools else 0

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier
                .weight(1f)
                .testTag("stat_total_schools"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "$totalSchools",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Schools",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card(
            modifier = Modifier
                .weight(1.3f)
                .testTag("stat_total_students"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = String.format("%,d", totalStudents),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Total Students",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .testTag("stat_avg_students"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "$avgStudents",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.tertiary
                )
                Text(
                    text = "Avg Students",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun SchoolCard(
    school: School,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onChatClick: () -> Unit,
    onToggleLock: (Boolean) -> Unit,
    onToggleSubscribe: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("school_card_${school.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Title and Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = school.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("school_name_${school.id}")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Badge: School Type
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when (school.schoolType) {
                                        "Public" -> Color(0xFFE3F2FD)
                                        "Private" -> Color(0xFFEDE7F6)
                                        "International" -> Color(0xFFE8F5E9)
                                        else -> Color(0xFFFFF3E0)
                                    }
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = school.schoolType,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = when (school.schoolType) {
                                        "Public" -> Color(0xFF0D47A1)
                                        "Private" -> Color(0xFF4A148C)
                                        "International" -> Color(0xFF1B5E20)
                                        else -> Color(0xFFE65100)
                                    }
                                )
                            )
                        }

                        // Status Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (school.status == "Active") Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = school.status,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (school.status == "Active") Color(0xFF1B5E20) else Color(0xFFB71C1C)
                                )
                            )
                        }
                    }
                }

                Row {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    IconButton(
                        onClick = {
                            val intent = android.content.Intent(context, com.example.AdminChatActivity::class.java).apply {
                                putExtra("SCHOOL_EMAIL", school.email)
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("admin_chat_button_${school.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Admin Chat & Calls",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onChatClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("chat_button_${school.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = "Chat with School",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onEditClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("edit_button_${school.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit School",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("delete_button_${school.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete School",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Details
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Address
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Address",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = school.address,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Phone
                    if (school.phone.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Phone",
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = school.phone,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Email
                    if (school.email.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Email",
                                tint = MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = school.email,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Footer stats
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Established: ${school.establishedYear}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )

                    Text(
                        text = "Students: ${String.format("%,d", school.studentCount)}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Master PIN, subscription_status, dates
                if (school.master_pin.isNotEmpty() || school.teacher_pin.isNotEmpty() || school.subscription_status.isNotEmpty() || school.subscriptionStartDate != null || school.subscriptionEndDate != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                            .padding(8.dp)
                    ) {
                        if (school.master_pin.isNotEmpty()) {
                            Text(
                                text = "Master PIN: ${school.master_pin}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (school.teacher_pin.isNotEmpty()) {
                            Text(
                                text = "Teacher PIN: ${school.teacher_pin}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (school.subscription_status.isNotEmpty()) {
                            Text(
                                text = "Sub Status: ${school.subscription_status}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = if (school.subscription_status == "ACTIVE") Color(0xFF1B5E20) else Color(0xFFB71C1C)
                            )
                        }
                        
                        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                        if (school.subscriptionStartDate != null || school.subscriptionEndDate != null) {
                            val startText = school.subscriptionStartDate?.let { dateFormat.format(it.toDate()) } ?: "N/A"
                            val endText = school.subscriptionEndDate?.let { dateFormat.format(it.toDate()) } ?: "N/A"
                            Text(
                                text = "Period: $startText to $endText",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 12.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // App Lock Switch
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                            .clickable { onToggleLock(!school.isLocked) }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "App Lock",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Switch(
                            checked = school.isLocked,
                            onCheckedChange = { onToggleLock(it) },
                            modifier = Modifier.testTag("switch_lock_${school.id}")
                        )
                    }

                    // Subscribed Switch
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                            .clickable { onToggleSubscribe(!school.isSubscribed) }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Subscribed",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Switch(
                            checked = school.isSubscribed,
                            onCheckedChange = { onToggleSubscribe(it) },
                            modifier = Modifier.testTag("switch_subscribe_${school.id}")
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditSchoolDialog(
    school: School?,
    onDismiss: () -> Unit,
    onConfirm: (School) -> Unit,
    onDeleteSchool: (String) -> Unit = {}
) {
    var name by remember { mutableStateOf(school?.name ?: "") }
    var address by remember { mutableStateOf(school?.address ?: "") }
    var phone by remember { mutableStateOf(school?.phone ?: "") }
    var email by remember { mutableStateOf(school?.email ?: "") }
    var studentCountStr by remember { mutableStateOf(school?.studentCount?.toString() ?: "") }
    var schoolType by remember { mutableStateOf(school?.schoolType ?: "Public") }
    var establishedYearStr by remember { mutableStateOf(school?.establishedYear?.toString() ?: "2000") }
    var status by remember { mutableStateOf(school?.status ?: "Active") }
    var isLocked by remember { mutableStateOf(school?.isLocked ?: false) }
    var isSubscribed by remember { mutableStateOf(school?.isSubscribed ?: false) }
    var subscription_status by remember { mutableStateOf(school?.subscription_status ?: "ACTIVE") }
    var master_pin by remember { mutableStateOf(school?.master_pin ?: "") }
    var teacher_pin by remember { mutableStateOf(school?.teacher_pin ?: "") }
    var subscriptionStartDate by remember { mutableStateOf(school?.subscriptionStartDate) }
    var subscriptionEndDate by remember { mutableStateOf(school?.subscriptionEndDate) }

    var nameError by remember { mutableStateOf(false) }
    var addressError by remember { mutableStateOf(false) }
    var studentCountError by remember { mutableStateOf(false) }

    var typeMenuExpanded by remember { mutableStateOf(false) }
    var statusMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (school == null) "Add School" else "Edit School") },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_edit_form")
            ) {
                // School Name
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            name = it
                            nameError = it.trim().isEmpty()
                        },
                        label = { Text("School Name *") },
                        isError = nameError,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_name_input")
                    )
                    if (nameError) {
                        Text(
                            text = "Name cannot be empty",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }

                // Address
                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = {
                            address = it
                            addressError = it.trim().isEmpty()
                        },
                        label = { Text("Address *") },
                        isError = addressError,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_address_input")
                    )
                    if (addressError) {
                        Text(
                            text = "Address cannot be empty",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }

                // Phone
                item {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_phone_input")
                    )
                }

                // Email
                item {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_email_input")
                    )
                }

                // Student Count
                item {
                    OutlinedTextField(
                        value = studentCountStr,
                        onValueChange = {
                            studentCountStr = it
                            studentCountError = it.toIntOrNull() == null
                        },
                        label = { Text("Student Count *") },
                        isError = studentCountError,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_students_input")
                    )
                    if (studentCountError) {
                        Text(
                            text = "Please enter a valid number",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }

                // Established Year
                item {
                    OutlinedTextField(
                        value = establishedYearStr,
                        onValueChange = { establishedYearStr = it },
                        label = { Text("Established Year") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_year_input")
                    )
                }

                // School Type Dropdown
                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = schoolType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("School Type") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("school_type_dropdown_trigger")
                                .clickable { typeMenuExpanded = true }
                        )
                        DropdownMenu(
                            expanded = typeMenuExpanded,
                            onDismissRequest = { typeMenuExpanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("Public", "Private", "International", "Chartered").forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        schoolType = type
                                        typeMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Status Dropdown
                item {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = status,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Status") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("school_status_dropdown_trigger")
                                .clickable { statusMenuExpanded = true }
                        )
                        DropdownMenu(
                            expanded = statusMenuExpanded,
                            onDismissRequest = { statusMenuExpanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("Active", "Inactive").forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s) },
                                    onClick = {
                                        status = s
                                        statusMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // App Lock Toggle in Dialog
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .clickable { isLocked = !isLocked }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Enable App Lock",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Switch(
                            checked = isLocked,
                            onCheckedChange = { isLocked = it },
                            modifier = Modifier.testTag("dialog_switch_lock")
                        )
                    }
                }

                // Subscribed Toggle in Dialog
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .clickable { isSubscribed = !isSubscribed }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Is Subscribed",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium
                        )
                        Switch(
                            checked = isSubscribed,
                            onCheckedChange = { isSubscribed = it },
                            modifier = Modifier.testTag("dialog_switch_subscribed")
                        )
                    }
                }

                // Master PIN Input
                item {
                    OutlinedTextField(
                        value = master_pin,
                        onValueChange = { master_pin = it },
                        label = { Text("Master PIN") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_master_pin_input")
                    )
                }

                // Teacher PIN Input
                item {
                    OutlinedTextField(
                        value = teacher_pin,
                        onValueChange = { teacher_pin = it },
                        label = { Text("Teacher PIN") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_teacher_pin_input")
                    )
                }

                // Subscription Status Dropdown
                item {
                    var subStatusMenuExpanded by remember { mutableStateOf(false) }
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = subscription_status,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Subscription Status") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("school_sub_status_dropdown_trigger")
                                .clickable { subStatusMenuExpanded = true }
                        )
                        DropdownMenu(
                            expanded = subStatusMenuExpanded,
                            onDismissRequest = { subStatusMenuExpanded = false },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("ACTIVE", "EXPIRED", "PENDING", "NONE").forEach { statusVal ->
                                DropdownMenuItem(
                                    text = { Text(statusVal) },
                                    onClick = {
                                        subscription_status = statusVal
                                        subStatusMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Start Date & Expiry Date Pickers
                item {
                    val context = androidx.compose.ui.platform.LocalContext.current
                    val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
                    
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Start Date Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Start Date: " + (subscriptionStartDate?.let { dateFormat.format(it.toDate()) } ?: "Not Set"),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Button(
                                onClick = {
                                    val cal = java.util.Calendar.getInstance()
                                    subscriptionStartDate?.let { cal.time = it.toDate() }
                                    android.app.DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            val selectedCal = java.util.Calendar.getInstance()
                                            selectedCal.set(java.util.Calendar.YEAR, year)
                                            selectedCal.set(java.util.Calendar.MONTH, month)
                                            selectedCal.set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                                            
                                            android.app.TimePickerDialog(
                                                context,
                                                { _, hourOfDay, minute ->
                                                    selectedCal.set(java.util.Calendar.HOUR_OF_DAY, hourOfDay)
                                                    selectedCal.set(java.util.Calendar.MINUTE, minute)
                                                    selectedCal.set(java.util.Calendar.SECOND, 0)
                                                    selectedCal.set(java.util.Calendar.MILLISECOND, 0)
                                                    subscriptionStartDate = com.google.firebase.Timestamp(selectedCal.time)
                                                },
                                                cal.get(java.util.Calendar.HOUR_OF_DAY),
                                                cal.get(java.util.Calendar.MINUTE),
                                                true
                                            ).show()
                                        },
                                        cal.get(java.util.Calendar.YEAR),
                                        cal.get(java.util.Calendar.MONTH),
                                        cal.get(java.util.Calendar.DAY_OF_MONTH)
                                    ).show()
                                },
                                modifier = Modifier.testTag("btn_pick_start_date")
                            ) {
                                Text("Pick Start Date")
                            }
                        }
                        
                        // Expiry Date Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Expiry Date: " + (subscriptionEndDate?.let { dateFormat.format(it.toDate()) } ?: "Not Set"),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Button(
                                onClick = {
                                    val cal = java.util.Calendar.getInstance()
                                    subscriptionEndDate?.let { cal.time = it.toDate() }
                                    android.app.DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            val selectedCal = java.util.Calendar.getInstance()
                                            selectedCal.set(java.util.Calendar.YEAR, year)
                                            selectedCal.set(java.util.Calendar.MONTH, month)
                                            selectedCal.set(java.util.Calendar.DAY_OF_MONTH, dayOfMonth)
                                            
                                            android.app.TimePickerDialog(
                                                context,
                                                { _, hourOfDay, minute ->
                                                    selectedCal.set(java.util.Calendar.HOUR_OF_DAY, hourOfDay)
                                                    selectedCal.set(java.util.Calendar.MINUTE, minute)
                                                    selectedCal.set(java.util.Calendar.SECOND, 0)
                                                    selectedCal.set(java.util.Calendar.MILLISECOND, 0)
                                                    subscriptionEndDate = com.google.firebase.Timestamp(selectedCal.time)
                                                },
                                                cal.get(java.util.Calendar.HOUR_OF_DAY),
                                                cal.get(java.util.Calendar.MINUTE),
                                                true
                                            ).show()
                                        },
                                        cal.get(java.util.Calendar.YEAR),
                                        cal.get(java.util.Calendar.MONTH),
                                        cal.get(java.util.Calendar.DAY_OF_MONTH)
                                    ).show()
                                },
                                modifier = Modifier.testTag("btn_pick_end_date")
                            ) {
                                Text("Pick Expiry Date")
                            }
                        }
                    }
                }

                // Auth & Delete control actions for existing schools
                if (school != null) {
                    item {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))
                        Text(
                            text = "School Auth & Data Controls",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        
                        val context = androidx.compose.ui.platform.LocalContext.current
                        
                        Button(
                            onClick = {
                                if (school.email.isNotBlank()) {
                                    try {
                                        com.google.firebase.auth.FirebaseAuth.getInstance()
                                            .sendPasswordResetEmail(school.email)
                                            .addOnCompleteListener { task ->
                                                if (task.isSuccessful) {
                                                    android.widget.Toast.makeText(context, "Password reset email sent to ${school.email}", android.widget.Toast.LENGTH_LONG).show()
                                                } else {
                                                    android.widget.Toast.makeText(context, "Failed: ${task.exception?.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
                                                }
                                            }
                                    } catch (e: Exception) {
                                        android.widget.Toast.makeText(context, "Auth Error: ${e.localizedMessage}", android.widget.Toast.LENGTH_LONG).show()
                                    }
                                } else {
                                    android.widget.Toast.makeText(context, "School email is required to send password reset.", android.widget.Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_reset_password")
                        ) {
                            Text("Send Password Reset Email", color = Color.White)
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Button(
                            onClick = {
                                onDismiss()
                                onDeleteSchool(school.id)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE91E63)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_delete_school")
                        ) {
                            Text("DELETE ENTIRE SCHOOL DATA", color = Color.White)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalName = name.trim()
                    val finalAddress = address.trim()
                    val studentCount = studentCountStr.toIntOrNull() ?: 0
                    val establishedYear = establishedYearStr.toIntOrNull() ?: 2000

                    nameError = finalName.isEmpty()
                    addressError = finalAddress.isEmpty()
                    studentCountError = studentCountStr.isEmpty() || studentCountStr.toIntOrNull() == null

                    if (!nameError && !addressError && !studentCountError) {
                        onConfirm(
                            School(
                                id = school?.id ?: "",
                                name = finalName,
                                address = finalAddress,
                                phone = phone.trim(),
                                email = email.trim(),
                                studentCount = studentCount,
                                schoolType = schoolType,
                                establishedYear = establishedYear,
                                status = status,
                                isLocked = isLocked,
                                isSubscribed = isSubscribed,
                                subscription_status = subscription_status,
                                master_pin = master_pin,
                                teacher_pin = teacher_pin,
                                subscriptionStartDate = subscriptionStartDate,
                                subscriptionEndDate = subscriptionEndDate
                            )
                        )
                    }
                },
                modifier = Modifier.testTag("save_school_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
        modifier = Modifier.testTag("add_edit_dialog")
    )
}

@Composable
fun ChatDialog(
    school: School,
    viewModel: SchoolViewModel,
    onDismiss: () -> Unit
) {
    val messages by viewModel.activeChatMessages.collectAsState()
    var messageText by remember { mutableStateOf("") }
    
    LaunchedEffect(school.id) {
        viewModel.startChatListener(school.id, school.email)
    }
    
    AlertDialog(
        onDismissRequest = {
            viewModel.stopChatListener(school.email)
            onDismiss()
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = school.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        // Online / Offline Presence Dot
                        val partnerStatus by viewModel.partnerPresence.collectAsState()
                        val dotColor = if (partnerStatus == "online") Color(0xFF4CAF50) else Color(0xFFF44336)
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(dotColor)
                                .testTag("presence_dot")
                        )
                    }
                    val partnerStatus by viewModel.partnerPresence.collectAsState()
                    Text(
                        text = "Support Chat (${partnerStatus.uppercase()})",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                
                // Messages List
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (messages.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No messages yet. Send a message to start the conversation.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.outline,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                modifier = Modifier.padding(16.dp)
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            reverseLayout = false
                        ) {
                            items(messages) { message ->
                                val isAdmin = message.sender == "admin"
                                val bubbleColor = if (isAdmin) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                }
                                val textColor = if (isAdmin) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                }
                                val alignment = if (isAdmin) Alignment.End else Alignment.Start
                                
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = alignment
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(
                                                RoundedCornerShape(
                                                    topStart = 12.dp,
                                                    topEnd = 12.dp,
                                                    bottomStart = if (isAdmin) 12.dp else 0.dp,
                                                    bottomEnd = if (isAdmin) 0.dp else 12.dp
                                                )
                                            )
                                            .background(bubbleColor)
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                            .widthIn(max = 220.dp)
                                    ) {
                                        Column {
                                            Text(
                                                text = message.text,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = textColor
                                            )
                                            message.timestamp?.let { ts ->
                                                val sdf = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                                                Text(
                                                    text = sdf.format(ts.toDate()),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = textColor.copy(alpha = 0.6f),
                                                    modifier = Modifier.align(Alignment.End).padding(top = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                val activeTicketCallStatus by viewModel.activeTicketCallStatus.collectAsState()
                val activeTicketVideoCallAllowed by viewModel.activeTicketVideoCallAllowed.collectAsState()
                val activeTicketCallerRole by viewModel.activeTicketCallerRole.collectAsState()

                if (activeTicketCallStatus != "IDLE") {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = when (activeTicketCallStatus) {
                                "RINGING" -> if (activeTicketCallerRole == "school") MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer
                                "CONNECTED" -> Color(0xFFE8F5E9)
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (activeTicketCallStatus == "CONNECTED") Icons.Default.Info else Icons.Default.Phone,
                                    contentDescription = "Call Status Icon",
                                    tint = when (activeTicketCallStatus) {
                                        "RINGING" -> MaterialTheme.colorScheme.error
                                        "CONNECTED" -> Color(0xFF2E7D32)
                                        else -> MaterialTheme.colorScheme.primary
                                    }
                                )
                                Column {
                                    Text(
                                        text = when (activeTicketCallStatus) {
                                            "RINGING" -> if (activeTicketCallerRole == "school") "Calling Admin..." else "Incoming Admin Call..."
                                            "CONNECTED" -> "Call Connected"
                                            else -> "Call Status Unknown"
                                        },
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = when (activeTicketCallStatus) {
                                            "RINGING" -> if (activeTicketCallerRole == "school") "Waiting for answer" else "Admin is calling"
                                            "CONNECTED" -> "Agora Video Engine Active"
                                            else -> "Ready"
                                        },
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                            
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (activeTicketCallStatus == "RINGING" && activeTicketCallerRole == "admin") {
                                    Button(
                                        onClick = {
                                            viewModel.updateCallStatus(school.email, "CONNECTED")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Answer", style = MaterialTheme.typography.labelMedium)
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.updateCallStatus(school.email, "IDLE")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Decline", style = MaterialTheme.typography.labelMedium)
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            viewModel.updateCallStatus(school.email, "IDLE")
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("End Call", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                } else if (activeTicketVideoCallAllowed) {
                    Button(
                        onClick = {
                            viewModel.startSchoolCall(school.email)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("school_call_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Call support icon",
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text("Start Live Support Call")
                    }
                }
                
                // Controls panel: Allow Video Call & Close Case
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Video Call Switch
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        var videoCallAllowed by remember { mutableStateOf(false) }
                        androidx.compose.material3.Switch(
                            checked = videoCallAllowed,
                            onCheckedChange = { checked ->
                                videoCallAllowed = checked
                                viewModel.grantVideoCallAccess(school.email, checked)
                            },
                            modifier = Modifier.scale(0.8f).testTag("video_call_switch")
                        )
                        Text(
                            text = "Allow Video Call",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Solve Case & Clear Chat
                    TextButton(
                        onClick = {
                            viewModel.closeCaseAndClearChat(school.email) {
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.testTag("close_case_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Solve & Clear Chat",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                // Message Input Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = messageText,
                        onValueChange = { messageText = it },
                        placeholder = { Text("Type a message...") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp)
                    )
                    
                    IconButton(
                        onClick = {
                            if (messageText.isNotBlank()) {
                                viewModel.sendChatMessage(school.id, school.email, messageText)
                                messageText = ""
                            }
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .size(40.dp)
                            .testTag("send_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send Message",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    viewModel.stopChatListener(school.email)
                    onDismiss()
                },
                modifier = Modifier.testTag("close_chat_button")
            ) {
                Text("Close")
            }
        }
    )
}

@Composable
fun LiveNoticeBoardPanel(
    noticeText: String,
    isActive: Boolean,
    onPublishClick: () -> Unit,
    onClearClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("live_notice_board_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) {
                MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
            }
        ),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isActive) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Notice Board",
                        tint = if (isActive) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = "Live School Notice Board",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (isActive) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                }

                // Live status badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isActive) Color(0xFF4CAF50) else Color(0xFF757575)
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isActive) "LIVE ACTIVE" else "INACTIVE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (isActive && noticeText.isNotBlank()) {
                Text(
                    text = noticeText,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Medium,
                        lineHeight = 22.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            } else {
                Text(
                    text = "No active live notice is currently published for the school app.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onPublishClick,
                    modifier = Modifier
                        .weight(1.2f)
                        .height(40.dp)
                        .testTag("btn_publish_notice"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isActive) "Change Notice" else "Publish Notice",
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                if (isActive) {
                    OutlinedButton(
                        onClick = onClearClick,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            MaterialTheme.colorScheme.error.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("btn_clear_notice"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Clear Notice",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

