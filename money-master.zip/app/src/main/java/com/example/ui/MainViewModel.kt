package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RankedStudent(
    val studentId: String,
    val studentName: String,
    val marks: Map<String, Int>,
    val grades: Map<String, String> = emptyMap(),
    val total: Int,
    val average: Double,
    val status: String,
    val rank: Int = 0,
    val photoBytes: ByteArray? = null,
    val dob: String = "",
    val gender: String = "Male",
    val address: String = "",
    val guardian: String = "",
    val phone: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SchoolDatabase.getDatabase(application, viewModelScope)
    private val repository = SchoolRepository(database.schoolDao())

    val loggedInUser = MutableStateFlow<String?>(null)
    val isLoggedIn: StateFlow<Boolean> = loggedInUser
        .map { it != null }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

    suspend fun login(email: String, passwordHash: String): Boolean {
        val user = repository.getUser(email.trim().lowercase())
        if (user != null && user.passwordHash == passwordHash) {
            loggedInUser.value = user.email
            return true
        }
        return false
    }

    suspend fun register(email: String, passwordHash: String): String? {
        val trimmed = email.trim().lowercase()
        if (trimmed.isBlank() || passwordHash.isBlank()) {
            return "Email and password cannot be empty."
        }
        val existing = repository.getUser(trimmed)
        if (existing != null) {
            return "This email is already registered."
        }
        repository.insertUser(User(trimmed, passwordHash))
        return null
    }

    fun logout() {
        loggedInUser.value = null
    }

    val schoolConfig: StateFlow<SchoolConfig> = repository.schoolConfig
        .map { it ?: SchoolConfig() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SchoolConfig()
        )

    val allClassConfigs: StateFlow<List<ClassConfig>> = repository.allClassConfigs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val selectedClass = MutableStateFlow("10-A")

    // Filtered subjects for the active class
    val classSubjects: StateFlow<List<Subject>> = combine(
        selectedClass,
        repository.allSubjects
    ) { selClass, allSubs ->
        allSubs.filter { it.className == selClass }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Filtered students for the active class, ranked within this class
    val classRankedStudents: StateFlow<List<RankedStudent>> = combine(
        selectedClass,
        repository.allStudents,
        repository.allSubjects
    ) { selClass, allStuds, allSubs ->
        val classStuds = allStuds.filter { it.className == selClass }
        val classSubs = allSubs.filter { it.className == selClass }
        calculateRankings(classStuds, classSubs)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // All raw subjects & students for school-wide overview computations
    val allSubjects: StateFlow<List<Subject>> = repository.allSubjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateSchoolConfig(
        schoolName: String,
        gradeClass: String, // Fallback/unused but preserved for compatibility
        classTeacher: String, // Fallback/unused but preserved for compatibility
        examType: String,
        academicYear: String,
        schoolPhotoBytes: ByteArray? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSchoolConfig(
                SchoolConfig(
                    id = 1,
                    schoolName = schoolName,
                    gradeClass = gradeClass,
                    classTeacher = classTeacher,
                    examType = examType,
                    academicYear = academicYear,
                    schoolPhotoBytes = schoolPhotoBytes
                )
            )
        }
    }

    fun selectClass(className: String) {
        selectedClass.value = className
    }

    fun addClass(className: String, teacherName: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertClassConfig(
                ClassConfig(
                    className = className.trim(),
                    classTeacher = teacherName.trim()
                )
            )
            // Auto-select the newly added class
            selectedClass.value = className.trim()
        }
    }

    fun deleteClass(className: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteClassConfig(ClassConfig(className = className, classTeacher = ""))
            repository.clearSubjectsForClass(className)
            repository.clearStudentsForClass(className)
            
            // Switch selection to another class if available
            val remaining = repository.allClassConfigs.firstOrNull() ?: emptyList()
            val nextClass = remaining.firstOrNull { it.className != className }?.className ?: ""
            if (nextClass.isNotEmpty()) {
                selectedClass.value = nextClass
            }
        }
    }

    fun updateClassTeacher(className: String, teacherName: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertClassConfig(
                ClassConfig(
                    className = className,
                    classTeacher = teacherName.trim()
                )
            )
        }
    }

    fun addSubject(name: String, passMark: Int = 35, className: String) {
        if (name.isBlank() || className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSubject(name.trim(), passMark, className)
        }
    }

    fun removeSubject(subject: Subject) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeSubject(subject)
            // Clean up marks for this subject from all students in the same class
            val classStuds = repository.allStudents.first().filter { it.className == subject.className }
            classStuds.forEach { student ->
                if (student.marks.containsKey(subject.name)) {
                    val newMarks = student.marks.filterKeys { it != subject.name }
                    repository.insertStudent(student.copy(marks = newMarks))
                }
            }
        }
    }

    fun renameClass(oldClassName: String, newClassName: String) {
        val old = oldClassName.trim()
        val new = newClassName.trim()
        if (old.isBlank() || new.isBlank() || old == new) return
        viewModelScope.launch(Dispatchers.IO) {
            val configs = repository.allClassConfigs.first()
            val oldConfig = configs.find { it.className == old }
            val teacherName = oldConfig?.classTeacher ?: "Assign Teacher"
            
            repository.insertClassConfig(ClassConfig(className = new, classTeacher = teacherName))
            repository.deleteClassConfig(ClassConfig(className = old, classTeacher = ""))
            
            val classSubs = repository.allSubjects.first().filter { it.className == old }
            classSubs.forEach { sub ->
                repository.removeSubject(sub)
                repository.addSubject(sub.name, sub.passMark, new)
            }
            
            val classStuds = repository.allStudents.first().filter { it.className == old }
            classStuds.forEach { stud ->
                repository.deleteStudent(stud)
                repository.insertStudent(stud.copy(className = new))
            }
            
            selectedClass.value = new
        }
    }

    fun clearSubjectsForClass(className: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearSubjectsForClass(className)
        }
    }

    fun addOrUpdateStudent(studentId: String, studentName: String, marks: Map<String, Int>, className: String, photoBytes: ByteArray? = null) {
        if (studentId.isBlank() || studentName.isBlank() || className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.allStudents.first().find { it.studentId == studentId.trim() }
            val finalPhoto = photoBytes ?: existing?.photoBytes
            val dob = existing?.dob ?: ""
            val gender = existing?.gender ?: "Male"
            val address = existing?.address ?: ""
            val guardian = existing?.guardian ?: ""
            val phone = existing?.phone ?: ""
            repository.insertStudent(
                Student(
                    studentId = studentId.trim(),
                    studentName = studentName.trim(),
                    marks = marks,
                    className = className,
                    photoBytes = finalPhoto,
                    dob = dob,
                    gender = gender,
                    address = address,
                    guardian = guardian,
                    phone = phone
                )
            )
        }
    }

    fun updateStudentProfile(
        studentId: String,
        dob: String,
        gender: String,
        address: String,
        guardian: String,
        phone: String
    ) {
        if (studentId.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.allStudents.first().find { it.studentId == studentId.trim() }
            if (existing != null) {
                repository.insertStudent(
                    existing.copy(
                        dob = dob.trim(),
                        gender = gender.trim(),
                        address = address.trim(),
                        guardian = guardian.trim(),
                        phone = phone.trim()
                    )
                )
            }
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteStudent(
                Student(
                    studentId = studentId,
                    studentName = "",
                    marks = emptyMap()
                )
            )
        }
    }

    fun clearStudentsForClass(className: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearStudentsForClass(className)
        }
    }

    fun calculateRankings(students: List<Student>, subjects: List<Subject>): List<RankedStudent> {
        if (students.isEmpty()) return emptyList()

        val subjectNames = subjects.map { it.name }
        val subjectPassMarks = subjects.associate { it.name to it.passMark }
        
        // 1. Map to raw RankedStudent (without rank)
        val rawRanked = students.map { student ->
            // Only sum marks for subjects that currently exist in the database!
            val activeMarks = student.marks.filterKeys { it in subjectNames }
            val total = activeMarks.values.sum()
            val avg = if (subjectNames.isNotEmpty()) {
                (total.toDouble() / subjectNames.size)
            } else {
                0.0
            }
            val roundedAvg = Math.round(avg * 100.0) / 100.0
            
            // Calculate grade for each active subject mark using subject's specific passMark
            val grades = activeMarks.mapValues { (subName, score) ->
                val pm = subjectPassMarks[subName] ?: 35
                when {
                    score >= 75 -> "A"
                    score >= 65 -> "B"
                    score >= 55 -> "C"
                    score >= pm -> "S"
                    else -> "F"
                }
            }
            
            val status = if (roundedAvg >= 35.0) "🏆 Pass" else "❌ Needs Improvement"
            
            RankedStudent(
                studentId = student.studentId,
                studentName = student.studentName,
                marks = activeMarks,
                grades = grades,
                total = total,
                average = roundedAvg,
                status = status,
                photoBytes = student.photoBytes,
                dob = student.dob,
                gender = student.gender,
                address = student.address,
                guardian = student.guardian,
                phone = student.phone
            )
        }

        // 2. Sort by total descending
        val sortedByTotal = rawRanked.sortedByDescending { it.total }

        // 3. Assign ranks
        val rankedList = mutableListOf<RankedStudent>()
        var currentRank = 1
        var previousTotal = -1
        var sameTotalCount = 0

        for (i in sortedByTotal.indices) {
            val student = sortedByTotal[i]
            if (i == 0) {
                currentRank = 1
                previousTotal = student.total
                sameTotalCount = 1
            } else {
                if (student.total == previousTotal) {
                    sameTotalCount++
                } else {
                    currentRank += sameTotalCount
                    previousTotal = student.total
                    sameTotalCount = 1
                }
            }
            rankedList.add(student.copy(rank = currentRank))
        }

        return rankedList.sortedBy { it.rank }
    }

    suspend fun exportDatabaseToJson(): String {
        val config = repository.schoolConfig.first() ?: SchoolConfig()
        val classes = repository.allClassConfigs.first()
        val subjects = repository.allSubjects.first()
        val students = repository.allStudents.first()
        val users = repository.getAllUsers()

        val rootObj = org.json.JSONObject()

        // School Info
        val schoolObj = org.json.JSONObject()
        schoolObj.put("schoolName", config.schoolName)
        schoolObj.put("examType", config.examType)
        schoolObj.put("academicYear", config.academicYear)
        config.schoolPhotoBytes?.let {
            schoolObj.put("schoolPhotoBase64", android.util.Base64.encodeToString(it, android.util.Base64.DEFAULT))
        }
        rootObj.put("school_info", schoolObj)

        // Classes
        val classesArr = org.json.JSONArray()
        for (c in classes) {
            val cObj = org.json.JSONObject()
            cObj.put("className", c.className)
            cObj.put("classTeacher", c.classTeacher)
            classesArr.put(cObj)
        }
        rootObj.put("classes", classesArr)

        // Subjects
        val subjectsArr = org.json.JSONArray()
        for (s in subjects) {
            val sObj = org.json.JSONObject()
            sObj.put("name", s.name)
            sObj.put("passMark", s.passMark)
            sObj.put("className", s.className)
            subjectsArr.put(sObj)
        }
        rootObj.put("subjects", subjectsArr)

        // Students
        val studentsArr = org.json.JSONArray()
        for (st in students) {
            val stObj = org.json.JSONObject()
            stObj.put("studentId", st.studentId)
            stObj.put("studentName", st.studentName)
            stObj.put("className", st.className)
            stObj.put("dob", st.dob)
            stObj.put("gender", st.gender)
            stObj.put("address", st.address)
            stObj.put("guardian", st.guardian)
            stObj.put("phone", st.phone)
            
            // Marks map
            val marksObj = org.json.JSONObject()
            for ((subName, score) in st.marks) {
                marksObj.put(subName, score)
            }
            stObj.put("marks", marksObj)

            // Photo bytes as base64
            st.photoBytes?.let {
                stObj.put("photoBase64", android.util.Base64.encodeToString(it, android.util.Base64.DEFAULT))
            }

            studentsArr.put(stObj)
        }
        rootObj.put("students", studentsArr)

        // Users
        val usersArr = org.json.JSONArray()
        for (u in users) {
            val uObj = org.json.JSONObject()
            uObj.put("email", u.email)
            uObj.put("passwordHash", u.passwordHash)
            usersArr.put(uObj)
        }
        rootObj.put("users", usersArr)

        return rootObj.toString(4)
    }

    suspend fun importDatabaseFromJson(jsonStr: String): Boolean {
        return try {
            val rootObj = org.json.JSONObject(jsonStr)

            // Clear existing tables
            repository.clearAllClassConfigs()
            repository.clearAllSubjects()
            repository.clearAllStudents()

            // 1. School Info
            if (rootObj.has("school_info")) {
                val schoolObj = rootObj.getJSONObject("school_info")
                val name = schoolObj.optString("schoolName", "")
                val exam = schoolObj.optString("examType", "")
                val year = schoolObj.optString("academicYear", "")
                val photoBase64 = schoolObj.optString("schoolPhotoBase64", "")
                val photoBytes = if (photoBase64.isNotEmpty()) {
                    android.util.Base64.decode(photoBase64, android.util.Base64.DEFAULT)
                } else null

                repository.updateSchoolConfig(
                    SchoolConfig(
                        id = 1,
                        schoolName = name,
                        gradeClass = "",
                        classTeacher = "",
                        examType = exam,
                        academicYear = year,
                        schoolPhotoBytes = photoBytes
                    )
                )
            }

            // 2. Classes
            if (rootObj.has("classes")) {
                val classesArr = rootObj.getJSONArray("classes")
                for (i in 0 until classesArr.length()) {
                    val cObj = classesArr.getJSONObject(i)
                    val className = cObj.getString("className")
                    val classTeacher = cObj.optString("classTeacher", "")
                    repository.insertClassConfig(
                        ClassConfig(className = className, classTeacher = classTeacher)
                    )
                }
            }

            // 3. Subjects
            if (rootObj.has("subjects")) {
                val subjectsArr = rootObj.getJSONArray("subjects")
                for (i in 0 until subjectsArr.length()) {
                    val sObj = subjectsArr.getJSONObject(i)
                    val name = sObj.getString("name")
                    val passMark = sObj.optInt("passMark", 35)
                    val className = sObj.getString("className")
                    repository.addSubject(name, passMark, className)
                }
            }

            // 4. Students
            if (rootObj.has("students")) {
                val studentsArr = rootObj.getJSONArray("students")
                for (i in 0 until studentsArr.length()) {
                    val stObj = studentsArr.getJSONObject(i)
                    val studentId = stObj.getString("studentId")
                    val studentName = stObj.getString("studentName")
                    val className = stObj.getString("className")
                    val dob = stObj.optString("dob", "")
                    val gender = stObj.optString("gender", "Male")
                    val address = stObj.optString("address", "")
                    val guardian = stObj.optString("guardian", "")
                    val phone = stObj.optString("phone", "")

                    val marksMap = mutableMapOf<String, Int>()
                    if (stObj.has("marks")) {
                        val marksObj = stObj.getJSONObject("marks")
                        val keys = marksObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            marksMap[key] = marksObj.getInt(key)
                        }
                    }

                    val photoBase64 = stObj.optString("photoBase64", "")
                    val photoBytes = if (photoBase64.isNotEmpty()) {
                        android.util.Base64.decode(photoBase64, android.util.Base64.DEFAULT)
                    } else null

                    repository.insertStudent(
                        Student(
                            studentId = studentId,
                            studentName = studentName,
                            marks = marksMap,
                            className = className,
                            photoBytes = photoBytes,
                            dob = dob,
                            gender = gender,
                            address = address,
                            guardian = guardian,
                            phone = phone
                        )
                    )
                }
            }

            // 5. Users
            if (rootObj.has("users")) {
                val usersArr = rootObj.getJSONArray("users")
                for (i in 0 until usersArr.length()) {
                    val uObj = usersArr.getJSONObject(i)
                    val email = uObj.getString("email")
                    val passwordHash = uObj.getString("passwordHash")
                    repository.insertUser(User(email, passwordHash))
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
