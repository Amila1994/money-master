package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RankedStudent(
    val studentId: String,
    val studentName: String,
    val marks: Map<String, Int>,
    val grades: Map<String, String> = emptyMap(),
    val total: Int,
    val average: Double,
    val status: String,
    val rank: Int = 0,
    val photoBytes: ByteArray? = null,
    val dob: String = "",
    val gender: String = "Male",
    val address: String = "",
    val guardian: String = "",
    val phone: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SchoolDatabase.getDatabase(application, viewModelScope)
    private val repository = SchoolRepository(database.schoolDao())

    // PIN security system states
    val unlockedClasses = MutableStateFlow<Set<String>>(emptySet())
    val principalVerified = MutableStateFlow(false)
    val principalPinState = MutableStateFlow<String?>(null)
    private val _masterPin = principalPinState
    val isCheckingMasterPin = MutableStateFlow(true)

    // Subscription security system states
    val isSubscribed = MutableStateFlow<Boolean>(true)
    val subscriptionStartDate = MutableStateFlow<com.google.firebase.Timestamp?>(null)
    val subscriptionEndDate = MutableStateFlow<com.google.firebase.Timestamp?>(null)
    val packagePrice = androidx.compose.runtime.mutableStateOf(500)
    val adminMessage = androidx.compose.runtime.mutableStateOf("Subscription expired. Please contact administration to renew.")
    val subscriptionPrices = androidx.compose.runtime.mutableStateOf<Map<String, Long>>(emptyMap())
    val isAppLocked = MutableStateFlow<Boolean>(false)
    val isAccountDisabled = MutableStateFlow<Boolean>(false)

    private var schoolListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null
    private var classesListenerRegistration: com.google.firebase.firestore.ListenerRegistration? = null

    fun validateSubscriptionStatus() {
        val email = currentSchoolEmail ?: return
        val endDate = subscriptionEndDate.value ?: return
        val current = com.google.firebase.Timestamp.now()
        if (current.seconds > endDate.seconds) {
            isSubscribed.value = false
            // Automatically update isSubscribed to false in Firestore and trigger locked state
            db.collection("schools").document(email)
                .update("isSubscribed", false)
                .addOnSuccessListener {
                    android.util.Log.d("MainViewModel", "Subscription expired, isSubscribed updated to false in Firestore")
                }
                .addOnFailureListener { e ->
                    android.util.Log.e("MainViewModel", "Failed to update isSubscribed to false in Firestore: ${e.message}")
                }
        }
    }

    fun listenToClassesInFirestore(email: String) {
        classesListenerRegistration?.remove()
        classesListenerRegistration = db.collection("schools").document(email).collection("classes")
            .addSnapshotListener { querySnapshot, error ->
                if (error != null) {
                    android.util.Log.e("MainViewModel", "Listen to classes subcollection failed: $error")
                    return@addSnapshotListener
                }
                if (querySnapshot != null) {
                    val map = mutableMapOf<String, String>()
                    for (doc in querySnapshot.documents) {
                        val pin = doc.getString("class_pin")
                        if (pin != null) {
                            map[doc.id] = pin
                        }
                    }
                    classPinsState.value = map
                    android.util.Log.d("MainViewModel", "Loaded class PINs from Firestore: $map")
                }
            }
    }

    fun fetchMasterPinFromFirestore(onComplete: (String?) -> Unit = {}) {
        val email = currentSchoolEmail
        if (email.isNullOrBlank()) {
            isCheckingMasterPin.value = false
            onComplete(null)
            return
        }
        isCheckingMasterPin.value = true
        
        listenToClassesInFirestore(email)
        
        schoolListenerRegistration?.remove()
        
        var isFirstTrigger = true
        schoolListenerRegistration = db.collection("schools").document(email)
            .addSnapshotListener { document, error ->
                if (error != null) {
                    android.util.Log.e("MainViewModel", "Listen to school document failed: $error")
                    if (isFirstTrigger) {
                        isCheckingMasterPin.value = false
                        onComplete(null)
                        isFirstTrigger = false
                    }
                    return@addSnapshotListener
                }
                
                if (document != null && document.exists()) {
                    val pin = document.getString("master_pin")
                    if (!pin.isNullOrBlank()) {
                        principalPinState.value = pin
                        pinsRef?.child("principal_pin")?.setValue(pin)
                    }
                    
                    // Fetch the three subscription fields
                    val sub = document.getBoolean("isSubscribed")
                    val start = document.getTimestamp("subscriptionStartDate")
                    val end = document.getTimestamp("subscriptionEndDate")
                    
                    if (sub != null) {
                        isSubscribed.value = sub
                    } else {
                        isSubscribed.value = true
                    }
                    subscriptionStartDate.value = start
                    subscriptionEndDate.value = end

                    // Fetch app lock and account disabled statuses
                    val locked = document.getBoolean("isLocked") ?: document.getBoolean("appLocked") ?: false
                    isAppLocked.value = locked

                    val disabled = document.getBoolean("isDisabled") ?: document.getBoolean("accountDisabled") ?: false
                    isAccountDisabled.value = disabled
                    
                    // Fetch packagePrice (Long/Int)
                    val price = document.getLong("packagePrice")
                    if (price != null) {
                        packagePrice.value = price.toInt()
                    } else {
                        packagePrice.value = 500
                    }

                    // Fetch adminMessage
                    val msg = document.getString("adminMessage")
                    if (!msg.isNullOrBlank()) {
                        adminMessage.value = msg
                    } else {
                        adminMessage.value = "Subscription expired. Please contact administration to renew."
                    }

                    // Fetch prices Map
                    val pricesMap = document.get("prices") as? Map<String, Any>
                    val parsedPrices = mutableMapOf<String, Long>()
                    pricesMap?.forEach { (k, v) ->
                        val longVal = when (v) {
                            is Number -> v.toLong()
                            is String -> v.toLongOrNull() ?: 0L
                            else -> 0L
                        }
                        parsedPrices[k] = longVal
                    }
                    subscriptionPrices.value = parsedPrices
                    
                    validateSubscriptionStatus()
                    
                    if (isFirstTrigger) {
                        isCheckingMasterPin.value = false
                        onComplete(pin)
                        isFirstTrigger = false
                    }
                } else {
                    if (isFirstTrigger) {
                        isCheckingMasterPin.value = false
                        onComplete(null)
                        isFirstTrigger = false
                    }
                }
            }
    }

    override fun onCleared() {
        super.onCleared()
        schoolListenerRegistration?.remove()
        classesListenerRegistration?.remove()
    }

    private val db by lazy {
        com.google.firebase.firestore.FirebaseFirestore.getInstance()
    }
    val classPinsState = MutableStateFlow<Map<String, String>>(emptyMap())
    val isPinsLoading = MutableStateFlow(false)

    // Reference to Firebase Realtime Database
    private val fbDatabase by lazy {
        try {
            FirebaseDatabase.getInstance()
        } catch (e: Exception) {
            android.util.Log.e("MainViewModel", "FirebaseDatabase.getInstance() failed: ${e.message}")
            null
        }
    }

    private val pinsRef by lazy {
        fbDatabase?.reference?.child("school_pins")
    }

    fun fetchPinsFromFirebase() {
        val ref = pinsRef ?: return
        isPinsLoading.value = true
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val principalPin = snapshot.child("principal_pin").getValue(String::class.java)
                if (principalPin != null) {
                    principalPinState.value = principalPin
                }

                val classPinsMap = mutableMapOf<String, String>()
                val classesSnap = snapshot.child("classes")
                for (child in classesSnap.children) {
                    val key = child.key
                    val value = child.getValue(String::class.java)
                    if (key != null && value != null) {
                        classPinsMap[key] = value
                    }
                }
                classPinsState.value = classPinsMap
                isPinsLoading.value = false
                android.util.Log.d("MainViewModel", "Loaded PINs from Firebase: Principal=$principalPin, Classes=$classPinsMap")
            }

            override fun onCancelled(error: DatabaseError) {
                isPinsLoading.value = false
                android.util.Log.e("MainViewModel", "Firebase PIN fetch cancelled: ${error.message}")
            }
        })
    }

    fun saveClassPin(className: String, pin: String, onSuccess: () -> Unit = {}, onFailure: (Exception) -> Unit = {}) {
        val email = currentSchoolEmail
        if (email.isNullOrBlank()) {
            onFailure(Exception("School email is not logged in"))
            return
        }
        val data = mapOf("class_pin" to pin)
        db.collection("schools").document(email).collection("classes").document(className)
            .set(data)
            .addOnSuccessListener {
                pinsRef?.child("classes")?.child(className)?.setValue(pin)
                // Auto-unlock this class once set/changed
                val current = unlockedClasses.value.toMutableSet()
                current.add(className)
                unlockedClasses.value = current
                onSuccess()
            }
            .addOnFailureListener {
                onFailure(it)
            }
    }

    fun deleteClassPin(className: String, onSuccess: () -> Unit = {}, onFailure: (Exception) -> Unit = {}) {
        val email = currentSchoolEmail
        if (email.isNullOrBlank()) {
            onFailure(Exception("School email is not logged in"))
            return
        }
        db.collection("schools").document(email).collection("classes").document(className)
            .update("class_pin", com.google.firebase.firestore.FieldValue.delete())
            .addOnSuccessListener {
                pinsRef?.child("classes")?.child(className)?.removeValue()
                // Remove from unlocked classes set so it locks again
                val current = unlockedClasses.value.toMutableSet()
                current.remove(className)
                unlockedClasses.value = current
                onSuccess()
            }
            .addOnFailureListener {
                onFailure(it)
            }
    }

    fun savePrincipalPin(pin: String, onSuccess: () -> Unit = {}, onFailure: (Exception) -> Unit = {}) {
        val ref = pinsRef ?: run {
            onFailure(Exception("Firebase not initialized"))
            return
        }
        ref.child("principal_pin").setValue(pin)
            .addOnSuccessListener {
                principalVerified.value = true
                principalPinState.value = pin
                onSuccess()
            }
            .addOnFailureListener {
                onFailure(it)
            }
    }

    fun verifyClassPin(className: String, enteredPin: String): Boolean {
        // Principal master PIN bypass
        val masterPin = principalPinState.value
        if (masterPin != null && enteredPin == masterPin) {
            val current = unlockedClasses.value.toMutableSet()
            current.add(className)
            unlockedClasses.value = current
            return true
        }

        // Class-specific PIN match
        val classPin = classPinsState.value[className]
        if (classPin != null && enteredPin == classPin) {
            val current = unlockedClasses.value.toMutableSet()
            current.add(className)
            unlockedClasses.value = current
            return true
        }

        return false
    }

    fun verifyPrincipalPin(enteredPin: String): Boolean {
        val masterPin = principalPinState.value
        if (masterPin != null && enteredPin == masterPin) {
            principalVerified.value = true
            return true
        }
        return false
    }

    val currentSchoolEmail: String?
        get() = FirebaseAuth.getInstance().currentUser?.email ?: loggedInUser.value

    fun sendMasterPinResetEmail(onResult: (Boolean) -> Unit) {
        val email = currentSchoolEmail
        if (!email.isNullOrBlank()) {
            FirebaseAuth.getInstance().sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    onResult(task.isSuccessful)
                }
        } else {
            onResult(false)
        }
    }

    // 🔑 පරිශීලකයා ඇතුළත් කරන ඕනෑම Email එකකට ආරක්ෂිත Password Reset Link එකක් යැවීම
    fun sendGeneralPasswordResetEmail(email: String, onResult: (Boolean) -> Unit) {
        if (email.trim().isNotEmpty()) {
            FirebaseAuth.getInstance().sendPasswordResetEmail(email.trim())
                .addOnCompleteListener { task ->
                    onResult(task.isSuccessful)
                }
        } else {
            onResult(false)
        }
    }

    // 🔑 ප්රින්සිපල්ගේ මුල්ම Master PIN එක සේව් කිරීම සහ ඩේටාබේස් එකට යැවීම
    fun saveInitialMasterPin(newPin: String, onComplete: (Boolean) -> Unit) {
        currentSchoolEmail?.let { email ->
            val now = com.google.firebase.Timestamp.now()
            val calendar = java.util.Calendar.getInstance()
            calendar.time = now.toDate()
            calendar.add(java.util.Calendar.DAY_OF_YEAR, 7) // 7-day trial as requested
            val trialEnd = com.google.firebase.Timestamp(calendar.time)

            val data = mapOf(
                "master_pin" to newPin,
                "subscription_status" to "ACTIVE", // Subscription එකත් මෙතනදීම ACTIVE කරනවා
                "isSubscribed" to true,
                "subscriptionStartDate" to now,
                "subscriptionEndDate" to trialEnd
            )
            
            db.collection("schools").document(email)
                .set(data, com.google.firebase.firestore.SetOptions.merge()) // කලින් තියෙන ඒවා මකන්නේ නැතුව merge කරනවා
                .addOnSuccessListener {
                    _masterPin.value = newPin // Local State එකත් අලුත් PIN එකට මාරු කරනවා
                    principalVerified.value = true // Immediately verify principal to unlock the workspaces
                    isSubscribed.value = true
                    subscriptionStartDate.value = now
                    subscriptionEndDate.value = trialEnd
                    
                    // Synchronize with Realtime Database so that fetchPinsFromFirebase doesn't override it to null
                    pinsRef?.child("principal_pin")?.setValue(newPin)
                        ?.addOnCompleteListener {
                            onComplete(true)
                        } ?: onComplete(true)
                }
                .addOnFailureListener {
                    onComplete(false)
                }
        } ?: onComplete(false)
    }

    fun lockClass(className: String) {
        val current = unlockedClasses.value.toMutableSet()
        current.remove(className)
        unlockedClasses.value = current
    }

    fun lockAll() {
        unlockedClasses.value = emptySet()
        principalVerified.value = false
    }

    fun isClassUnlocked(className: String): Boolean {
        if (principalVerified.value) return true
        return unlockedClasses.value.contains(className)
    }

    fun hasClassPin(className: String): Boolean {
        return classPinsState.value.containsKey(className)
    }

    fun isPrincipalPinSet(): Boolean {
        return !principalPinState.value.isNullOrBlank()
    }

    val loggedInUser = MutableStateFlow<String?>(com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email)
    val isLoggedIn: StateFlow<Boolean> = loggedInUser
        .map { it != null }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

    private val themePrefs = getApplication<Application>().getSharedPreferences("ThemePrefs", Application.MODE_PRIVATE)
    val isDarkTheme = MutableStateFlow(themePrefs.getBoolean("is_dark_theme", false))

    fun toggleDarkTheme(enabled: Boolean) {
        isDarkTheme.value = enabled
        themePrefs.edit().putBoolean("is_dark_theme", enabled).apply()
    }

    init {
        // 1. Silent Auto-Restore from Google Drive / Local Fallback on startup
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val backupJson = com.example.utils.BackupManager.performRestore(getApplication())
                if (!backupJson.isNullOrBlank()) {
                    val success = importDatabaseFromJson(backupJson)
                    if (success) {
                        android.util.Log.d("MainViewModel", "Auto-restore successful on startup.")
                    } else {
                        android.util.Log.e("MainViewModel", "Auto-restore on startup failed: invalid backup JSON.")
                    }
                } else {
                    android.util.Log.d("MainViewModel", "No previous backup found to auto-restore.")
                }
            } catch (e: Exception) {
                android.util.Log.e("MainViewModel", "Auto-restore on startup failed: ${e.message}", e)
            }
        }

        // 2. Silent Auto-Backup on any database updates (debounced to avoid heavy operations)
        viewModelScope.launch(Dispatchers.IO) {
            // Wait a bit before starting observation to let startup restore complete first
            kotlinx.coroutines.delay(5000)
            combine(
                repository.schoolConfig,
                repository.allClassConfigs,
                repository.allSubjects,
                repository.allStudents
            ) { _, _, _, _ ->
                Unit
            }
            .debounce(3000)
            .collectLatest {
                try {
                    val jsonStr = exportDatabaseToJson()
                    com.example.utils.BackupManager.performBackup(getApplication(), jsonStr)
                } catch (e: Exception) {
                    android.util.Log.e("MainViewModel", "Auto-backup failed: ${e.message}", e)
                }
            }
        }
        fetchPinsFromFirebase()
        val email = currentSchoolEmail
        if (!email.isNullOrBlank()) {
            fetchMasterPinFromFirestore()
        } else {
            isCheckingMasterPin.value = false
        }
    }

    suspend fun login(email: String, passwordText: String): Pair<Boolean, String?> {
        return try {
            val result = kotlin.coroutines.suspendCoroutine { continuation ->
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(), passwordText)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val userEmail = task.result?.user?.email ?: email
                            loggedInUser.value = userEmail
                            fetchMasterPinFromFirestore {
                                continuation.resumeWith(Result.success(Pair(true, null)))
                            }
                        } else {
                            val msg = task.exception?.localizedMessage ?: "Invalid Email or Password. Please try again."
                            continuation.resumeWith(Result.success(Pair(false, msg)))
                        }
                    }
            }
            result
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "Firebase Authentication error."
            Pair(false, msg)
        }
    }

    suspend fun register(email: String, passwordHash: String): String? {
        val trimmed = email.trim().lowercase()
        if (trimmed.isBlank() || passwordHash.isBlank()) {
            return "Email and password cannot be empty."
        }
        val existing = repository.getUser(trimmed)
        if (existing != null) {
            return "This email is already registered."
        }
        repository.insertUser(User(trimmed, passwordHash))
        return null
    }

    fun loginWithGoogle(email: String, context: android.content.Context? = null) {
        loggedInUser.value = email.trim().lowercase()
        fetchMasterPinFromFirestore()
        
        if (context != null) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    // Wait a moment for authorization token sync
                    kotlinx.coroutines.delay(1000)
                    val backupJson = com.example.utils.BackupManager.performRestore(context)
                    if (!backupJson.isNullOrBlank()) {
                        val success = importDatabaseFromJson(backupJson)
                        if (success) {
                            android.util.Log.d("MainViewModel", "Auto-restore successful on Google Sign-In.")
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("MainViewModel", "Auto-restore on Google Sign-In failed: ${e.message}")
                }
            }
        }
    }

    fun logout() {
        loggedInUser.value = null
        try {
            FirebaseAuth.getInstance().signOut()
        } catch (e: Exception) {
            // ignore
        }
    }

    val schoolConfig: StateFlow<SchoolConfig> = repository.schoolConfig
        .map { it ?: SchoolConfig() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SchoolConfig()
        )

    val allClassConfigs: StateFlow<List<ClassConfig>> = repository.allClassConfigs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val selectedClass = MutableStateFlow("")

    // Filtered subjects for the active class
    val classSubjects: StateFlow<List<Subject>> = combine(
        selectedClass,
        repository.allSubjects
    ) { selClass, allSubs ->
        if (selClass.isEmpty()) emptyList() else allSubs.filter { it.className == selClass }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Filtered students for the active class, ranked within this class
    val classRankedStudents: StateFlow<List<RankedStudent>> = combine(
        selectedClass,
        repository.allStudents,
        repository.allSubjects
    ) { selClass, allStuds, allSubs ->
        if (selClass.isEmpty()) {
            emptyList()
        } else {
            val classStuds = allStuds.filter { it.className == selClass }
            val classSubs = allSubs.filter { it.className == selClass }
            calculateRankings(classStuds, classSubs)
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // All raw subjects & students for school-wide overview computations
    val allSubjects: StateFlow<List<Subject>> = repository.allSubjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateSchoolConfig(
        schoolName: String,
        gradeClass: String, // Fallback/unused but preserved for compatibility
        classTeacher: String, // Fallback/unused but preserved for compatibility
        examType: String,
        academicYear: String,
        schoolPhotoBytes: ByteArray? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSchoolConfig(
                SchoolConfig(
                    id = 1,
                    schoolName = schoolName,
                    gradeClass = gradeClass,
                    classTeacher = classTeacher,
                    examType = examType,
                    academicYear = academicYear,
                    schoolPhotoBytes = schoolPhotoBytes
                )
            )
        }
    }

    fun selectClass(className: String) {
        selectedClass.value = className
    }

    fun addClass(className: String, teacherName: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertClassConfig(
                ClassConfig(
                    className = className.trim(),
                    classTeacher = teacherName.trim()
                )
            )
            // Auto-select the newly added class
            selectedClass.value = className.trim()
        }
    }

    fun deleteClass(className: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteClassConfig(ClassConfig(className = className, classTeacher = ""))
            repository.clearSubjectsForClass(className)
            repository.clearStudentsForClass(className)
            
            // Switch selection to another class if available
            val remaining = repository.allClassConfigs.firstOrNull() ?: emptyList()
            val nextClass = remaining.firstOrNull { it.className != className }?.className ?: ""
            if (nextClass.isNotEmpty()) {
                selectedClass.value = nextClass
            }
        }
    }

    fun updateClassTeacher(className: String, teacherName: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertClassConfig(
                ClassConfig(
                    className = className,
                    classTeacher = teacherName.trim()
                )
            )
        }
    }

    fun addSubject(name: String, passMark: Int = 35, className: String) {
        if (name.isBlank() || className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSubject(name.trim(), passMark, className)
        }
    }

    fun removeSubject(subject: Subject) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeSubject(subject)
            // Clean up marks for this subject from all students in the same class
            val classStuds = repository.allStudents.first().filter { it.className == subject.className }
            classStuds.forEach { student ->
                if (student.marks.containsKey(subject.name)) {
                    val newMarks = student.marks.filterKeys { it != subject.name }
                    repository.insertStudent(student.copy(marks = newMarks))
                }
            }
        }
    }

    fun renameClass(oldClassName: String, newClassName: String) {
        val old = oldClassName.trim()
        val new = newClassName.trim()
        if (old.isBlank() || new.isBlank() || old == new) return
        viewModelScope.launch(Dispatchers.IO) {
            val configs = repository.allClassConfigs.first()
            val oldConfig = configs.find { it.className == old }
            val teacherName = oldConfig?.classTeacher ?: "Assign Teacher"
            
            repository.insertClassConfig(ClassConfig(className = new, classTeacher = teacherName))
            repository.deleteClassConfig(ClassConfig(className = old, classTeacher = ""))
            
            val classSubs = repository.allSubjects.first().filter { it.className == old }
            classSubs.forEach { sub ->
                repository.removeSubject(sub)
                repository.addSubject(sub.name, sub.passMark, new)
            }
            
            val classStuds = repository.allStudents.first().filter { it.className == old }
            classStuds.forEach { stud ->
                repository.deleteStudent(stud)
                repository.insertStudent(stud.copy(className = new))
            }
            
            selectedClass.value = new
        }
    }

    fun clearSubjectsForClass(className: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearSubjectsForClass(className)
        }
    }

    fun addOrUpdateStudent(studentId: String, studentName: String, marks: Map<String, Int>, className: String, photoBytes: ByteArray? = null) {
        if (studentId.isBlank() || studentName.isBlank() || className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.allStudents.first().find { it.studentId == studentId.trim() }
            val finalPhoto = photoBytes ?: existing?.photoBytes
            val dob = existing?.dob ?: ""
            val gender = existing?.gender ?: "Male"
            val address = existing?.address ?: ""
            val guardian = existing?.guardian ?: ""
            val phone = existing?.phone ?: ""
            repository.insertStudent(
                Student(
                    studentId = studentId.trim(),
                    studentName = studentName.trim(),
                    marks = marks,
                    className = className,
                    photoBytes = finalPhoto,
                    dob = dob,
                    gender = gender,
                    address = address,
                    guardian = guardian,
                    phone = phone
                )
            )
        }
    }

    fun updateStudentProfile(
        studentId: String,
        dob: String,
        gender: String,
        address: String,
        guardian: String,
        phone: String
    ) {
        if (studentId.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.allStudents.first().find { it.studentId == studentId.trim() }
            if (existing != null) {
                repository.insertStudent(
                    existing.copy(
                        dob = dob.trim(),
                        gender = gender.trim(),
                        address = address.trim(),
                        guardian = guardian.trim(),
                        phone = phone.trim()
                    )
                )
            }
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteStudent(
                Student(
                    studentId = studentId,
                    studentName = "",
                    marks = emptyMap()
                )
            )
        }
    }

    fun clearStudentsForClass(className: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearStudentsForClass(className)
        }
    }

    fun calculateRankings(students: List<Student>, subjects: List<Subject>): List<RankedStudent> {
        if (students.isEmpty()) return emptyList()

        val subjectNames = subjects.map { it.name }
        val subjectPassMarks = subjects.associate { it.name to it.passMark }
        
        // 1. Map to raw RankedStudent (without rank)
        val rawRanked = students.map { student ->
            // Only sum marks for subjects that currently exist in the database!
            val activeMarks = student.marks.filterKeys { it in subjectNames }
            val total = activeMarks.values.sum()
            val avg = if (subjectNames.isNotEmpty()) {
                (total.toDouble() / subjectNames.size)
            } else {
                0.0
            }
            val roundedAvg = Math.round(avg * 100.0) / 100.0
            
            // Calculate grade for each active subject mark using subject's specific passMark
            val grades = activeMarks.mapValues { (subName, score) ->
                val pm = subjectPassMarks[subName] ?: 35
                when {
                    score >= 75 -> "A"
                    score >= 65 -> "B"
                    score >= 55 -> "C"
                    score >= pm -> "S"
                    else -> "F"
                }
            }
            
            val status = if (roundedAvg >= 35.0) "🏆 Pass" else "❌ Needs Improvement"
            
            RankedStudent(
                studentId = student.studentId,
                studentName = student.studentName,
                marks = activeMarks,
                grades = grades,
                total = total,
                average = roundedAvg,
                status = status,
                photoBytes = student.photoBytes,
                dob = student.dob,
                gender = student.gender,
                address = student.address,
                guardian = student.guardian,
                phone = student.phone
            )
        }

        // 2. Sort by total descending
        val sortedByTotal = rawRanked.sortedByDescending { it.total }

        // 3. Assign ranks
        val rankedList = mutableListOf<RankedStudent>()
        var currentRank = 1
        var previousTotal = -1
        var sameTotalCount = 0

        for (i in sortedByTotal.indices) {
            val student = sortedByTotal[i]
            if (i == 0) {
                currentRank = 1
                previousTotal = student.total
                sameTotalCount = 1
            } else {
                if (student.total == previousTotal) {
                    sameTotalCount++
                } else {
                    currentRank += sameTotalCount
                    previousTotal = student.total
                    sameTotalCount = 1
                }
            }
            rankedList.add(student.copy(rank = currentRank))
        }

        return rankedList.sortedBy { it.rank }
    }

    suspend fun exportDatabaseToJson(): String {
        val config = repository.schoolConfig.first() ?: SchoolConfig()
        val classes = repository.allClassConfigs.first()
        val subjects = repository.allSubjects.first()
        val students = repository.allStudents.first()
        val users = repository.getAllUsers()

        val rootObj = org.json.JSONObject()

        // School Info
        val schoolObj = org.json.JSONObject()
        schoolObj.put("schoolName", config.schoolName)
        schoolObj.put("examType", config.examType)
        schoolObj.put("academicYear", config.academicYear)
        config.schoolPhotoBytes?.let {
            schoolObj.put("schoolPhotoBase64", android.util.Base64.encodeToString(it, android.util.Base64.DEFAULT))
        }
        rootObj.put("school_info", schoolObj)

        // Classes
        val classesArr = org.json.JSONArray()
        for (c in classes) {
            val cObj = org.json.JSONObject()
            cObj.put("className", c.className)
            cObj.put("classTeacher", c.classTeacher)
            classesArr.put(cObj)
        }
        rootObj.put("classes", classesArr)

        // Subjects
        val subjectsArr = org.json.JSONArray()
        for (s in subjects) {
            val sObj = org.json.JSONObject()
            sObj.put("name", s.name)
            sObj.put("passMark", s.passMark)
            sObj.put("className", s.className)
            subjectsArr.put(sObj)
        }
        rootObj.put("subjects", subjectsArr)

        // Students
        val studentsArr = org.json.JSONArray()
        for (st in students) {
            val stObj = org.json.JSONObject()
            stObj.put("studentId", st.studentId)
            stObj.put("studentName", st.studentName)
            stObj.put("className", st.className)
            stObj.put("dob", st.dob)
            stObj.put("gender", st.gender)
            stObj.put("address", st.address)
            stObj.put("guardian", st.guardian)
            stObj.put("phone", st.phone)
            
            // Marks map
            val marksObj = org.json.JSONObject()
            for ((subName, score) in st.marks) {
                marksObj.put(subName, score)
            }
            stObj.put("marks", marksObj)

            // Photo bytes as base64
            st.photoBytes?.let {
                stObj.put("photoBase64", android.util.Base64.encodeToString(it, android.util.Base64.DEFAULT))
            }

            studentsArr.put(stObj)
        }
        rootObj.put("students", studentsArr)

        // Users
        val usersArr = org.json.JSONArray()
        for (u in users) {
            val uObj = org.json.JSONObject()
            uObj.put("email", u.email)
            uObj.put("passwordHash", u.passwordHash)
            usersArr.put(uObj)
        }
        rootObj.put("users", usersArr)

        return rootObj.toString(4)
    }

    suspend fun importDatabaseFromJson(jsonStr: String): Boolean {
        return try {
            val rootObj = org.json.JSONObject(jsonStr)

            // Clear existing tables
            repository.clearAllClassConfigs()
            repository.clearAllSubjects()
            repository.clearAllStudents()

            // 1. School Info
            if (rootObj.has("school_info")) {
                val schoolObj = rootObj.getJSONObject("school_info")
                val name = schoolObj.optString("schoolName", "")
                val exam = schoolObj.optString("examType", "")
                val year = schoolObj.optString("academicYear", "")
                val photoBase64 = schoolObj.optString("schoolPhotoBase64", "")
                val photoBytes = if (photoBase64.isNotEmpty()) {
                    android.util.Base64.decode(photoBase64, android.util.Base64.DEFAULT)
                } else null

                repository.updateSchoolConfig(
                    SchoolConfig(
                        id = 1,
                        schoolName = name,
                        gradeClass = "",
                        classTeacher = "",
                        examType = exam,
                        academicYear = year,
                        schoolPhotoBytes = photoBytes
                    )
                )
            }

            // 2. Classes
            if (rootObj.has("classes")) {
                val classesArr = rootObj.getJSONArray("classes")
                for (i in 0 until classesArr.length()) {
                    val cObj = classesArr.getJSONObject(i)
                    val className = cObj.getString("className")
                    val classTeacher = cObj.optString("classTeacher", "")
                    repository.insertClassConfig(
                        ClassConfig(className = className, classTeacher = classTeacher)
                    )
                }
            }

            // 3. Subjects
            if (rootObj.has("subjects")) {
                val subjectsArr = rootObj.getJSONArray("subjects")
                for (i in 0 until subjectsArr.length()) {
                    val sObj = subjectsArr.getJSONObject(i)
                    val name = sObj.getString("name")
                    val passMark = sObj.optInt("passMark", 35)
                    val className = sObj.getString("className")
                    repository.addSubject(name, passMark, className)
                }
            }

            // 4. Students
            if (rootObj.has("students")) {
                val studentsArr = rootObj.getJSONArray("students")
                for (i in 0 until studentsArr.length()) {
                    val stObj = studentsArr.getJSONObject(i)
                    val studentId = stObj.getString("studentId")
                    val studentName = stObj.getString("studentName")
                    val className = stObj.getString("className")
                    val dob = stObj.optString("dob", "")
                    val gender = stObj.optString("gender", "Male")
                    val address = stObj.optString("address", "")
                    val guardian = stObj.optString("guardian", "")
                    val phone = stObj.optString("phone", "")

                    val marksMap = mutableMapOf<String, Int>()
                    if (stObj.has("marks")) {
                        val marksObj = stObj.getJSONObject("marks")
                        val keys = marksObj.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            marksMap[key] = marksObj.getInt(key)
                        }
                    }

                    val photoBase64 = stObj.optString("photoBase64", "")
                    val photoBytes = if (photoBase64.isNotEmpty()) {
                        android.util.Base64.decode(photoBase64, android.util.Base64.DEFAULT)
                    } else null

                    repository.insertStudent(
                        Student(
                            studentId = studentId,
                            studentName = studentName,
                            marks = marksMap,
                            className = className,
                            photoBytes = photoBytes,
                            dob = dob,
                            gender = gender,
                            address = address,
                            guardian = guardian,
                            phone = phone
                        )
                    )
                }
            }

            // 5. Users
            if (rootObj.has("users")) {
                val usersArr = rootObj.getJSONArray("users")
                for (i in 0 until usersArr.length()) {
                    val uObj = usersArr.getJSONObject(i)
                    val email = uObj.getString("email")
                    val passwordHash = uObj.getString("passwordHash")
                    repository.insertUser(User(email, passwordHash))
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
