package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RankedStudent(
    val studentId: String,
    val studentName: String,
    val marks: Map<String, Int>,
    val grades: Map<String, String> = emptyMap(),
    val total: Int,
    val average: Double,
    val status: String,
    val rank: Int = 0
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = SchoolDatabase.getDatabase(application, viewModelScope)
    private val repository = SchoolRepository(database.schoolDao())

    val schoolConfig: StateFlow<SchoolConfig> = repository.schoolConfig
        .map { it ?: SchoolConfig() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SchoolConfig()
        )

    val allClassConfigs: StateFlow<List<ClassConfig>> = repository.allClassConfigs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val selectedClass = MutableStateFlow("10-A")

    // Filtered subjects for the active class
    val classSubjects: StateFlow<List<Subject>> = combine(
        selectedClass,
        repository.allSubjects
    ) { selClass, allSubs ->
        allSubs.filter { it.className == selClass }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Filtered students for the active class, ranked within this class
    val classRankedStudents: StateFlow<List<RankedStudent>> = combine(
        selectedClass,
        repository.allStudents,
        repository.allSubjects
    ) { selClass, allStuds, allSubs ->
        val classStuds = allStuds.filter { it.className == selClass }
        val classSubs = allSubs.filter { it.className == selClass }
        calculateRankings(classStuds, classSubs)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // All raw subjects & students for school-wide overview computations
    val allSubjects: StateFlow<List<Subject>> = repository.allSubjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allStudents: StateFlow<List<Student>> = repository.allStudents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateSchoolConfig(
        schoolName: String,
        gradeClass: String, // Fallback/unused but preserved for compatibility
        classTeacher: String, // Fallback/unused but preserved for compatibility
        examType: String,
        academicYear: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSchoolConfig(
                SchoolConfig(
                    id = 1,
                    schoolName = schoolName,
                    gradeClass = gradeClass,
                    classTeacher = classTeacher,
                    examType = examType,
                    academicYear = academicYear
                )
            )
        }
    }

    fun selectClass(className: String) {
        selectedClass.value = className
    }

    fun addClass(className: String, teacherName: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertClassConfig(
                ClassConfig(
                    className = className.trim(),
                    classTeacher = teacherName.trim()
                )
            )
            // Auto-select the newly added class
            selectedClass.value = className.trim()
        }
    }

    fun deleteClass(className: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteClassConfig(ClassConfig(className = className, classTeacher = ""))
            repository.clearSubjectsForClass(className)
            repository.clearStudentsForClass(className)
            
            // Switch selection to another class if available
            val remaining = repository.allClassConfigs.firstOrNull() ?: emptyList()
            val nextClass = remaining.firstOrNull { it.className != className }?.className ?: ""
            if (nextClass.isNotEmpty()) {
                selectedClass.value = nextClass
            }
        }
    }

    fun updateClassTeacher(className: String, teacherName: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertClassConfig(
                ClassConfig(
                    className = className,
                    classTeacher = teacherName.trim()
                )
            )
        }
    }

    fun addSubject(name: String, passMark: Int = 35, className: String) {
        if (name.isBlank() || className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSubject(name.trim(), passMark, className)
        }
    }

    fun removeSubject(subject: Subject) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeSubject(subject)
        }
    }

    fun clearSubjectsForClass(className: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearSubjectsForClass(className)
        }
    }

    fun addOrUpdateStudent(studentId: String, studentName: String, marks: Map<String, Int>, className: String) {
        if (studentId.isBlank() || studentName.isBlank() || className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertStudent(
                Student(
                    studentId = studentId.trim(),
                    studentName = studentName.trim(),
                    marks = marks,
                    className = className
                )
            )
        }
    }

    fun deleteStudent(studentId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteStudent(
                Student(
                    studentId = studentId,
                    studentName = "",
                    marks = emptyMap()
                )
            )
        }
    }

    fun clearStudentsForClass(className: String) {
        if (className.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearStudentsForClass(className)
        }
    }

    fun calculateRankings(students: List<Student>, subjects: List<Subject>): List<RankedStudent> {
        if (students.isEmpty()) return emptyList()

        val subjectNames = subjects.map { it.name }
        val subjectPassMarks = subjects.associate { it.name to it.passMark }
        
        // 1. Map to raw RankedStudent (without rank)
        val rawRanked = students.map { student ->
            // Only sum marks for subjects that currently exist in the database!
            val activeMarks = student.marks.filterKeys { it in subjectNames }
            val total = activeMarks.values.sum()
            val avg = if (subjectNames.isNotEmpty()) {
                (total.toDouble() / subjectNames.size)
            } else {
                0.0
            }
            val roundedAvg = Math.round(avg * 100.0) / 100.0
            
            // Calculate grade for each active subject mark using subject's specific passMark
            val grades = activeMarks.mapValues { (subName, score) ->
                val pm = subjectPassMarks[subName] ?: 35
                when {
                    score >= 75 -> "A"
                    score >= 65 -> "B"
                    score >= 55 -> "C"
                    score >= pm -> "S"
                    else -> "F"
                }
            }
            
            val status = if (roundedAvg >= 35.0) "🏆 Pass" else "❌ Needs Improvement"
            
            RankedStudent(
                studentId = student.studentId,
                studentName = student.studentName,
                marks = activeMarks,
                grades = grades,
                total = total,
                average = roundedAvg,
                status = status
            )
        }

        // 2. Sort by total descending
        val sortedByTotal = rawRanked.sortedByDescending { it.total }

        // 3. Assign ranks
        val rankedList = mutableListOf<RankedStudent>()
        var currentRank = 1
        var previousTotal = -1
        var sameTotalCount = 0

        for (i in sortedByTotal.indices) {
            val student = sortedByTotal[i]
            if (i == 0) {
                currentRank = 1
                previousTotal = student.total
                sameTotalCount = 1
            } else {
                if (student.total == previousTotal) {
                    sameTotalCount++
                } else {
                    currentRank += sameTotalCount
                    previousTotal = student.total
                    sameTotalCount = 1
                }
            }
            rankedList.add(student.copy(rank = currentRank))
        }

        return rankedList.sortedBy { it.rank }
    }
}
