package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import com.example.data.ClassConfig
import com.example.data.SchoolConfig
import com.example.data.Subject
import com.example.utils.PdfGenerator
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val schoolConfig by viewModel.schoolConfig.collectAsState()
    val allClassConfigs by viewModel.allClassConfigs.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()
    val classSubjects by viewModel.classSubjects.collectAsState()
    val classRankedStudents by viewModel.classRankedStudents.collectAsState()
    val allSubjects by viewModel.allSubjects.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()

    var mainTabIndex by remember { mutableIntStateOf(0) }
    val mainTabs = listOf(
        "🏠 Home & Overview",
        "⚙️ School Settings",
        "📊 Class Workspaces"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = schoolConfig.schoolName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.testTag("navigation_bar")
            ) {
                mainTabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        icon = {
                            val icon = when (index) {
                                0 -> Icons.Default.Home
                                1 -> Icons.Default.Settings
                                else -> Icons.Default.Workspaces
                            }
                            Icon(icon, contentDescription = label)
                        },
                        label = { Text(label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        selected = mainTabIndex == index,
                        onClick = { mainTabIndex = index }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (mainTabIndex) {
                0 -> HomeOverviewTab(
                    schoolConfig = schoolConfig,
                    classes = allClassConfigs,
                    allStudents = allStudents,
                    allSubjects = allSubjects,
                    viewModel = viewModel
                )
                1 -> SchoolSettingsTab(
                    schoolConfig = schoolConfig,
                    onUpdateConfig = { name, exam, year ->
                        viewModel.updateSchoolConfig(name, "", "", exam, year)
                        Toast.makeText(context, "School settings saved successfully!", Toast.LENGTH_SHORT).show()
                    }
                )
                2 -> ClassWorkspacesTab(
                    selectedClass = selectedClass,
                    classes = allClassConfigs,
                    subjects = classSubjects,
                    students = classRankedStudents,
                    schoolConfig = schoolConfig,
                    viewModel = viewModel
                )
            }
        }
    }
}

// ==========================================
// TAB 1: HOME & OVERVIEW
// ==========================================
@Composable
fun HomeOverviewTab(
    schoolConfig: SchoolConfig,
    classes: List<ClassConfig>,
    allStudents: List<com.example.data.Student>,
    allSubjects: List<Subject>,
    viewModel: MainViewModel
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            )
                        )
                        .padding(24.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "🏫 ${schoolConfig.schoolName.uppercase()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${schoolConfig.examType} — ${schoolConfig.academicYear}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "✨ WELCOME TO THE SCHOOL MANAGEMENT & RANKING PORTAL ✨\nපන්ති ප්‍රතිඵල, සාමාර්ථ සහ ශ්‍රේණිගත කිරීම් ස්වයංක්‍රීයව සකස් කරන පද්ධතිය",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "📊 All Classes Summary (Overview)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (classes.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No classes added yet. Go to the Class Workspaces tab to create classes.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(classes, key = { it.className }) { classConfig ->
                val classStudents = allStudents.filter { it.className == classConfig.className }
                val classSubjects = allSubjects.filter { it.className == classConfig.className }
                val ranked = viewModel.calculateRankings(classStudents, classSubjects)
                val topStudent = ranked.firstOrNull()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = classConfig.className,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = classConfig.classTeacher,
                                    fontWeight = FontWeight.Medium,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "👥 Students: ${classStudents.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "📚 Subjects: ${classSubjects.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (topStudent != null) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "🏆 Class Top: ${topStudent.studentName} (${topStudent.total} Marks)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            } else {
                                Text(
                                    text = "🏆 Class Top: N/A",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = "Go to workspace",
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                            modifier = Modifier
                                .size(16.dp)
                                .clickable {
                                    viewModel.selectClass(classConfig.className)
                                }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 2: SCHOOL SETTINGS
// ==========================================
@Composable
fun SchoolSettingsTab(
    schoolConfig: SchoolConfig,
    onUpdateConfig: (String, String, String) -> Unit
) {
    var schoolName by remember(schoolConfig) { mutableStateOf(schoolConfig.schoolName) }
    var examType by remember(schoolConfig) { mutableStateOf(schoolConfig.examType) }
    var academicYear by remember(schoolConfig) { mutableStateOf(schoolConfig.academicYear) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "⚙️ School & Examination Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "පාසලේ පොදු විස්තර සහ ප්‍රධාන තොරතුරු මෙතැනින් වෙනස් කරන්න:",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = schoolName,
                        onValueChange = { schoolName = it },
                        label = { Text("පාසලේ නම (School Name)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = examType,
                        onValueChange = { examType = it },
                        label = { Text("විභාග වර්ගය (Exam Type)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text("අධ්‍යයන වර්ෂය (Year)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Button(
                        onClick = { onUpdateConfig(schoolName, examType, academicYear) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_settings_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save School Settings")
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 3: CLASS WORKSPACES
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ClassWorkspacesTab(
    selectedClass: String,
    classes: List<ClassConfig>,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    var showAddClassDialog by remember { mutableStateOf(false) }
    var newClassName by remember { mutableStateOf("") }
    var newClassTeacher by remember { mutableStateOf("") }

    var workspaceTabIndex by remember { mutableIntStateOf(0) }
    val workspaceTabs = listOf("📝 Marks", "📊 Grades", "🏆 Rankings")

    val activeClassConfig = classes.firstOrNull { it.className == selectedClass }
    var teacherNameInput by remember(activeClassConfig) { mutableStateOf(activeClassConfig?.classTeacher ?: "") }

    var showAddSubjectSection by remember { mutableStateOf(false) }
    var newSubjectName by remember { mutableStateOf("") }
    var newSubjectPassMark by remember { mutableStateOf(35) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Class Selection & Management Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "🎯 Select Class (වැඩ කිරීමට පන්තිය තෝරන්න):",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            if (classes.isEmpty()) {
                                Text(
                                    text = "No Classes",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            } else {
                                var expandedClassDropdown by remember { mutableStateOf(false) }
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { expandedClassDropdown = true }
                                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = selectedClass,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                    DropdownMenu(
                                        expanded = expandedClassDropdown,
                                        onDismissRequest = { expandedClassDropdown = false }
                                    ) {
                                        classes.forEach { c ->
                                            DropdownMenuItem(
                                                text = { Text(c.className, fontWeight = FontWeight.Bold) },
                                                onClick = {
                                                    viewModel.selectClass(c.className)
                                                    expandedClassDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Add Class Button
                            IconButton(
                                onClick = { showAddClassDialog = true },
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add Class", tint = MaterialTheme.colorScheme.onPrimaryContainer)
                            }

                            // Delete Class Button
                            if (classes.isNotEmpty()) {
                                var showDeleteConfirmation by remember { mutableStateOf(false) }
                                IconButton(
                                    onClick = { showDeleteConfirmation = true },
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.errorContainer)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Class", tint = MaterialTheme.colorScheme.onErrorContainer)
                                }

                                if (showDeleteConfirmation) {
                                    AlertDialog(
                                        onDismissRequest = { showDeleteConfirmation = false },
                                        title = { Text("Delete Entire Class?") },
                                        text = { Text("Are you sure you want to delete class $selectedClass? This will also clear all subjects and students associated with this class. This action cannot be undone.") },
                                        confirmButton = {
                                            TextButton(
                                                onClick = {
                                                    viewModel.deleteClass(selectedClass)
                                                    showDeleteConfirmation = false
                                                }
                                            ) {
                                                Text("Yes, Delete", color = MaterialTheme.colorScheme.error)
                                            }
                                        },
                                        dismissButton = {
                                            TextButton(onClick = { showDeleteConfirmation = false }) {
                                                Text("Cancel")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Dynamic Rename Class Text Field
                    if (classes.isNotEmpty()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            var renameInput by remember(selectedClass) { mutableStateOf(selectedClass) }
                            OutlinedTextField(
                                value = renameInput,
                                onValueChange = { renameInput = it },
                                label = { Text("✏️ පන්තියේ නම වෙනස් කරන්න (Rename Class)") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp)
                            )
                            IconButton(
                                onClick = {
                                    if (renameInput.isNotBlank() && renameInput != selectedClass) {
                                        viewModel.renameClass(selectedClass, renameInput)
                                        Toast.makeText(context, "Class renamed successfully!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .size(48.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Rename Class", tint = Color.White)
                            }
                        }
                    }

                    if (activeClassConfig != null) {
                        // Class Teacher row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = teacherNameInput,
                                onValueChange = { teacherNameInput = it },
                                label = { Text("🧑‍🏫 Class Teacher") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp)
                            )
                            IconButton(
                                onClick = {
                                    viewModel.updateClassTeacher(selectedClass, teacherNameInput)
                                    Toast.makeText(context, "Teacher saved!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .size(48.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Save Teacher", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }

        if (activeClassConfig != null) {
            // Subject Management Section with Secure Dropdown Checkbox Protection
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📚 Subject Management",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(onClick = { showAddSubjectSection = !showAddSubjectSection }) {
                                Text(if (showAddSubjectSection) "Collapse" else "➕ Add Subject")
                            }
                        }

                        if (showAddSubjectSection) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = newSubjectName,
                                    onValueChange = { newSubjectName = it },
                                    label = { Text("Subject Name") },
                                    placeholder = { Text("e.g. Mathematics, Science") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                OutlinedTextField(
                                    value = newSubjectPassMark.toString(),
                                    onValueChange = { newSubjectPassMark = it.toIntOrNull() ?: 35 },
                                    label = { Text("Pass Mark") },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                Button(
                                    onClick = {
                                        if (newSubjectName.isNotBlank()) {
                                            viewModel.addSubject(newSubjectName, newSubjectPassMark, selectedClass)
                                            newSubjectName = ""
                                            showAddSubjectSection = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Add Subject to Class")
                                }
                            }
                        }

                        if (subjects.isEmpty()) {
                            Text(
                                text = "No subjects in this class yet. Add some subjects above to begin adding marks.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        } else {
                            Text(
                                text = "Active Class Subjects:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                subjects.forEach { sub ->
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("${sub.name} (${sub.passMark})") }
                                    )
                                }
                            }

                            // Safe Subject Deletion with confirmation dropdown and checkbox (Subject Delete Protection)
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = "🛡️ Delete Subject with Protection (විෂයන් මකා දැමීම):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            
                            var selectedSubToDelete by remember { mutableStateOf<Subject?>(null) }
                            var isConfirmCheckboxChecked by remember { mutableStateOf(false) }
                            var expandedDeleteDropdown by remember { mutableStateOf(false) }
                            
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandedDeleteDropdown = true }
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = selectedSubToDelete?.name ?: "-- Select Subject to Delete --",
                                        fontWeight = FontWeight.Medium,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (selectedSubToDelete != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                                DropdownMenu(
                                    expanded = expandedDeleteDropdown,
                                    onDismissRequest = { expandedDeleteDropdown = false },
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("-- Select Subject to Delete --") },
                                        onClick = {
                                            selectedSubToDelete = null
                                            isConfirmCheckboxChecked = false
                                            expandedDeleteDropdown = false
                                        }
                                    )
                                    subjects.forEach { sub ->
                                        DropdownMenuItem(
                                            text = { Text(sub.name) },
                                            onClick = {
                                                selectedSubToDelete = sub
                                                isConfirmCheckboxChecked = false
                                                expandedDeleteDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                            
                            val activeSubToDel = selectedSubToDelete
                            if (activeSubToDel != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(
                                        checked = isConfirmCheckboxChecked,
                                        onCheckedChange = { isConfirmCheckboxChecked = it }
                                    )
                                    Text(
                                        text = "⚠️ මම ස්ථිරවම ${activeSubToDel.name} විෂය සහ එහි සියලුම ලකුණු මකා දැමීමට එකඟ වෙමි.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                
                                Button(
                                    onClick = {
                                        viewModel.removeSubject(activeSubToDel)
                                        Toast.makeText(context, "${activeSubToDel.name} deleted safely!", Toast.LENGTH_SHORT).show()
                                        selectedSubToDelete = null
                                        isConfirmCheckboxChecked = false
                                    },
                                    enabled = isConfirmCheckboxChecked,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Confirm Delete Subject")
                                }
                            }
                        }
                    }
                }
            }

            // Sub-Tabs within the workspace
            item {
                TabRow(
                    selectedTabIndex = workspaceTabIndex,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    workspaceTabs.forEachIndexed { index, label ->
                        Tab(
                            selected = workspaceTabIndex == index,
                            onClick = { workspaceTabIndex = index },
                            text = { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Render selected Workspace Sub-Tab
            item {
                when (workspaceTabIndex) {
                    0 -> WorkspaceStudentMarksView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        viewModel = viewModel
                    )
                    1 -> WorkspaceStudentGradesView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students
                    )
                    2 -> WorkspaceRankingsExportView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        classConfig = activeClassConfig
                    )
                }
            }
        }
    }

    // Add Class Dialog
    if (showAddClassDialog) {
        Dialog(onDismissRequest = { showAddClassDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "➕ Create New Class Workspace",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedTextField(
                        value = newClassName,
                        onValueChange = { newClassName = it },
                        label = { Text("Class Name (e.g., 10-C)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newClassTeacher,
                        onValueChange = { newClassTeacher = it },
                        label = { Text("Class Teacher Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showAddClassDialog = false }) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newClassName.isNotBlank()) {
                                    viewModel.addClass(newClassName, newClassTeacher)
                                    newClassName = ""
                                    newClassTeacher = ""
                                    showAddClassDialog = false
                                }
                            }
                        ) {
                            Text("Create")
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 1: STUDENT MARKS VIEW
// ==========================================
@Composable
fun WorkspaceStudentMarksView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var showAddStudentDialog by remember { mutableStateOf(false) }

    // Student fields for Add/Edit
    var editingStudentId by remember { mutableStateOf("") }
    var editingStudentName by remember { mutableStateOf("") }
    var isEditMode by remember { mutableStateOf(false) }
    var photoBytesSelected by remember { mutableStateOf<ByteArray?>(null) }
    val editingStudentMarks = remember { mutableStateMapOf<String, String>() }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            photoBytesSelected = it.toByteArray(context)
        }
    }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("🔍 Search students...") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(8.dp)
            )

            Button(
                onClick = {
                    isEditMode = false
                    editingStudentId = ""
                    editingStudentName = ""
                    photoBytesSelected = null
                    editingStudentMarks.clear()
                    subjects.forEach { editingStudentMarks[it.name] = "" }
                    showAddStudentDialog = true
                },
                modifier = Modifier.height(56.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Student")
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No students found. Use 'Add Student' above to start entering data.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            filtered.forEach { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Display Student circular portrait photo (Circular Avatar Preview)
                        val avatarBitmap = remember(student.photoBytes) {
                            student.photoBytes?.let {
                                android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                            }?.asImageBitmap()
                        }
                        
                        if (avatarBitmap != null) {
                            Image(
                                bitmap = avatarBitmap,
                                contentDescription = "Student Photo",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = student.studentName,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    Text(
                                        text = "ID: ${student.studentId}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            isEditMode = true
                                            editingStudentId = student.studentId
                                            editingStudentName = student.studentName
                                            photoBytesSelected = student.photoBytes
                                            editingStudentMarks.clear()
                                            subjects.forEach {
                                                editingStudentMarks[it.name] = (student.marks[it.name] ?: 0).toString()
                                            }
                                            showAddStudentDialog = true
                                        }
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit student", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteStudent(student.studentId) }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete student", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }

                            // Marks summary
                            Text(
                                text = subjects.joinToString("  |  ") { sub ->
                                    "${sub.name}: ${student.marks[sub.name] ?: 0}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    // Add/Edit Student Dialog with custom Portrait Photo selector
    if (showAddStudentDialog) {
        Dialog(onDismissRequest = { showAddStudentDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = if (isEditMode) "✏️ Edit Student Info & Marks" else "➕ Add Student to $selectedClass",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = editingStudentId,
                            onValueChange = { if (!isEditMode) editingStudentId = it },
                            label = { Text("Student ID (e.g. ST001)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            enabled = !isEditMode,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = editingStudentName,
                            onValueChange = { editingStudentName = it },
                            label = { Text("Student Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    // Photo Picker Layout
                    item {
                        Text(
                            text = "👦 ළමුන්ගේ පින්තූර ඇතුළත් කරන්න (Student Photo):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val bitmap = remember(photoBytesSelected) {
                                photoBytesSelected?.let {
                                    android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                }?.asImageBitmap()
                            }
                            
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = "Selected Photo",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { photoPickerLauncher.launch("image/*") },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Upload Photo")
                                }
                                if (photoBytesSelected != null) {
                                    TextButton(
                                        onClick = { photoBytesSelected = null }
                                    ) {
                                        Text("Remove Photo", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }

                    if (subjects.isNotEmpty()) {
                        item {
                            Text(
                                text = "Enter Subject Marks:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        items(subjects, key = { it.id }) { sub ->
                            var markVal by remember { mutableStateOf(editingStudentMarks[sub.name] ?: "") }
                            OutlinedTextField(
                                value = markVal,
                                onValueChange = {
                                    markVal = it
                                    editingStudentMarks[sub.name] = it
                                },
                                label = { Text("${sub.name} (Pass Mark: ${sub.passMark})") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showAddStudentDialog = false }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (editingStudentId.isNotBlank() && editingStudentName.isNotBlank()) {
                                        val marksMap = subjects.associate { sub ->
                                            sub.name to (editingStudentMarks[sub.name]?.toIntOrNull() ?: 0)
                                        }
                                        viewModel.addOrUpdateStudent(
                                            studentId = editingStudentId,
                                            studentName = editingStudentName,
                                            marks = marksMap,
                                            className = selectedClass,
                                            photoBytes = photoBytesSelected
                                        )
                                        showAddStudentDialog = false
                                    }
                                }
                            ) {
                                Text("Save")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 2: STUDENT GRADES VIEW
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkspaceStudentGradesView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>
) {
    var searchQuery by remember { mutableStateOf("") }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("🔍 සාමාර්ථ බැලීමට ශිෂ්‍ය නම/ID ටයිප් කරන්න") },
            placeholder = { Text("Search grades by name or ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(8.dp)
        )

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No matching students found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            filtered.forEach { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = student.studentName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "ID: ${student.studentId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "Avg: ${student.average}%",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(
                            modifier = Modifier
                                .height(1.dp)
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        )

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            subjects.forEach { subject ->
                                val score = student.marks[subject.name] ?: 0
                                val grade = student.grades[subject.name] ?: "F"
                                
                                val badgeColor = when (grade) {
                                    "A" -> Color(0xFFE6F4EA)
                                    "B" -> Color(0xFFE8F0FE)
                                    "C" -> Color(0xFFE2F1F8)
                                    "S" -> Color(0xFFFEF7E0)
                                    else -> Color(0xFFFCE8E6)
                                }
                                val textColor = when (grade) {
                                    "A" -> Color(0xFF137333)
                                    "B" -> Color(0xFF1A73E8)
                                    "C" -> Color(0xFF00838F)
                                    "S" -> Color(0xFFB06000)
                                    else -> Color(0xFFC5221F)
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.border(
                                        width = 1.dp,
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "${subject.name}: $score",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(badgeColor)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = grade,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = textColor
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 3: RANKINGS & EXPORT
// ==========================================
@Composable
fun WorkspaceRankingsExportView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    classConfig: ClassConfig?
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true) ||
            it.rank.toString() == searchQuery
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("🔍 සාමාර්ථ / ශ්‍රේණිගත කිරීම් සෙවීම (Search Rankings...)") },
            placeholder = { Text("Search by rank, name or ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(8.dp)
        )

        // Rankings list
        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No ranked data found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            filtered.forEach { student ->
                val medalIcon = when (student.rank) {
                    1 -> "🥇 "
                    2 -> "🥈 "
                    3 -> "🥉 "
                    else -> "#${student.rank} "
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.dp,
                        color = when (student.rank) {
                            1 -> Color(0xFFFFD700)
                            2 -> Color(0xFFC0C0C0)
                            3 -> Color(0xFFCD7F32)
                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Circular photo preview inside ranked list row
                            val rankAvatarBitmap = remember(student.photoBytes) {
                                student.photoBytes?.let {
                                    android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                }?.asImageBitmap()
                            }
                            
                            if (rankAvatarBitmap != null) {
                                Image(
                                    bitmap = rankAvatarBitmap,
                                    contentDescription = "Photo",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .border(0.5.dp, MaterialTheme.colorScheme.outline, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = medalIcon,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = student.studentName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "ID: ${student.studentId}  |  Total: ${student.total}  |  Average: ${student.average}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Status badge
                        val badgeColor = if (student.status.contains("Pass")) Color(0xFFE6F4EA) else Color(0xFFFCE8E6)
                        val badgeTextColor = if (student.status.contains("Pass")) Color(0xFF137333) else Color(0xFFC5221F)

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badgeColor)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = student.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeTextColor
                            )
                        }
                    }
                }
            }
        }

        // Individual Progress Report Card Generator
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "🧑‍🎓 Individual Student Report Card Generator",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Text(
                    text = "ප්‍රගති වාර්තාව (Individual PDF) සෑදීම සඳහා ශිෂ්‍යයා තෝරන්න:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                var selectedStudentForReport by remember(students) { mutableStateOf(students.firstOrNull()) }
                var expandedStudentDropdown by remember { mutableStateOf(false) }

                Box(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandedStudentDropdown = true }
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = selectedStudentForReport?.studentName ?: "Select a student...",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (selectedStudentForReport != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    DropdownMenu(
                        expanded = expandedStudentDropdown,
                        onDismissRequest = { expandedStudentDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        students.forEach { std ->
                            DropdownMenuItem(
                                text = { Text("[${std.studentId}] ${std.studentName}", fontWeight = FontWeight.Bold) },
                                onClick = {
                                    selectedStudentForReport = std
                                    expandedStudentDropdown = false
                                }
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val currentStudent = selectedStudentForReport
                        if (currentStudent == null) {
                            Toast.makeText(context, "Please select a student first!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "Report_Card_${currentStudent.studentId}.pdf")
                            val fos = FileOutputStream(pdfFile)
                            val subjectNames = subjects.map { it.name }
                            
                            PdfGenerator.generateIndividualReport(
                                context = context,
                                config = schoolConfig,
                                className = selectedClass,
                                classTeacher = classConfig?.classTeacher ?: "Unknown",
                                student = currentStudent,
                                subjects = subjectNames,
                                outputStream = fos
                            )
                            fos.close()

                            val pdfUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                pdfFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                putExtra(Intent.EXTRA_SUBJECT, "Report Card - ${currentStudent.studentName}")
                                putExtra(Intent.EXTRA_TEXT, "Official Student Progress Report Card for ${currentStudent.studentName}.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Individual Progress Report"))

                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to generate Individual PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate & Share Individual Report (PDF)")
                }
            }
        }

        // Export Actions Section (Class Rankings)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Official Academic Reports (නිල වාර්තා) 📄",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Generate and share styled official PDF reports or download full rankings spreadsheets compatible with Excel for $selectedClass.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                // PDF Export (Class Rankings)
                Button(
                    onClick = {
                        if (students.isEmpty()) {
                            Toast.makeText(context, "No student data available to generate report!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "Official_Report_${selectedClass.replace(" ", "_")}.pdf")
                            val fos = FileOutputStream(pdfFile)
                            val subjectNames = subjects.map { it.name }
                            
                            PdfGenerator.generateReport(
                                context = context,
                                config = schoolConfig,
                                className = selectedClass,
                                classTeacher = classConfig?.classTeacher ?: "Unknown",
                                subjects = subjectNames,
                                students = students,
                                outputStream = fos
                            )
                            fos.close()

                            val pdfUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                pdfFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                putExtra(Intent.EXTRA_SUBJECT, "$selectedClass - ${schoolConfig.examType} Official Report")
                                putExtra(Intent.EXTRA_TEXT, "Here is the official academic rankings and performance report for Class $selectedClass.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Official PDF Report"))

                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to generate PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        contentColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_pdf_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download Class Rankings PDF (With Stamp Photos)")
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Excel/CSV Export
                FilledTonalButton(
                    onClick = {
                        if (students.isEmpty()) {
                            Toast.makeText(context, "No student data available to generate spreadsheet!", Toast.LENGTH_SHORT).show()
                            return@FilledTonalButton
                        }
                        try {
                            val fileName = "${selectedClass.replace(" ", "_")}_${schoolConfig.examType.replace(" ", "_")}_Report.csv"
                            val csvFile = File(context.cacheDir, fileName)
                            val fos = FileOutputStream(csvFile)
                            val writer = java.io.BufferedWriter(java.io.OutputStreamWriter(fos, "UTF-8"))

                            // UTF-8 BOM
                            writer.write('\ufeff'.toInt())

                            // CSV headers
                            val headers = mutableListOf("Rank", "Student ID", "Student Name")
                            subjects.forEach {
                                headers.add(it.name)
                                headers.add("${it.name} (Grade)")
                            }
                            headers.add("Total")
                            headers.add("Average")
                            headers.add("Status")
                            writer.write(headers.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                            writer.newLine()

                            // CSV rows
                            students.forEach { student ->
                                val row = mutableListOf<String>()
                                row.add(student.rank.toString())
                                row.add(student.studentId)
                                row.add(student.studentName)
                                subjects.forEach { subject ->
                                    row.add((student.marks[subject.name] ?: 0).toString())
                                    row.add(student.grades[subject.name] ?: "F")
                                }
                                row.add(student.total.toString())
                                row.add(student.average.toString())
                                row.add(student.status)
                                writer.write(row.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                                writer.newLine()
                            }
                            writer.flush()
                            writer.close()
                            fos.close()

                            val csvUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                csvFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/comma-separated-values"
                                putExtra(Intent.EXTRA_STREAM, csvUri)
                                putExtra(Intent.EXTRA_SUBJECT, "$selectedClass - ${schoolConfig.examType} Spreadsheet")
                                putExtra(Intent.EXTRA_TEXT, "Here is the academic spreadsheet containing scores and grades for Class $selectedClass.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Rankings Spreadsheet (Excel/CSV)"))
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to export spreadsheet: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        contentColor = MaterialTheme.colorScheme.secondaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_excel_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.TableView, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Download & Share Spreadsheet (Excel)")
                }
            }
        }
    }
}

private fun Uri.toByteArray(context: Context): ByteArray? {
    return try {
        context.contentResolver.openInputStream(this)?.use { inputStream ->
            val originalBitmap = android.graphics.BitmapFactory.decodeStream(inputStream) ?: return null
            
            val maxSize = 400
            val inWidth = originalBitmap.width
            val inHeight = originalBitmap.height
            val outWidth: Int
            val outHeight: Int
            
            if (inWidth > inHeight) {
                outWidth = maxSize
                outHeight = (inHeight * maxSize) / inWidth
            } else {
                outHeight = maxSize
                outWidth = (inWidth * maxSize) / inHeight
            }
            
            val resizedBitmap = android.graphics.Bitmap.createScaledBitmap(originalBitmap, outWidth, outHeight, false)
            val outputStream = java.io.ByteArrayOutputStream()
            resizedBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, outputStream)
            val byteArray = outputStream.toByteArray()
            
            originalBitmap.recycle()
            if (resizedBitmap != originalBitmap) {
                resizedBitmap.recycle()
            }
            
            byteArray
        }
    } catch (e: Exception) {
        null
    }
}
