package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import com.example.data.ClassConfig
import com.example.data.SchoolConfig
import com.example.data.Subject
import com.example.utils.PdfGenerator
import com.example.MasterReportActivity
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

object Translation {
    val languages = listOf("English", "Sinhala", "Tamil")
    
    class TranslationSet(
        val title: String,
        val home: String,
        val settings: String,
        val workspace: String,
        val profiles: String,
        val selectLang: String,
        val schName: String,
        val examType: String,
        val year: String,
        val classSelect: String,
        val addClass: String,
        val teacher: String,
        val subManage: String,
        val addSub: String,
        val passMark: String,
        val tabInput: String,
        val tabGrades: String,
        val tabRanks: String,
        val tabCharts: String,
        val saveBtn: String,
        val photoToggle: String,
        val pdfBtn: String,
        val search: String,
        val saveProfile: String,
        val chartTitle: String,
        val selectSubChart: String
    )
    
    val dict = mapOf(
        "English" to TranslationSet(
            title = "🏫 Advanced School Performance & Ranking System",
            home = "🏠 Home & Overview",
            settings = "⚙️ School Settings",
            workspace = "📊 Class Workspaces",
            profiles = "👤 Student Profiles",
            selectLang = "🌐 Select Language:",
            schName = "School Name:",
            examType = "Exam Type:",
            year = "Academic Year:",
            classSelect = "🎯 Select Class Workspace:",
            addClass = "➕ Create New Class:",
            teacher = "🧑‍🏫 Class Teacher Name:",
            subManage = "📚 Subject Management",
            addSub = "Add New Subject:",
            passMark = "Pass Mark:",
            tabInput = "📝 Marks & Photos Input",
            tabGrades = "📊 Student Grades",
            tabRanks = "🏆 Class Rankings & PDF",
            tabCharts = "📊 Subject Analysis Charts",
            saveBtn = "💾 Save All Marks Changes",
            photoToggle = "📸 Include Student Photos in PDF Report",
            pdfBtn = "📥 Download Official Class Report (A4 PDF)",
            search = "🔍 Search Student by Name or ID:",
            saveProfile = "💾 Save Personal Profile",
            chartTitle = "📊 Grade Distribution Analysis per Subject",
            selectSubChart = "📈 Select Subject to View Chart:"
        ),
        "Sinhala" to TranslationSet(
            title = "🏫 උසස් පාසල් ප්‍රතිඵල සහ ශ්‍රේණිගත කිරීමේ පද්ධතිය",
            home = "🏠 මුල් පිටුව සහ සාරාංශය",
            settings = "⚙️ පාසල් සැකසුම්",
            workspace = "📊 පන්ති කාමර",
            profiles = "👤 ශිෂ්‍ය පුද්ගලික විස්තර",
            selectLang = "🌐 භාෂාව තෝරන්න (Select Language):",
            schName = "පාසලේ නම:",
            examType = "විභාග වර්ගය:",
            year = "වර්ෂය:",
            classSelect = "🎯 වැඩ කිරීමට අවශ්‍ය පන්තිය තෝරන්න:",
            addClass = "➕ අලුත් පන්තියක් සාදන්න:",
            teacher = "🧑‍🏫 පන්තිභාර ගුරුතුමා/ගුරුතුමිය:",
            subManage = "📚 විෂයයන් කළමනාකරණය",
            addSub = "අලුත් විෂයක් එකතු කරන්න:",
            passMark = "සමත් ලකුණ:",
            tabCharts = "📊 විෂය විශ්ලේෂණ ප්‍රස්ථාර",
            chartTitle = "📊 එක් එක් විෂය සඳහා සාමාර්ථ විශ්ලේෂණය",
            selectSubChart = "📈 ප්‍රස්ථාරය බැලීමට විෂය තෝරන්න:",
            tabInput = "📝 ලකුණු ඇතුළත් කිරීම",
            tabGrades = "📊 ශිෂ්‍ය සාමාර්ථ",
            tabRanks = "🏆 ශ්‍රේණිගත කිරීම් සහ PDF",
            saveBtn = "💾 සියලුම ලකුණු සුරකින්න",
            photoToggle = "📸 PDF වාර්තාවට ළමුන්ගේ පින්තූර ඇතුළත් කරන්න",
            pdfBtn = "📥 නිල පන්ති වාර්තාව බාගත කරන්න (A4 PDF)",
            search = "🔍 ශිෂ්‍ය නම හෝ ID මඟින් සොයන්න:",
            saveProfile = "💾 පුද්ගලಿಕ විස්තර සුරකින්න"
        ),
        "Tamil" to TranslationSet(
            title = "🏫 மேம்பட்ட பள்ளி செயல்திறன் மற்றும் தரவரிசை முறைமை",
            home = "🏠 முகப்பு மற்றும் சுருக்கம்",
            settings = "⚙️ பள்ளி அமைப்புகள்",
            workspace = "📊 வகுப்பறைகள்",
            profiles = "👤 மாணவர் சுயவிவரம்",
            selectLang = "🌐 மொழியைத் தேர்வுசெய்க:",
            schName = "பள்ளியின் பெயர்:",
            examType = "தேர்வு வகை:",
            year = "ஆண்டு:",
            classSelect = "🎯 வேலை செய்ய வேண்டிய வகுப்பைத் தேர்ந்தெடுக்கவும்:",
            addClass = "➕ புதிய வகுப்பை உருவாக்குங்கள்:",
            teacher = "🧑‍🏫 வகுப்பு ஆசிரியர் பெயர்:",
            subManage = "📚 பாடங்கள் மேலாண்மை",
            addSub = "புதிய பாடத்தைச் சேர்க்கவும்:",
            passMark = "தேர்ச்சி புள்ளி:",
            tabCharts = "📊 பாட வாரியான வரைபடங்கள்",
            chartTitle = "📊 பாட வாரியான தரப் பகிர்வு",
            selectSubChart = "📈 வரைபடத்தைப் பார்க்க பாடத்தைத் தேர்ந்தெடுக்கவும்:",
            tabInput = "📝 மதிப்பெண்கள் உள்ளீடு",
            tabGrades = "📊 மாணவர் தரங்கள்",
            tabRanks = "🏆 தரவரிசை மற்றும் PDF",
            saveBtn = "💾 மதிப்பெண்களைச் சேமிக்கவும்",
            photoToggle = "📸 PDF அறிக்கையில் மாணவர் புகைப்படங்களைச் சேர்க்கவும்",
            pdfBtn = "📥 உத்தியோகபூர்வ வகுப்பு அறிக்கையைப் பதிவிறக்கவும் (A4 PDF)",
            search = "🔍 மாணவர் பெயர் அல்லது ID மூலம் தேடவும்:",
            saveProfile = "💾 சுயவிவரத்தைச் சேமிக்கவும்"
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val schoolConfig by viewModel.schoolConfig.collectAsState()
    val allClassConfigs by viewModel.allClassConfigs.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()
    val classSubjects by viewModel.classSubjects.collectAsState()
    val classRankedStudents by viewModel.classRankedStudents.collectAsState()
    val allSubjects by viewModel.allSubjects.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()

    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val loggedInUser by viewModel.loggedInUser.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isAppLocked by viewModel.isAppLocked.collectAsState()
    val isAccountDisabled by viewModel.isAccountDisabled.collectAsState()

    var selectedLanguage by remember { mutableStateOf("English") }
    var mainTabIndex by remember { mutableIntStateOf(0) }
    var showPrincipalAnalytics by remember { mutableStateOf(false) }
    var showSupportChat by remember { mutableStateOf(false) }
    
    val mainTabs = listOf(
        Translation.dict[selectedLanguage]?.home ?: "🏠 Home & Overview",
        Translation.dict[selectedLanguage]?.settings ?: "⚙️ School Settings",
        Translation.dict[selectedLanguage]?.workspace ?: "📊 Class Workspaces",
        Translation.dict[selectedLanguage]?.profiles ?: "👤 Student Profiles",
        "🏫 Classroom Hub"
    )

    // Document Storage Access Framework (SAF) Launchers for Google Drive / Cloud Sync
    val fileSaveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val jsonStr = viewModel.exportDatabaseToJson()
                    context.contentResolver.openOutputStream(it)?.use { os ->
                        os.write(jsonStr.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(context, "🎉 Cloud Backup Successful!", Toast.LENGTH_LONG).show()
                } catch (e: java.lang.Exception) {
                    Toast.makeText(context, "Backup Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val fileOpenLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    context.contentResolver.openInputStream(it)?.use { ins ->
                        val jsonStr = ins.bufferedReader().use { r -> r.readText() }
                        val success = viewModel.importDatabaseFromJson(jsonStr)
                        if (success) {
                            Toast.makeText(context, "🎉 Data successfully restored!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Restore Failed: Invalid JSON backup file.", Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (e: java.lang.Exception) {
                    Toast.makeText(context, "Restore Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    if (!isLoggedIn) {
        LoginLobbyScreen(
            viewModel = viewModel,
            selectedLanguage = selectedLanguage,
            onLoginSuccess = {
                Toast.makeText(context, "Welcome back, Teacher!", Toast.LENGTH_SHORT).show()
            }
        )
    } else if (showSupportChat) {
        SchoolChatScreen(
            viewModel = viewModel,
            selectedLanguage = selectedLanguage,
            onBack = { showSupportChat = false }
        )
    } else if (isAccountDisabled) {
        val title = when (selectedLanguage) {
            "Sinhala" -> "ගිණුම අක්‍රීය කර ඇත"
            "Tamil" -> "கணக்கு முடக்கப்பட்டது"
            else -> "Account Disabled"
        }
        val msg = when (selectedLanguage) {
            "Sinhala" -> "ඔබගේ ගිණුම පරිපාලක විසින් අක්‍රීය කර ඇත. කරුණාකර සහාය සඳහා පරිපාලක අමතන්න."
            "Tamil" -> "உங்கள் கணக்கு நிர்வாகியால் முடக்கப்பட்டுள்ளது. உதவிக்கு நிர்வாகியைத் தொடர்பு கொள்ளவும்."
            else -> "Your user account has been disabled by the administrator. Please contact administration for assistance."
        }
        val btn = when (selectedLanguage) {
            "Sinhala" -> "ගිණුමෙන් ඉවත් වන්න"
            "Tamil" -> "வெளியேறு"
            else -> "Logout / Switch Account"
        }
        MasterControlBlockedScreen(
            title = title,
            message = msg,
            buttonText = btn,
            onButtonClick = { viewModel.logout() },
            onChatClick = { showSupportChat = true }
        )
    } else if (isAppLocked) {
        val title = when (selectedLanguage) {
            "Sinhala" -> "ගිණුම සක්‍රීය කර නැත"
            "Tamil" -> "கணக்கு செயல்படுத்தப்படவில்லை"
            else -> "Account Not Activated"
        }
        val msg = when (selectedLanguage) {
            "Sinhala" -> "ඔබේ ගිණුම සක්රීය කර නැත. වසරකට රු. 1000ක් ගෙවා ඇප් එක සක්රීය කරවා ගැනීමට පරිපාලක අමතන්න."
            "Tamil" -> "உங்கள் கணக்கு செயல்படுத்தப்படவில்லை. வருடத்திற்கு ரூ. 1000 செலுத்தி கணக்கை செயல்படுத்த நிர்வாகியை தொடர்பு கொள்ளவும்."
            else -> "Your account is not activated. Please pay Rs. 1000 per year and contact the administrator to activate."
        }
        val btn = when (selectedLanguage) {
            "Sinhala" -> "ගිණුමෙන් ඉවත් වන්න"
            "Tamil" -> "வெளியேறு"
            else -> "Logout / Switch Account"
        }
        MasterControlBlockedScreen(
            title = title,
            message = msg,
            buttonText = btn,
            onButtonClick = { viewModel.logout() },
            whatsappNumber = "0785323346",
            contactNumber = "0785323346",
            onChatClick = { showSupportChat = true }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = schoolConfig.schoolName.ifBlank { Translation.dict[selectedLanguage]?.title ?: "School Master" },
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        loggedInUser?.let { email ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text(
                                    text = email,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 120.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(onClick = { viewModel.logout() }) {
                                    Icon(
                                        imageVector = Icons.Default.Logout,
                                        contentDescription = "Logout",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        var expandedLangMenu by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { expandedLangMenu = true }) {
                                Icon(imageVector = Icons.Default.Translate, contentDescription = "Change Language", tint = MaterialTheme.colorScheme.primary)
                            }
                            DropdownMenu(
                                expanded = expandedLangMenu,
                                onDismissRequest = { expandedLangMenu = false }
                            ) {
                                Translation.languages.forEach { lang ->
                                    DropdownMenuItem(
                                        text = { Text(lang) },
                                        onClick = {
                                            selectedLanguage = lang
                                            expandedLangMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.testTag("navigation_bar")
                ) {
                    mainTabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            icon = {
                                val icon = when (index) {
                                    0 -> Icons.Default.Home
                                    1 -> Icons.Default.Settings
                                    2 -> Icons.Default.Workspaces
                                    3 -> Icons.Default.Person
                                    else -> Icons.Default.School
                                }
                                Icon(icon, contentDescription = label)
                            },
                            label = { Text(label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = mainTabIndex == index,
                            onClick = { mainTabIndex = index }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showPrincipalAnalytics) {
                    PrincipalDashboardScreen(
                        viewModel = viewModel,
                        schoolConfig = schoolConfig,
                        classes = allClassConfigs,
                        allStudents = allStudents,
                        allSubjects = allSubjects,
                        selectedLanguage = selectedLanguage,
                        onClose = { showPrincipalAnalytics = false }
                    )
                } else if (!isSubscribed && mainTabIndex in listOf(1, 2, 3, 4)) {
                    SubscriptionExpiredScreen(viewModel = viewModel, selectedLanguage = selectedLanguage, onChatClick = { showSupportChat = true })
                } else {
                    when (mainTabIndex) {
                        0 -> HomeOverviewTab(
                            schoolConfig = schoolConfig,
                            classes = allClassConfigs,
                            allStudents = allStudents,
                            allSubjects = allSubjects,
                            viewModel = viewModel,
                            selectedLanguage = selectedLanguage,
                            onOpenPrincipalAnalytics = { showPrincipalAnalytics = true }
                        )
                        1 -> {
                            val isDarkThemeState by viewModel.isDarkTheme.collectAsState()
                            SchoolSettingsTab(
                                schoolConfig = schoolConfig,
                                onUpdateConfig = { name, exam, year, photoBytes ->
                                    viewModel.updateSchoolConfig(name, "", "", exam, year, photoBytes)
                                    Toast.makeText(context, "School settings saved successfully!", Toast.LENGTH_SHORT).show()
                                },
                                selectedLanguage = selectedLanguage,
                                onBackupClick = {
                                    coroutineScope.launch {
                                        val jsonStr = viewModel.exportDatabaseToJson()
                                        Toast.makeText(context, "☁️ Cloud Backup started...", Toast.LENGTH_SHORT).show()
                                        val success = com.example.utils.BackupManager.performBackup(context, jsonStr)
                                        if (success) {
                                            Toast.makeText(context, "🎉 Cloud Backup Successful (Single File Overwritten)!", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "Backup failed. Saved to local fallback.", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                onRestoreClick = {
                                    coroutineScope.launch {
                                        Toast.makeText(context, "☁️ Checking Google Drive for backup...", Toast.LENGTH_SHORT).show()
                                        val backupJson = com.example.utils.BackupManager.performRestore(context)
                                        if (!backupJson.isNullOrBlank()) {
                                            val success = viewModel.importDatabaseFromJson(backupJson)
                                            if (success) {
                                                Toast.makeText(context, "🎉 Data successfully restored!", Toast.LENGTH_LONG).show()
                                            } else {
                                                Toast.makeText(context, "Restore Failed: Invalid JSON backup file.", Toast.LENGTH_LONG).show()
                                            }
                                        } else {
                                            Toast.makeText(context, "No backup file found on Google Drive or local storage.", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                isDarkTheme = isDarkThemeState,
                                onDarkThemeToggle = { viewModel.toggleDarkTheme(it) },
                                viewModel = viewModel,
                                classes = allClassConfigs,
                                onChatSupportClick = { showSupportChat = true }
                            )
                        }
                        2 -> ClassWorkspacesTab(
                            selectedClass = selectedClass,
                            classes = allClassConfigs,
                            subjects = classSubjects,
                            students = classRankedStudents,
                            schoolConfig = schoolConfig,
                            viewModel = viewModel,
                            selectedLanguage = selectedLanguage
                        )
                        3 -> StudentProfilesTab(
                            viewModel = viewModel,
                            allStudents = allStudents,
                            allClasses = allClassConfigs,
                            selectedLanguage = selectedLanguage
                        )
                        4 -> ClassroomHubTab(
                            viewModel = viewModel,
                            allClasses = allClassConfigs,
                            allStudents = allStudents,
                            selectedLanguage = selectedLanguage
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 1: HOME & OVERVIEW
// ==========================================
@Composable
fun HomeOverviewTab(
    schoolConfig: SchoolConfig,
    classes: List<ClassConfig>,
    allStudents: List<com.example.data.Student>,
    allSubjects: List<Subject>,
    viewModel: MainViewModel,
    selectedLanguage: String = "English",
    onOpenPrincipalAnalytics: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var showMasterReportVerificationDialog by remember { mutableStateOf(false) }
    var masterReportPinInput by remember { mutableStateOf("") }
    var masterReportPinError by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                val schoolBitmap = remember(schoolConfig.schoolPhotoBytes) {
                    schoolConfig.schoolPhotoBytes?.let {
                        android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                    }?.asImageBitmap()
                }

                Box(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (schoolBitmap != null) {
                        Image(
                            bitmap = schoolBitmap,
                            contentDescription = "School Banner Background",
                            modifier = Modifier.matchParentSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(Color.Black.copy(alpha = 0.55f))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                )
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "🏫 ${schoolConfig.schoolName.uppercase()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${schoolConfig.examType} — ${schoolConfig.academicYear}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            val welcomeMsg = when (selectedLanguage) {
                                "Sinhala" -> "✨ සාදරයෙන් පිළිගනිමු ✨\nපන්ති ප්‍රතිඵල, සාමාර්ථ සහ ශ්‍රේණිගත කිරීම් ස්වයංක්‍රීයව සකස් කරන පද්ධතිය"
                                "Tamil" -> "✨ நல்வரவு ✨\nதானியங்கி வகுப்பு செயல்திறன் மற்றும் தரவரிசை முறைமை"
                                else -> "✨ WELCOME TO THE SCHOOL MANAGEMENT & PORTAL ✨\nAutomated Class Performance and Rankings System"
                            }
                            Text(
                                text = welcomeMsg,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenPrincipalAnalytics() },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "විදුහල්පති විශ්ලේෂණ ද්වාරය"
                                "Tamil" -> "அதிபர் பகுப்பாய்வு போர்டல்"
                                else -> "Principal Analytics Portal"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "විශ්ලේෂණ සහ PDF වාර්තා ජනනය සඳහා පිවිසෙන්න"
                                "Tamil" -> "பகுப்பாய்வு மற்றும் PDF அறிக்கைகளை அணுகவும்"
                                else -> "Access in-depth statistics & publish PDF reports"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showMasterReportVerificationDialog = true },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                ),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Summarize,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "විදුහල්පති සමස්ත සාරාංශ වාර්තාව (Master Report)"
                                "Tamil" -> "அதிபர் மாஸ்டர் அறிக்கை"
                                else -> "Executive Attendance & Master Report"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "මුළු සිසුන්/ගුරුවරුන් සංඛ්‍යාව සහ පැමිණීමේ විස්තර වාර්තා PDF බාගන්න"
                                "Tamil" -> "மாணவர்/ஆசிரியர் வருகை அறிக்கையைப் பதிவிறக்கவும்"
                                else -> "View registered counts, daily attendance, and download summary PDF"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        item {
            Text(
                text = Translation.dict[selectedLanguage]?.home ?: "📊 All Classes Summary (Overview)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (classes.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No classes added yet. Go to the Class Workspaces tab to create classes.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(classes, key = { it.className }) { classConfig ->
                val classStudents = allStudents.filter { it.className == classConfig.className }
                val classSubjects = allSubjects.filter { it.className == classConfig.className }
                val ranked = viewModel.calculateRankings(classStudents, classSubjects)
                val topStudent = ranked.firstOrNull()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = classConfig.className,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = classConfig.classTeacher,
                                    fontWeight = FontWeight.Medium,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "👥 Students: ${classStudents.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "📚 Subjects: ${classSubjects.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (topStudent != null) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "🏆 Class Top: ${topStudent.studentName} (${topStudent.total} Marks)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            } else {
                                Text(
                                    text = "🏆 Class Top: N/A",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = "Go to workspace",
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                            modifier = Modifier
                                .size(16.dp)
                                .clickable {
                                    viewModel.selectClass(classConfig.className)
                                }
                        )
                    }
                }
            }
        }
    }

    if (showMasterReportVerificationDialog) {
        AlertDialog(
            onDismissRequest = {
                showMasterReportVerificationDialog = false
                masterReportPinInput = ""
                masterReportPinError = false
            },
            title = {
                Text(
                    text = "Master PIN Verification",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "සමස්ත වාර්තා පද්ධතියට ඇතුල් වීමට Master PIN අංකය ඇතුළත් කරන්න."
                    )
                    OutlinedTextField(
                        value = masterReportPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) masterReportPinInput = it },
                        label = { Text("Master PIN") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        isError = masterReportPinError,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (masterReportPinError) {
                        Text(
                            text = "ඇතුල්වීම ප්‍රතික්ෂේපිතයි! වැරදි Master PIN එකක්.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val isValid = viewModel.verifyPrincipalPin(masterReportPinInput)
                        if (isValid) {
                            val intent = Intent(context, MasterReportActivity::class.java)
                            context.startActivity(intent)
                            showMasterReportVerificationDialog = false
                            masterReportPinInput = ""
                            masterReportPinError = false
                        } else {
                            masterReportPinError = true
                        }
                    }
                ) {
                    Text("Enter")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showMasterReportVerificationDialog = false
                        masterReportPinInput = ""
                        masterReportPinError = false
                    }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

// ==========================================
// TAB 2: SCHOOL SETTINGS
// ==========================================
@Composable
fun SchoolSettingsTab(
    schoolConfig: SchoolConfig,
    onUpdateConfig: (String, String, String, ByteArray?) -> Unit,
    selectedLanguage: String = "English",
    onBackupClick: () -> Unit = {},
    onRestoreClick: () -> Unit = {},
    isDarkTheme: Boolean = false,
    onDarkThemeToggle: (Boolean) -> Unit = {},
    viewModel: MainViewModel,
    classes: List<ClassConfig>,
    onChatSupportClick: () -> Unit = {}
) {
    var schoolName by remember(schoolConfig) { mutableStateOf(schoolConfig.schoolName) }
    var examType by remember(schoolConfig) { mutableStateOf(schoolConfig.examType) }
    var academicYear by remember(schoolConfig) { mutableStateOf(schoolConfig.academicYear) }
    var schoolPhotoBytesSelected by remember(schoolConfig) { mutableStateOf<ByteArray?>(schoolConfig.schoolPhotoBytes) }

    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            schoolPhotoBytesSelected = it.toByteArray(context)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.dict[selectedLanguage]?.settings ?: "⚙️ School & Examination Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "පාසලේ පොදු විස්තර සහ ප්‍රධාන තොරතුරු මෙතැනින් වෙනස් කරන්න:"
                    "Tamil" -> "பள்ளியின் பொதுவான விவரங்களையும் முக்கிய தகவல்களையும் இங்கே மாற்றவும்:"
                    else -> "Modify the school's general information and settings here:"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = schoolName,
                        onValueChange = { schoolName = it },
                        label = { Text(Translation.dict[selectedLanguage]?.schName ?: "School Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = examType,
                        onValueChange = { examType = it },
                        label = { Text(Translation.dict[selectedLanguage]?.examType ?: "Exam Type") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text(Translation.dict[selectedLanguage]?.year ?: "Academic Year") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    // School Photo Layout
                    Text(
                        text = "🖼️ " + when (selectedLanguage) {
                            "Sinhala" -> "පාසල් ඡායාරූපය (School Photo Banner)"
                            "Tamil" -> "பள்ளி புகைப்படம் (School Photo Banner)"
                            else -> "School Photo Banner"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val bitmap = remember(schoolPhotoBytesSelected) {
                        schoolPhotoBytesSelected?.let {
                            android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                        }?.asImageBitmap()
                    }

                    if (bitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        ) {
                            Image(
                                bitmap = bitmap,
                                contentDescription = "Selected School Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            IconButton(
                                onClick = { schoolPhotoBytesSelected = null },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove photo",
                                    tint = Color.White
                                )
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Image,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Select School Photo / Banner")
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "ඇප් එකට සහ PDF බැනරයට අවශ්‍ය පාසල් ඡායාරූපය තෝරන්න"
                                        "Tamil" -> "பயன்பாட்டிற்கும் PDF பதாகைக்கும் தேவையான புகைப்படத்தைத் தேர்ந்தெடுக்கவும்"
                                        else -> "Choose a photo/banner for the application and the generated A4 PDF reports"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Button(
                        onClick = { onUpdateConfig(schoolName, examType, academicYear, schoolPhotoBytesSelected) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_settings_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Translation.dict[selectedLanguage]?.saveBtn ?: "Save School Settings")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "අඳුරු මාදිලිය (Dark Mode)"
                                "Tamil" -> "இருண்ட தீம் (Dark Mode)"
                                else -> "Dark Mode Theme"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "ඇප් එක සඳහා අඳුරු තේමාව සක්‍රිය කරන්න"
                                "Tamil" -> "பயன்பாட்டிற்கு இருண்ட தீம் இயக்கவும்"
                                else -> "Enable dark theme across the application"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = isDarkTheme,
                        onCheckedChange = onDarkThemeToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }
        }



        // --- 🔑 Reset Master PIN Section (Via Email Link) ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "ප්‍රධාන (Master) PIN අංකය නැවත සකසන්න"
                                "Tamil" -> "முதன்மை PIN ஐ மீட்டமை"
                                else -> "Reset Master PIN"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "ඔබගේ ලියාපදිංචි පාසල් විද්‍යුත් තැපැල් (Email) ලිපිනයට ආරක්ෂිත මුද්‍රිත PIN/රහස්පද ප්‍රතිසාධන සබැඳියක් (Reset Link) යවන්න:"
                            "Tamil" -> "பதிவுசெய்யப்பட்ட பள்ளி மின்னஞ்சல் முகவரிக்கு பாதுகாப்பான மீட்டமைப்பு இணைப்பை அனுப்பவும்:"
                            else -> "Send a secure password/PIN reset recovery link directly to your registered school email address:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            viewModel.sendMasterPinResetEmail { success ->
                                if (success) {
                                    Toast.makeText(context, "Reset link sent to your registered email!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to send reset email. Verify your connection or registered email.", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(imageVector = Icons.Default.Email, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "මුද්‍රිත PIN Reset ඊමේල් එකක් යවන්න"
                                "Tamil" -> "மீட்டமைப்பு மின்னஞ்சலை அனுப்பவும்"
                                else -> "Send Reset Email Link"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- 🔐 Reset Class PIN Section (Via Master PIN verification) ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "පන්ති PIN අංකය නැවත සකසන්න"
                                "Tamil" -> "வகுப்பு PIN ஐ மீட்டமைக்கவும்"
                                else -> "Reset Class PIN"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "ප්‍රධාන (Master) PIN අංකය ඇතුළත් කර තහවුරු කිරීමෙන් පසු ඕනෑම පන්තියක PIN අංකයක් අලුතින් සකස් කළ හැක:"
                            "Tamil" -> "முதன்மை PIN ஐ உள்ளிட்டு சரிபார்த்த பிறகு எந்த வகுப்பின் PIN ஐயும் மீட்டமைக்கலாம்:"
                            else -> "Reset the PIN of any class workspace by verifying with the global Master PIN:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    var selectedClassToReset by remember { mutableStateOf("") }
                    var enteredMasterPin by remember { mutableStateOf("") }
                    var newClassPinInput by remember { mutableStateOf("") }
                    var dropdownExpanded by remember { mutableStateOf(false) }

                    // Class Dropdown Selection
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "1. පන්තිය තෝරන්න:"
                            "Tamil" -> "1. வகுப்பைத் தேர்ந்தெடுக்கவும்:"
                            else -> "1. Select Class:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedCard(
                            onClick = { dropdownExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (selectedClassToReset.isEmpty()) {
                                        when (selectedLanguage) {
                                            "Sinhala" -> "පන්තියක් තෝරන්න"
                                            "Tamil" -> "வகுப்பைத் தேர்ந்தெடுக்கவும்"
                                            else -> "-- Select Class --"
                                        }
                                    } else {
                                        selectedClassToReset
                                    },
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                        }
                        
                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            classes.forEach { classConfig ->
                                DropdownMenuItem(
                                    text = { Text(classConfig.className) },
                                    onClick = {
                                        selectedClassToReset = classConfig.className
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Master PIN Input
                    OutlinedTextField(
                        value = enteredMasterPin,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) enteredMasterPin = it },
                        label = {
                            Text(
                                when (selectedLanguage) {
                                    "Sinhala" -> "2. ප්‍රධාන (Master) PIN අංකය ඇතුළත් කරන්න"
                                    "Tamil" -> "2. முதன்மை PIN ஐ உள்ளிடவும்"
                                    else -> "2. Enter Master PIN"
                                }
                            )
                        },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    )

                    val isMasterPinCorrect = enteredMasterPin.isNotEmpty() && enteredMasterPin == viewModel.principalPinState.value

                    if (isMasterPinCorrect && selectedClassToReset.isNotEmpty()) {
                        // Secure field to enter New Class PIN
                        OutlinedTextField(
                            value = newClassPinInput,
                            onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) newClassPinInput = it },
                            label = {
                                Text(
                                    when (selectedLanguage) {
                                        "Sinhala" -> "3. නව පන්ති PIN අංකය ඇතුළත් කරන්න"
                                        "Tamil" -> "3. புதிய வகுப்பு PIN ஐ உள்ளிடவும்"
                                        else -> "3. Enter New Class PIN"
                                    }
                                )
                            },
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (newClassPinInput.length >= 4) {
                                        viewModel.saveClassPin(selectedClassToReset, newClassPinInput, {
                                            Toast.makeText(context, "Class PIN for $selectedClassToReset successfully reset!", Toast.LENGTH_LONG).show()
                                            newClassPinInput = ""
                                            enteredMasterPin = ""
                                            selectedClassToReset = ""
                                        }, {
                                            Toast.makeText(context, "Error: ${it.localizedMessage}", Toast.LENGTH_LONG).show()
                                        })
                                    } else {
                                        Toast.makeText(context, "Class PIN must be at least 4 digits!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "PIN එක සුරකින්න"
                                        "Tamil" -> "PIN ஐச் சேமிக்கவும்"
                                        else -> "Save PIN"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }

                            Button(
                                onClick = {
                                    viewModel.deleteClassPin(selectedClassToReset, {
                                        Toast.makeText(context, "Class PIN for $selectedClassToReset successfully deleted!", Toast.LENGTH_LONG).show()
                                        newClassPinInput = ""
                                        enteredMasterPin = ""
                                        selectedClassToReset = ""
                                    }, {
                                        Toast.makeText(context, "Error: ${it.localizedMessage}", Toast.LENGTH_LONG).show()
                                    })
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "PIN එක මකන්න"
                                        "Tamil" -> "PIN ஐ நீக்கு"
                                        else -> "Delete PIN"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    } else if (enteredMasterPin.isNotEmpty() && !isMasterPinCorrect) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "වැරදි ප්‍රධාන (Master) PIN අංකයකි."
                                "Tamil" -> "தவறான முதன்மை PIN."
                                else -> "Incorrect Master PIN."
                            },
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // --- 📞 Contact & Support Section ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "සහාය සහ සම්බන්ධතා (Contact & Support)"
                                "Tamil" -> "உதவி மற்றும் தொடர்பு (Contact & Support)"
                                else -> "Contact & Support"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "යෙදුම සක්‍රීය කිරීමට, තාක්ෂණික සහාය හෝ වෙනත් ඕනෑම ගැටලුවක් සඳහා පරිපාලක අමතන්න:"
                            "Tamil" -> "பயன்பாட்டு செயல்படுத்தல், தொழில்நுட்ப ஆதரவு அல்லது ஏதேனும் சிக்கல்களுக்கு நிர்வாகியைத் தொடர்பு கொள்ளவும்:"
                            else -> "Contact administration for application activation, technical support, or any other issues:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "පරිපාලක දුරකථන අංකය"
                                        "Tamil" -> "நிர்வாகி மொபைல் எண்"
                                        else -> "Admin Mobile Number"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "0785323346",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            
                            IconButton(
                                onClick = {
                                    try {
                                        val intent = android.content.Intent(android.content.Intent.ACTION_DIAL).apply {
                                            data = android.net.Uri.parse("tel:0785323346")
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Cannot open dialer.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = "Call",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    data = android.net.Uri.parse("https://wa.me/94785323346")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Could not open WhatsApp.", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("whatsapp_support_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF25D366) // WhatsApp green
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "WhatsApp සහාය අමතන්න"
                                "Tamil" -> "WhatsApp ஆதரவு"
                                else -> "WhatsApp Support"
                            },
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onChatSupportClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("in_app_chat_support_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "ඇප් එක තුලින් ඇඩ්මින් සමඟ කතාබස් කරන්න"
                                "Tamil" -> "பயன்பாட்டிற்குள் அரட்டை அடிக்கவும்"
                                else -> "In-App Support Chat"
                            },
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 3: CLASS WORKSPACES (Moved to ClassWorkspaceScreen.kt)
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ObsoleteClassWorkspacesTab(
    selectedClass: String,
    classes: List<ClassConfig>,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    viewModel: MainViewModel,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var activeManagementMode by remember { mutableStateOf<String?>(null) } // null, "add", "update", "delete"
    var inlineClassName by remember { mutableStateOf("") }
    var inlineTeacherName by remember { mutableStateOf("") }

    var showMasterDeleteDialog by remember { mutableStateOf(false) }
    var pendingDeleteAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    var workspaceTabIndex by remember { mutableIntStateOf(0) }
    val workspaceTabs = listOf(
        Translation.dict[selectedLanguage]?.tabInput ?: "📝 Marks",
        Translation.dict[selectedLanguage]?.tabGrades ?: "📊 Grades",
        Translation.dict[selectedLanguage]?.tabRanks ?: "🏆 Rankings",
        Translation.dict[selectedLanguage]?.tabCharts ?: "📊 Charts"
    )

    val activeClassConfig = classes.firstOrNull { it.className == selectedClass }
    var teacherNameInput by remember(activeClassConfig) { mutableStateOf(activeClassConfig?.classTeacher ?: "") }

    var showAddSubjectSection by remember { mutableStateOf(false) }
    var newSubjectName by remember { mutableStateOf("") }
    var newSubjectPassMark by remember { mutableStateOf(35) }

    val unlockedSet by viewModel.unlockedClasses.collectAsState()
    val principalVerifiedState by viewModel.principalVerified.collectAsState()
    val isUnlocked = principalVerifiedState || unlockedSet.contains(selectedClass)

    if (classes.isNotEmpty() && !isUnlocked) {
        ObsoleteClassPINLockScreen(
            selectedClass = selectedClass,
            viewModel = viewModel,
            selectedLanguage = selectedLanguage
        )
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Class Selection & Management Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "🎯 පන්තිය තෝරන්න (Select Class Workspace):"
                                    "Tamil" -> "🎯 வகுப்பைத் தேர்ந்தெடுக்கவும்:"
                                    else -> "🎯 Select Class Workspace:"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            
                            if (classes.isEmpty()) {
                                Text(
                                    text = "No Classes Available",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            } else {
                                var expandedClassDropdown by remember { mutableStateOf(false) }
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { expandedClassDropdown = true }
                                            .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = selectedClass,
                                            fontWeight = FontWeight.ExtraBold,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                    DropdownMenu(
                                        expanded = expandedClassDropdown,
                                        onDismissRequest = { expandedClassDropdown = false }
                                    ) {
                                        classes.forEach { c ->
                                            DropdownMenuItem(
                                                text = { Text(c.className, fontWeight = FontWeight.Bold) },
                                                onClick = {
                                                    viewModel.selectClass(c.className)
                                                    expandedClassDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (classes.isNotEmpty()) {
                            Button(
                                onClick = {
                                    viewModel.lockClass(selectedClass)
                                    Toast.makeText(context, "Workspace locked!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                                ),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = "Lock", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "ලොක් කරන්න"
                                        "Tamil" -> "பூட்டு"
                                        else -> "Lock"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    // Inline Class Management: Add, Update, Delete Buttons in a single beautiful row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isAdd = activeManagementMode == "add"
                        val isUpdate = activeManagementMode == "update"
                        val isDelete = activeManagementMode == "delete"
                        
                        // Add Button
                        Button(
                            onClick = { activeManagementMode = if (isAdd) null else "add" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAdd) Color(0xFF10B981) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                contentColor = if (isAdd) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "එක් කරන්න"
                                    "Tamil" -> "சேர்க்க"
                                    else -> "Add"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        
                        // Update Button
                        Button(
                            onClick = { activeManagementMode = if (isUpdate) null else "update" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isUpdate) Color(0xFFF59E0B) else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                                contentColor = if (isUpdate) Color.White else MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "වෙනස් කරන්න"
                                    "Tamil" -> "புதுப்பிக்க"
                                    else -> "Update"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        
                        // Delete Button
                        Button(
                            onClick = { activeManagementMode = if (isDelete) null else "delete" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDelete) Color(0xFFEF4444) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                                contentColor = if (isDelete) Color.White else MaterialTheme.colorScheme.onErrorContainer
                            ),
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "මකන්න"
                                    "Tamil" -> "நீக்குக"
                                    else -> "Delete"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    // Interactive Inline Editor Cards below the action row (Absolutely Popup & Dialog Free)
                    AnimatedVisibility(
                        visible = activeManagementMode != null,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = when (activeManagementMode) {
                                    "add" -> Color(0xFF10B981).copy(alpha = 0.08f)
                                    "update" -> Color(0xFFF59E0B).copy(alpha = 0.08f)
                                    else -> Color(0xFFEF4444).copy(alpha = 0.08f)
                                }
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = when (activeManagementMode) {
                                    "add" -> Color(0xFF10B981).copy(alpha = 0.3f)
                                    "update" -> Color(0xFFF59E0B).copy(alpha = 0.3f)
                                    else -> Color(0xFFEF4444).copy(alpha = 0.3f)
                                }
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                when (activeManagementMode) {
                                    "add" -> {
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "➕ නව පන්තියක් එක් කිරීම (Add New Class)"
                                                "Tamil" -> "➕ புதிய வகுப்பு சேர்க்க"
                                                else -> "➕ Add New Class"
                                            },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF4CAF50)
                                        )
                                        OutlinedTextField(
                                            value = inlineClassName,
                                            onValueChange = { inlineClassName = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "පන්තියේ නම (උදා: 10-A)"
                                                    "Tamil" -> "வகுப்பு பெயர் (உதாரணம்: 10-A)"
                                                    else -> "Class Name (e.g., 10-A)"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = inlineTeacherName,
                                            onValueChange = { inlineTeacherName = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "පන්තිභාර ගුරුතුමා/ගුරුතුමිය"
                                                    "Tamil" -> "வகுப்பு ஆசிரியர் பெயர்"
                                                    else -> "Class Teacher Name"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(onClick = { activeManagementMode = null }) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "අවලංගු කරන්න"
                                                        "Tamil" -> "ரத்துசெய்"
                                                        else -> "Cancel"
                                                    }
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    if (inlineClassName.isNotBlank()) {
                                                        viewModel.addClass(inlineClassName, inlineTeacherName)
                                                        inlineClassName = ""
                                                        inlineTeacherName = ""
                                                        activeManagementMode = null
                                                        Toast.makeText(context, "Class added successfully!", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                                            ) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "එකතු කරන්න"
                                                        "Tamil" -> "சேர்க்க"
                                                        else -> "Add Class"
                                                    },
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                    "update" -> {
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "✏️ පන්තියේ තොරතුරු වෙනස් කිරීම (Update Class Details)"
                                                "Tamil" -> "✏️ வகுப்பு விவரங்களை மாற்றவும்"
                                                else -> "✏️ Update Class Details"
                                            },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFF9800)
                                        )
                                        
                                        var renameInput by remember(selectedClass) { mutableStateOf(selectedClass) }
                                        var teacherInput by remember(teacherNameInput) { mutableStateOf(teacherNameInput) }
                                        
                                        OutlinedTextField(
                                            value = renameInput,
                                            onValueChange = { renameInput = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "පන්තියේ නම වෙනස් කරන්න"
                                                    "Tamil" -> "வகுப்பு பெயரை மாற்றவும்"
                                                    else -> "Rename Class Name"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = teacherInput,
                                            onValueChange = { teacherInput = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "ගුරුතුමා/ගුරුතුමිය වෙනස් කරන්න"
                                                    "Tamil" -> "வகுப்பு ஆசிரியரை மாற்றவும்"
                                                    else -> "Change Class Teacher"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(onClick = { activeManagementMode = null }) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "අවලංගු කරන්න"
                                                        "Tamil" -> "ரத்துசெய்"
                                                        else -> "Cancel"
                                                    }
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    if (renameInput.isNotBlank()) {
                                                        if (renameInput != selectedClass) {
                                                            viewModel.renameClass(selectedClass, renameInput)
                                                        }
                                                        viewModel.updateClassTeacher(renameInput, teacherInput)
                                                        activeManagementMode = null
                                                        Toast.makeText(context, "Class updated successfully!", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
                                            ) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "වෙනස් කරන්න"
                                                        "Tamil" -> "புதுப்பிக்க"
                                                        else -> "Update"
                                                    },
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                    "delete" -> {
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "🗑️ පන්තිය මකා දැමීම (Delete Class Workspace)"
                                                "Tamil" -> "🗑️ வகுப்பு நீக்குதல்"
                                                else -> "🗑️ Delete Class Workspace"
                                            },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFF44336)
                                        )
                                        
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "අවධානය: ඔබට ස්ථිරවම '$selectedClass' පන්තිය සහ ඊට අදාළ සියලුම විෂයන් සහ සිසුන්ගේ දත්ත මකා දැමීමට අවශ්‍යද? මෙම ක්‍රියාව නැවත වෙනස් කළ නොහැක."
                                                "Tamil" -> "எச்சரிக்கை: வகுப்பு '$selectedClass' மற்றும் அதனுடன் தொடர்புடைய அனைத்து பாடங்களையும் மாணவர்களின் தரவையும் நிரந்தரமாக நீக்க வேண்டுமா?"
                                                else -> "Warning: Are you sure you want to delete class '$selectedClass'? This will permanently clear all subjects and students associated with this class. This action cannot be undone."
                                            },
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(onClick = { activeManagementMode = null }) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "අවලංගු කරන්න"
                                                        "Tamil" -> "ரத்துசெய்"
                                                        else -> "Cancel"
                                                    }
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    pendingDeleteAction = {
                                                        viewModel.deleteClass(selectedClass)
                                                        activeManagementMode = null
                                                        Toast.makeText(context, "Class deleted successfully!", Toast.LENGTH_SHORT).show()
                                                    }
                                                    showMasterDeleteDialog = true
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336))
                                            ) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "ඔව්, මකන්න"
                                                        "Tamil" -> "ஆம், நீக்கு"
                                                        else -> "Yes, Delete"
                                                    },
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (activeClassConfig != null) {
            // Subject Management Section with Secure Dropdown Checkbox Protection
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📚 Subject Management",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(onClick = { showAddSubjectSection = !showAddSubjectSection }) {
                                Text(if (showAddSubjectSection) "Collapse" else "➕ Add Subject")
                            }
                        }

                        if (showAddSubjectSection) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = newSubjectName,
                                    onValueChange = { newSubjectName = it },
                                    label = { Text("Subject Name") },
                                    placeholder = { Text("e.g. Mathematics, Science") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                OutlinedTextField(
                                    value = newSubjectPassMark.toString(),
                                    onValueChange = { newSubjectPassMark = it.toIntOrNull() ?: 35 },
                                    label = { Text("Pass Mark") },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                Button(
                                    onClick = {
                                        if (newSubjectName.isNotBlank()) {
                                            viewModel.addSubject(newSubjectName, newSubjectPassMark, selectedClass)
                                            newSubjectName = ""
                                            showAddSubjectSection = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Add Subject to Class")
                                }
                            }
                        }

                        if (subjects.isEmpty()) {
                            Text(
                                text = "No subjects in this class yet. Add some subjects above to begin adding marks.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        } else {
                            Text(
                                text = "Active Class Subjects:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                subjects.forEach { sub ->
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("${sub.name} (${sub.passMark})") }
                                    )
                                }
                            }

                            // Safe Subject Deletion with confirmation dropdown and checkbox (Subject Delete Protection)
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = "🛡️ Delete Subject with Protection (විෂයන් මකා දැමීම):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            
                            var selectedSubToDelete by remember { mutableStateOf<Subject?>(null) }
                            var isConfirmCheckboxChecked by remember { mutableStateOf(false) }
                            var expandedDeleteDropdown by remember { mutableStateOf(false) }
                            
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandedDeleteDropdown = true }
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = selectedSubToDelete?.name ?: "-- Select Subject to Delete --",
                                        fontWeight = FontWeight.Medium,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (selectedSubToDelete != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                                DropdownMenu(
                                    expanded = expandedDeleteDropdown,
                                    onDismissRequest = { expandedDeleteDropdown = false },
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("-- Select Subject to Delete --") },
                                        onClick = {
                                            selectedSubToDelete = null
                                            isConfirmCheckboxChecked = false
                                            expandedDeleteDropdown = false
                                        }
                                    )
                                    subjects.forEach { sub ->
                                        DropdownMenuItem(
                                            text = { Text(sub.name) },
                                            onClick = {
                                                selectedSubToDelete = sub
                                                isConfirmCheckboxChecked = false
                                                expandedDeleteDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                            
                            val activeSubToDel = selectedSubToDelete
                            if (activeSubToDel != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(
                                        checked = isConfirmCheckboxChecked,
                                        onCheckedChange = { isConfirmCheckboxChecked = it }
                                    )
                                    Text(
                                        text = "⚠️ මම ස්ථිරවම ${activeSubToDel.name} විෂය සහ එහි සියලුම ලකුණු මකා දැමීමට එකඟ වෙමි.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                
                                Button(
                                    onClick = {
                                        viewModel.removeSubject(activeSubToDel)
                                        Toast.makeText(context, "${activeSubToDel.name} deleted safely!", Toast.LENGTH_SHORT).show()
                                        selectedSubToDelete = null
                                        isConfirmCheckboxChecked = false
                                    },
                                    enabled = isConfirmCheckboxChecked,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Confirm Delete Subject")
                                }
                            }
                        }
                    }
                }
            }

            // Sub-Tabs within the workspace
            item {
                TabRow(
                    selectedTabIndex = workspaceTabIndex,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    workspaceTabs.forEachIndexed { index, label ->
                        Tab(
                            selected = workspaceTabIndex == index,
                            onClick = { workspaceTabIndex = index },
                            text = { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Render selected Workspace Sub-Tab
            item {
                when (workspaceTabIndex) {
                    0 -> WorkspaceStudentMarksView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        viewModel = viewModel
                    )
                    1 -> WorkspaceStudentGradesView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students
                    )
                    2 -> WorkspaceRankingsExportView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        classConfig = activeClassConfig,
                        selectedLanguage = selectedLanguage
                    )
                    3 -> WorkspaceSubjectChartsView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        selectedLanguage = selectedLanguage
                    )
                }
            }
        }
    }

    if (showMasterDeleteDialog) {
        var pinInput by remember { mutableStateOf("") }
        var showError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                showMasterDeleteDialog = false
                pendingDeleteAction = null
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ප්‍රධාන අවසරය අවශ්‍යයි"
                        "Tamil" -> "முக்கிய அங்கீகாரம் தேவை"
                        else -> "Master Authorization Required"
                    },
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "දත්ත මකාදැමීම සිදුකළ හැක්කේ ප්‍රධාන Master PIN අංකයෙන් පමණි."
                            "Tamil" -> "தரவை நீக்குவது முக்கிய மாஸ்டர் பின் மூலம் மட்டுமே செய்ய முடியும்."
                            else -> "Data deletion can only be authorized using the main Master PIN."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pinInput = it },
                        label = {
                            Text(
                                when (selectedLanguage) {
                                    "Sinhala" -> "ප්‍රධාන Master PIN අංකය"
                                    "Tamil" -> "மாஸ்டர் பின்"
                                    else -> "Master PIN"
                                }
                            )
                        },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        isError = showError,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (showError) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "ක්‍රියාව අත්හිටුවන ලදී! Master PIN එක වැරදියි."
                                "Tamil" -> "தவறான மாஸ்டர் பின்!"
                                else -> "Incorrect Master PIN! Please try again."
                            },
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val isValid = viewModel.verifyPrincipalPin(pinInput)
                        if (isValid) {
                            pendingDeleteAction?.invoke()
                            showMasterDeleteDialog = false
                            pendingDeleteAction = null
                        } else {
                            showError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "තහවුරු කරන්න"
                            "Tamil" -> "உறுதிப்படுத்து"
                            else -> "Confirm Delete"
                        }
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showMasterDeleteDialog = false
                        pendingDeleteAction = null
                    }
                ) {
                    Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "අවලංගු කරන්න"
                            "Tamil" -> "ரத்துசெய்"
                            else -> "Cancel"
                        }
                    )
                }
            }
        )
    }
}

// ==========================================
// WORKSPACE SUB-TAB 1: STUDENT MARKS VIEW
// ==========================================
@Composable
fun WorkspaceStudentMarksView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var showAddStudentDialog by remember { mutableStateOf(false) }

    var showMasterDeleteDialog by remember { mutableStateOf(false) }
    var pendingDeleteAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    // Student fields for Add/Edit
    var editingStudentId by remember { mutableStateOf("") }
    var editingStudentName by remember { mutableStateOf("") }
    var isEditMode by remember { mutableStateOf(false) }
    var photoBytesSelected by remember { mutableStateOf<ByteArray?>(null) }
    val editingStudentMarks = remember { mutableStateMapOf<String, String>() }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            photoBytesSelected = it.toByteArray(context)
        }
    }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("🔍 Search students...") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(8.dp)
            )

            Button(
                onClick = {
                    isEditMode = false
                    editingStudentId = ""
                    editingStudentName = ""
                    photoBytesSelected = null
                    editingStudentMarks.clear()
                    subjects.forEach { editingStudentMarks[it.name] = "" }
                    showAddStudentDialog = true
                },
                modifier = Modifier.height(56.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Student")
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No students found. Use 'Add Student' above to start entering data.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            filtered.forEach { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Display Student circular portrait photo (Circular Avatar Preview)
                        val avatarBitmap = remember(student.photoBytes) {
                            student.photoBytes?.let {
                                android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                            }?.asImageBitmap()
                        }
                        
                        if (avatarBitmap != null) {
                            Image(
                                bitmap = avatarBitmap,
                                contentDescription = "Student Photo",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = student.studentName,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    Text(
                                        text = "ID: ${student.studentId}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            isEditMode = true
                                            editingStudentId = student.studentId
                                            editingStudentName = student.studentName
                                            photoBytesSelected = student.photoBytes
                                            editingStudentMarks.clear()
                                            subjects.forEach {
                                                editingStudentMarks[it.name] = (student.marks[it.name] ?: 0).toString()
                                            }
                                            showAddStudentDialog = true
                                        }
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit student", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        onClick = {
                                            pendingDeleteAction = {
                                                viewModel.deleteStudent(student.studentId)
                                            }
                                            showMasterDeleteDialog = true
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete student", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }

                            // Marks summary
                            Text(
                                text = subjects.joinToString("  |  ") { sub ->
                                    "${sub.name}: ${student.marks[sub.name] ?: 0}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    // Add/Edit Student Dialog with custom Portrait Photo selector
    if (showAddStudentDialog) {
        Dialog(onDismissRequest = { showAddStudentDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = if (isEditMode) "✏️ Edit Student Info & Marks" else "➕ Add Student to $selectedClass",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = editingStudentId,
                            onValueChange = { if (!isEditMode) editingStudentId = it },
                            label = { Text("Student ID (e.g. ST001)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            enabled = !isEditMode,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = editingStudentName,
                            onValueChange = { editingStudentName = it },
                            label = { Text("Student Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    // Photo Picker Layout
                    item {
                        Text(
                            text = "👦 ළමුන්ගේ පින්තූර ඇතුළත් කරන්න (Student Photo):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val bitmap = remember(photoBytesSelected) {
                                photoBytesSelected?.let {
                                    android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                }?.asImageBitmap()
                            }
                            
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = "Selected Photo",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { photoPickerLauncher.launch("image/*") },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Upload Photo")
                                }
                                if (photoBytesSelected != null) {
                                    TextButton(
                                        onClick = { photoBytesSelected = null }
                                    ) {
                                        Text("Remove Photo", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }

                    if (subjects.isNotEmpty()) {
                        item {
                            Text(
                                text = "Enter Subject Marks:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        items(subjects, key = { it.id }) { sub ->
                            var markVal by remember { mutableStateOf(editingStudentMarks[sub.name] ?: "") }
                            OutlinedTextField(
                                value = markVal,
                                onValueChange = {
                                    markVal = it
                                    editingStudentMarks[sub.name] = it
                                },
                                label = { Text("${sub.name} (Pass Mark: ${sub.passMark})") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showAddStudentDialog = false }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (editingStudentId.isNotBlank() && editingStudentName.isNotBlank()) {
                                        val marksMap = subjects.associate { sub ->
                                            sub.name to (editingStudentMarks[sub.name]?.toIntOrNull() ?: 0)
                                        }
                                        viewModel.addOrUpdateStudent(
                                            studentId = editingStudentId,
                                            studentName = editingStudentName,
                                            marks = marksMap,
                                            className = selectedClass,
                                            photoBytes = photoBytesSelected
                                        )
                                        showAddStudentDialog = false
                                    }
                                }
                            ) {
                                Text("Save")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showMasterDeleteDialog) {
        var pinInput by remember { mutableStateOf("") }
        var showError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                showMasterDeleteDialog = false
                pendingDeleteAction = null
            },
            title = {
                Text(
                    text = "ප්‍රධාන අවසරය අවශ්‍යයි",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "දත්ත මකාදැමීම සිදුකළ හැක්කේ ප්‍රධාන Master PIN අංකයෙන් පමණි.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pinInput = it },
                        label = {
                            Text("ප්‍රධාන Master PIN අංකය")
                        },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        isError = showError,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (showError) {
                        Text(
                            text = "ක්‍රියාව අත්හිටුවන ලදී! Master PIN එක වැරදියි.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val isValid = viewModel.verifyPrincipalPin(pinInput)
                        if (isValid) {
                            pendingDeleteAction?.invoke()
                            showMasterDeleteDialog = false
                            pendingDeleteAction = null
                        } else {
                            showError = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("තහවුරු කරන්න")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showMasterDeleteDialog = false
                        pendingDeleteAction = null
                    }
                ) {
                    Text("අවලංගු කරන්න")
                }
            }
        )
    }
}

// ==========================================
// WORKSPACE SUB-TAB 2: STUDENT GRADES VIEW
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkspaceStudentGradesView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>
) {
    var searchQuery by remember { mutableStateOf("") }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("🔍 සාමාර්ථ බැලීමට ශිෂ්‍ය නම/ID ටයිප් කරන්න") },
            placeholder = { Text("Search grades by name or ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(8.dp)
        )

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No matching students found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            filtered.forEach { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = student.studentName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "ID: ${student.studentId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "Avg: ${student.average}%",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(
                            modifier = Modifier
                                .height(1.dp)
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        )

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            subjects.forEach { subject ->
                                val score = student.marks[subject.name] ?: 0
                                val grade = student.grades[subject.name] ?: "F"
                                
                                val badgeColor = when (grade) {
                                    "A" -> Color(0xFFE6F4EA)
                                    "B" -> Color(0xFFE8F0FE)
                                    "C" -> Color(0xFFE2F1F8)
                                    "S" -> Color(0xFFFEF7E0)
                                    else -> Color(0xFFFCE8E6)
                                }
                                val textColor = when (grade) {
                                    "A" -> Color(0xFF137333)
                                    "B" -> Color(0xFF1A73E8)
                                    "C" -> Color(0xFF00838F)
                                    "S" -> Color(0xFFB06000)
                                    else -> Color(0xFFC5221F)
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.border(
                                        width = 1.dp,
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "${subject.name}: $score",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(badgeColor)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = grade,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = textColor
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 3: RANKINGS & EXPORT
// ==========================================
@Composable
fun WorkspaceRankingsExportView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    classConfig: ClassConfig?,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var includePhotosInReport by remember { mutableStateOf(true) }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true) ||
            it.rank.toString() == searchQuery
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text(Translation.dict[selectedLanguage]?.search ?: "🔍 Search Rankings...") },
            placeholder = { Text("Search by rank, name or ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(8.dp)
        )

        // Rankings list
        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No ranked data found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            filtered.forEach { student ->
                val medalIcon = when (student.rank) {
                    1 -> "🥇 "
                    2 -> "🥈 "
                    3 -> "🥉 "
                    else -> "#${student.rank} "
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.dp,
                        color = when (student.rank) {
                            1 -> Color(0xFFFFD700)
                            2 -> Color(0xFFC0C0C0)
                            3 -> Color(0xFFCD7F32)
                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Circular photo preview inside ranked list row
                            val rankAvatarBitmap = remember(student.photoBytes) {
                                student.photoBytes?.let {
                                    android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                }?.asImageBitmap()
                            }
                            
                            if (rankAvatarBitmap != null) {
                                Image(
                                    bitmap = rankAvatarBitmap,
                                    contentDescription = "Photo",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .border(0.5.dp, MaterialTheme.colorScheme.outline, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = medalIcon,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = student.studentName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "ID: ${student.studentId}  |  Total: ${student.total}  |  Average: ${student.average}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Status badge
                        val badgeColor = if (student.status.contains("Pass")) Color(0xFFE6F4EA) else Color(0xFFFCE8E6)
                        val badgeTextColor = if (student.status.contains("Pass")) Color(0xFF137333) else Color(0xFFC5221F)

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badgeColor)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = student.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeTextColor
                            )
                        }
                    }
                }
            }
        }

        // Individual Progress Report Card Generator
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "🧑‍🎓 " + when (selectedLanguage) {
                        "Sinhala" -> "ශිෂ්‍ය ප්‍රගති වාර්තා සාදන්නා (Individual Report Card)"
                        "Tamil" -> "தனிநபர் மாணவர் அறிக்கை அட்டை (Individual Report Card)"
                        else -> "Individual Student Report Card Generator"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ප්‍රගති වාර්තාව (Individual PDF) සෑදීම සඳහා ශිෂ්‍යයා තෝරන්න:"
                        "Tamil" -> "தனிநபர் PDF அறிக்கையை உருவாக்க மாணவரைத் தேர்ந்தெடுக்கவும்:"
                        else -> "Select a student to generate their individual A4 progress report card:"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                var selectedStudentForReport by remember(students) { mutableStateOf(students.firstOrNull()) }
                var expandedStudentDropdown by remember { mutableStateOf(false) }

                Box(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandedStudentDropdown = true }
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = selectedStudentForReport?.studentName ?: "Select a student...",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (selectedStudentForReport != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    DropdownMenu(
                        expanded = expandedStudentDropdown,
                        onDismissRequest = { expandedStudentDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        students.forEach { std ->
                            DropdownMenuItem(
                                text = { Text("[${std.studentId}] ${std.studentName}", fontWeight = FontWeight.Bold) },
                                onClick = {
                                    selectedStudentForReport = std
                                    expandedStudentDropdown = false
                                }
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val currentStudent = selectedStudentForReport
                        if (currentStudent == null) {
                            Toast.makeText(context, "Please select a student first!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "Report_Card_${currentStudent.studentId}.pdf")
                            val fos = FileOutputStream(pdfFile)
                            val subjectNames = subjects.map { it.name }
                            
                            PdfGenerator.generateIndividualReport(
                                context = context,
                                config = schoolConfig,
                                className = selectedClass,
                                classTeacher = classConfig?.classTeacher ?: "Unknown",
                                student = currentStudent,
                                subjects = subjectNames,
                                outputStream = fos
                            )
                            fos.close()

                            val pdfUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                pdfFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                putExtra(Intent.EXTRA_SUBJECT, "Report Card - ${currentStudent.studentName}")
                                putExtra(Intent.EXTRA_TEXT, "Official Student Progress Report Card for ${currentStudent.studentName}.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Individual Progress Report"))

                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to generate Individual PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(when (selectedLanguage) {
                        "Sinhala" -> "නිල තනි ප්‍රගති වාර්තාව PDF සාදන්න"
                        "Tamil" -> "தனிநபர் PDF அறிக்கையை உருவாக்கவும்"
                        else -> "Generate & Share Individual Report (PDF)"
                    })
                }
            }
        }

        // Export Actions Section (Class Rankings)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "නිල අධ්‍යයන වාර්තා (Official Academic Reports) 📄"
                        "Tamil" -> "உத்தியோகபூர்வ கல்வி அறிக்கைகள் 📄"
                        else -> "Official Academic Reports (නිල වාර්තා) 📄"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "සියලුම සිසුන්ගේ ශ්‍රේණිගත කිරීම් සහ ලකුණු ඇතුළත් නිල පන්ති ලේඛන වාර්තාවක් (A4 PDF) හෝ එක්සෙල් ගොනුවක් බාගත කරන්න."
                        "Tamil" -> "அனைத்து மாணவர்களின் தரவரிசைகள் மற்றும் மதிப்பெண்கள் அடங்கிய உத்தியோகபூர்வ வகுப்பு அறிக்கையை (PDF அல்லது Excel) பதிவிறக்கவும்."
                        else -> "Generate and share styled official PDF reports or download full rankings spreadsheets compatible with Excel for $selectedClass."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                // Photos toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable { includePhotosInReport = !includePhotosInReport },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Checkbox(
                        checked = includePhotosInReport,
                        onCheckedChange = { includePhotosInReport = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Translation.dict[selectedLanguage]?.photoToggle ?: "📸 Include Student Photos in PDF Report",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                // PDF Export (Class Rankings)
                Button(
                    onClick = {
                        if (students.isEmpty()) {
                            Toast.makeText(context, "No student data available to generate report!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "Official_Report_${selectedClass.replace(" ", "_")}.pdf")
                            val fos = FileOutputStream(pdfFile)
                            val subjectNames = subjects.map { it.name }
                            
                            PdfGenerator.generateReport(
                                context = context,
                                config = schoolConfig,
                                className = selectedClass,
                                classTeacher = classConfig?.classTeacher ?: "Unknown",
                                subjects = subjectNames,
                                students = students,
                                outputStream = fos,
                                includePhotos = includePhotosInReport
                            )
                            fos.close()

                            val pdfUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                pdfFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                putExtra(Intent.EXTRA_SUBJECT, "$selectedClass - ${schoolConfig.examType} Official Report")
                                putExtra(Intent.EXTRA_TEXT, "Here is the official academic rankings and performance report for Class $selectedClass.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Official PDF Report"))

                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to generate PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        contentColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_pdf_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(Translation.dict[selectedLanguage]?.pdfBtn ?: "Download Official Class Report (A4 PDF)")
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Excel/CSV Export
                FilledTonalButton(
                    onClick = {
                        if (students.isEmpty()) {
                            Toast.makeText(context, "No student data available to generate spreadsheet!", Toast.LENGTH_SHORT).show()
                            return@FilledTonalButton
                        }
                        try {
                            val fileName = "${selectedClass.replace(" ", "_")}_${schoolConfig.examType.replace(" ", "_")}_Report.csv"
                            val csvFile = File(context.cacheDir, fileName)
                            val fos = FileOutputStream(csvFile)
                            val writer = java.io.BufferedWriter(java.io.OutputStreamWriter(fos, "UTF-8"))

                            // UTF-8 BOM
                            writer.write('\ufeff'.toInt())

                            // CSV headers
                            val headers = mutableListOf("Rank", "Student ID", "Student Name")
                            subjects.forEach {
                                headers.add(it.name)
                                headers.add("${it.name} (Grade)")
                            }
                            headers.add("Total")
                            headers.add("Average")
                            headers.add("Status")
                            writer.write(headers.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                            writer.newLine()

                            // CSV rows
                            students.forEach { student ->
                                val row = mutableListOf<String>()
                                row.add(student.rank.toString())
                                row.add(student.studentId)
                                row.add(student.studentName)
                                subjects.forEach { subject ->
                                    row.add((student.marks[subject.name] ?: 0).toString())
                                    row.add(student.grades[subject.name] ?: "F")
                                }
                                row.add(student.total.toString())
                                row.add(student.average.toString())
                                row.add(student.status)
                                writer.write(row.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                                writer.newLine()
                            }
                            writer.flush()
                            writer.close()
                            fos.close()

                            val csvUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                csvFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/comma-separated-values"
                                putExtra(Intent.EXTRA_STREAM, csvUri)
                                putExtra(Intent.EXTRA_SUBJECT, "$selectedClass - ${schoolConfig.examType} Spreadsheet")
                                putExtra(Intent.EXTRA_TEXT, "Here is the academic spreadsheet containing scores and grades for Class $selectedClass.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Rankings Spreadsheet (Excel/CSV)"))
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to export spreadsheet: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        contentColor = MaterialTheme.colorScheme.secondaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_excel_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.TableView, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(when (selectedLanguage) {
                        "Sinhala" -> "Excel ශ්‍රේණිගත කිරීම් වාර්තාව බාගත කරන්න"
                        "Tamil" -> "Excel தரவரிசை அறிக்கையைப் பதிவிறக்கவும்"
                        else -> "Download & Share Spreadsheet (Excel)"
                    })
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 4: SUBJECT ANALYSIS CHARTS
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceSubjectChartsView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    selectedLanguage: String
) {
    val t = Translation.dict[selectedLanguage]
    val classSubjects = subjects.filter { it.className == selectedClass }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = t?.chartTitle ?: "📊 Grade Distribution Analysis per Subject",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        if (classSubjects.isEmpty() || students.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "ප්‍රස්ථාර බැලීමට ප්‍රමාණවත් විෂයයන් හෝ සිසුන්ගේ ලකුණු දත්ත පද්ධතියේ නැත."
                            "Tamil" -> "வரைபடங்களைப் பார்க்க போதுமான பாடங்கள் அல்லது மாணவர்களின் மதிப்பெண் தரவு கணினியில் இல்லை."
                            else -> "There are no subjects or student marks in the system to display charts."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        } else {
            var selectedSubject by remember(selectedClass) { mutableStateOf(classSubjects.first()) }
            var expandedDropdown by remember { mutableStateOf(false) }

            val chartTypes = listOf(
                "Bar Chart",
                "Line Chart",
                "Pie Chart",
                "Donut Chart",
                "Area Chart",
                "Failure vs. Passing Ratio",
                "Monthly Attendance Trends",
                "Class Average Progress",
                "Grade Distribution Pie",
                "Syllabus Coverage Progress"
            )
            var selectedChartType by remember { mutableStateOf("Bar Chart") }
            var expandedChartDropdown by remember { mutableStateOf(false) }

            // Subject Selection Dropdown
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedSubject.name,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(t?.selectSubChart ?: "📈 Select Subject to View Chart:") },
                    trailingIcon = {
                        IconButton(onClick = { expandedDropdown = !expandedDropdown }) {
                            Icon(
                                imageVector = if (expandedDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Toggle Subject Dropdown"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedDropdown = !expandedDropdown },
                    shape = RoundedCornerShape(8.dp)
                )

                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    classSubjects.forEach { subject ->
                        DropdownMenuItem(
                            text = { Text(subject.name, fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                selectedSubject = subject
                                expandedDropdown = false
                            }
                        )
                    }
                }
            }

            // Chart Type Dropdown (Bilingual)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = when (selectedChartType) {
                        "Bar Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "තීරු ප්‍රස්ථාරය (Bar Chart)"
                            "Tamil" -> "பட்டை வரைபடம் (Bar Chart)"
                            else -> "Bar Chart"
                        }
                        "Line Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "රේඛීය ප්‍රස්ථාරය (Line Chart)"
                            "Tamil" -> "வரி வரைபடம் (Line Chart)"
                            else -> "Line Chart"
                        }
                        "Pie Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "වට ප්‍රස්ථාරය (Pie Chart)"
                            "Tamil" -> "வட்ட வரைபடம் (Pie Chart)"
                            else -> "Pie Chart"
                        }
                        "Donut Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "ඩෝනට් ප්‍රස්ථාරය (Donut Chart)"
                            "Tamil" -> "டோனட் வரைபடம் (Donut Chart)"
                            else -> "Donut Chart"
                        }
                        "Area Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "ප්‍රදේශ ප්‍රස්ථාරය (Area Chart)"
                            "Tamil" -> "பரப்பு வரைபடம் (Area Chart)"
                            else -> "Area Chart"
                        }
                        "Failure vs. Passing Ratio" -> when (selectedLanguage) {
                            "Sinhala" -> "අසමත් සහ සමත් අනුපාතය (Failure vs. Passing Ratio)"
                            "Tamil" -> "தேர்ச்சி vs தோல்வி விகிதம் (Failure vs. Passing Ratio)"
                            else -> "Failure vs. Passing Ratio"
                        }
                        "Monthly Attendance Trends" -> when (selectedLanguage) {
                            "Sinhala" -> "මාසික පැමිණීමේ ප්‍රවණතා (Monthly Attendance Trends)"
                            "Tamil" -> "மாதாந்திர வருகை போக்குகள் (Monthly Attendance Trends)"
                            else -> "Monthly Attendance Trends"
                        }
                        "Class Average Progress" -> when (selectedLanguage) {
                            "Sinhala" -> "පන්ති සාමාන්‍ය ප්‍රගතිය (Class Average Progress)"
                            "Tamil" -> "வகுப்பு சராசரி முன்னேற்றம் (Class Average Progress)"
                            else -> "Class Average Progress"
                        }
                        "Grade Distribution Pie" -> when (selectedLanguage) {
                            "Sinhala" -> "සාමාර්ථ ව්‍යාප්ති වට ප්‍රස්ථාරය (Grade Distribution Pie)"
                            "Tamil" -> "மதிப்பெண் விநியோக வட்ட வரைபடம் (Grade Distribution Pie)"
                            else -> "Grade Distribution Pie"
                        }
                        "Syllabus Coverage Progress" -> when (selectedLanguage) {
                            "Sinhala" -> "විෂය නිර්දේශ ආවරණය (Syllabus Coverage Progress)"
                            "Tamil" -> "பாடத்திட்ட கவரேஜ் முன்னேற்றம் (Syllabus Coverage Progress)"
                            else -> "Syllabus Coverage Progress"
                        }
                        else -> selectedChartType
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "📊 ප්‍රස්ථාර වර්ගය තෝරන්න (Select Chart Type):"
                            "Tamil" -> "📊 வரைபட வகையைத் தேர்ந்தெடுக்கவும்:"
                            else -> "📊 Select Chart Type:"
                        }
                    ) },
                    trailingIcon = {
                        IconButton(onClick = { expandedChartDropdown = !expandedChartDropdown }) {
                            Icon(
                                imageVector = if (expandedChartDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Toggle Chart Dropdown"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedChartDropdown = !expandedChartDropdown },
                    shape = RoundedCornerShape(8.dp)
                )

                DropdownMenu(
                    expanded = expandedChartDropdown,
                    onDismissRequest = { expandedChartDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    chartTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { 
                                Text(
                                    text = when (type) {
                                        "Bar Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "තීරු ප්‍රස්ථාරය (Bar Chart)"
                                            "Tamil" -> "பட்டை வரைபடம் (Bar Chart)"
                                            else -> "Bar Chart"
                                        }
                                        "Line Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "රේඛීය ප්‍රස්ථාරය (Line Chart)"
                                            "Tamil" -> "வரி வரைபடம் (Line Chart)"
                                            else -> "Line Chart"
                                        }
                                        "Pie Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "වට ප්‍රස්ථාරය (Pie Chart)"
                                            "Tamil" -> "வட்ட வரைபடம் (Pie Chart)"
                                            else -> "Pie Chart"
                                        }
                                        "Donut Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "ඩෝනට් ප්‍රස්ථාරය (Donut Chart)"
                                            "Tamil" -> "டோனட் வரைபடம் (Donut Chart)"
                                            else -> "Donut Chart"
                                        }
                                        "Area Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "ප්‍රදේශ ප්‍රස්ථාරය (Area Chart)"
                                            "Tamil" -> "பரப்பு வரைபடம் (Area Chart)"
                                            else -> "Area Chart"
                                        }
                                        "Failure vs. Passing Ratio" -> when (selectedLanguage) {
                                            "Sinhala" -> "අසමත් සහ සමත් අනුපාතය (Failure vs. Passing Ratio)"
                                            "Tamil" -> "தேர்ச்சி vs தோல்வி விகிதம் (Failure vs. Passing Ratio)"
                                            else -> "Failure vs. Passing Ratio"
                                        }
                                        "Monthly Attendance Trends" -> when (selectedLanguage) {
                                            "Sinhala" -> "මාසික පැමිණීමේ ප්‍රවණතා (Monthly Attendance Trends)"
                                            "Tamil" -> "மாதாந்திர வருகை போக்குகள் (Monthly Attendance Trends)"
                                            else -> "Monthly Attendance Trends"
                                        }
                                        "Class Average Progress" -> when (selectedLanguage) {
                                            "Sinhala" -> "පන්ති සාමාන්‍ය ප්‍රගතිය (Class Average Progress)"
                                            "Tamil" -> "வகுப்பு சராசரி முன்னேற்றம் (Class Average Progress)"
                                            else -> "Class Average Progress"
                                        }
                                        "Grade Distribution Pie" -> when (selectedLanguage) {
                                            "Sinhala" -> "සාමාර්ථ ව්‍යාප්ති වට ප්‍රස්ථාරය (Grade Distribution Pie)"
                                            "Tamil" -> "மதிப்பெண் விநியோக வட்ட வரைபடம் (Grade Distribution Pie)"
                                            else -> "Grade Distribution Pie"
                                        }
                                        "Syllabus Coverage Progress" -> when (selectedLanguage) {
                                            "Sinhala" -> "විෂය නිර්දේශ ආවරණය (Syllabus Coverage Progress)"
                                            "Tamil" -> "பாடத்திட்ட கவரேஜ் முன்னேற்றம் (Syllabus Coverage Progress)"
                                            else -> "Syllabus Coverage Progress"
                                        }
                                        else -> type
                                    },
                                    fontWeight = FontWeight.SemiBold
                                ) 
                            },
                            onClick = {
                                selectedChartType = type
                                expandedChartDropdown = false
                            }
                        )
                    }
                }
            }

            // Grade counts calculations
            val gradeCounts = students.map { it.grades[selectedSubject.name] ?: "F" }
                .groupingBy { it }
                .eachCount()

            val possibleGrades = listOf("A", "B", "C", "S", "F")
            val chartData = possibleGrades.map { grade ->
                grade to (gradeCounts[grade] ?: 0)
            }

            val gradeColors = mapOf(
                "A" to Color(0xFF4CAF50), // Green
                "B" to Color(0xFF2196F3), // Blue
                "C" to Color(0xFFFF9800), // Orange
                "S" to Color(0xFF9C27B0), // Purple
                "F" to Color(0xFFF44336)  // Red
            )

            // Beautiful styled card containing the Active Chart Type
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedSubject.name} - ${when (selectedLanguage) {
                                "Sinhala" -> "සාමාර්ථ ව්‍යාප්තිය"
                                "Tamil" -> "தரப் பகிர்வு"
                                else -> "Grade Distribution"
                            }}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )

                        // 📥 DOWNLOAD CHART BUTTON
                        Button(
                            onClick = {
                                saveChartAsPng(
                                    context = context,
                                    schoolConfig = schoolConfig,
                                    className = selectedClass,
                                    subjectName = selectedSubject.name,
                                    chartType = selectedChartType,
                                    data = chartData
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Download Chart",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "බාගත කරන්න"
                                    "Tamil" -> "பதிவிறக்கவும்"
                                    else -> "Export PNG"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic Render based on selection
                    when (selectedChartType) {
                        "Bar Chart" -> ColorfulBarChart(data = chartData, gradeColors = gradeColors)
                        "Line Chart" -> ColorfulLineChart(data = chartData, gradeColors = gradeColors)
                        "Pie Chart" -> ColorfulPieChart(data = chartData, gradeColors = gradeColors)
                        "Donut Chart" -> ColorfulDonutChart(data = chartData, gradeColors = gradeColors)
                        "Area Chart" -> ColorfulAreaChart(data = chartData, gradeColors = gradeColors)
                        "Failure vs. Passing Ratio" -> {
                            val passing = chartData.filter { it.first != "F" }.sumOf { it.second }
                            val failing = chartData.firstOrNull { it.first == "F" }?.second ?: 0
                            FailurePassingStackedBarChart(passing = passing, failing = failing, selectedLanguage = selectedLanguage)
                        }
                        "Monthly Attendance Trends" -> {
                            MonthlyStudentAttendanceTrends(selectedLanguage = selectedLanguage)
                        }
                        "Class Average Progress" -> {
                            TermOverTermClassProgressChart(selectedLanguage = selectedLanguage)
                        }
                        "Grade Distribution Pie" -> {
                            val a = chartData.firstOrNull { it.first == "A" }?.second ?: 0
                            val b = chartData.firstOrNull { it.first == "B" }?.second ?: 0
                            val c = chartData.firstOrNull { it.first == "C" }?.second ?: 0
                            val f = chartData.firstOrNull { it.first == "F" }?.second ?: 0
                            CustomGradePieChart(a = a, b = b, c = c, f = f, selectedLanguage = selectedLanguage)
                        }
                        "Syllabus Coverage Progress" -> {
                            SyllabusCoverageProgressBars(selectedLanguage = selectedLanguage)
                        }
                    }
                }
            }

            // Summary Table Section
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "📝 සාරාංශ වගුව"
                    "Tamil" -> "📝 சுருக்க அட்டவணை"
                    else -> "📝 Summary Table"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .padding(vertical = 12.dp, horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "සාමාර්ථය"
                                "Tamil" -> "தரம்"
                                else -> "Grade"
                            },
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Start
                        )
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "සිසුන් සංඛ්‍යාව"
                                "Tamil" -> "மாணவர்களின் எண்ணிக்கை"
                                else -> "Student Count"
                            },
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                    }

                    // Table Rows
                    chartData.forEachIndexed { index, (grade, count) ->
                        val rowBgColor = if (index % 2 == 0) {
                            MaterialTheme.colorScheme.surface
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBgColor)
                                .padding(vertical = 12.dp, horizontal = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Grade indicator circle/badge
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Start
                            ) {
                                val badgeColor = gradeColors[grade] ?: Color.Gray
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(badgeColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = grade,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = when (grade) {
                                        "A" -> "Distinction (A)"
                                        "B" -> "Very Good (B)"
                                        "C" -> "Credit (C)"
                                        "S" -> "Ordinary Pass (S)"
                                        else -> "Weak/Fail (F)"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Text(
                                text = count.toString(),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// INDIVIDUAL DYNAMIC COMPOSABLE CHARTS
// ==========================================

@Composable
fun ColorfulBarChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 1
    val maxCount = if (maxVal == 0) 1 else maxVal

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEach { (grade, value) ->
            val animatedHeightFraction by animateFloatAsState(
                targetValue = value.toFloat() / maxCount,
                animationSpec = spring(dampingRatio = 0.8f, stiffness = 120f),
                label = "bar_height"
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                if (value > 0) {
                    Text(
                        text = value.toString(),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.55f)
                        .fillMaxHeight(animatedHeightFraction.coerceIn(0.01f, 1f))
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    gradeColors[grade] ?: Color.Gray,
                                    (gradeColors[grade] ?: Color.Gray).copy(alpha = 0.5f)
                                )
                            )
                        )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = grade,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun ColorfulLineChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 1
    val maxCount = if (maxVal == 0) 1 else maxVal
    val lineColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val pointCount = data.size
            val stepX = width / (pointCount - 1)

            // Draw grid lines
            for (i in 0..4) {
                val y = i * (height / 4)
                drawLine(
                    color = Color.Gray.copy(alpha = 0.15f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Calculate coordinates
            val points = data.mapIndexed { index, (_, value) ->
                val x = index * stepX
                val y = height - (value.toFloat() / maxCount) * height
                Offset(x, y)
            }

            // Draw continuous line
            val path = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) moveTo(point.x, point.y)
                    else lineTo(point.x, point.y)
                }
            }
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
            )

            // Draw distinct data node indicators
            points.forEachIndexed { index, point ->
                val grade = data[index].first
                val ptColor = gradeColors[grade] ?: Color.Gray

                drawCircle(
                    color = ptColor,
                    radius = 7.dp.toPx(),
                    center = point
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = point
                )
            }
        }
        
        // Label mapping below the Canvas
        Row(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            data.forEach { (grade, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$grade\n($value)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorfulPieChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val totalCount = data.sumOf { it.second }
    val totalSum = if (totalCount == 0) 1f else totalCount.toFloat()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (totalCount == 0) {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No Student Marks Registered",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(
                modifier = Modifier.size(160.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    data.forEach { (grade, value) ->
                        val sweepAngle = (value.toFloat() / totalSum) * 360f
                        if (sweepAngle > 0f) {
                            drawArc(
                                color = gradeColors[grade] ?: Color.Gray,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true
                            )
                            startAngle += sweepAngle
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Multi-line responsive FlowRow legend representation
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 3
        ) {
            data.forEach { (grade, value) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(gradeColors[grade] ?: Color.Gray)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$grade: $value (${String.format("%.1f", (value / totalSum) * 100)}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorfulDonutChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val totalCount = data.sumOf { it.second }
    val totalSum = if (totalCount == 0) 1f else totalCount.toFloat()
    val holeColor = MaterialTheme.colorScheme.surface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (totalCount == 0) {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No Student Marks Registered",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    data.forEach { (grade, value) ->
                        val sweepAngle = (value.toFloat() / totalSum) * 360f
                        if (sweepAngle > 0f) {
                            drawArc(
                                color = gradeColors[grade] ?: Color.Gray,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true
                            )
                            startAngle += sweepAngle
                        }
                    }
                    
                    // Overlay smaller white cutout circle to transform the Pie Chart into a Donut Chart
                    drawCircle(
                        color = holeColor,
                        radius = size.width / 4.2f
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = totalCount.toString(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Total",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 3
        ) {
            data.forEach { (grade, value) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(gradeColors[grade] ?: Color.Gray)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$grade: $value (${String.format("%.1f", (value / totalSum) * 100)}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun ColorfulAreaChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 1
    val maxCount = if (maxVal == 0) 1 else maxVal
    val lineColor = MaterialTheme.colorScheme.primary
    val areaColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val pointCount = data.size
            val stepX = width / (pointCount - 1)

            // Grid References
            for (i in 0..4) {
                val y = i * (height / 4)
                drawLine(
                    color = Color.Gray.copy(alpha = 0.15f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val points = data.mapIndexed { index, (_, value) ->
                val x = index * stepX
                val y = height - (value.toFloat() / maxCount) * height
                Offset(x, y)
            }

            // 1. Draw solid gradient/tint filled path first
            val areaPath = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) {
                        moveTo(point.x, height)
                        lineTo(point.x, point.y)
                    } else {
                        lineTo(point.x, point.y)
                    }
                }
                lineTo(points.last().x, height)
                close()
            }
            drawPath(
                path = areaPath,
                color = areaColor
            )

            // 2. Draw continuous line path on top
            val path = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) moveTo(point.x, point.y)
                    else lineTo(point.x, point.y)
                }
            }
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
            )

            // 3. Draw nodes
            points.forEachIndexed { index, point ->
                val grade = data[index].first
                val ptColor = gradeColors[grade] ?: Color.Gray

                drawCircle(
                    color = ptColor,
                    radius = 7.dp.toPx(),
                    center = point
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = point
                )
            }
        }
        
        // Bottom markers
        Row(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            data.forEach { (grade, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$grade\n($value)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun FailurePassingStackedBarChart(
    passing: Int,
    failing: Int,
    selectedLanguage: String
) {
    val total = passing + failing
    val totalVal = if (total == 0) 1f else total.toFloat()
    val passRatio = passing.toFloat() / totalVal
    val failRatio = failing.toFloat() / totalVal

    val textColor = MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "විෂය අනුව සමත් සහ අසමත් අනුපාතය"
                    "Tamil" -> "பாடம் வாரியாக தேர்ச்சி மற்றும் தோல்வி விகிதம்"
                    else -> "Subject-wise Passing vs Failing Ratio"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height

                    // Y-axis grid lines
                    for (i in 0..4) {
                        val y = i * (height / 4)
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.15f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    val barWidth = width * 0.35f
                    val left = (width - barWidth) / 2f

                    val failHeight = height * failRatio
                    val passHeight = height * passRatio

                    // Stack failing (Red) on bottom, passing (Green) on top
                    if (failing > 0) {
                        drawRect(
                            color = Color(0xFFEF4444),
                            topLeft = Offset(left, height - failHeight),
                            size = androidx.compose.ui.geometry.Size(barWidth, failHeight)
                        )
                    }
                    if (passing > 0) {
                        drawRect(
                            color = Color(0xFF10B981),
                            topLeft = Offset(left, height - failHeight - passHeight),
                            size = androidx.compose.ui.geometry.Size(barWidth, passHeight)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(12.dp).background(Color(0xFF10B981), RoundedCornerShape(2.dp)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Pass: $passing (${String.format("%.0f", passRatio * 100)}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(12.dp).background(Color(0xFFEF4444), RoundedCornerShape(2.dp)))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Fail: $failing (${String.format("%.0f", failRatio * 100)}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                }
            }
        }
    }
}

@Composable
fun MonthlyStudentAttendanceTrends(selectedLanguage: String) {
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun")
    val attendance = listOf(94f, 91f, 96f, 87f, 95f, 98f)
    val textColor = MaterialTheme.colorScheme.onSurface
    val primaryColor = MaterialTheme.colorScheme.primary

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "මාසික ශිෂ්‍ය පැමිණීමේ ප්‍රවණතා"
                    "Tamil" -> "மாதாந்திர மாணவர் வருகை போக்குகள்"
                    else -> "Monthly Student Attendance Trends"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = primaryColor,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val stepX = width / (months.size - 1)

                    // Y Grid levels mapped to 80% - 100% range
                    val gridLevels = listOf(100f, 95f, 90f, 85f, 80f)
                    gridLevels.forEach { level ->
                        val y = height - ((level - 80f) / 20f) * height
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.12f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    val points = attendance.mapIndexed { index, value ->
                        val x = index * stepX
                        val pct = (value - 80f) / 20f
                        val y = height - pct.coerceIn(0f, 1f) * height
                        Offset(x, y)
                    }

                    val path = Path()
                    val fillPath = Path()

                    if (points.isNotEmpty()) {
                        path.moveTo(points.first().x, points.first().y)
                        fillPath.moveTo(points.first().x, height)
                        fillPath.lineTo(points.first().x, points.first().y)

                        for (i in 1 until points.size) {
                            val prev = points[i - 1]
                            val curr = points[i]
                            val conX1 = prev.x + (curr.x - prev.x) / 2f
                            val conY1 = prev.y
                            val conX2 = prev.x + (curr.x - prev.x) / 2f
                            val conY2 = curr.y

                            path.cubicTo(conX1, conY1, conX2, conY2, curr.x, curr.y)
                            fillPath.cubicTo(conX1, conY1, conX2, conY2, curr.x, curr.y)
                        }
                        fillPath.lineTo(points.last().x, height)
                        fillPath.close()
                    }

                    // Shaded gradient fill
                    drawPath(
                        path = fillPath,
                        color = primaryColor.copy(alpha = 0.15f)
                    )

                    // Smooth line
                    drawPath(
                        path = path,
                        color = primaryColor,
                        style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
                    )

                    // Data points
                    points.forEach { point ->
                        drawCircle(
                            color = primaryColor,
                            radius = 6.dp.toPx(),
                            center = point
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 3.dp.toPx(),
                            center = point
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                months.forEachIndexed { index, m ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = m,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                        Text(
                            text = "${attendance[index].toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TermOverTermClassProgressChart(selectedLanguage: String) {
    val subjects = listOf("Maths", "Science", "Sinhala", "English", "History")
    val term1Avg = listOf(66f, 70f, 82f, 64f, 75f)
    val term2Avg = listOf(74f, 78f, 85f, 70f, 81f)
    val textColor = MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "වාරයෙන් වාරයට පන්ති සාමාන්‍ය ප්‍රගතිය"
                    "Tamil" -> "வகுப்பு சராசரி முன்னேற்ற ஒப்பீடு"
                    else -> "Term-over-Term Class Average Progress"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val stepX = width / (subjects.size - 1)

                    // Y Grid lines (0 to 100%)
                    for (i in 0..4) {
                        val y = i * (height / 4)
                        drawLine(
                            color = Color.Gray.copy(alpha = 0.12f),
                            start = Offset(0f, y),
                            end = Offset(width, y),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    fun mapToOffset(index: Int, valPct: Float): Offset {
                        val x = index * stepX
                        val pct = (valPct - 40f) / 60f // scale 40-100 to 0-1
                        val y = height - pct.coerceIn(0f, 1f) * height
                        return Offset(x, y)
                    }

                    val pointsT1 = term1Avg.mapIndexed { idx, v -> mapToOffset(idx, v) }
                    val pointsT2 = term2Avg.mapIndexed { idx, v -> mapToOffset(idx, v) }

                    // Term 1 Path (Blue)
                    val pathT1 = Path().apply {
                        pointsT1.forEachIndexed { idx, pt ->
                            if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
                        }
                    }
                    drawPath(
                        path = pathT1,
                        color = Color(0xFF3B82F6),
                        style = Stroke(width = 2.5.dp.toPx(), join = StrokeJoin.Round)
                    )

                    // Term 2 Path (Emerald)
                    val pathT2 = Path().apply {
                        pointsT2.forEachIndexed { idx, pt ->
                            if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
                        }
                    }
                    drawPath(
                        path = pathT2,
                        color = Color(0xFF10B981),
                        style = Stroke(width = 2.5.dp.toPx(), join = StrokeJoin.Round)
                    )

                    // T1 Points
                    pointsT1.forEach { pt ->
                        drawCircle(color = Color(0xFF3B82F6), radius = 5.dp.toPx(), center = pt)
                        drawCircle(color = Color.White, radius = 2.dp.toPx(), center = pt)
                    }

                    // T2 Points
                    pointsT2.forEach { pt ->
                        drawCircle(color = Color(0xFF10B981), radius = 5.dp.toPx(), center = pt)
                        drawCircle(color = Color.White, radius = 2.dp.toPx(), center = pt)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                subjects.forEachIndexed { index, sub ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = sub,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                        Text(
                            text = "T1: ${term1Avg[index].toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF3B82F6)
                        )
                        Text(
                            text = "T2: ${term2Avg[index].toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF10B981),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomGradePieChart(
    a: Int, b: Int, c: Int, f: Int,
    selectedLanguage: String
) {
    val possibleGrades = listOf(
        "A" to a,
        "B" to b,
        "C" to c,
        "F" to f
    )
    val gradeColors = mapOf(
        "A" to Color(0xFF4CAF50),
        "B" to Color(0xFF2196F3),
        "C" to Color(0xFFFF9800),
        "F" to Color(0xFFEF4444)
    )
    val total = possibleGrades.sumOf { it.second }
    val totalSum = if (total == 0) 1f else total.toFloat()

    val textColor = MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "සාමාර්ථ ව්‍යාප්ති වට ප්‍රස්ථාරය"
                    "Tamil" -> "மதிப்பெண் விநியோக வட்ட வரைபடம்"
                    else -> "Grade Distribution Pie Chart"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (total == 0) {
                Text(
                    text = "No Student Marks Registered",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Box(
                    modifier = Modifier.size(160.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        var startAngle = -90f
                        possibleGrades.forEach { (grade, value) ->
                            val sweepAngle = (value.toFloat() / totalSum) * 360f
                            if (sweepAngle > 0f) {
                                drawArc(
                                    color = gradeColors[grade] ?: Color.Gray,
                                    startAngle = startAngle,
                                    sweepAngle = sweepAngle,
                                    useCenter = true
                                )
                                startAngle += sweepAngle
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxItemsInEachRow = 2
                ) {
                    possibleGrades.forEach { (grade, value) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(gradeColors[grade] ?: Color.Gray)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$grade: $value (${String.format("%.1f", (value / totalSum) * 100)}%)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = textColor
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SyllabusCoverageProgressBars(selectedLanguage: String) {
    val subjects = listOf("Mathematics", "Science", "English", "Sinhala", "History")
    val progress = listOf(0.85f, 0.90f, 0.65f, 0.82f, 0.75f)
    val textColor = MaterialTheme.colorScheme.onSurface
    val primaryColor = MaterialTheme.colorScheme.primary

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "විෂය නිර්දේශ ආවරණ ප්‍රගතිය"
                    "Tamil" -> "பாடத்திட்டம் முடிக்கப்பட்ட முன்னேற்றம்"
                    else -> "Teacher Syllabus Coverage Progress"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = primaryColor,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            subjects.forEachIndexed { index, sub ->
                val prg = progress[index]
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = sub,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                        Text(
                            text = "${(prg * 100).toInt()}% Covered",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = primaryColor
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                    ) {
                        val trackWidth = size.width
                        val trackHeight = size.height

                        // Background track
                        drawRoundRect(
                            color = Color.Gray.copy(alpha = 0.15f),
                            size = size,
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeight / 2, trackHeight / 2)
                        )

                        // Progress bar filling
                        drawRoundRect(
                            color = primaryColor,
                            size = androidx.compose.ui.geometry.Size(trackWidth * prg, trackHeight),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(trackHeight / 2, trackHeight / 2)
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// HIGH-PERFORMANCE OFFLINE CHART SAVING ENGINE
// ==========================================

fun saveChartAsPng(
    context: android.content.Context,
    schoolConfig: SchoolConfig,
    className: String,
    subjectName: String,
    chartType: String,
    data: List<Pair<String, Int>>
) {
    try {
        val width = 1200
        val height = 1000
        val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)

        // Reset with pristine white background canvas
        canvas.drawColor(android.graphics.Color.WHITE)

        // Set up high quality typography paint styles
        val titlePaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#1A237E") // Imperial Dark Indigo
            textSize = 38f
            isAntiAlias = true
            isFakeBoldText = true
        }

        val subtitlePaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#3F51B5") // Royal Indigo Accent
            textSize = 28f
            isAntiAlias = true
            isFakeBoldText = true
        }

        val metaPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#37474F") // Slate Charcoal
            textSize = 22f
            isAntiAlias = true
        }

        val labelPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 22f
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }

        val valuePaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#455A64")
            textSize = 20f
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }

        val gridPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#ECEFF1")
            strokeWidth = 2f
        }

        // Draw top aesthetic accent border banner
        val headerPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#3F51B5")
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 15f, headerPaint)

        // Title and Subtitle rendering
        canvas.drawText("MONEY MASTER - ACADEMIC SUITE", 50f, 70f, titlePaint)
        canvas.drawText("Subject Performance Analysis ($chartType)", 50f, 110f, subtitlePaint)

        // Main upper line divider
        canvas.drawLine(50f, 140f, (width - 50).toFloat(), 140f, gridPaint)

        // Render detailed Academic Metadata block at the top
        val metaYStart = 180f
        canvas.drawText("🏫 School: ${schoolConfig.schoolName.ifBlank { "N/A" }}", 50f, metaYStart, metaPaint)
        canvas.drawText("📅 Year: ${schoolConfig.academicYear.ifBlank { "N/A" }}", 50f, metaYStart + 40f, metaPaint)
        canvas.drawText("📝 Exam Type: ${schoolConfig.examType.ifBlank { "N/A" }}", 50f, metaYStart + 80f, metaPaint)

        canvas.drawText("🏫 Class Name: $className", 600f, metaYStart, metaPaint)
        canvas.drawText("📚 Subject Name: $subjectName", 600f, metaYStart + 40f, metaPaint)
        canvas.drawText("📊 Registered Students: ${data.sumOf { it.second }}", 600f, metaYStart + 80f, metaPaint)

        // Divider separation
        canvas.drawLine(50f, 300f, (width - 50).toFloat(), 300f, gridPaint)

        // Calculate and plot the charts canvas
        val chartLeft = 100f
        val chartRight = (width - 100).toFloat()
        val chartTop = 350f
        val chartBottom = 750f
        val chartWidth = chartRight - chartLeft
        val chartHeight = chartBottom - chartTop

        val gradeColors = mapOf(
            "A" to android.graphics.Color.parseColor("#4CAF50"),
            "B" to android.graphics.Color.parseColor("#2196F3"),
            "C" to android.graphics.Color.parseColor("#FF9800"),
            "S" to android.graphics.Color.parseColor("#9C27B0"),
            "F" to android.graphics.Color.parseColor("#F44336")
        )

        val totalCount = data.sumOf { it.second }
        val maxVal = data.maxOfOrNull { it.second } ?: 1
        val maxCount = if (maxVal == 0) 1 else maxVal

        when (chartType) {
            "Pie Chart", "Donut Chart" -> {
                val rectF = android.graphics.RectF(
                    (width / 2 - 200).toFloat(),
                    (chartTop + 50f),
                    (width / 2 + 200).toFloat(),
                    (chartTop + 450f)
                )
                if (totalCount == 0) {
                    canvas.drawText("No Student Data Available", (width / 2).toFloat(), (chartTop + 250f), labelPaint)
                } else {
                    var startAngle = -90f
                    data.forEach { (grade, value) ->
                        val sweepAngle = (value.toFloat() / totalCount) * 360f
                        if (sweepAngle > 0f) {
                            val arcPaint = android.graphics.Paint().apply {
                                color = gradeColors[grade] ?: android.graphics.Color.GRAY
                                style = android.graphics.Paint.Style.FILL
                                isAntiAlias = true
                            }
                            canvas.drawArc(rectF, startAngle, sweepAngle, true, arcPaint)
                            startAngle += sweepAngle
                        }
                    }

                    if (chartType == "Donut Chart") {
                        val holePaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.WHITE
                            style = android.graphics.Paint.Style.FILL
                            isAntiAlias = true
                        }
                        canvas.drawCircle((width / 2).toFloat(), (chartTop + 250f), 100f, holePaint)
                        
                        val innerTextPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.BLACK
                            textSize = 32f
                            isFakeBoldText = true
                            isAntiAlias = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        canvas.drawText(totalCount.toString(), (width / 2).toFloat(), (chartTop + 250f), innerTextPaint)
                        val innerLabelPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.GRAY
                            textSize = 18f
                            isAntiAlias = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        canvas.drawText("Total", (width / 2).toFloat(), (chartTop + 280f), innerLabelPaint)
                    }
                }
            }
            "Line Chart", "Area Chart" -> {
                // Plot grid line levels
                for (i in 0..4) {
                    val y = chartBottom - i * (chartHeight / 4)
                    canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
                    val labelVal = (i * (maxCount.toFloat() / 4f)).toInt()
                    canvas.drawText(labelVal.toString(), chartLeft - 30f, y + 8f, valuePaint)
                }

                val stepX = chartWidth / (data.size - 1)
                val points = data.mapIndexed { index, (_, value) ->
                    val x = chartLeft + index * stepX
                    val y = chartBottom - (value.toFloat() / maxCount) * chartHeight
                    android.graphics.PointF(x, y)
                }

                if (chartType == "Area Chart") {
                    val areaPath = android.graphics.Path().apply {
                        moveTo(points.first().x, chartBottom)
                        points.forEach { lineTo(it.x, it.y) }
                        lineTo(points.last().x, chartBottom)
                        close()
                    }
                    val areaPaint = android.graphics.Paint().apply {
                        color = android.graphics.Color.parseColor("#B3E5FC")
                        style = android.graphics.Paint.Style.FILL
                        alpha = 150
                        isAntiAlias = true
                    }
                    canvas.drawPath(areaPath, areaPaint)
                }

                val linePaint = android.graphics.Paint().apply {
                    color = android.graphics.Color.parseColor("#1976D2")
                    strokeWidth = 6f
                    style = android.graphics.Paint.Style.STROKE
                    strokeJoin = android.graphics.Paint.Join.ROUND
                    isAntiAlias = true
                }
                val path = android.graphics.Path().apply {
                    points.forEachIndexed { index, point ->
                        if (index == 0) moveTo(point.x, point.y)
                        else lineTo(point.x, point.y)
                    }
                }
                canvas.drawPath(path, linePaint)

                points.forEachIndexed { index, point ->
                    val (grade, value) = data[index]
                    val dotColor = gradeColors[grade] ?: android.graphics.Color.GRAY

                    val ptPaint = android.graphics.Paint().apply {
                        color = dotColor
                        style = android.graphics.Paint.Style.FILL
                        isAntiAlias = true
                    }
                    canvas.drawCircle(point.x, point.y, 12f, ptPaint)

                    val whitePaint = android.graphics.Paint().apply {
                        color = android.graphics.Color.WHITE
                        style = android.graphics.Paint.Style.FILL
                        isAntiAlias = true
                    }
                    canvas.drawCircle(point.x, point.y, 6f, whitePaint)

                    canvas.drawText("$grade ($value)", point.x, point.y - 25f, valuePaint)
                }
            }
            else -> {
                // Bar Chart
                for (i in 0..4) {
                    val y = chartBottom - i * (chartHeight / 4)
                    canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
                    val labelVal = (i * (maxCount.toFloat() / 4f)).toInt()
                    canvas.drawText(labelVal.toString(), chartLeft - 30f, y + 8f, valuePaint)
                }

                val barCount = data.size
                val spaceBetween = 40f
                val barWidth = (chartWidth - (spaceBetween * (barCount + 1))) / barCount

                data.forEachIndexed { index, (grade, value) ->
                    val left = chartLeft + spaceBetween + index * (barWidth + spaceBetween)
                    val right = left + barWidth
                    val top = chartBottom - (value.toFloat() / maxCount) * chartHeight

                    val barPaint = android.graphics.Paint().apply {
                        color = gradeColors[grade] ?: android.graphics.Color.GRAY
                        style = android.graphics.Paint.Style.FILL
                        isAntiAlias = true
                    }
                    
                    canvas.drawRect(left, top, right, chartBottom, barPaint)

                    canvas.drawText(grade, left + barWidth / 2f, chartBottom + 35f, labelPaint)

                    if (value > 0) {
                        canvas.drawText(value.toString(), left + barWidth / 2f, top - 15f, valuePaint)
                    }
                }
            }
        }

        // Lower divider separation
        canvas.drawLine(50f, 820f, (width - 50).toFloat(), 820f, gridPaint)

        // Plot descriptive chart legends at bottom
        val legendY = 860f
        val legendSpace = width / 5f
        data.forEachIndexed { index, (grade, value) ->
            val x = 100f + index * legendSpace
            val badgePaint = android.graphics.Paint().apply {
                color = gradeColors[grade] ?: android.graphics.Color.GRAY
                style = android.graphics.Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawCircle(x, legendY, 12f, badgePaint)
            
            val legendTextPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.BLACK
                textSize = 20f
                isAntiAlias = true
            }
            canvas.drawText("$grade Grade: $value", x + 25f, legendY + 7f, legendTextPaint)
        }

        // Standard watermarking signature at bottom right
        val waterPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 16f
            textAlign = android.graphics.Paint.Align.RIGHT
        }
        canvas.drawText("Generated via Money Master - Academic Suite", (width - 50).toFloat(), 950f, waterPaint)

        // Write the created Bitmap cleanly into device storage
        val fileName = "MoneyMaster_Chart_${subjectName}_${className}_${System.currentTimeMillis()}.png"
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val imageUri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (imageUri != null) {
                resolver.openOutputStream(imageUri).use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out!!)
                }
                Toast.makeText(context, "✅ Chart saved to Downloads folder!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "❌ Failed to save chart image", Toast.LENGTH_SHORT).show()
            }
        } else {
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            val file = java.io.File(downloadsDir, fileName)
            java.io.FileOutputStream(file).use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
            }
            Toast.makeText(context, "✅ Chart saved to Downloads: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "❌ Error saving chart image: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

private fun Uri.toByteArray(context: Context): ByteArray? {
    return try {
        context.contentResolver.openInputStream(this)?.use { inputStream ->
            val originalBitmap = android.graphics.BitmapFactory.decodeStream(inputStream) ?: return null
            
            val maxSize = 400
            val inWidth = originalBitmap.width
            val inHeight = originalBitmap.height
            val outWidth: Int
            val outHeight: Int
            
            if (inWidth > inHeight) {
                outWidth = maxSize
                outHeight = (inHeight * maxSize) / inWidth
            } else {
                outHeight = maxSize
                outWidth = (inWidth * maxSize) / inHeight
            }
            
            val resizedBitmap = android.graphics.Bitmap.createScaledBitmap(originalBitmap, outWidth, outHeight, false)
            val outputStream = java.io.ByteArrayOutputStream()
            resizedBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, outputStream)
            val byteArray = outputStream.toByteArray()
            
            originalBitmap.recycle()
            if (resizedBitmap != originalBitmap) {
                resizedBitmap.recycle()
            }
            
            byteArray
        }
    } catch (e: Exception) {
        null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentProfilesTab(
    viewModel: MainViewModel,
    allStudents: List<com.example.data.Student>,
    allClasses: List<ClassConfig>,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var selectedClassName by remember { mutableStateOf("") }
    if (selectedClassName.isEmpty() && allClasses.isNotEmpty()) {
        selectedClassName = allClasses.first().className
    }

    val classStudents = allStudents.filter { it.className == selectedClassName }
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredStudents = classStudents.filter {
        it.studentId.contains(searchQuery, ignoreCase = true) ||
        it.studentName.contains(searchQuery, ignoreCase = true)
    }

    var selectedStudent by remember { mutableStateOf<com.example.data.Student?>(null) }

    LaunchedEffect(selectedClassName, searchQuery, classStudents) {
        if (selectedStudent == null || selectedStudent!!.className != selectedClassName) {
            selectedStudent = filteredStudents.firstOrNull()
        } else {
            val fresh = classStudents.find { it.studentId == selectedStudent?.studentId }
            selectedStudent = fresh ?: filteredStudents.firstOrNull()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "👤 Student Personal Profile",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "ශිෂ්‍ය පුද්ගලික විස්තර කළමනාකරණය",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Class selector card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Select Class (පන්තිය තෝරන්න):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Medium
                    )

                    if (allClasses.isEmpty()) {
                        Text(
                            text = "No Classes Available",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        var expandedClassDropdown by remember { mutableStateOf(false) }
                        Box {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { expandedClassDropdown = true }
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .fillMaxWidth()
                            ) {
                                Text(
                                    text = selectedClassName,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(
                                expanded = expandedClassDropdown,
                                onDismissRequest = { expandedClassDropdown = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                allClasses.forEach { c ->
                                    DropdownMenuItem(
                                        text = { Text(c.className, fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            selectedClassName = c.className
                                            expandedClassDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (allClasses.isNotEmpty()) {
            if (classStudents.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "⚠️ මෙම පන්තියට තවම සිසුන් ඇතුළත් කර නැත. Class Workspaces වෙතින් සිසුන් ඇතුළත් කරන්න.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "No students have been added to this class yet. Please add students from the Class Workspaces tab.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                // Search Bar and Student Selector
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Search Box
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                label = { Text("🔍 Search student by ID or Name (සොයන්න)") },
                                placeholder = { Text("e.g. ST001 or Kamal") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("student_profile_search_input"),
                                singleLine = true
                            )

                            // Selected Student Selector Dropdown
                            Text(
                                text = "Select Student (සිසුවා තෝරන්න):",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Medium
                            )

                            if (filteredStudents.isEmpty()) {
                                Text(
                                    text = "No matching students found",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            } else {
                                var expandedStudentDropdown by remember { mutableStateOf(false) }
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { expandedStudentDropdown = true }
                                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                                            .padding(horizontal = 16.dp, vertical = 12.dp)
                                            .fillMaxWidth()
                                    ) {
                                        Text(
                                            text = selectedStudent?.let { "[${it.studentId}] ${it.studentName}" } ?: "Select a student",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyLarge,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(
                                        expanded = expandedStudentDropdown,
                                        onDismissRequest = { expandedStudentDropdown = false },
                                        modifier = Modifier.fillMaxWidth(0.9f)
                                    ) {
                                        filteredStudents.forEach { s ->
                                            DropdownMenuItem(
                                                text = { Text("[${s.studentId}] ${s.studentName}", fontWeight = FontWeight.Bold) },
                                                onClick = {
                                                    selectedStudent = s
                                                    expandedStudentDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                selectedStudent?.let { student ->
                    val currentStudentId = student.studentId
                    item {
                        var dobInput by remember(currentStudentId) { mutableStateOf(student.dob) }
                        var genderInput by remember(currentStudentId) { mutableStateOf(student.gender) }
                        var addressInput by remember(currentStudentId) { mutableStateOf(student.address) }
                        var guardianInput by remember(currentStudentId) { mutableStateOf(student.guardian) }
                        var phoneInput by remember(currentStudentId) { mutableStateOf(student.phone) }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    // Image Thumbnail
                                    val studentBitmap = remember(student.photoBytes) {
                                        student.photoBytes?.let {
                                            android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                        }?.asImageBitmap()
                                    }

                                    if (studentBitmap != null) {
                                        Image(
                                            bitmap = studentBitmap,
                                            contentDescription = "Student Photo",
                                            modifier = Modifier
                                                .size(80.dp)
                                                .clip(RoundedCornerShape(40.dp))
                                                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(40.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(80.dp)
                                                .clip(RoundedCornerShape(40.dp))
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(40.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.size(36.dp)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = student.studentName,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Student ID: ${student.studentId}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "📝 Edit Personal Details (පුද්ගලික විස්තර ඇතුළත් කිරීම)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                // Form fields
                                OutlinedTextField(
                                    value = dobInput,
                                    onValueChange = { dobInput = it },
                                    label = { Text("📅 Date of Birth (YYYY-MM-DD)") },
                                    placeholder = { Text("e.g. 2010-05-12") },
                                    leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_dob_input"),
                                    singleLine = true
                                )

                                // Gender Dropdown
                                var genderDropdownExpanded by remember { mutableStateOf(false) }
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = genderInput,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("🚹🚺 Gender (ස්ත්‍රී / පුරුෂ භාවය)") },
                                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                        trailingIcon = {
                                            IconButton(onClick = { genderDropdownExpanded = true }) {
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { genderDropdownExpanded = true }
                                            .testTag("student_profile_gender_input")
                                    )
                                    DropdownMenu(
                                        expanded = genderDropdownExpanded,
                                        onDismissRequest = { genderDropdownExpanded = false },
                                        modifier = Modifier.fillMaxWidth(0.85f)
                                    ) {
                                        listOf("Male", "Female", "Other").forEach { gender ->
                                            DropdownMenuItem(
                                                text = { Text(gender) },
                                                onClick = {
                                                    genderInput = gender
                                                    genderDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = guardianInput,
                                    onValueChange = { guardianInput = it },
                                    label = { Text("👨‍👩‍👦 Guardian Name (භාරකරුගේ නම)") },
                                    leadingIcon = { Icon(Icons.Default.SupervisorAccount, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_guardian_input"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = phoneInput,
                                    onValueChange = { phoneInput = it },
                                    label = { Text("📞 Phone Number (දුරකථන අංකය)") },
                                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_phone_input"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = addressInput,
                                    onValueChange = { addressInput = it },
                                    label = { Text("🏠 Home Address (ලිපිනය)") },
                                    leadingIcon = { Icon(Icons.Default.HomeWork, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_address_input"),
                                    maxLines = 3
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = {
                                        viewModel.updateStudentProfile(
                                            studentId = student.studentId,
                                            dob = dobInput,
                                            gender = genderInput,
                                            address = addressInput,
                                            guardian = guardianInput,
                                            phone = phoneInput
                                        )
                                        Toast.makeText(context, "Profile saved successfully for ${student.studentName}!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("save_profile_button")
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Save Student Profile (පුද්ගලික විස්තර සුරකින්න)", fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedButton(
                                    onClick = {
                                        viewModel.exportReportCardPDF(student.studentId, context)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("generate_report_card_pdf_button"),
                                    border = androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Comprehensive Progress Report Card (PDF)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GoogleGIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(24.dp)) {
        val sizePx = size.width
        val centerX = sizePx / 2f
        val centerY = sizePx / 2f
        val stroke = sizePx * 0.18f
        val rect = androidx.compose.ui.geometry.Rect(
            stroke / 2f, stroke / 2f,
            sizePx - stroke / 2f, sizePx - stroke / 2f
        )
        
        // 1. Red top-left/top arc
        drawArc(
            color = Color(0xFFEA4335),
            startAngle = 180f,
            sweepAngle = 115f,
            useCenter = false,
            topLeft = rect.topLeft,
            size = rect.size,
            style = Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
        
        // 2. Yellow bottom-left arc
        drawArc(
            color = Color(0xFFFBBC05),
            startAngle = 115f,
            sweepAngle = 65f,
            useCenter = false,
            topLeft = rect.topLeft,
            size = rect.size,
            style = Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
        
        // 3. Green bottom arc
        drawArc(
            color = Color(0xFF34A853),
            startAngle = 0f,
            sweepAngle = 115f,
            useCenter = false,
            topLeft = rect.topLeft,
            size = rect.size,
            style = Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
        
        // 4. Blue right arc
        drawArc(
            color = Color(0xFF4285F4),
            startAngle = -65f,
            sweepAngle = 65f,
            useCenter = false,
            topLeft = rect.topLeft,
            size = rect.size,
            style = Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        )
        
        // Inner horizontal bar for 'G'
        drawLine(
            color = Color(0xFF4285F4),
            start = Offset(centerX - sizePx * 0.05f, centerY),
            end = Offset(sizePx - stroke, centerY),
            strokeWidth = stroke,
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
    }
}

@Composable
fun MasterControlBlockedScreen(
    title: String,
    message: String,
    buttonText: String,
    onButtonClick: () -> Unit,
    whatsappNumber: String? = null,
    contactNumber: String? = null,
    onChatClick: (() -> Unit)? = null
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 500.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(64.dp)
                )
                
                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )
                
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                if (contactNumber != null) {
                    Text(
                        text = "📞 $contactNumber",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                }

                if (whatsappNumber != null) {
                    Button(
                        onClick = {
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    data = android.net.Uri.parse("https://wa.me/94785323346")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Could not open WhatsApp.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF25D366)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "WhatsApp Chat",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
                
                if (onChatClick != null) {
                    Button(
                        onClick = onChatClick,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(24.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "In-App Chat Support",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }

                Button(
                    onClick = onButtonClick,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(
                        text = buttonText,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onError
                    )
                }
            }
        }
    }
}

@Composable
fun LoginLobbyScreen(
    viewModel: MainViewModel,
    selectedLanguage: String,
    onLoginSuccess: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var emailVal by remember { mutableStateOf("") }
    var passwordVal by remember { mutableStateOf("") }
    var isEmailLoginLoading by remember { mutableStateOf(false) }
    var isPasswordVisible by remember { mutableStateOf(false) }

    val googleSignInOptions = remember {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("897428730200-tck4enomjvhek4su0fuqbflp69osi0ps.apps.googleusercontent.com")
            .requestEmail()
            .requestScopes(com.google.android.gms.common.api.Scope("https://www.googleapis.com/auth/drive.file"))
            .build()
    }
    val googleSignInClient = remember {
        GoogleSignIn.getClient(context, googleSignInOptions)
    }

    val googleAuthLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val email = account?.email
            val idToken = account?.idToken
            
            if (!idToken.isNullOrBlank()) {
                val credential = com.google.firebase.auth.GoogleAuthProvider.getCredential(idToken, null)
                com.google.firebase.auth.FirebaseAuth.getInstance().signInWithCredential(credential)
                    .addOnCompleteListener { authTask ->
                        if (authTask.isSuccessful) {
                            Toast.makeText(context, when (selectedLanguage) {
                                "Sinhala" -> "සාර්ථකව Firebase සමඟ සම්බන්ධ වුණා!"
                                "Tamil" -> "Firebase உடன் வெற்றிகரமாக இணைக்கப்பட்டது!"
                                else -> "Successfully authenticated with Firebase!"
                            }, Toast.LENGTH_SHORT).show()

                            val finalEmail = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.email ?: email
                            
                            if (!finalEmail.isNullOrBlank()) {
                                coroutineScope.launch {
                                    viewModel.loginWithGoogle(finalEmail, context)
                                    
                                    // Fetch the real Google OAuth2 access token in the background and save it for BackupManager
                                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                        try {
                                            val scopeString = "oauth2:https://www.googleapis.com/auth/drive.file"
                                            val googleAccount = account.account ?: android.accounts.Account(finalEmail, "com.google")
                                            val token = com.google.android.gms.auth.GoogleAuthUtil.getToken(
                                                context,
                                                googleAccount,
                                                scopeString
                                            )
                                            if (!token.isNullOrBlank()) {
                                                com.example.utils.BackupManager.saveAccessToken(context, token)
                                                android.util.Log.d("LoginLobby", "Successfully saved Google Drive access token: $token")
                                                
                                                // Instantly restore drive data
                                                val backupJson = com.example.utils.BackupManager.performRestore(context)
                                                if (!backupJson.isNullOrBlank()) {
                                                    viewModel.importDatabaseFromJson(backupJson)
                                                }
                                            }
                                        } catch (e: Exception) {
                                            android.util.Log.e("LoginLobby", "Failed to retrieve or store Google Drive access token", e)
                                        }
                                    }
                                    
                                    isEmailLoginLoading = false
                                    onLoginSuccess()
                                }
                            } else {
                                isEmailLoginLoading = false
                                Toast.makeText(context, "Failed to retrieve Google Account email.", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            isEmailLoginLoading = false
                            val errorMsg = authTask.exception?.localizedMessage ?: "Firebase Sign-In failed."
                            Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                        }
                    }
            } else if (!email.isNullOrBlank()) {
                coroutineScope.launch {
                    viewModel.loginWithGoogle(email, context)
                    
                    // Fetch the real Google OAuth2 access token in the background and save it for BackupManager
                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        try {
                            val scopeString = "oauth2:https://www.googleapis.com/auth/drive.file"
                            val googleAccount = account.account ?: android.accounts.Account(email, "com.google")
                            val token = com.google.android.gms.auth.GoogleAuthUtil.getToken(
                                context,
                                googleAccount,
                                scopeString
                            )
                            if (!token.isNullOrBlank()) {
                                com.example.utils.BackupManager.saveAccessToken(context, token)
                                android.util.Log.d("LoginLobby", "Successfully saved Google Drive access token: $token")
                                
                                // Instantly restore drive data
                                val backupJson = com.example.utils.BackupManager.performRestore(context)
                                if (!backupJson.isNullOrBlank()) {
                                    viewModel.importDatabaseFromJson(backupJson)
                                }
                            }
                        } catch (e: Exception) {
                            android.util.Log.e("LoginLobby", "Failed to retrieve or store Google Drive access token", e)
                        }
                    }
                    
                    isEmailLoginLoading = false
                    onLoginSuccess()
                }
            } else {
                isEmailLoginLoading = false
                Toast.makeText(context, "Failed to retrieve Google Account credentials.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: ApiException) {
            isEmailLoginLoading = false
            Toast.makeText(context, "Google Sign-In failed: ${e.localizedMessage ?: ("API Error " + e.statusCode)}", Toast.LENGTH_LONG).show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                        MaterialTheme.colorScheme.surface
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 450.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // School Master Icon and Title
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "🏫 පාසල් ප්‍රගති සහ ශ්‍රේණිගත කිරීමේ ද්වාරය"
                        "Tamil" -> "🏫 பள்ளி அறிக்கை மற்றும் தரவரிசை போர்டல்"
                        else -> "🏫 School Report & Ranking Portal"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ගුරුවරුන්ගේ වැඩකටයුතු පහසු කරන උසස් කළමනාකරණ පද්ධතිය"
                        "Tamil" -> "ஆசிரியர்களின் வேலையை எளிதாக்கும் மேம்பட்ட மேலாண்மை அமைப்பு"
                        else -> "Advanced Management System that simplifies teachers' tasks"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 📧 Email Input Field
                OutlinedTextField(
                    value = emailVal,
                    onValueChange = { emailVal = it },
                    label = { 
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "විද්‍යුත් තැපෑල (Email Address)"
                                "Tamil" -> "மின்னஞ்சல் முகவரி (Email Address)"
                                else -> "Email Address"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ) 
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = "Email Icon",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("email_input"),
                    shape = RoundedCornerShape(16.dp)
                )

                // 🔒 Password Input Field
                OutlinedTextField(
                    value = passwordVal,
                    onValueChange = { passwordVal = it },
                    label = { 
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "මුරපදය (Password)"
                                "Tamil" -> "கடவுச்சொல் (Password)"
                                else -> "Password"
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ) 
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Password Icon",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                            Icon(
                                imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Toggle password visibility"
                            )
                        }
                    },
                    visualTransformation = if (isPasswordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("password_input"),
                    shape = RoundedCornerShape(16.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))

                // 🚀 Sign In Button
                Button(
                    onClick = {
                        val trimmedEmail = emailVal.trim()
                        if (trimmedEmail.isNotEmpty() && passwordVal.isNotEmpty()) {
                            coroutineScope.launch {
                                isEmailLoginLoading = true
                                val (success, errorMsg) = viewModel.login(trimmedEmail, passwordVal)
                                isEmailLoginLoading = false
                                if (success) {
                                    Toast.makeText(context, when (selectedLanguage) {
                                        "Sinhala" -> "සාර්ථකව ලොග් වුණා!"
                                        "Tamil" -> "வெற்றிகரமாக உள்நுழைந்தீர்கள்!"
                                        else -> "Logged in successfully!"
                                    }, Toast.LENGTH_SHORT).show()
                                    onLoginSuccess()
                                } else {
                                    Toast.makeText(context, errorMsg ?: "Authentication failed", Toast.LENGTH_LONG).show()
                                }
                            }
                        } else {
                            Toast.makeText(
                                context,
                                when (selectedLanguage) {
                                    "Sinhala" -> "කරුණාකර සියලුම ක්ෂේත්‍ර පුරවන්න!"
                                    "Tamil" -> "தயவுசெய்து அனைத்து புலங்களையும் நிரப்பவும்!"
                                    else -> "Please fill in all fields!"
                                },
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("signin_button"),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    enabled = !isEmailLoginLoading
                ) {
                    if (isEmailLoginLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "ඇතුල් වන්න"
                                "Tamil" -> "உள்நுழைக"
                                else -> "Sign In"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // 🔑 Forgot Password Button
                TextButton(
                    onClick = {
                        val trimmedEmail = emailVal.trim()
                        if (trimmedEmail.isEmpty()) {
                            Toast.makeText(
                                context,
                                when (selectedLanguage) {
                                    "Sinhala" -> "මුරපදය යළි පිහිටුවීමට කරුණාකර පළමුව ඔබගේ Email ලිපිනය ඇතුළත් කරන්න!"
                                    "Tamil" -> "கடவுச்சொல்லை மீட்டமைக்க முதலில் உங்கள் மின்னஞ்சலை உள்ளிடவும்!"
                                    else -> "Please enter your email address first to reset your password!"
                                },
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            isEmailLoginLoading = true
                            com.google.firebase.auth.FirebaseAuth.getInstance().sendPasswordResetEmail(trimmedEmail)
                                .addOnCompleteListener { resetTask ->
                                    isEmailLoginLoading = false
                                    if (resetTask.isSuccessful) {
                                        Toast.makeText(
                                            context,
                                            when (selectedLanguage) {
                                                "Sinhala" -> "මුරපදය යළි පිහිටුවීමේ සබැඳිය ඔබගේ Email ලිපිනයට යවන ලදී."
                                                "Tamil" -> "கடவுச்சொல் மீட்டமைப்பு இணைப்பு உங்கள் மின்னஞ்சலுக்கு அனுப்பப்பட்டது."
                                                else -> "Password reset link sent to your email address."
                                            },
                                            Toast.LENGTH_LONG
                                        ).show()
                                    } else {
                                        val errorMsg = resetTask.exception?.localizedMessage ?: "Failed to send reset email."
                                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                    }
                                }
                        }
                    },
                    enabled = !isEmailLoginLoading,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "මුරපදය අමතකද? (Forgot Password?)"
                            "Tamil" -> "கடவுச்சொல் மறந்துவிட்டதா? (Forgot Password?)"
                            else -> "Forgot Password?"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline
                    )
                }

                // Horizontal Divider Separator
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Divider(
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    )
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> " නැතහොත් "
                            "Tamil" -> " அல்லது "
                            else -> " OR "
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Divider(
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    )
                }

                // Beautiful standard styled Google Sign In Button
                Button(
                    onClick = {
                        try {
                            isEmailLoginLoading = true
                            val signInIntent = googleSignInClient.signInIntent
                            googleAuthLauncher.launch(signInIntent)
                        } catch (e: Exception) {
                            isEmailLoginLoading = false
                            Toast.makeText(context, "Failed to launch Google Sign-In: ${e.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("google_signin_button"),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp),
                    enabled = !isEmailLoginLoading
                ) {
                    if (isEmailLoginLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            GoogleGIcon(modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "Google ගිණුමෙන් පුරනය වන්න"
                                    "Tamil" -> "Google உடன் உள்நுழைக"
                                    else -> "Sign in with Google"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Small language picker inside login screen to make it friendly
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Language / භාෂාව: ",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = selectedLanguage,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
fun ObsoleteClassPINLockScreen(
    selectedClass: String,
    viewModel: MainViewModel,
    selectedLanguage: String
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val principalPin by viewModel.principalPinState.collectAsState()
    val classPins by viewModel.classPinsState.collectAsState()
    val principalVerifiedState by viewModel.principalVerified.collectAsState()
    
    var enteredPin by remember { mutableStateOf("") }
    var enteredPinError by remember { mutableStateOf(false) }
    
    // States for configuring a PIN
    var newPinInput by remember { mutableStateOf("") }
    var confirmPinInput by remember { mutableStateOf("") }
    
    // States for Principal operations
    var showPrincipalDialog by remember { mutableStateOf(false) }
    var principalPinInput by remember { mutableStateOf("") }
    var principalPinError by remember { mutableStateOf(false) }
    
    // States for Principal Resetting a Class PIN
    var showResetClassPinDialog by remember { mutableStateOf(false) }
    var resetClassPinInput by remember { mutableStateOf("") }
    
    // States for resetting the global Principal Master PIN
    var showResetPrincipalPinDialog by remember { mutableStateOf(false) }
    var resetPrincipalPinInput by remember { mutableStateOf("") }

    val hasClassPin = classPins.containsKey(selectedClass)
    val hasPrincipalPin = !principalPin.isNullOrBlank()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = androidx.compose.ui.Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            if (!hasPrincipalPin) {
                PrincipalMasterPinSetupScreen(
                    viewModel = viewModel,
                    selectedLanguage = selectedLanguage,
                    onSetupComplete = {
                        viewModel.fetchPinsFromFirebase()
                    }
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Icon
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(
                                if (hasClassPin) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (hasClassPin) androidx.compose.material.icons.Icons.Default.Lock else androidx.compose.material.icons.Icons.Default.LockOpen,
                            contentDescription = "Lock Icon",
                            tint = if (hasClassPin) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // Header Title
                    Text(
                        text = if (!hasClassPin) {
                            when (selectedLanguage) {
                                "Sinhala" -> "පන්ති PIN අංකය සකසන්න"
                                "Tamil" -> "வகுப்பு PIN ஐ அமைக்கவும்"
                                else -> "Configure Class PIN"
                            }
                        } else {
                            when (selectedLanguage) {
                                "Sinhala" -> "$selectedClass පන්තිය අගුළු දමා ඇත"
                                "Tamil" -> "$selectedClass வகுப்பு பூட்டப்பட்டுள்ளது"
                                else -> "Class $selectedClass is Locked"
                            }
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )

                    // Subtitle/Instruction
                    Text(
                        text = if (!hasClassPin) {
                            when (selectedLanguage) {
                                "Sinhala" -> "$selectedClass පන්තිය සඳහා තවම PIN එකක් සකසා නැත. මෙම වැඩතීරුව ආරක්ෂා කිරීමට කරුණාකර 4-6 digit PIN එකක් ඇතුළත් කරන්න."
                                "Tamil" -> "$selectedClass வகுப்பிற்கு இன்னும் PIN அமைக்கப்படவில்லை. பணிவிடத்தைப் பாதுகாக்க 4-6 இலக்க PIN ஐ அமைக்கவும்."
                                else -> "No PIN has been configured for Class $selectedClass yet. Set a 4-to-6 digit PIN to protect this workspace."
                            }
                        } else {
                            when (selectedLanguage) {
                                "Sinhala" -> "ඉදිරියට යාමට කරුණාකර මෙම පන්තිය සඳහා නියමිත PIN අංකය හෝ විදුහල්පති PIN අංකය ඇතුළත් කරන්න."
                                "Tamil" -> "தொடர வகுப்பின் PIN அல்லது அதிபர் முதன்மை PIN ஐ உள்ளிடவும்."
                                else -> "Please enter the Class-Level PIN or the global Principal Master PIN to unlock this workspace."
                            }
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Input Section based on state
                    if (!hasClassPin) {
                    // Class PIN Setup Inputs
                    OutlinedTextField(
                        value = newPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) newPinInput = it },
                        label = {
                            Text(
                                when (selectedLanguage) {
                                    "Sinhala" -> "නව පන්ති PIN අංකය"
                                    "Tamil" -> "புதிய வகுப்பு PIN"
                                    else -> "New Class PIN"
                                }
                            )
                        },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    )

                    OutlinedTextField(
                        value = confirmPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirmPinInput = it },
                        label = {
                            Text(
                                when (selectedLanguage) {
                                    "Sinhala" -> "PIN අංකය තහවුරු කරන්න"
                                    "Tamil" -> "PIN ஐ உறுதிப்படுத்தவும்"
                                    else -> "Confirm Class PIN"
                                }
                            )
                        },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (newPinInput.length >= 4 && newPinInput == confirmPinInput) {
                                viewModel.saveClassPin(selectedClass, newPinInput, {
                                    android.widget.Toast.makeText(context, "PIN for Class $selectedClass Saved!", android.widget.Toast.LENGTH_SHORT).show()
                                    newPinInput = ""
                                    confirmPinInput = ""
                                }, {
                                    android.widget.Toast.makeText(context, "Error: ${it.localizedMessage}", android.widget.Toast.LENGTH_SHORT).show()
                                })
                            } else {
                                android.widget.Toast.makeText(context, "PINs must match and be at least 4 digits!", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "පන්ති PIN එක සුරකින්න"
                                "Tamil" -> "வகுப்பு PIN ஐ சேமி"
                                else -> "Save Class PIN"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    // Standard PIN Input & Verification
                    OutlinedTextField(
                        value = enteredPin,
                        onValueChange = {
                            if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                enteredPin = it
                                enteredPinError = false
                            }
                        },
                        label = {
                            Text(
                                when (selectedLanguage) {
                                    "Sinhala" -> "PIN අංකය"
                                    "Tamil" -> "PIN குறியீடு"
                                    else -> "Enter PIN"
                                }
                            )
                        },
                        isError = enteredPinError,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        trailingIcon = {
                            if (enteredPinError) {
                                Icon(
                                    imageVector = androidx.compose.material.icons.Icons.Default.Warning,
                                    contentDescription = "Error",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    )

                    if (enteredPinError) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "වැරදි PIN අංකයකි. නැවත උත්සාහ කරන්න."
                                "Tamil" -> "தவறான PIN. மீண்டும் முயற்சிக்கவும்."
                                else -> "Invalid PIN. Please try again."
                            },
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.align(androidx.compose.ui.Alignment.Start)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val success = viewModel.verifyClassPin(selectedClass, enteredPin)
                            if (success) {
                                android.widget.Toast.makeText(context, "Class $selectedClass Unlocked!", android.widget.Toast.LENGTH_SHORT).show()
                                enteredPin = ""
                            } else {
                                enteredPinError = true
                                enteredPin = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "වැඩතීරුව අගුළු හරින්න"
                                "Tamil" -> "பணிவிடத்தைத் திற"
                                else -> "Unlock Workspace"
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Principal Bypass and Action Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { showPrincipalDialog = true }
                        ) {
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "🔑 විදුහල්පති Bypass"
                                    "Tamil" -> "🔑 அதிபர் பைபாஸ்"
                                    else -> "🔑 Principal Bypass"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        TextButton(
                            onClick = {
                                viewModel.sendMasterPinResetEmail { success ->
                                    val schoolEmail = viewModel.currentSchoolEmail ?: ""
                                    if (success) {
                                        val msg = when (selectedLanguage) {
                                            "Sinhala" -> "විදුහල්පති PIN අංකය යළි පිහිටුවීමේ උපදෙස් $schoolEmail වෙත යවා ඇත."
                                            "Tamil" -> "அதிபர் PIN மீட்டமைப்பு வழிமுறைகள் $schoolEmail க்கு அனுப்பப்பட்டுள்ளன."
                                            else -> "Reset instructions have been sent to the school's official email address: $schoolEmail"
                                        }
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                                    } else {
                                        val msg = when (selectedLanguage) {
                                            "Sinhala" -> "ඊමේල් යැවීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න."
                                            "Tamil" -> "மின்னஞ்சலை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்."
                                            else -> "Failed to send reset email. Please try again."
                                        }
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        ) {
                            Text(
                                text = "Forgot Master PIN? Reset via Email",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    }

    // Dynamic dialog for Principal Login/Verification
    if (showPrincipalDialog) {
        AlertDialog(
            onDismissRequest = {
                showPrincipalDialog = false
                principalPinInput = ""
                principalPinError = false
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "විදුහල්පති තහවුරු කිරීම"
                        "Tamil" -> "அதிபர் சரிபார்ப்பு"
                        else -> "Verify as Principal"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "පන්තියේ PIN එක වෙනස් කිරීමට හෝ සෘජුවම ඇතුළු වීමට ප්‍රධාන විදුහල්පති PIN අංකය ඇතුළත් කරන්න."
                            "Tamil" -> "வகுப்பின் PIN ஐ மாற்ற அல்லது நேரடியாக நுழைய அதிபர் முதன்மை PIN ஐ உள்ளிடவும்."
                            else -> "Enter the global Principal Master PIN to manage or bypass class level configurations."
                        }
                    )
                    OutlinedTextField(
                        value = principalPinInput,
                        onValueChange = {
                            if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                principalPinInput = it
                                principalPinError = false
                            }
                        },
                        label = { Text("Principal Master PIN") },
                        isError = principalPinError,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    if (principalPinError) {
                        Text(
                            text = "Invalid Principal Master PIN!",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    TextButton(
                        onClick = {
                            viewModel.sendMasterPinResetEmail { success ->
                                val schoolEmail = viewModel.currentSchoolEmail ?: ""
                                if (success) {
                                    val msg = when (selectedLanguage) {
                                        "Sinhala" -> "විදුහල්පති PIN අංකය යළි පිහිටුවීමේ උපදෙස් $schoolEmail වෙත යවා ඇත."
                                        "Tamil" -> "அதிபர் PIN மீட்டமைப்பு வழிமுறைகள் $schoolEmail க்கு அனுப்பப்பட்டுள்ளன."
                                        else -> "Reset instructions have been sent to the school's official email address: $schoolEmail"
                                    }
                                    android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                                } else {
                                    val msg = when (selectedLanguage) {
                                        "Sinhala" -> "ඊමේල් යැවීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න."
                                        "Tamil" -> "மின்னஞ்சலை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்."
                                        else -> "Failed to send reset email. Please try again."
                                    }
                                    android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.align(androidx.compose.ui.Alignment.CenterHorizontally)
                    ) {
                        Text(
                            text = "Forgot Master PIN? Reset via Email",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.verifyPrincipalPin(principalPinInput)
                        if (success) {
                            android.widget.Toast.makeText(context, "Principal Mode Active!", android.widget.Toast.LENGTH_SHORT).show()
                            showPrincipalDialog = false
                            principalPinInput = ""
                            showResetClassPinDialog = true
                        } else {
                            principalPinError = true
                            principalPinInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Verify")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrincipalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog to let Principal reset or change the Class-Level PIN
    if (showResetClassPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showResetClassPinDialog = false
                resetClassPinInput = ""
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "$selectedClass PIN එක සකසන්න (විදුහල්පති)"
                        "Tamil" -> "$selectedClass வகுப்பு PIN ஐ அமை (அதிபர்)"
                        else -> "Set PIN for $selectedClass (Principal)"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Enter a new 4-to-6 digit PIN to protect Class $selectedClass workspace."
                    )
                    OutlinedTextField(
                        value = resetClassPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) resetClassPinInput = it },
                        label = { Text("New PIN") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = {
                            showResetClassPinDialog = false
                            showResetPrincipalPinDialog = true
                        }
                    ) {
                        Text("🔑 Change Principal Master PIN")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetClassPinInput.length >= 4) {
                            viewModel.saveClassPin(selectedClass, resetClassPinInput, {
                                android.widget.Toast.makeText(context, "PIN reset successfully!", android.widget.Toast.LENGTH_SHORT).show()
                                showResetClassPinDialog = false
                                resetClassPinInput = ""
                            }, {
                                android.widget.Toast.makeText(context, "Error: ${it.localizedMessage}", android.widget.Toast.LENGTH_SHORT).show()
                            })
                        } else {
                            android.widget.Toast.makeText(context, "PIN must be at least 4 digits!", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Reset PIN")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetClassPinDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog to let Principal reset the global Principal Master PIN
    if (showResetPrincipalPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showResetPrincipalPinDialog = false
                resetPrincipalPinInput = ""
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "නව විදුහල්පති PIN එකක් සැකසීම"
                        "Tamil" -> "புதிய அதிபர் முதன்மை PIN ஐ அமை"
                        else -> "Set New Principal Master PIN"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Enter a new 4-to-6 digit global Principal Master PIN to protect the entire portal."
                    )
                    OutlinedTextField(
                        value = resetPrincipalPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) resetPrincipalPinInput = it },
                        label = { Text("New Master PIN") },
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetPrincipalPinInput.length >= 4) {
                            viewModel.savePrincipalPin(resetPrincipalPinInput, {
                                android.widget.Toast.makeText(context, "Principal Master PIN changed successfully!", android.widget.Toast.LENGTH_SHORT).show()
                                showResetPrincipalPinDialog = false
                                resetPrincipalPinInput = ""
                            }, {
                                android.widget.Toast.makeText(context, "Error: ${it.localizedMessage}", android.widget.Toast.LENGTH_SHORT).show()
                            })
                        } else {
                            android.widget.Toast.makeText(context, "PIN must be at least 4 digits!", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetPrincipalPinDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SubscriptionExpiredScreen(
    viewModel: MainViewModel,
    selectedLanguage: String,
    onChatClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val adminMessageText = viewModel.adminMessage.value
    val rawPrices = viewModel.subscriptionPrices.value
    
    // Fallback if firestore hasn't synced/doesn't have the field yet
    val displayPrices = if (rawPrices.isNotEmpty()) rawPrices else mapOf("1_year" to 1000L)

    val titleText = when (selectedLanguage) {
        "Sinhala" -> "දායකත්වය කල් ඉකුත් වී ඇත"
        "Tamil" -> "சந்தா காலாவதியானது"
        else -> "Subscription Expired"
    }

    val tiersHeading = when (selectedLanguage) {
        "Sinhala" -> "පවතින අලුත් කිරීමේ පැකේජ:"
        "Tamil" -> "கிடைக்கக்கூடிய புதுப்பித்தல் திட்டங்கள்:"
        else -> "Available Renewal Tiers:"
    }

    val contactBtnText = when (selectedLanguage) {
        "Sinhala" -> "අලුත් කිරීමට පරිපාලක අමතන්න"
        "Tamil" -> "புதுப்பிக்க நிர்வாகியைத் தொடர்பு கொள்ளவும்"
        else -> "Contact Administrator to Renew"
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.98f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        ElevatedCard(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
                .testTag("subscription_expired_card"),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Warning icon with dynamic ambient glowing container
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Subscription Locked",
                        modifier = Modifier.size(42.dp),
                        tint = MaterialTheme.colorScheme.error
                    )
                }

                // Title
                Text(
                    text = titleText,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )

                // Admin Message Box (styled prominently like an announcement banner)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = "Announcement",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = adminMessageText,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))

                // Subscription Tiers Heading
                Text(
                    text = tiersHeading,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.align(Alignment.Start)
                )

                // Grid/List of Tiers
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    displayPrices.forEach { (pkgKey, amount) ->
                        val prettyName = formatPackageName(pkgKey)
                        val icon = if (pkgKey.contains("year", ignoreCase = true) || pkgKey.contains("3", ignoreCase = true) || pkgKey.contains("5", ignoreCase = true)) {
                            Icons.Default.Star
                        } else {
                            Icons.Default.DateRange
                        }
                        
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = prettyName,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                
                                Text(
                                    text = "Rs. $amount",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Renew Action Button
                Button(
                    onClick = {
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://wa.me/94785323346")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not open WhatsApp. Please message 0785323346 directly.", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("contact_admin_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF25D366)
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = contactBtnText,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onChatClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("in_app_chat_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Chat,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "ඇප් එක තුලින් ඇඩ්මින් සමඟ කතාබස් කරන්න"
                            "Tamil" -> "பயன்பாட்டிற்குள் அரட்டை அடிக்கவும்"
                            else -> "In-App Support Chat"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }
}

// Utility function to format key name beautifully
fun formatPackageName(key: String): String {
    return key.split("_")
        .joinToString(" ") { word ->
            word.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
        }
}

// ==========================================
// TAB 5: CLASSROOM HUB (TEACHER & CLASSROOM TOOLS)
// ==========================================
@Composable
fun ClassroomHubTab(
    viewModel: MainViewModel,
    allClasses: List<com.example.data.ClassConfig>,
    allStudents: List<com.example.data.Student>,
    selectedLanguage: String = "English"
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var selectedClassHub by remember { mutableStateOf("") }
    if (selectedClassHub.isEmpty() && allClasses.isNotEmpty()) {
        selectedClassHub = allClasses.first().className
    }
    
    val classStudents = allStudents.filter { it.className == selectedClassHub }
    
    var activeHubTool by remember { mutableStateOf("attendance") }
    
    Column(
        modifier = androidx.compose.ui.Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Class Selector Header Card
        Card(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f))
        ) {
            Row(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = androidx.compose.ui.Modifier.size(32.dp)
                )
                Column(modifier = androidx.compose.ui.Modifier.weight(1f)) {
                    Text(
                        text = "Classroom Hub (පන්ති කාමර කළමනාකරණය)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Selected Class: ${selectedClassHub.ifEmpty { "None (පන්තියක් තෝරන්න)" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                if (allClasses.isNotEmpty()) {
                    var showClassMenu by remember { mutableStateOf(false) }
                    Box {
                        Button(
                            onClick = { showClassMenu = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Change (වෙනස් කරන්න)")
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = showClassMenu,
                            onDismissRequest = { showClassMenu = false }
                        ) {
                            allClasses.forEach { cl ->
                                DropdownMenuItem(
                                    text = { Text(cl.className, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        selectedClassHub = cl.className
                                        showClassMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
        
        // Horizontal Scroll of Visual Tools
        LazyRow(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tools = listOf(
                Triple("attendance", "📅 Attendance", "පැමිණීම"),
                Triple("emergency", "📞 Emergency Profiles", "හදිසි ඇමතුම්"),
                Triple("behavior", "🤝 Behavior Log", "හැසිරීම් වාර්තා"),
                Triple("syllabus", "📚 Syllabus Tracker", "විෂය නිර්දේශ ප්‍රගතිය"),
                Triple("inventory", "🛠️ Inventory", "භාණ්ඩ ලැයිස්තුව"),
                Triple("funds", "💵 Class Funds", "පන්ති අරමුදල")
            )
            
            items(tools.size) { i ->
                val (id, label, labelSn) = tools[i]
                val isSelected = activeHubTool == id
                FilterChip(
                    selected = isSelected,
                    onClick = { activeHubTool = id },
                    label = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(labelSn, fontSize = 9.sp, color = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                )
            }
        }
        
        // Tool Display Area
        Box(modifier = androidx.compose.ui.Modifier.weight(1f)) {
            if (selectedClassHub.isEmpty()) {
                Box(
                    modifier = androidx.compose.ui.Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "⚠️ Please unlock or add a class first to use these tools.\nපළමුව Class Workspaces වෙතින් පන්තියක් ඇතුළත් කරන්න.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                when (activeHubTool) {
                    "attendance" -> AttendanceTool(viewModel, selectedClassHub, classStudents)
                    "emergency" -> EmergencyTool(viewModel, selectedClassHub, classStudents)
                    "behavior" -> BehaviorTool(viewModel, selectedClassHub, classStudents)
                    "syllabus" -> SyllabusToolView(viewModel)
                    "inventory" -> InventoryTool(viewModel)
                    "funds" -> FundsTool(viewModel)
                }
            }
        }
    }
}

@Composable
fun AttendanceTool(viewModel: MainViewModel, className: String, students: List<com.example.data.Student>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var dateString by remember {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
        mutableStateOf(sdf.format(java.util.Date()))
    }
    
    val record = viewModel.attendanceList.find { it.date == dateString }
    val presents = record?.presents ?: emptyList()
    val absents = record?.absents ?: emptyList()
    
    LazyColumn(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "📅 Attendance Tracker (දිනපතා පැමිණීම සටහන් කිරීම)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    OutlinedTextField(
                        value = dateString,
                        onValueChange = { dateString = it },
                        label = { Text("Selected Date (දිනය: YYYY-MM-DD)") },
                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    Row(
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Class size: ${students.size}", fontWeight = FontWeight.SemiBold)
                        Text("Present: ${presents.size} | Absent: ${students.size - presents.size}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        if (students.isEmpty()) {
            item {
                Box(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No students registered in this class. (මෙම පන්තියේ සිසුන් නැත)")
                }
            }
        } else {
            items(students.size) { idx ->
                val std = students[idx]
                val isPresent = presents.contains(std.studentId)
                val isAbsent = absents.contains(std.studentId)
                val statusColor = if (isPresent) Color(0xFF48BB78) else if (isAbsent) Color(0xFFE53E3E) else Color.Gray
                
                Card(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = androidx.compose.ui.Modifier
                                .size(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusColor)
                        )
                        Column(modifier = androidx.compose.ui.Modifier.weight(1f)) {
                            Text(std.studentName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Text("ID: ${std.studentId}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.toggleAttendance(dateString, std.studentId, true) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isPresent) Color(0xFF48BB78) else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Present", color = if (isPresent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            }
                            
                            Button(
                                onClick = { viewModel.toggleAttendance(dateString, std.studentId, false) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isAbsent) Color(0xFFE53E3E) else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Absent", color = if (isAbsent) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmergencyTool(viewModel: MainViewModel, className: String, students: List<com.example.data.Student>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedStdId by remember { mutableStateOf("") }
    if (selectedStdId.isEmpty() && students.isNotEmpty()) {
        selectedStdId = students.first().studentId
    }
    
    var parentPhone by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("A+") }
    var allergies by remember { mutableStateOf("") }
    
    val profile = viewModel.emergencyProfiles[selectedStdId]
    
    LazyColumn(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "📞 Add / Update Emergency Profile (හදිසි ඇමතුම් විස්තර සටහන් කිරීම)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    if (students.isNotEmpty()) {
                        var studentMenuExpanded by remember { mutableStateOf(false) }
                        val activeStudent = students.find { it.studentId == selectedStdId }
                        Box(modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = activeStudent?.let { "[${it.studentId}] ${it.studentName}" } ?: "Select student",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Student (සිසුවා තෝරන්න)") },
                                trailingIcon = {
                                    IconButton(onClick = { studentMenuExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = androidx.compose.ui.Modifier.fillMaxWidth().clickable { studentMenuExpanded = true }
                            )
                            DropdownMenu(
                                expanded = studentMenuExpanded,
                                onDismissRequest = { studentMenuExpanded = false }
                            ) {
                                students.forEach { s ->
                                    DropdownMenuItem(
                                        text = { Text("[${s.studentId}] ${s.studentName}") },
                                        onClick = {
                                            selectedStdId = s.studentId
                                            val existing = viewModel.emergencyProfiles[s.studentId]
                                            parentPhone = existing?.parentPhone ?: s.phone
                                            bloodGroup = existing?.bloodGroup ?: "A+"
                                            allergies = existing?.allergies ?: ""
                                            studentMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    
                    OutlinedTextField(
                        value = parentPhone,
                        onValueChange = { parentPhone = it },
                        label = { Text("Parent / Guardian Phone Number (භාරකරුගේ දුරකථන අංකය)") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    // Blood Group selection
                    var bloodMenuExpanded by remember { mutableStateOf(false) }
                    Box(modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Blood Group (රුධිර ගණය)") },
                            trailingIcon = {
                                IconButton(onClick = { bloodMenuExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = androidx.compose.ui.Modifier.fillMaxWidth().clickable { bloodMenuExpanded = true }
                        )
                        DropdownMenu(
                            expanded = bloodMenuExpanded,
                            onDismissRequest = { bloodMenuExpanded = false }
                        ) {
                            listOf("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-").forEach { bg ->
                                DropdownMenuItem(
                                    text = { Text(bg) },
                                    onClick = {
                                        bloodGroup = bg
                                        bloodMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    
                    OutlinedTextField(
                        value = allergies,
                        onValueChange = { allergies = it },
                        label = { Text("Allergies / Medical Warnings (අසාත්මිකතා හෝ සෞඛ්‍ය අනතුරු ඇඟවීම්)") },
                        leadingIcon = { Icon(Icons.Default.MedicalServices, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                    
                    Button(
                        onClick = {
                            if (selectedStdId.isNotEmpty()) {
                                viewModel.emergencyProfiles[selectedStdId] = EmergencyProfile(
                                    studentId = selectedStdId,
                                    parentPhone = parentPhone,
                                    bloodGroup = bloodGroup,
                                    allergies = allergies
                                )
                                viewModel.triggerBackup()
                                Toast.makeText(context, "Emergency Profile Saved Successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = androidx.compose.ui.Modifier.width(8.dp))
                        Text("Save Emergency Details (සුරකින්න)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        item {
            Text(
                "🚨 Registered Emergency Profiles (සටහන් වී ඇති හදිසි විස්තර)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        val registeredProfiles = viewModel.emergencyProfiles.values.toList()
        if (registeredProfiles.isEmpty()) {
            item {
                Text("No emergency profiles saved yet. Use the editor above.")
            }
        } else {
            items(registeredProfiles.size) { index ->
                val ep = registeredProfiles[index]
                val matchingStd = students.find { it.studentId == ep.studentId }
                if (matchingStd != null) {
                    Card(
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = androidx.compose.ui.Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("[${ep.studentId}] ${matchingStd.studentName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("📞 Parent Phone: ${ep.parentPhone}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                                Box(
                                    modifier = androidx.compose.ui.Modifier
                                        .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("🩸 Group: ${ep.bloodGroup}", color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            if (ep.allergies.isNotEmpty()) {
                                Text("⚠️ Allergies: ${ep.allergies}", color = Color.Red, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BehaviorTool(viewModel: MainViewModel, className: String, students: List<com.example.data.Student>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selectedStdId by remember { mutableStateOf("") }
    if (selectedStdId.isEmpty() && students.isNotEmpty()) {
        selectedStdId = students.first().studentId
    }
    
    var logType by remember { mutableStateOf("Positive Efforts") }
    var desc by remember { mutableStateOf("") }
    
    LazyColumn(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🤝 Log Behavioral Incidents (සිසුන්ගේ චර්යාත්මක/හැසිරීම් සටහන් කිරීම)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    if (students.isNotEmpty()) {
                        var studentMenuExpanded by remember { mutableStateOf(false) }
                        val activeStudent = students.find { it.studentId == selectedStdId }
                        Box(modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = activeStudent?.let { "[${it.studentId}] ${it.studentName}" } ?: "Select student",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Student (සිසුවා තෝරන්න)") },
                                trailingIcon = {
                                    IconButton(onClick = { studentMenuExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = androidx.compose.ui.Modifier.fillMaxWidth().clickable { studentMenuExpanded = true }
                            )
                            DropdownMenu(
                                expanded = studentMenuExpanded,
                                onDismissRequest = { studentMenuExpanded = false }
                            ) {
                                students.forEach { s ->
                                    DropdownMenuItem(
                                        text = { Text("[${s.studentId}] ${s.studentName}") },
                                        onClick = {
                                            selectedStdId = s.studentId
                                            studentMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    
                    // Log Type Selector
                    var typeExpanded by remember { mutableStateOf(false) }
                    Box(modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = logType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Incident Category (කාණ්ඩය)") },
                            trailingIcon = {
                                IconButton(onClick = { typeExpanded = true }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                            },
                            modifier = androidx.compose.ui.Modifier.fillMaxWidth().clickable { typeExpanded = true }
                        )
                        DropdownMenu(
                            expanded = typeExpanded,
                            onDismissRequest = { typeExpanded = false }
                        ) {
                            listOf("Positive Efforts", "Outstanding Performance", "Disciplinary Warning", "General Note").forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        logType = cat
                                        typeExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Incident Description (සිදුවීමේ විස්තරය)") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                    
                    Button(
                        onClick = {
                            if (selectedStdId.isNotEmpty() && desc.isNotEmpty()) {
                                val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                                val today = sdf.format(java.util.Date())
                                viewModel.behaviorLogs.add(
                                    BehaviorLog(
                                        id = java.util.UUID.randomUUID().toString(),
                                        studentId = selectedStdId,
                                        date = today,
                                        type = logType,
                                        Description = desc
                                    )
                                )
                                viewModel.triggerBackup()
                                desc = ""
                                Toast.makeText(context, "Behavior Log Registered Successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = androidx.compose.ui.Modifier.width(8.dp))
                        Text("Add Behavioral Scribe (සටහනක් එක්කරන්න)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        item {
            Text(
                "📈 Live Behavioral Scribe Timeline (මෑතකාලීන හැසිරීම් සටහන් පෙළ)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        val logs = viewModel.behaviorLogs.toList()
        if (logs.isEmpty()) {
            item {
                Text("No behavior logs recorded. (තවම කිසිදු චර්යා සටහනක් ලැබී නැත)")
            }
        } else {
            items(logs.size) { index ->
                val log = logs[logs.size - 1 - index] // show newest first
                val matchingStd = students.find { it.studentId == log.studentId }
                if (matchingStd != null) {
                    val isPositive = log.type.contains("Positive") || log.type.contains("Outstanding")
                    val badgeColor = if (isPositive) Color(0xFFE6FFFA) else Color(0xFFFFF5F5)
                    val badgeTxtColor = if (isPositive) Color(0xFF319795) else Color(0xFFE53E3E)
                    
                    Card(
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(
                            modifier = androidx.compose.ui.Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("[${log.studentId}] ${matchingStd.studentName}", fontWeight = FontWeight.Bold)
                                Box(
                                    modifier = androidx.compose.ui.Modifier
                                        .background(badgeColor, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(log.type, color = badgeTxtColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            
                            Text(log.Description, style = MaterialTheme.typography.bodyMedium)
                            
                            Row(
                                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Scribed on: ${log.date}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                IconButton(
                                    onClick = {
                                        viewModel.behaviorLogs.remove(log)
                                        viewModel.triggerBackup()
                                    },
                                    modifier = androidx.compose.ui.Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = androidx.compose.ui.Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SyllabusToolView(viewModel: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var subjectInput by remember { mutableStateOf("") }
    var topicInput by remember { mutableStateOf("") }
    
    LazyColumn(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "📚 Syllabus Task Manager (විෂය නිර්දේශ ඒකක ප්‍රගතිය)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    OutlinedTextField(
                        value = subjectInput,
                        onValueChange = { subjectInput = it },
                        label = { Text("Subject (විෂය - e.g. Mathematics)") },
                        leadingIcon = { Icon(Icons.Default.Book, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    OutlinedTextField(
                        value = topicInput,
                        onValueChange = { topicInput = it },
                        label = { Text("Topic / Chapter (මාතෘකාව - e.g. Algebra)") },
                        leadingIcon = { Icon(Icons.Default.Assignment, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    Button(
                        onClick = {
                            if (subjectInput.isNotEmpty() && topicInput.isNotEmpty()) {
                                viewModel.syllabusTasks.add(
                                    SyllabusTask(
                                        id = java.util.UUID.randomUUID().toString(),
                                        subject = subjectInput,
                                        topic = topicInput,
                                        isCompleted = false
                                    )
                                )
                                viewModel.triggerBackup()
                                topicInput = ""
                                Toast.makeText(context, "Syllabus Task Added!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = androidx.compose.ui.Modifier.width(8.dp))
                        Text("Add Syllabus Task (එක් කරන්න)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        // Subject Wise Progress Calculation
        val tasks = viewModel.syllabusTasks.toList()
        val groupedBySubject = tasks.groupBy { it.subject }
        
        if (groupedBySubject.isEmpty()) {
            item {
                Text("No syllabus tasks defined. Enter details above to track progress.")
            }
        } else {
            item {
                Text(
                    "📊 Syllabus Completion Progress (ප්‍රගති ප්‍රස්ථාරය)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            groupedBySubject.forEach { (subject, list) ->
                val completedCount = list.count { it.isCompleted }
                val pct = if (list.isNotEmpty()) completedCount.toFloat() / list.size else 0f
                
                item {
                    Card(
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = androidx.compose.ui.Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(subject, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                                Text("${(pct * 100).toInt()}% completed", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            }
                            
                            LinearProgressIndicator(
                                progress = { pct },
                                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                                color = if (pct >= 0.8f) Color(0xFF48BB78) else MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                            
                            Spacer(modifier = androidx.compose.ui.Modifier.height(4.dp))
                            
                            list.forEach { task ->
                                Row(
                                    modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = task.isCompleted,
                                        onCheckedChange = { isChecked ->
                                            val idx = viewModel.syllabusTasks.indexOfFirst { it.id == task.id }
                                            if (idx != -1) {
                                                viewModel.syllabusTasks[idx] = task.copy(isCompleted = isChecked)
                                                viewModel.triggerBackup()
                                            }
                                        }
                                    )
                                    Text(
                                        text = task.topic,
                                        modifier = androidx.compose.ui.Modifier.weight(1f),
                                        style = if (task.isCompleted) MaterialTheme.typography.bodyMedium.copy(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough, color = Color.Gray) else MaterialTheme.typography.bodyMedium
                                    )
                                    IconButton(
                                        onClick = {
                                            viewModel.syllabusTasks.remove(task)
                                            viewModel.triggerBackup()
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = androidx.compose.ui.Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InventoryTool(viewModel: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var itemName by remember { mutableStateOf("") }
    var totalQty by remember { mutableStateOf("") }
    
    LazyColumn(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🛠️ Classroom Asset & Inventory Manager (පන්ති කාමර භාණ්ඩ ලේඛනය)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    OutlinedTextField(
                        value = itemName,
                        onValueChange = { itemName = it },
                        label = { Text("Asset Name (භාණ්ඩයේ නම - e.g. Desk, Lab Kit)") },
                        leadingIcon = { Icon(Icons.Default.HomeWork, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    OutlinedTextField(
                        value = totalQty,
                        onValueChange = { totalQty = it },
                        label = { Text("Total Registered Quantity (මුළු ප්‍රමාණය)") },
                        leadingIcon = { Icon(Icons.Default.Numbers, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                    )
                    
                    Button(
                        onClick = {
                            val qtyInt = totalQty.toIntOrNull() ?: 0
                            if (itemName.isNotEmpty() && qtyInt > 0) {
                                viewModel.inventoryItems.add(
                                    InventoryItem(
                                        id = java.util.UUID.randomUUID().toString(),
                                        name = itemName,
                                        totalQty = qtyInt,
                                        brokenQty = 0
                                    )
                                )
                                viewModel.triggerBackup()
                                itemName = ""
                                totalQty = ""
                                Toast.makeText(context, "Asset added successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = androidx.compose.ui.Modifier.width(8.dp))
                        Text("Add New Inventory Asset (භාණ්ඩයක් එක්කරන්න)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        item {
            Text(
                "🛠️ Live Physical Assets Audit Ledger (භාණ්ඩ ලේඛනය සහ තත්ත්වය)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        val items = viewModel.inventoryItems.toList()
        if (items.isEmpty()) {
            item {
                Text("No inventory assets registered yet.")
            }
        } else {
            items(items.size) { index ->
                val item = items[index]
                val brokenLimitWarning = item.brokenQty >= (item.totalQty / 2f)
                
                Card(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                            if (brokenLimitWarning) {
                                Box(
                                    modifier = androidx.compose.ui.Modifier
                                        .background(Color(0xFFFFF5F5), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("⚠️ Refurbish Needed", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        
                        Row(
                            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Qty: ${item.totalQty} | Good condition: ${item.totalQty - item.brokenQty}", fontSize = 13.sp)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text("Broken (නැසීගිය): ${item.brokenQty}", fontWeight = FontWeight.SemiBold, color = if (item.brokenQty > 0) Color.Red else Color.Gray)
                                IconButton(
                                    onClick = {
                                        if (item.brokenQty > 0) {
                                            val idx = viewModel.inventoryItems.indexOfFirst { it.id == item.id }
                                            if (idx != -1) {
                                                viewModel.inventoryItems[idx] = item.copy(brokenQty = item.brokenQty - 1)
                                                viewModel.triggerBackup()
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.RemoveCircle, contentDescription = "Decrease", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = {
                                        if (item.brokenQty < item.totalQty) {
                                            val idx = viewModel.inventoryItems.indexOfFirst { it.id == item.id }
                                            if (idx != -1) {
                                                viewModel.inventoryItems[idx] = item.copy(brokenQty = item.brokenQty + 1)
                                                viewModel.triggerBackup()
                                            }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.AddCircle, contentDescription = "Increase", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(
                                    onClick = {
                                        viewModel.inventoryItems.remove(item)
                                        viewModel.triggerBackup()
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = androidx.compose.ui.Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FundsTool(viewModel: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var description by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var isIncomeType by remember { mutableStateOf(true) }
    
    val transactions = viewModel.fundTransactions.toList()
    val totalIncome = transactions.filter { it.isIncome }.sumOf { it.amount }
    val totalExpense = transactions.filter { !it.isIncome }.sumOf { it.amount }
    val balance = totalIncome - totalExpense
    
    LazyColumn(
        modifier = androidx.compose.ui.Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = if (balance >= 0) Color(0xFFE6FFFA) else Color(0xFFFFF5F5))
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "💵 Current Class Net Balance (පන්ති අරමුදල් ශේෂය)",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Rs. ${String.format("%.2f", balance)}",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (balance >= 0) Color(0xFF319795) else Color(0xFFE53E3E)
                    )
                    Row(
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Text("Income (ආදායම්): Rs. ${String.format("%.1f", totalIncome)}", color = Color(0xFF319795), fontWeight = FontWeight.SemiBold)
                        Text("Expense (වියදම්): Rs. ${String.format("%.1f", totalExpense)}", color = Color(0xFFE53E3E), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        
        item {
            Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "📝 Log Transaction (නව ගනුදෙනුවක් සටහන් කිරීම)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description (ගනුදෙනුවේ විස්තරය)") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it },
                        label = { Text("Amount (මුදල - Rs.)") },
                        leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null) },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                    )
                    
                    Row(
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { isIncomeType = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isIncomeType) Color(0xFF319795) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = androidx.compose.ui.Modifier.weight(1f)
                        ) {
                            Text("Income (ආදායම)", color = if (isIncomeType) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = { isIncomeType = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!isIncomeType) Color(0xFFE53E3E) else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = androidx.compose.ui.Modifier.weight(1f)
                        ) {
                            Text("Expense (වියදම)", color = if (!isIncomeType) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (description.isNotEmpty() && amt > 0) {
                                viewModel.addFundTransaction(description, amt, isIncomeType)
                                description = ""
                                amountStr = ""
                                Toast.makeText(context, "Transaction Scribed Successfully!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = androidx.compose.ui.Modifier.width(8.dp))
                        Text("Log Scribe (එක්කරන්න)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        
        item {
            Text(
                "📈 Recent Transaction Scribe Feed (මෑතකාලීන ගනුදෙනු පෙළ)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        
        if (transactions.isEmpty()) {
            item {
                Text("No transactions logged yet.")
            }
        } else {
            items(transactions.size) { index ->
                val trans = transactions[transactions.size - 1 - index] // show newest first
                val sign = if (trans.isIncome) "+" else "-"
                val color = if (trans.isIncome) Color(0xFF319795) else Color(0xFFE53E3E)
                
                Card(
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = androidx.compose.ui.Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(trans.Description, fontWeight = FontWeight.Bold)
                            Text("Logged on: ${trans.date}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("$sign Rs. ${String.format("%.2f", trans.amount)}", color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            IconButton(
                                onClick = {
                                    viewModel.fundTransactions.remove(trans)
                                    viewModel.triggerBackup()
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = androidx.compose.ui.Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

