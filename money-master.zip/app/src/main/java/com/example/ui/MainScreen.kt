package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import com.example.data.ClassConfig
import com.example.data.SchoolConfig
import com.example.data.Subject
import com.example.utils.PdfGenerator
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

object Translation {
    val languages = listOf("English", "Sinhala", "Tamil")
    
    class TranslationSet(
        val title: String,
        val home: String,
        val settings: String,
        val workspace: String,
        val profiles: String,
        val selectLang: String,
        val schName: String,
        val examType: String,
        val year: String,
        val classSelect: String,
        val addClass: String,
        val teacher: String,
        val subManage: String,
        val addSub: String,
        val passMark: String,
        val tabInput: String,
        val tabGrades: String,
        val tabRanks: String,
        val tabCharts: String,
        val saveBtn: String,
        val photoToggle: String,
        val pdfBtn: String,
        val search: String,
        val saveProfile: String,
        val chartTitle: String,
        val selectSubChart: String
    )
    
    val dict = mapOf(
        "English" to TranslationSet(
            title = "🏫 Advanced School Performance & Ranking System",
            home = "🏠 Home & Overview",
            settings = "⚙️ School Settings",
            workspace = "📊 Class Workspaces",
            profiles = "👤 Student Profiles",
            selectLang = "🌐 Select Language:",
            schName = "School Name:",
            examType = "Exam Type:",
            year = "Academic Year:",
            classSelect = "🎯 Select Class Workspace:",
            addClass = "➕ Create New Class:",
            teacher = "🧑‍🏫 Class Teacher Name:",
            subManage = "📚 Subject Management",
            addSub = "Add New Subject:",
            passMark = "Pass Mark:",
            tabInput = "📝 Marks & Photos Input",
            tabGrades = "📊 Student Grades",
            tabRanks = "🏆 Class Rankings & PDF",
            tabCharts = "📊 Subject Analysis Charts",
            saveBtn = "💾 Save All Marks Changes",
            photoToggle = "📸 Include Student Photos in PDF Report",
            pdfBtn = "📥 Download Official Class Report (A4 PDF)",
            search = "🔍 Search Student by Name or ID:",
            saveProfile = "💾 Save Personal Profile",
            chartTitle = "📊 Grade Distribution Analysis per Subject",
            selectSubChart = "📈 Select Subject to View Chart:"
        ),
        "Sinhala" to TranslationSet(
            title = "🏫 උසස් පාසල් ප්‍රතිඵල සහ ශ්‍රේණිගත කිරීමේ පද්ධතිය",
            home = "🏠 මුල් පිටුව සහ සාරාංශය",
            settings = "⚙️ පාසල් සැකසුම්",
            workspace = "📊 පන්ති කාමර",
            profiles = "👤 ශිෂ්‍ය පුද්ගලික විස්තර",
            selectLang = "🌐 භාෂාව තෝරන්න (Select Language):",
            schName = "පාසලේ නම:",
            examType = "විභාග වර්ගය:",
            year = "වර්ෂය:",
            classSelect = "🎯 වැඩ කිරීමට අවශ්‍ය පන්තිය තෝරන්න:",
            addClass = "➕ අලුත් පන්තියක් සාදන්න:",
            teacher = "🧑‍🏫 පන්තිභාර ගුරුතුමා/ගුරුතුමිය:",
            subManage = "📚 විෂයයන් කළමනාකරණය",
            addSub = "අලුත් විෂයක් එකතු කරන්න:",
            passMark = "සමත් ලකුණ:",
            tabCharts = "📊 විෂය විශ්ලේෂණ ප්‍රස්ථාර",
            chartTitle = "📊 එක් එක් විෂය සඳහා සාමාර්ථ විශ්ලේෂණය",
            selectSubChart = "📈 ප්‍රස්ථාරය බැලීමට විෂය තෝරන්න:",
            tabInput = "📝 ලකුණු ඇතුළත් කිරීම",
            tabGrades = "📊 ශිෂ්‍ය සාමාර්ථ",
            tabRanks = "🏆 ශ්‍රේණිගත කිරීම් සහ PDF",
            saveBtn = "💾 සියලුම ලකුණු සුරකින්න",
            photoToggle = "📸 PDF වාර්තාවට ළමුන්ගේ පින්තූර ඇතුළත් කරන්න",
            pdfBtn = "📥 නිල පන්ති වාර්තාව බාගත කරන්න (A4 PDF)",
            search = "🔍 ශිෂ්‍ය නම හෝ ID මඟින් සොයන්න:",
            saveProfile = "💾 පුද්ගලಿಕ විස්තර සුරකින්න"
        ),
        "Tamil" to TranslationSet(
            title = "🏫 மேம்பட்ட பள்ளி செயல்திறன் மற்றும் தரவரிசை முறைமை",
            home = "🏠 முகப்பு மற்றும் சுருக்கம்",
            settings = "⚙️ பள்ளி அமைப்புகள்",
            workspace = "📊 வகுப்பறைகள்",
            profiles = "👤 மாணவர் சுயவிவரம்",
            selectLang = "🌐 மொழியைத் தேர்வுசெய்க:",
            schName = "பள்ளியின் பெயர்:",
            examType = "தேர்வு வகை:",
            year = "ஆண்டு:",
            classSelect = "🎯 வேலை செய்ய வேண்டிய வகுப்பைத் தேர்ந்தெடுக்கவும்:",
            addClass = "➕ புதிய வகுப்பை உருவாக்குங்கள்:",
            teacher = "🧑‍🏫 வகுப்பு ஆசிரியர் பெயர்:",
            subManage = "📚 பாடங்கள் மேலாண்மை",
            addSub = "புதிய பாடத்தைச் சேர்க்கவும்:",
            passMark = "தேர்ச்சி புள்ளி:",
            tabCharts = "📊 பாட வாரியான வரைபடங்கள்",
            chartTitle = "📊 பாட வாரியான தரப் பகிர்வு",
            selectSubChart = "📈 வரைபடத்தைப் பார்க்க பாடத்தைத் தேர்ந்தெடுக்கவும்:",
            tabInput = "📝 மதிப்பெண்கள் உள்ளீடு",
            tabGrades = "📊 மாணவர் தரங்கள்",
            tabRanks = "🏆 தரவரிசை மற்றும் PDF",
            saveBtn = "💾 மதிப்பெண்களைச் சேமிக்கவும்",
            photoToggle = "📸 PDF அறிக்கையில் மாணவர் புகைப்படங்களைச் சேர்க்கவும்",
            pdfBtn = "📥 உத்தியோகபூர்வ வகுப்பு அறிக்கையைப் பதிவிறக்கவும் (A4 PDF)",
            search = "🔍 மாணவர் பெயர் அல்லது ID மூலம் தேடவும்:",
            saveProfile = "💾 சுயவிவரத்தைச் சேமிக்கவும்"
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val schoolConfig by viewModel.schoolConfig.collectAsState()
    val allClassConfigs by viewModel.allClassConfigs.collectAsState()
    val selectedClass by viewModel.selectedClass.collectAsState()
    val classSubjects by viewModel.classSubjects.collectAsState()
    val classRankedStudents by viewModel.classRankedStudents.collectAsState()
    val allSubjects by viewModel.allSubjects.collectAsState()
    val allStudents by viewModel.allStudents.collectAsState()

    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val loggedInUser by viewModel.loggedInUser.collectAsState()

    var selectedLanguage by remember { mutableStateOf("English") }
    var mainTabIndex by remember { mutableIntStateOf(0) }
    
    val mainTabs = listOf(
        Translation.dict[selectedLanguage]?.home ?: "🏠 Home & Overview",
        Translation.dict[selectedLanguage]?.settings ?: "⚙️ School Settings",
        Translation.dict[selectedLanguage]?.workspace ?: "📊 Class Workspaces",
        Translation.dict[selectedLanguage]?.profiles ?: "👤 Student Profiles"
    )

    // Document Storage Access Framework (SAF) Launchers for Google Drive / Cloud Sync
    val fileSaveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val jsonStr = viewModel.exportDatabaseToJson()
                    context.contentResolver.openOutputStream(it)?.use { os ->
                        os.write(jsonStr.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(context, "🎉 Cloud Backup Successful!", Toast.LENGTH_LONG).show()
                } catch (e: java.lang.Exception) {
                    Toast.makeText(context, "Backup Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val fileOpenLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    context.contentResolver.openInputStream(it)?.use { ins ->
                        val jsonStr = ins.bufferedReader().use { r -> r.readText() }
                        val success = viewModel.importDatabaseFromJson(jsonStr)
                        if (success) {
                            Toast.makeText(context, "🎉 Data successfully restored!", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Restore Failed: Invalid JSON backup file.", Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (e: java.lang.Exception) {
                    Toast.makeText(context, "Restore Failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    if (!isLoggedIn) {
        LoginLobbyScreen(
            viewModel = viewModel,
            selectedLanguage = selectedLanguage,
            onLoginSuccess = {
                Toast.makeText(context, "Welcome back, Teacher!", Toast.LENGTH_SHORT).show()
            }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = schoolConfig.schoolName.ifBlank { Translation.dict[selectedLanguage]?.title ?: "School Master" },
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        loggedInUser?.let { email ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text(
                                    text = email,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 120.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                IconButton(onClick = { viewModel.logout() }) {
                                    Icon(
                                        imageVector = Icons.Default.Logout,
                                        contentDescription = "Logout",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }

                        var expandedLangMenu by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { expandedLangMenu = true }) {
                                Icon(imageVector = Icons.Default.Translate, contentDescription = "Change Language", tint = MaterialTheme.colorScheme.primary)
                            }
                            DropdownMenu(
                                expanded = expandedLangMenu,
                                onDismissRequest = { expandedLangMenu = false }
                            ) {
                                Translation.languages.forEach { lang ->
                                    DropdownMenuItem(
                                        text = { Text(lang) },
                                        onClick = {
                                            selectedLanguage = lang
                                            expandedLangMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    modifier = Modifier.testTag("navigation_bar")
                ) {
                    mainTabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            icon = {
                                val icon = when (index) {
                                    0 -> Icons.Default.Home
                                    1 -> Icons.Default.Settings
                                    2 -> Icons.Default.Workspaces
                                    else -> Icons.Default.Person
                                }
                                Icon(icon, contentDescription = label)
                            },
                            label = { Text(label, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = mainTabIndex == index,
                            onClick = { mainTabIndex = index }
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (mainTabIndex) {
                    0 -> HomeOverviewTab(
                        schoolConfig = schoolConfig,
                        classes = allClassConfigs,
                        allStudents = allStudents,
                        allSubjects = allSubjects,
                        viewModel = viewModel,
                        selectedLanguage = selectedLanguage
                    )
                    1 -> SchoolSettingsTab(
                        schoolConfig = schoolConfig,
                        onUpdateConfig = { name, exam, year, photoBytes ->
                            viewModel.updateSchoolConfig(name, "", "", exam, year, photoBytes)
                            Toast.makeText(context, "School settings saved successfully!", Toast.LENGTH_SHORT).show()
                        },
                        selectedLanguage = selectedLanguage,
                        onBackupClick = {
                            val defaultBackupName = "Backup_${loggedInUser?.replace("@", "_")?.replace(".", "_")}.json"
                            fileSaveLauncher.launch(defaultBackupName)
                        },
                        onRestoreClick = {
                            fileOpenLauncher.launch(arrayOf("application/json"))
                        }
                    )
                    2 -> ClassWorkspacesTab(
                        selectedClass = selectedClass,
                        classes = allClassConfigs,
                        subjects = classSubjects,
                        students = classRankedStudents,
                        schoolConfig = schoolConfig,
                        viewModel = viewModel,
                        selectedLanguage = selectedLanguage
                    )
                    3 -> StudentProfilesTab(
                        viewModel = viewModel,
                        allStudents = allStudents,
                        allClasses = allClassConfigs,
                        selectedLanguage = selectedLanguage
                    )
                }
            }
        }
    }
}

// ==========================================
// TAB 1: HOME & OVERVIEW
// ==========================================
@Composable
fun HomeOverviewTab(
    schoolConfig: SchoolConfig,
    classes: List<ClassConfig>,
    allStudents: List<com.example.data.Student>,
    allSubjects: List<Subject>,
    viewModel: MainViewModel,
    selectedLanguage: String = "English"
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                val schoolBitmap = remember(schoolConfig.schoolPhotoBytes) {
                    schoolConfig.schoolPhotoBytes?.let {
                        android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                    }?.asImageBitmap()
                }

                Box(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (schoolBitmap != null) {
                        Image(
                            bitmap = schoolBitmap,
                            contentDescription = "School Banner Background",
                            modifier = Modifier.matchParentSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(Color.Black.copy(alpha = 0.55f))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                )
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "🏫 ${schoolConfig.schoolName.uppercase()}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${schoolConfig.examType} — ${schoolConfig.academicYear}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            val welcomeMsg = when (selectedLanguage) {
                                "Sinhala" -> "✨ සාදරයෙන් පිළිගනිමු ✨\nපන්ති ප්‍රතිඵල, සාමාර්ථ සහ ශ්‍රේණිගත කිරීම් ස්වයංක්‍රීයව සකස් කරන පද්ධතිය"
                                "Tamil" -> "✨ நல்வரவு ✨\nதானியங்கி வகுப்பு செயல்திறன் மற்றும் தரவரிசை முறைமை"
                                else -> "✨ WELCOME TO THE SCHOOL MANAGEMENT & PORTAL ✨\nAutomated Class Performance and Rankings System"
                            }
                            Text(
                                text = welcomeMsg,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = Translation.dict[selectedLanguage]?.home ?: "📊 All Classes Summary (Overview)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (classes.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No classes added yet. Go to the Class Workspaces tab to create classes.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(classes, key = { it.className }) { classConfig ->
                val classStudents = allStudents.filter { it.className == classConfig.className }
                val classSubjects = allSubjects.filter { it.className == classConfig.className }
                val ranked = viewModel.calculateRankings(classStudents, classSubjects)
                val topStudent = ranked.firstOrNull()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = classConfig.className,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = classConfig.classTeacher,
                                    fontWeight = FontWeight.Medium,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    text = "👥 Students: ${classStudents.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "📚 Subjects: ${classSubjects.size}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (topStudent != null) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "🏆 Class Top: ${topStudent.studentName} (${topStudent.total} Marks)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            } else {
                                Text(
                                    text = "🏆 Class Top: N/A",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = "Go to workspace",
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                            modifier = Modifier
                                .size(16.dp)
                                .clickable {
                                    viewModel.selectClass(classConfig.className)
                                }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 2: SCHOOL SETTINGS
// ==========================================
@Composable
fun SchoolSettingsTab(
    schoolConfig: SchoolConfig,
    onUpdateConfig: (String, String, String, ByteArray?) -> Unit,
    selectedLanguage: String = "English",
    onBackupClick: () -> Unit = {},
    onRestoreClick: () -> Unit = {}
) {
    var schoolName by remember(schoolConfig) { mutableStateOf(schoolConfig.schoolName) }
    var examType by remember(schoolConfig) { mutableStateOf(schoolConfig.examType) }
    var academicYear by remember(schoolConfig) { mutableStateOf(schoolConfig.academicYear) }
    var schoolPhotoBytesSelected by remember(schoolConfig) { mutableStateOf<ByteArray?>(schoolConfig.schoolPhotoBytes) }

    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            schoolPhotoBytesSelected = it.toByteArray(context)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = Translation.dict[selectedLanguage]?.settings ?: "⚙️ School & Examination Settings",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "පාසලේ පොදු විස්තර සහ ප්‍රධාන තොරතුරු මෙතැනින් වෙනස් කරන්න:"
                    "Tamil" -> "பள்ளியின் பொதுவான விவரங்களையும் முக்கிய தகவல்களையும் இங்கே மாற்றவும்:"
                    else -> "Modify the school's general information and settings here:"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = schoolName,
                        onValueChange = { schoolName = it },
                        label = { Text(Translation.dict[selectedLanguage]?.schName ?: "School Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = examType,
                        onValueChange = { examType = it },
                        label = { Text(Translation.dict[selectedLanguage]?.examType ?: "Exam Type") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = academicYear,
                        onValueChange = { academicYear = it },
                        label = { Text(Translation.dict[selectedLanguage]?.year ?: "Academic Year") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    // School Photo Layout
                    Text(
                        text = "🖼️ " + when (selectedLanguage) {
                            "Sinhala" -> "පාසල් ඡායාරූපය (School Photo Banner)"
                            "Tamil" -> "பள்ளி புகைப்படம் (School Photo Banner)"
                            else -> "School Photo Banner"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val bitmap = remember(schoolPhotoBytesSelected) {
                        schoolPhotoBytesSelected?.let {
                            android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                        }?.asImageBitmap()
                    }

                    if (bitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                        ) {
                            Image(
                                bitmap = bitmap,
                                contentDescription = "Selected School Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            IconButton(
                                onClick = { schoolPhotoBytesSelected = null },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Remove photo",
                                    tint = Color.White
                                )
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Image,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Select School Photo / Banner")
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "ඇප් එකට සහ PDF බැනරයට අවශ්‍ය පාසල් ඡායාරූපය තෝරන්න"
                                        "Tamil" -> "பயன்பாட்டிற்கும் PDF பதாகைக்கும் தேவையான புகைப்படத்தைத் தேர்ந்தெடுக்கவும்"
                                        else -> "Choose a photo/banner for the application and the generated A4 PDF reports"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Button(
                        onClick = { onUpdateConfig(schoolName, examType, academicYear, schoolPhotoBytesSelected) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_settings_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(Translation.dict[selectedLanguage]?.saveBtn ?: "Save School Settings")
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Cloud,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "☁️ Secure Cloud Backup System",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "ඔබේ පන්තිවල සියලුම ලකුණු සහ සිසුන්ගේ විස්තර සුරක්ෂිතව තබා ගැනීමට Google Drive / Cloud එකට Backup කරන්න:"
                            "Tamil" -> "உங்கள் அனைத்து வகுப்பு மதிப்பெண்களையும் மாணவர் விவரங்களையும் பாதுகாப்பாக வைத்திருக்க Google Drive / Cloud இல் காப்புப்பிரதி எடுக்கவும்:"
                            else -> "Backup your class workspace data, scores, settings and profiles securely to Google Drive or Cloud storage:"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onBackupClick,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(imageVector = Icons.Default.Upload, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "📤 Cloud Backup"
                                    "Tamil" -> "📤 காப்புப்பிரதி"
                                    else -> "📤 Cloud Backup"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = onRestoreClick,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "📥 Restore Data"
                                    "Tamil" -> "📥 மீட்டமை"
                                    else -> "📥 Restore Data"
                                },
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 3: CLASS WORKSPACES
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ClassWorkspacesTab(
    selectedClass: String,
    classes: List<ClassConfig>,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    viewModel: MainViewModel,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var activeManagementMode by remember { mutableStateOf<String?>(null) } // null, "add", "update", "delete"
    var inlineClassName by remember { mutableStateOf("") }
    var inlineTeacherName by remember { mutableStateOf("") }

    var workspaceTabIndex by remember { mutableIntStateOf(0) }
    val workspaceTabs = listOf(
        Translation.dict[selectedLanguage]?.tabInput ?: "📝 Marks",
        Translation.dict[selectedLanguage]?.tabGrades ?: "📊 Grades",
        Translation.dict[selectedLanguage]?.tabRanks ?: "🏆 Rankings",
        Translation.dict[selectedLanguage]?.tabCharts ?: "📊 Charts"
    )

    val activeClassConfig = classes.firstOrNull { it.className == selectedClass }
    var teacherNameInput by remember(activeClassConfig) { mutableStateOf(activeClassConfig?.classTeacher ?: "") }

    var showAddSubjectSection by remember { mutableStateOf(false) }
    var newSubjectName by remember { mutableStateOf("") }
    var newSubjectPassMark by remember { mutableStateOf(35) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Class Selection & Management Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "🎯 පන්තිය තෝරන්න (Select Class Workspace):"
                                    "Tamil" -> "🎯 வகுப்பைத் தேர்ந்தெடுக்கவும்:"
                                    else -> "🎯 Select Class Workspace:"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            
                            if (classes.isEmpty()) {
                                Text(
                                    text = "No Classes Available",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            } else {
                                var expandedClassDropdown by remember { mutableStateOf(false) }
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { expandedClassDropdown = true }
                                            .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = selectedClass,
                                            fontWeight = FontWeight.ExtraBold,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                    DropdownMenu(
                                        expanded = expandedClassDropdown,
                                        onDismissRequest = { expandedClassDropdown = false }
                                    ) {
                                        classes.forEach { c ->
                                            DropdownMenuItem(
                                                text = { Text(c.className, fontWeight = FontWeight.Bold) },
                                                onClick = {
                                                    viewModel.selectClass(c.className)
                                                    expandedClassDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Inline Class Management: Add, Update, Delete Buttons in a single beautiful row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isAdd = activeManagementMode == "add"
                        val isUpdate = activeManagementMode == "update"
                        val isDelete = activeManagementMode == "delete"
                        
                        // Add Button
                        Button(
                            onClick = { activeManagementMode = if (isAdd) null else "add" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAdd) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                contentColor = if (isAdd) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "එක් කරන්න"
                                    "Tamil" -> "சேர்க்க"
                                    else -> "Add"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        
                        // Update Button
                        Button(
                            onClick = { activeManagementMode = if (isUpdate) null else "update" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isUpdate) Color(0xFFFF9800) else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                                contentColor = if (isUpdate) Color.White else MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "වෙනස් කරන්න"
                                    "Tamil" -> "புதுப்பிக்க"
                                    else -> "Update"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                        
                        // Delete Button
                        Button(
                            onClick = { activeManagementMode = if (isDelete) null else "delete" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDelete) Color(0xFFF44336) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                                contentColor = if (isDelete) Color.White else MaterialTheme.colorScheme.onErrorContainer
                            ),
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "මකන්න"
                                    "Tamil" -> "நீக்குக"
                                    else -> "Delete"
                                },
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }

                    // Interactive Inline Editor Cards below the action row (Absolutely Popup & Dialog Free)
                    AnimatedVisibility(
                        visible = activeManagementMode != null,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = when (activeManagementMode) {
                                    "add" -> Color(0xFF4CAF50).copy(alpha = 0.08f)
                                    "update" -> Color(0xFFFF9800).copy(alpha = 0.08f)
                                    else -> Color(0xFFF44336).copy(alpha = 0.08f)
                                }
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = when (activeManagementMode) {
                                    "add" -> Color(0xFF4CAF50).copy(alpha = 0.3f)
                                    "update" -> Color(0xFFFF9800).copy(alpha = 0.3f)
                                    else -> Color(0xFFF44336).copy(alpha = 0.3f)
                                }
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                when (activeManagementMode) {
                                    "add" -> {
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "➕ නව පන්තියක් එක් කිරීම (Add New Class)"
                                                "Tamil" -> "➕ புதிய வகுப்பு சேர்க்க"
                                                else -> "➕ Add New Class"
                                            },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF4CAF50)
                                        )
                                        OutlinedTextField(
                                            value = inlineClassName,
                                            onValueChange = { inlineClassName = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "පන්තියේ නම (උදා: 10-A)"
                                                    "Tamil" -> "வகுப்பு பெயர் (உதாரணம்: 10-A)"
                                                    else -> "Class Name (e.g., 10-A)"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = inlineTeacherName,
                                            onValueChange = { inlineTeacherName = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "පන්තිභාර ගුරුතුමා/ගුරුතුමිය"
                                                    "Tamil" -> "வகுப்பு ஆசிரியர் பெயர்"
                                                    else -> "Class Teacher Name"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(onClick = { activeManagementMode = null }) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "අවලංගු කරන්න"
                                                        "Tamil" -> "ரத்துசெய்"
                                                        else -> "Cancel"
                                                    }
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    if (inlineClassName.isNotBlank()) {
                                                        viewModel.addClass(inlineClassName, inlineTeacherName)
                                                        inlineClassName = ""
                                                        inlineTeacherName = ""
                                                        activeManagementMode = null
                                                        Toast.makeText(context, "Class added successfully!", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                                            ) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "එකතු කරන්න"
                                                        "Tamil" -> "சேர்க்க"
                                                        else -> "Add Class"
                                                    },
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                    "update" -> {
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "✏️ පන්තියේ තොරතුරු වෙනස් කිරීම (Update Class Details)"
                                                "Tamil" -> "✏️ வகுப்பு விவரங்களை மாற்றவும்"
                                                else -> "✏️ Update Class Details"
                                            },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFFF9800)
                                        )
                                        
                                        var renameInput by remember(selectedClass) { mutableStateOf(selectedClass) }
                                        var teacherInput by remember(teacherNameInput) { mutableStateOf(teacherNameInput) }
                                        
                                        OutlinedTextField(
                                            value = renameInput,
                                            onValueChange = { renameInput = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "පන්තියේ නම වෙනස් කරන්න"
                                                    "Tamil" -> "வகுப்பு பெயரை மாற்றவும்"
                                                    else -> "Rename Class Name"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        OutlinedTextField(
                                            value = teacherInput,
                                            onValueChange = { teacherInput = it },
                                            label = { Text(
                                                when (selectedLanguage) {
                                                    "Sinhala" -> "ගුරුතුමා/ගුරුතුමිය වෙනස් කරන්න"
                                                    "Tamil" -> "வகுப்பு ஆசிரியரை மாற்றவும்"
                                                    else -> "Change Class Teacher"
                                                }
                                            ) },
                                            modifier = Modifier.fillMaxWidth(),
                                            singleLine = true,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(onClick = { activeManagementMode = null }) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "අවලංගු කරන්න"
                                                        "Tamil" -> "ரத்துசெய்"
                                                        else -> "Cancel"
                                                    }
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    if (renameInput.isNotBlank()) {
                                                        if (renameInput != selectedClass) {
                                                            viewModel.renameClass(selectedClass, renameInput)
                                                        }
                                                        viewModel.updateClassTeacher(renameInput, teacherInput)
                                                        activeManagementMode = null
                                                        Toast.makeText(context, "Class updated successfully!", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
                                            ) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "වෙනස් කරන්න"
                                                        "Tamil" -> "புதுப்பிக்க"
                                                        else -> "Update"
                                                    },
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                    "delete" -> {
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "🗑️ පන්තිය මකා දැමීම (Delete Class Workspace)"
                                                "Tamil" -> "🗑️ வகுப்பு நீக்குதல்"
                                                else -> "🗑️ Delete Class Workspace"
                                            },
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFF44336)
                                        )
                                        
                                        Text(
                                            text = when (selectedLanguage) {
                                                "Sinhala" -> "අවධානය: ඔබට ස්ථිරවම '$selectedClass' පන්තිය සහ ඊට අදාළ සියලුම විෂයන් සහ සිසුන්ගේ දත්ත මකා දැමීමට අවශ්‍යද? මෙම ක්‍රියාව නැවත වෙනස් කළ නොහැක."
                                                "Tamil" -> "எச்சரிக்கை: வகுப்பு '$selectedClass' மற்றும் அதனுடன் தொடர்புடைய அனைத்து பாடங்களையும் மாணவர்களின் தரவையும் நிரந்தரமாக நீக்க வேண்டுமா?"
                                                else -> "Warning: Are you sure you want to delete class '$selectedClass'? This will permanently clear all subjects and students associated with this class. This action cannot be undone."
                                            },
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(onClick = { activeManagementMode = null }) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "අවලංගු කරන්න"
                                                        "Tamil" -> "ரத்துசெய்"
                                                        else -> "Cancel"
                                                    }
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    viewModel.deleteClass(selectedClass)
                                                    activeManagementMode = null
                                                    Toast.makeText(context, "Class deleted successfully!", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336))
                                            ) {
                                                Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "ඔව්, මකන්න"
                                                        "Tamil" -> "ஆம், நீக்கு"
                                                        else -> "Yes, Delete"
                                                    },
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (activeClassConfig != null) {
            // Subject Management Section with Secure Dropdown Checkbox Protection
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📚 Subject Management",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(onClick = { showAddSubjectSection = !showAddSubjectSection }) {
                                Text(if (showAddSubjectSection) "Collapse" else "➕ Add Subject")
                            }
                        }

                        if (showAddSubjectSection) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = newSubjectName,
                                    onValueChange = { newSubjectName = it },
                                    label = { Text("Subject Name") },
                                    placeholder = { Text("e.g. Mathematics, Science") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                OutlinedTextField(
                                    value = newSubjectPassMark.toString(),
                                    onValueChange = { newSubjectPassMark = it.toIntOrNull() ?: 35 },
                                    label = { Text("Pass Mark") },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                Button(
                                    onClick = {
                                        if (newSubjectName.isNotBlank()) {
                                            viewModel.addSubject(newSubjectName, newSubjectPassMark, selectedClass)
                                            newSubjectName = ""
                                            showAddSubjectSection = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Add Subject to Class")
                                }
                            }
                        }

                        if (subjects.isEmpty()) {
                            Text(
                                text = "No subjects in this class yet. Add some subjects above to begin adding marks.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        } else {
                            Text(
                                text = "Active Class Subjects:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                subjects.forEach { sub ->
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("${sub.name} (${sub.passMark})") }
                                    )
                                }
                            }

                            // Safe Subject Deletion with confirmation dropdown and checkbox (Subject Delete Protection)
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = "🛡️ Delete Subject with Protection (විෂයන් මකා දැමීම):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            
                            var selectedSubToDelete by remember { mutableStateOf<Subject?>(null) }
                            var isConfirmCheckboxChecked by remember { mutableStateOf(false) }
                            var expandedDeleteDropdown by remember { mutableStateOf(false) }
                            
                            Box(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandedDeleteDropdown = true }
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = selectedSubToDelete?.name ?: "-- Select Subject to Delete --",
                                        fontWeight = FontWeight.Medium,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (selectedSubToDelete != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                                DropdownMenu(
                                    expanded = expandedDeleteDropdown,
                                    onDismissRequest = { expandedDeleteDropdown = false },
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("-- Select Subject to Delete --") },
                                        onClick = {
                                            selectedSubToDelete = null
                                            isConfirmCheckboxChecked = false
                                            expandedDeleteDropdown = false
                                        }
                                    )
                                    subjects.forEach { sub ->
                                        DropdownMenuItem(
                                            text = { Text(sub.name) },
                                            onClick = {
                                                selectedSubToDelete = sub
                                                isConfirmCheckboxChecked = false
                                                expandedDeleteDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                            
                            val activeSubToDel = selectedSubToDelete
                            if (activeSubToDel != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(
                                        checked = isConfirmCheckboxChecked,
                                        onCheckedChange = { isConfirmCheckboxChecked = it }
                                    )
                                    Text(
                                        text = "⚠️ මම ස්ථිරවම ${activeSubToDel.name} විෂය සහ එහි සියලුම ලකුණු මකා දැමීමට එකඟ වෙමි.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                                
                                Button(
                                    onClick = {
                                        viewModel.removeSubject(activeSubToDel)
                                        Toast.makeText(context, "${activeSubToDel.name} deleted safely!", Toast.LENGTH_SHORT).show()
                                        selectedSubToDelete = null
                                        isConfirmCheckboxChecked = false
                                    },
                                    enabled = isConfirmCheckboxChecked,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Confirm Delete Subject")
                                }
                            }
                        }
                    }
                }
            }

            // Sub-Tabs within the workspace
            item {
                TabRow(
                    selectedTabIndex = workspaceTabIndex,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    workspaceTabs.forEachIndexed { index, label ->
                        Tab(
                            selected = workspaceTabIndex == index,
                            onClick = { workspaceTabIndex = index },
                            text = { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Render selected Workspace Sub-Tab
            item {
                when (workspaceTabIndex) {
                    0 -> WorkspaceStudentMarksView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        viewModel = viewModel
                    )
                    1 -> WorkspaceStudentGradesView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students
                    )
                    2 -> WorkspaceRankingsExportView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        classConfig = activeClassConfig,
                        selectedLanguage = selectedLanguage
                    )
                    3 -> WorkspaceSubjectChartsView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        selectedLanguage = selectedLanguage
                    )
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 1: STUDENT MARKS VIEW
// ==========================================
@Composable
fun WorkspaceStudentMarksView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var showAddStudentDialog by remember { mutableStateOf(false) }

    // Student fields for Add/Edit
    var editingStudentId by remember { mutableStateOf("") }
    var editingStudentName by remember { mutableStateOf("") }
    var isEditMode by remember { mutableStateOf(false) }
    var photoBytesSelected by remember { mutableStateOf<ByteArray?>(null) }
    val editingStudentMarks = remember { mutableStateMapOf<String, String>() }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            photoBytesSelected = it.toByteArray(context)
        }
    }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("🔍 Search students...") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(8.dp)
            )

            Button(
                onClick = {
                    isEditMode = false
                    editingStudentId = ""
                    editingStudentName = ""
                    photoBytesSelected = null
                    editingStudentMarks.clear()
                    subjects.forEach { editingStudentMarks[it.name] = "" }
                    showAddStudentDialog = true
                },
                modifier = Modifier.height(56.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Student")
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No students found. Use 'Add Student' above to start entering data.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            filtered.forEach { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Display Student circular portrait photo (Circular Avatar Preview)
                        val avatarBitmap = remember(student.photoBytes) {
                            student.photoBytes?.let {
                                android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                            }?.asImageBitmap()
                        }
                        
                        if (avatarBitmap != null) {
                            Image(
                                bitmap = avatarBitmap,
                                contentDescription = "Student Photo",
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = student.studentName,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyLarge
                                    )
                                    Text(
                                        text = "ID: ${student.studentId}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            isEditMode = true
                                            editingStudentId = student.studentId
                                            editingStudentName = student.studentName
                                            photoBytesSelected = student.photoBytes
                                            editingStudentMarks.clear()
                                            subjects.forEach {
                                                editingStudentMarks[it.name] = (student.marks[it.name] ?: 0).toString()
                                            }
                                            showAddStudentDialog = true
                                        }
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit student", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteStudent(student.studentId) }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete student", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }

                            // Marks summary
                            Text(
                                text = subjects.joinToString("  |  ") { sub ->
                                    "${sub.name}: ${student.marks[sub.name] ?: 0}"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    // Add/Edit Student Dialog with custom Portrait Photo selector
    if (showAddStudentDialog) {
        Dialog(onDismissRequest = { showAddStudentDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = if (isEditMode) "✏️ Edit Student Info & Marks" else "➕ Add Student to $selectedClass",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = editingStudentId,
                            onValueChange = { if (!isEditMode) editingStudentId = it },
                            label = { Text("Student ID (e.g. ST001)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            enabled = !isEditMode,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = editingStudentName,
                            onValueChange = { editingStudentName = it },
                            label = { Text("Student Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }

                    // Photo Picker Layout
                    item {
                        Text(
                            text = "👦 ළමුන්ගේ පින්තූර ඇතුළත් කරන්න (Student Photo):",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val bitmap = remember(photoBytesSelected) {
                                photoBytesSelected?.let {
                                    android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                }?.asImageBitmap()
                            }
                            
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = "Selected Photo",
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                            
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { photoPickerLauncher.launch("image/*") },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Upload Photo")
                                }
                                if (photoBytesSelected != null) {
                                    TextButton(
                                        onClick = { photoBytesSelected = null }
                                    ) {
                                        Text("Remove Photo", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }

                    if (subjects.isNotEmpty()) {
                        item {
                            Text(
                                text = "Enter Subject Marks:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        items(subjects, key = { it.id }) { sub ->
                            var markVal by remember { mutableStateOf(editingStudentMarks[sub.name] ?: "") }
                            OutlinedTextField(
                                value = markVal,
                                onValueChange = {
                                    markVal = it
                                    editingStudentMarks[sub.name] = it
                                },
                                label = { Text("${sub.name} (Pass Mark: ${sub.passMark})") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showAddStudentDialog = false }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (editingStudentId.isNotBlank() && editingStudentName.isNotBlank()) {
                                        val marksMap = subjects.associate { sub ->
                                            sub.name to (editingStudentMarks[sub.name]?.toIntOrNull() ?: 0)
                                        }
                                        viewModel.addOrUpdateStudent(
                                            studentId = editingStudentId,
                                            studentName = editingStudentName,
                                            marks = marksMap,
                                            className = selectedClass,
                                            photoBytes = photoBytesSelected
                                        )
                                        showAddStudentDialog = false
                                    }
                                }
                            ) {
                                Text("Save")
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 2: STUDENT GRADES VIEW
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkspaceStudentGradesView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>
) {
    var searchQuery by remember { mutableStateOf("") }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("🔍 සාමාර්ථ බැලීමට ශිෂ්‍ය නම/ID ටයිප් කරන්න") },
            placeholder = { Text("Search grades by name or ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(8.dp)
        )

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No matching students found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            filtered.forEach { student ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = student.studentName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "ID: ${student.studentId}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = "Avg: ${student.average}%",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(
                            modifier = Modifier
                                .height(1.dp)
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        )

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            subjects.forEach { subject ->
                                val score = student.marks[subject.name] ?: 0
                                val grade = student.grades[subject.name] ?: "F"
                                
                                val badgeColor = when (grade) {
                                    "A" -> Color(0xFFE6F4EA)
                                    "B" -> Color(0xFFE8F0FE)
                                    "C" -> Color(0xFFE2F1F8)
                                    "S" -> Color(0xFFFEF7E0)
                                    else -> Color(0xFFFCE8E6)
                                }
                                val textColor = when (grade) {
                                    "A" -> Color(0xFF137333)
                                    "B" -> Color(0xFF1A73E8)
                                    "C" -> Color(0xFF00838F)
                                    "S" -> Color(0xFFB06000)
                                    else -> Color(0xFFC5221F)
                                }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.border(
                                        width = 1.dp,
                                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "${subject.name}: $score",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(badgeColor)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = grade,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = textColor
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 3: RANKINGS & EXPORT
// ==========================================
@Composable
fun WorkspaceRankingsExportView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    classConfig: ClassConfig?,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var includePhotosInReport by remember { mutableStateOf(true) }

    val filtered = if (searchQuery.isBlank()) {
        students
    } else {
        students.filter {
            it.studentName.contains(searchQuery, ignoreCase = true) ||
            it.studentId.contains(searchQuery, ignoreCase = true) ||
            it.rank.toString() == searchQuery
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text(Translation.dict[selectedLanguage]?.search ?: "🔍 Search Rankings...") },
            placeholder = { Text("Search by rank, name or ID...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(8.dp)
        )

        // Rankings list
        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No ranked data found.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            filtered.forEach { student ->
                val medalIcon = when (student.rank) {
                    1 -> "🥇 "
                    2 -> "🥈 "
                    3 -> "🥉 "
                    else -> "#${student.rank} "
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.dp,
                        color = when (student.rank) {
                            1 -> Color(0xFFFFD700)
                            2 -> Color(0xFFC0C0C0)
                            3 -> Color(0xFFCD7F32)
                            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Circular photo preview inside ranked list row
                            val rankAvatarBitmap = remember(student.photoBytes) {
                                student.photoBytes?.let {
                                    android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                }?.asImageBitmap()
                            }
                            
                            if (rankAvatarBitmap != null) {
                                Image(
                                    bitmap = rankAvatarBitmap,
                                    contentDescription = "Photo",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .border(0.5.dp, MaterialTheme.colorScheme.outline, CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = medalIcon,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = student.studentName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Text(
                                    text = "ID: ${student.studentId}  |  Total: ${student.total}  |  Average: ${student.average}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Status badge
                        val badgeColor = if (student.status.contains("Pass")) Color(0xFFE6F4EA) else Color(0xFFFCE8E6)
                        val badgeTextColor = if (student.status.contains("Pass")) Color(0xFF137333) else Color(0xFFC5221F)

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(badgeColor)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = student.status,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeTextColor
                            )
                        }
                    }
                }
            }
        }

        // Individual Progress Report Card Generator
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "🧑‍🎓 " + when (selectedLanguage) {
                        "Sinhala" -> "ශිෂ්‍ය ප්‍රගති වාර්තා සාදන්නා (Individual Report Card)"
                        "Tamil" -> "தனிநபர் மாணவர் அறிக்கை அட்டை (Individual Report Card)"
                        else -> "Individual Student Report Card Generator"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ප්‍රගති වාර්තාව (Individual PDF) සෑදීම සඳහා ශිෂ්‍යයා තෝරන්න:"
                        "Tamil" -> "தனிநபர் PDF அறிக்கையை உருவாக்க மாணவரைத் தேர்ந்தெடுக்கவும்:"
                        else -> "Select a student to generate their individual A4 progress report card:"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                var selectedStudentForReport by remember(students) { mutableStateOf(students.firstOrNull()) }
                var expandedStudentDropdown by remember { mutableStateOf(false) }

                Box(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandedStudentDropdown = true }
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 12.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = selectedStudentForReport?.studentName ?: "Select a student...",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (selectedStudentForReport != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    DropdownMenu(
                        expanded = expandedStudentDropdown,
                        onDismissRequest = { expandedStudentDropdown = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        students.forEach { std ->
                            DropdownMenuItem(
                                text = { Text("[${std.studentId}] ${std.studentName}", fontWeight = FontWeight.Bold) },
                                onClick = {
                                    selectedStudentForReport = std
                                    expandedStudentDropdown = false
                                }
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val currentStudent = selectedStudentForReport
                        if (currentStudent == null) {
                            Toast.makeText(context, "Please select a student first!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "Report_Card_${currentStudent.studentId}.pdf")
                            val fos = FileOutputStream(pdfFile)
                            val subjectNames = subjects.map { it.name }
                            
                            PdfGenerator.generateIndividualReport(
                                context = context,
                                config = schoolConfig,
                                className = selectedClass,
                                classTeacher = classConfig?.classTeacher ?: "Unknown",
                                student = currentStudent,
                                subjects = subjectNames,
                                outputStream = fos
                            )
                            fos.close()

                            val pdfUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                pdfFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                putExtra(Intent.EXTRA_SUBJECT, "Report Card - ${currentStudent.studentName}")
                                putExtra(Intent.EXTRA_TEXT, "Official Student Progress Report Card for ${currentStudent.studentName}.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Individual Progress Report"))

                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to generate Individual PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(when (selectedLanguage) {
                        "Sinhala" -> "නිල තනි ප්‍රගති වාර්තාව PDF සාදන්න"
                        "Tamil" -> "தனிநபர் PDF அறிக்கையை உருவாக்கவும்"
                        else -> "Generate & Share Individual Report (PDF)"
                    })
                }
            }
        }

        // Export Actions Section (Class Rankings)
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "නිල අධ්‍යයන වාර්තා (Official Academic Reports) 📄"
                        "Tamil" -> "உத்தியோகபூர்வ கல்வி அறிக்கைகள் 📄"
                        else -> "Official Academic Reports (නිල වාර්තා) 📄"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "සියලුම සිසුන්ගේ ශ්‍රේණිගත කිරීම් සහ ලකුණු ඇතුළත් නිල පන්ති ලේඛන වාර්තාවක් (A4 PDF) හෝ එක්සෙල් ගොනුවක් බාගත කරන්න."
                        "Tamil" -> "அனைத்து மாணவர்களின் தரவரிசைகள் மற்றும் மதிப்பெண்கள் அடங்கிய உத்தியோகபூர்வ வகுப்பு அறிக்கையை (PDF அல்லது Excel) பதிவிறக்கவும்."
                        else -> "Generate and share styled official PDF reports or download full rankings spreadsheets compatible with Excel for $selectedClass."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                // Photos toggle Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable { includePhotosInReport = !includePhotosInReport },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Checkbox(
                        checked = includePhotosInReport,
                        onCheckedChange = { includePhotosInReport = it }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = Translation.dict[selectedLanguage]?.photoToggle ?: "📸 Include Student Photos in PDF Report",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                // PDF Export (Class Rankings)
                Button(
                    onClick = {
                        if (students.isEmpty()) {
                            Toast.makeText(context, "No student data available to generate report!", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        try {
                            val pdfFile = File(context.cacheDir, "Official_Report_${selectedClass.replace(" ", "_")}.pdf")
                            val fos = FileOutputStream(pdfFile)
                            val subjectNames = subjects.map { it.name }
                            
                            PdfGenerator.generateReport(
                                context = context,
                                config = schoolConfig,
                                className = selectedClass,
                                classTeacher = classConfig?.classTeacher ?: "Unknown",
                                subjects = subjectNames,
                                students = students,
                                outputStream = fos,
                                includePhotos = includePhotosInReport
                            )
                            fos.close()

                            val pdfUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                pdfFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                putExtra(Intent.EXTRA_SUBJECT, "$selectedClass - ${schoolConfig.examType} Official Report")
                                putExtra(Intent.EXTRA_TEXT, "Here is the official academic rankings and performance report for Class $selectedClass.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Official PDF Report"))

                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to generate PDF: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        contentColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_pdf_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(Translation.dict[selectedLanguage]?.pdfBtn ?: "Download Official Class Report (A4 PDF)")
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Excel/CSV Export
                FilledTonalButton(
                    onClick = {
                        if (students.isEmpty()) {
                            Toast.makeText(context, "No student data available to generate spreadsheet!", Toast.LENGTH_SHORT).show()
                            return@FilledTonalButton
                        }
                        try {
                            val fileName = "${selectedClass.replace(" ", "_")}_${schoolConfig.examType.replace(" ", "_")}_Report.csv"
                            val csvFile = File(context.cacheDir, fileName)
                            val fos = FileOutputStream(csvFile)
                            val writer = java.io.BufferedWriter(java.io.OutputStreamWriter(fos, "UTF-8"))

                            // UTF-8 BOM
                            writer.write('\ufeff'.toInt())

                            // CSV headers
                            val headers = mutableListOf("Rank", "Student ID", "Student Name")
                            subjects.forEach {
                                headers.add(it.name)
                                headers.add("${it.name} (Grade)")
                            }
                            headers.add("Total")
                            headers.add("Average")
                            headers.add("Status")
                            writer.write(headers.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                            writer.newLine()

                            // CSV rows
                            students.forEach { student ->
                                val row = mutableListOf<String>()
                                row.add(student.rank.toString())
                                row.add(student.studentId)
                                row.add(student.studentName)
                                subjects.forEach { subject ->
                                    row.add((student.marks[subject.name] ?: 0).toString())
                                    row.add(student.grades[subject.name] ?: "F")
                                }
                                row.add(student.total.toString())
                                row.add(student.average.toString())
                                row.add(student.status)
                                writer.write(row.joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" })
                                writer.newLine()
                            }
                            writer.flush()
                            writer.close()
                            fos.close()

                            val csvUri = FileProvider.getUriForFile(
                                context,
                                "com.aistudio.schoolreportgenerator.fileprovider",
                                csvFile
                            )

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/comma-separated-values"
                                putExtra(Intent.EXTRA_STREAM, csvUri)
                                putExtra(Intent.EXTRA_SUBJECT, "$selectedClass - ${schoolConfig.examType} Spreadsheet")
                                putExtra(Intent.EXTRA_TEXT, "Here is the academic spreadsheet containing scores and grades for Class $selectedClass.")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }

                            context.startActivity(Intent.createChooser(shareIntent, "Share Rankings Spreadsheet (Excel/CSV)"))
                        } catch (e: Exception) {
                            e.printStackTrace()
                            Toast.makeText(context, "Failed to export spreadsheet: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        contentColor = MaterialTheme.colorScheme.secondaryContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_excel_button"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.TableView, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(when (selectedLanguage) {
                        "Sinhala" -> "Excel ශ්‍රේණිගත කිරීම් වාර්තාව බාගත කරන්න"
                        "Tamil" -> "Excel தரவரிசை அறிக்கையைப் பதிவிறக்கவும்"
                        else -> "Download & Share Spreadsheet (Excel)"
                    })
                }
            }
        }
    }
}

// ==========================================
// WORKSPACE SUB-TAB 4: SUBJECT ANALYSIS CHARTS
// ==========================================
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceSubjectChartsView(
    selectedClass: String,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    selectedLanguage: String
) {
    val t = Translation.dict[selectedLanguage]
    val classSubjects = subjects.filter { it.className == selectedClass }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = t?.chartTitle ?: "📊 Grade Distribution Analysis per Subject",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        if (classSubjects.isEmpty() || students.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "ප්‍රස්ථාර බැලීමට ප්‍රමාණවත් විෂයයන් හෝ සිසුන්ගේ ලකුණු දත්ත පද්ධතියේ නැත."
                            "Tamil" -> "வரைபடங்களைப் பார்க்க போதுமான பாடங்கள் அல்லது மாணவர்களின் மதிப்பெண் தரவு கணினியில் இல்லை."
                            else -> "There are no subjects or student marks in the system to display charts."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }
        } else {
            var selectedSubject by remember(selectedClass) { mutableStateOf(classSubjects.first()) }
            var expandedDropdown by remember { mutableStateOf(false) }

            val chartTypes = listOf("Bar Chart", "Line Chart", "Pie Chart", "Donut Chart", "Area Chart")
            var selectedChartType by remember { mutableStateOf("Bar Chart") }
            var expandedChartDropdown by remember { mutableStateOf(false) }

            // Subject Selection Dropdown
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = selectedSubject.name,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(t?.selectSubChart ?: "📈 Select Subject to View Chart:") },
                    trailingIcon = {
                        IconButton(onClick = { expandedDropdown = !expandedDropdown }) {
                            Icon(
                                imageVector = if (expandedDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Toggle Subject Dropdown"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedDropdown = !expandedDropdown },
                    shape = RoundedCornerShape(8.dp)
                )

                DropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    classSubjects.forEach { subject ->
                        DropdownMenuItem(
                            text = { Text(subject.name, fontWeight = FontWeight.SemiBold) },
                            onClick = {
                                selectedSubject = subject
                                expandedDropdown = false
                            }
                        )
                    }
                }
            }

            // Chart Type Dropdown (Bilingual)
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = when (selectedChartType) {
                        "Bar Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "තීරු ප්‍රස්ථාරය (Bar Chart)"
                            "Tamil" -> "பட்டை வரைபடம் (Bar Chart)"
                            else -> "Bar Chart"
                        }
                        "Line Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "රේඛීය ප්‍රස්ථාරය (Line Chart)"
                            "Tamil" -> "வரி வரைபடம் (Line Chart)"
                            else -> "Line Chart"
                        }
                        "Pie Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "වට ප්‍රස්ථාරය (Pie Chart)"
                            "Tamil" -> "வட்ட வரைபடம் (Pie Chart)"
                            else -> "Pie Chart"
                        }
                        "Donut Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "ඩෝනට් ප්‍රස්ථාරය (Donut Chart)"
                            "Tamil" -> "டோனட் வரைபடம் (Donut Chart)"
                            else -> "Donut Chart"
                        }
                        "Area Chart" -> when (selectedLanguage) {
                            "Sinhala" -> "ප්‍රදේශ ප්‍රස්ථාරය (Area Chart)"
                            "Tamil" -> "பரப்பு வரைபடம் (Area Chart)"
                            else -> "Area Chart"
                        }
                        else -> selectedChartType
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "📊 ප්‍රස්ථාර වර්ගය තෝරන්න (Select Chart Type):"
                            "Tamil" -> "📊 வரைபட வகையைத் தேர்ந்தெடுக்கவும்:"
                            else -> "📊 Select Chart Type:"
                        }
                    ) },
                    trailingIcon = {
                        IconButton(onClick = { expandedChartDropdown = !expandedChartDropdown }) {
                            Icon(
                                imageVector = if (expandedChartDropdown) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                contentDescription = "Toggle Chart Dropdown"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedChartDropdown = !expandedChartDropdown },
                    shape = RoundedCornerShape(8.dp)
                )

                DropdownMenu(
                    expanded = expandedChartDropdown,
                    onDismissRequest = { expandedChartDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    chartTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { 
                                Text(
                                    text = when (type) {
                                        "Bar Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "තීරු ප්‍රස්ථාරය (Bar Chart)"
                                            "Tamil" -> "பட்டை வரைபடம் (Bar Chart)"
                                            else -> "Bar Chart"
                                        }
                                        "Line Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "රේඛීය ප්‍රස්ථාරය (Line Chart)"
                                            "Tamil" -> "வரி வரைபடம் (Line Chart)"
                                            else -> "Line Chart"
                                        }
                                        "Pie Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "වට ප්‍රස්ථාරය (Pie Chart)"
                                            "Tamil" -> "வட்ட வரைபடம் (Pie Chart)"
                                            else -> "Pie Chart"
                                        }
                                        "Donut Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "ඩෝනට් ප්‍රස්ථාරය (Donut Chart)"
                                            "Tamil" -> "டோனட் வரைபடம் (Donut Chart)"
                                            else -> "Donut Chart"
                                        }
                                        "Area Chart" -> when (selectedLanguage) {
                                            "Sinhala" -> "ප්‍රදේශ ප්‍රස්ථාරය (Area Chart)"
                                            "Tamil" -> "பரப்பு வரைபடம் (Area Chart)"
                                            else -> "Area Chart"
                                        }
                                        else -> type
                                    },
                                    fontWeight = FontWeight.SemiBold
                                ) 
                            },
                            onClick = {
                                selectedChartType = type
                                expandedChartDropdown = false
                            }
                        )
                    }
                }
            }

            // Grade counts calculations
            val gradeCounts = students.map { it.grades[selectedSubject.name] ?: "F" }
                .groupingBy { it }
                .eachCount()

            val possibleGrades = listOf("A", "B", "C", "S", "F")
            val chartData = possibleGrades.map { grade ->
                grade to (gradeCounts[grade] ?: 0)
            }

            val gradeColors = mapOf(
                "A" to Color(0xFF4CAF50), // Green
                "B" to Color(0xFF2196F3), // Blue
                "C" to Color(0xFFFF9800), // Orange
                "S" to Color(0xFF9C27B0), // Purple
                "F" to Color(0xFFF44336)  // Red
            )

            // Beautiful styled card containing the Active Chart Type
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${selectedSubject.name} - ${when (selectedLanguage) {
                                "Sinhala" -> "සාමාර්ථ ව්‍යාප්තිය"
                                "Tamil" -> "தரப் பகிர்வு"
                                else -> "Grade Distribution"
                            }}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )

                        // 📥 DOWNLOAD CHART BUTTON
                        Button(
                            onClick = {
                                saveChartAsPng(
                                    context = context,
                                    schoolConfig = schoolConfig,
                                    className = selectedClass,
                                    subjectName = selectedSubject.name,
                                    chartType = selectedChartType,
                                    data = chartData
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Download Chart",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "බාගත කරන්න"
                                    "Tamil" -> "பதிவிறக்கவும்"
                                    else -> "Export PNG"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Dynamic Render based on selection
                    when (selectedChartType) {
                        "Bar Chart" -> ColorfulBarChart(data = chartData, gradeColors = gradeColors)
                        "Line Chart" -> ColorfulLineChart(data = chartData, gradeColors = gradeColors)
                        "Pie Chart" -> ColorfulPieChart(data = chartData, gradeColors = gradeColors)
                        "Donut Chart" -> ColorfulDonutChart(data = chartData, gradeColors = gradeColors)
                        "Area Chart" -> ColorfulAreaChart(data = chartData, gradeColors = gradeColors)
                    }
                }
            }

            // Summary Table Section
            Text(
                text = when (selectedLanguage) {
                    "Sinhala" -> "📝 සාරාංශ වගුව"
                    "Tamil" -> "📝 சுருக்க அட்டவணை"
                    else -> "📝 Summary Table"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .padding(vertical = 12.dp, horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "සාමාර්ථය"
                                "Tamil" -> "தரம்"
                                else -> "Grade"
                            },
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Start
                        )
                        Text(
                            text = when (selectedLanguage) {
                                "Sinhala" -> "සිසුන් සංඛ්‍යාව"
                                "Tamil" -> "மாணவர்களின் எண்ணிக்கை"
                                else -> "Student Count"
                            },
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                    }

                    // Table Rows
                    chartData.forEachIndexed { index, (grade, count) ->
                        val rowBgColor = if (index % 2 == 0) {
                            MaterialTheme.colorScheme.surface
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(rowBgColor)
                                .padding(vertical = 12.dp, horizontal = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Grade indicator circle/badge
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Start
                            ) {
                                val badgeColor = gradeColors[grade] ?: Color.Gray
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(badgeColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = grade,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = when (grade) {
                                        "A" -> "Distinction (A)"
                                        "B" -> "Very Good (B)"
                                        "C" -> "Credit (C)"
                                        "S" -> "Ordinary Pass (S)"
                                        else -> "Weak/Fail (F)"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Text(
                                text = count.toString(),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// INDIVIDUAL DYNAMIC COMPOSABLE CHARTS
// ==========================================

@Composable
fun ColorfulBarChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 1
    val maxCount = if (maxVal == 0) 1 else maxVal

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        data.forEach { (grade, value) ->
            val animatedHeightFraction by animateFloatAsState(
                targetValue = value.toFloat() / maxCount,
                animationSpec = spring(dampingRatio = 0.8f, stiffness = 120f),
                label = "bar_height"
            )

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                if (value > 0) {
                    Text(
                        text = value.toString(),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.55f)
                        .fillMaxHeight(animatedHeightFraction.coerceIn(0.01f, 1f))
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    gradeColors[grade] ?: Color.Gray,
                                    (gradeColors[grade] ?: Color.Gray).copy(alpha = 0.5f)
                                )
                            )
                        )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = grade,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun ColorfulLineChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 1
    val maxCount = if (maxVal == 0) 1 else maxVal
    val lineColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val pointCount = data.size
            val stepX = width / (pointCount - 1)

            // Draw grid lines
            for (i in 0..4) {
                val y = i * (height / 4)
                drawLine(
                    color = Color.Gray.copy(alpha = 0.15f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Calculate coordinates
            val points = data.mapIndexed { index, (_, value) ->
                val x = index * stepX
                val y = height - (value.toFloat() / maxCount) * height
                Offset(x, y)
            }

            // Draw continuous line
            val path = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) moveTo(point.x, point.y)
                    else lineTo(point.x, point.y)
                }
            }
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
            )

            // Draw distinct data node indicators
            points.forEachIndexed { index, point ->
                val grade = data[index].first
                val ptColor = gradeColors[grade] ?: Color.Gray

                drawCircle(
                    color = ptColor,
                    radius = 7.dp.toPx(),
                    center = point
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = point
                )
            }
        }
        
        // Label mapping below the Canvas
        Row(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            data.forEach { (grade, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$grade\n($value)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorfulPieChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val totalCount = data.sumOf { it.second }
    val totalSum = if (totalCount == 0) 1f else totalCount.toFloat()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (totalCount == 0) {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No Student Marks Registered",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(
                modifier = Modifier.size(160.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    data.forEach { (grade, value) ->
                        val sweepAngle = (value.toFloat() / totalSum) * 360f
                        if (sweepAngle > 0f) {
                            drawArc(
                                color = gradeColors[grade] ?: Color.Gray,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true
                            )
                            startAngle += sweepAngle
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Multi-line responsive FlowRow legend representation
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 3
        ) {
            data.forEach { (grade, value) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(gradeColors[grade] ?: Color.Gray)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$grade: $value (${String.format("%.1f", (value / totalSum) * 100)}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorfulDonutChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val totalCount = data.sumOf { it.second }
    val totalSum = if (totalCount == 0) 1f else totalCount.toFloat()
    val holeColor = MaterialTheme.colorScheme.surface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (totalCount == 0) {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No Student Marks Registered",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            Box(
                modifier = Modifier.size(160.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    var startAngle = -90f
                    data.forEach { (grade, value) ->
                        val sweepAngle = (value.toFloat() / totalSum) * 360f
                        if (sweepAngle > 0f) {
                            drawArc(
                                color = gradeColors[grade] ?: Color.Gray,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true
                            )
                            startAngle += sweepAngle
                        }
                    }
                    
                    // Overlay smaller white cutout circle to transform the Pie Chart into a Donut Chart
                    drawCircle(
                        color = holeColor,
                        radius = size.width / 4.2f
                    )
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = totalCount.toString(),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Total",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            maxItemsInEachRow = 3
        ) {
            data.forEach { (grade, value) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(gradeColors[grade] ?: Color.Gray)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$grade: $value (${String.format("%.1f", (value / totalSum) * 100)}%)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun ColorfulAreaChart(
    data: List<Pair<String, Int>>,
    gradeColors: Map<String, Color>
) {
    val maxVal = data.maxOfOrNull { it.second } ?: 1
    val maxCount = if (maxVal == 0) 1 else maxVal
    val lineColor = MaterialTheme.colorScheme.primary
    val areaColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(240.dp)
            .padding(16.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val pointCount = data.size
            val stepX = width / (pointCount - 1)

            // Grid References
            for (i in 0..4) {
                val y = i * (height / 4)
                drawLine(
                    color = Color.Gray.copy(alpha = 0.15f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val points = data.mapIndexed { index, (_, value) ->
                val x = index * stepX
                val y = height - (value.toFloat() / maxCount) * height
                Offset(x, y)
            }

            // 1. Draw solid gradient/tint filled path first
            val areaPath = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) {
                        moveTo(point.x, height)
                        lineTo(point.x, point.y)
                    } else {
                        lineTo(point.x, point.y)
                    }
                }
                lineTo(points.last().x, height)
                close()
            }
            drawPath(
                path = areaPath,
                color = areaColor
            )

            // 2. Draw continuous line path on top
            val path = Path().apply {
                points.forEachIndexed { index, point ->
                    if (index == 0) moveTo(point.x, point.y)
                    else lineTo(point.x, point.y)
                }
            }
            drawPath(
                path = path,
                color = lineColor,
                style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
            )

            // 3. Draw nodes
            points.forEachIndexed { index, point ->
                val grade = data[index].first
                val ptColor = gradeColors[grade] ?: Color.Gray

                drawCircle(
                    color = ptColor,
                    radius = 7.dp.toPx(),
                    center = point
                )
                drawCircle(
                    color = Color.White,
                    radius = 3.5.dp.toPx(),
                    center = point
                )
            }
        }
        
        // Bottom markers
        Row(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            data.forEach { (grade, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$grade\n($value)",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// ==========================================
// HIGH-PERFORMANCE OFFLINE CHART SAVING ENGINE
// ==========================================

fun saveChartAsPng(
    context: android.content.Context,
    schoolConfig: SchoolConfig,
    className: String,
    subjectName: String,
    chartType: String,
    data: List<Pair<String, Int>>
) {
    try {
        val width = 1200
        val height = 1000
        val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)

        // Reset with pristine white background canvas
        canvas.drawColor(android.graphics.Color.WHITE)

        // Set up high quality typography paint styles
        val titlePaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#1A237E") // Imperial Dark Indigo
            textSize = 38f
            isAntiAlias = true
            isFakeBoldText = true
        }

        val subtitlePaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#3F51B5") // Royal Indigo Accent
            textSize = 28f
            isAntiAlias = true
            isFakeBoldText = true
        }

        val metaPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#37474F") // Slate Charcoal
            textSize = 22f
            isAntiAlias = true
        }

        val labelPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 22f
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }

        val valuePaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#455A64")
            textSize = 20f
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
        }

        val gridPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#ECEFF1")
            strokeWidth = 2f
        }

        // Draw top aesthetic accent border banner
        val headerPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#3F51B5")
        }
        canvas.drawRect(0f, 0f, width.toFloat(), 15f, headerPaint)

        // Title and Subtitle rendering
        canvas.drawText("MONEY MASTER - ACADEMIC SUITE", 50f, 70f, titlePaint)
        canvas.drawText("Subject Performance Analysis ($chartType)", 50f, 110f, subtitlePaint)

        // Main upper line divider
        canvas.drawLine(50f, 140f, (width - 50).toFloat(), 140f, gridPaint)

        // Render detailed Academic Metadata block at the top
        val metaYStart = 180f
        canvas.drawText("🏫 School: ${schoolConfig.schoolName.ifBlank { "N/A" }}", 50f, metaYStart, metaPaint)
        canvas.drawText("📅 Year: ${schoolConfig.academicYear.ifBlank { "N/A" }}", 50f, metaYStart + 40f, metaPaint)
        canvas.drawText("📝 Exam Type: ${schoolConfig.examType.ifBlank { "N/A" }}", 50f, metaYStart + 80f, metaPaint)

        canvas.drawText("🏫 Class Name: $className", 600f, metaYStart, metaPaint)
        canvas.drawText("📚 Subject Name: $subjectName", 600f, metaYStart + 40f, metaPaint)
        canvas.drawText("📊 Registered Students: ${data.sumOf { it.second }}", 600f, metaYStart + 80f, metaPaint)

        // Divider separation
        canvas.drawLine(50f, 300f, (width - 50).toFloat(), 300f, gridPaint)

        // Calculate and plot the charts canvas
        val chartLeft = 100f
        val chartRight = (width - 100).toFloat()
        val chartTop = 350f
        val chartBottom = 750f
        val chartWidth = chartRight - chartLeft
        val chartHeight = chartBottom - chartTop

        val gradeColors = mapOf(
            "A" to android.graphics.Color.parseColor("#4CAF50"),
            "B" to android.graphics.Color.parseColor("#2196F3"),
            "C" to android.graphics.Color.parseColor("#FF9800"),
            "S" to android.graphics.Color.parseColor("#9C27B0"),
            "F" to android.graphics.Color.parseColor("#F44336")
        )

        val totalCount = data.sumOf { it.second }
        val maxVal = data.maxOfOrNull { it.second } ?: 1
        val maxCount = if (maxVal == 0) 1 else maxVal

        when (chartType) {
            "Pie Chart", "Donut Chart" -> {
                val rectF = android.graphics.RectF(
                    (width / 2 - 200).toFloat(),
                    (chartTop + 50f),
                    (width / 2 + 200).toFloat(),
                    (chartTop + 450f)
                )
                if (totalCount == 0) {
                    canvas.drawText("No Student Data Available", (width / 2).toFloat(), (chartTop + 250f), labelPaint)
                } else {
                    var startAngle = -90f
                    data.forEach { (grade, value) ->
                        val sweepAngle = (value.toFloat() / totalCount) * 360f
                        if (sweepAngle > 0f) {
                            val arcPaint = android.graphics.Paint().apply {
                                color = gradeColors[grade] ?: android.graphics.Color.GRAY
                                style = android.graphics.Paint.Style.FILL
                                isAntiAlias = true
                            }
                            canvas.drawArc(rectF, startAngle, sweepAngle, true, arcPaint)
                            startAngle += sweepAngle
                        }
                    }

                    if (chartType == "Donut Chart") {
                        val holePaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.WHITE
                            style = android.graphics.Paint.Style.FILL
                            isAntiAlias = true
                        }
                        canvas.drawCircle((width / 2).toFloat(), (chartTop + 250f), 100f, holePaint)
                        
                        val innerTextPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.BLACK
                            textSize = 32f
                            isFakeBoldText = true
                            isAntiAlias = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        canvas.drawText(totalCount.toString(), (width / 2).toFloat(), (chartTop + 250f), innerTextPaint)
                        val innerLabelPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.GRAY
                            textSize = 18f
                            isAntiAlias = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        canvas.drawText("Total", (width / 2).toFloat(), (chartTop + 280f), innerLabelPaint)
                    }
                }
            }
            "Line Chart", "Area Chart" -> {
                // Plot grid line levels
                for (i in 0..4) {
                    val y = chartBottom - i * (chartHeight / 4)
                    canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
                    val labelVal = (i * (maxCount.toFloat() / 4f)).toInt()
                    canvas.drawText(labelVal.toString(), chartLeft - 30f, y + 8f, valuePaint)
                }

                val stepX = chartWidth / (data.size - 1)
                val points = data.mapIndexed { index, (_, value) ->
                    val x = chartLeft + index * stepX
                    val y = chartBottom - (value.toFloat() / maxCount) * chartHeight
                    android.graphics.PointF(x, y)
                }

                if (chartType == "Area Chart") {
                    val areaPath = android.graphics.Path().apply {
                        moveTo(points.first().x, chartBottom)
                        points.forEach { lineTo(it.x, it.y) }
                        lineTo(points.last().x, chartBottom)
                        close()
                    }
                    val areaPaint = android.graphics.Paint().apply {
                        color = android.graphics.Color.parseColor("#B3E5FC")
                        style = android.graphics.Paint.Style.FILL
                        alpha = 150
                        isAntiAlias = true
                    }
                    canvas.drawPath(areaPath, areaPaint)
                }

                val linePaint = android.graphics.Paint().apply {
                    color = android.graphics.Color.parseColor("#1976D2")
                    strokeWidth = 6f
                    style = android.graphics.Paint.Style.STROKE
                    strokeJoin = android.graphics.Paint.Join.ROUND
                    isAntiAlias = true
                }
                val path = android.graphics.Path().apply {
                    points.forEachIndexed { index, point ->
                        if (index == 0) moveTo(point.x, point.y)
                        else lineTo(point.x, point.y)
                    }
                }
                canvas.drawPath(path, linePaint)

                points.forEachIndexed { index, point ->
                    val (grade, value) = data[index]
                    val dotColor = gradeColors[grade] ?: android.graphics.Color.GRAY

                    val ptPaint = android.graphics.Paint().apply {
                        color = dotColor
                        style = android.graphics.Paint.Style.FILL
                        isAntiAlias = true
                    }
                    canvas.drawCircle(point.x, point.y, 12f, ptPaint)

                    val whitePaint = android.graphics.Paint().apply {
                        color = android.graphics.Color.WHITE
                        style = android.graphics.Paint.Style.FILL
                        isAntiAlias = true
                    }
                    canvas.drawCircle(point.x, point.y, 6f, whitePaint)

                    canvas.drawText("$grade ($value)", point.x, point.y - 25f, valuePaint)
                }
            }
            else -> {
                // Bar Chart
                for (i in 0..4) {
                    val y = chartBottom - i * (chartHeight / 4)
                    canvas.drawLine(chartLeft, y, chartRight, y, gridPaint)
                    val labelVal = (i * (maxCount.toFloat() / 4f)).toInt()
                    canvas.drawText(labelVal.toString(), chartLeft - 30f, y + 8f, valuePaint)
                }

                val barCount = data.size
                val spaceBetween = 40f
                val barWidth = (chartWidth - (spaceBetween * (barCount + 1))) / barCount

                data.forEachIndexed { index, (grade, value) ->
                    val left = chartLeft + spaceBetween + index * (barWidth + spaceBetween)
                    val right = left + barWidth
                    val top = chartBottom - (value.toFloat() / maxCount) * chartHeight

                    val barPaint = android.graphics.Paint().apply {
                        color = gradeColors[grade] ?: android.graphics.Color.GRAY
                        style = android.graphics.Paint.Style.FILL
                        isAntiAlias = true
                    }
                    
                    canvas.drawRect(left, top, right, chartBottom, barPaint)

                    canvas.drawText(grade, left + barWidth / 2f, chartBottom + 35f, labelPaint)

                    if (value > 0) {
                        canvas.drawText(value.toString(), left + barWidth / 2f, top - 15f, valuePaint)
                    }
                }
            }
        }

        // Lower divider separation
        canvas.drawLine(50f, 820f, (width - 50).toFloat(), 820f, gridPaint)

        // Plot descriptive chart legends at bottom
        val legendY = 860f
        val legendSpace = width / 5f
        data.forEachIndexed { index, (grade, value) ->
            val x = 100f + index * legendSpace
            val badgePaint = android.graphics.Paint().apply {
                color = gradeColors[grade] ?: android.graphics.Color.GRAY
                style = android.graphics.Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawCircle(x, legendY, 12f, badgePaint)
            
            val legendTextPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.BLACK
                textSize = 20f
                isAntiAlias = true
            }
            canvas.drawText("$grade Grade: $value", x + 25f, legendY + 7f, legendTextPaint)
        }

        // Standard watermarking signature at bottom right
        val waterPaint = android.graphics.Paint().apply {
            color = android.graphics.Color.GRAY
            textSize = 16f
            textAlign = android.graphics.Paint.Align.RIGHT
        }
        canvas.drawText("Generated via Money Master - Academic Suite", (width - 50).toFloat(), 950f, waterPaint)

        // Write the created Bitmap cleanly into device storage
        val fileName = "MoneyMaster_Chart_${subjectName}_${className}_${System.currentTimeMillis()}.png"
        
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val imageUri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (imageUri != null) {
                resolver.openOutputStream(imageUri).use { out ->
                    bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out!!)
                }
                Toast.makeText(context, "✅ Chart saved to Downloads folder!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "❌ Failed to save chart image", Toast.LENGTH_SHORT).show()
            }
        } else {
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            val file = java.io.File(downloadsDir, fileName)
            java.io.FileOutputStream(file).use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
            }
            Toast.makeText(context, "✅ Chart saved to Downloads: ${file.absolutePath}", Toast.LENGTH_LONG).show()
        }
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "❌ Error saving chart image: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

private fun Uri.toByteArray(context: Context): ByteArray? {
    return try {
        context.contentResolver.openInputStream(this)?.use { inputStream ->
            val originalBitmap = android.graphics.BitmapFactory.decodeStream(inputStream) ?: return null
            
            val maxSize = 400
            val inWidth = originalBitmap.width
            val inHeight = originalBitmap.height
            val outWidth: Int
            val outHeight: Int
            
            if (inWidth > inHeight) {
                outWidth = maxSize
                outHeight = (inHeight * maxSize) / inWidth
            } else {
                outHeight = maxSize
                outWidth = (inWidth * maxSize) / inHeight
            }
            
            val resizedBitmap = android.graphics.Bitmap.createScaledBitmap(originalBitmap, outWidth, outHeight, false)
            val outputStream = java.io.ByteArrayOutputStream()
            resizedBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, outputStream)
            val byteArray = outputStream.toByteArray()
            
            originalBitmap.recycle()
            if (resizedBitmap != originalBitmap) {
                resizedBitmap.recycle()
            }
            
            byteArray
        }
    } catch (e: Exception) {
        null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentProfilesTab(
    viewModel: MainViewModel,
    allStudents: List<com.example.data.Student>,
    allClasses: List<ClassConfig>,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var selectedClassName by remember { mutableStateOf("") }
    if (selectedClassName.isEmpty() && allClasses.isNotEmpty()) {
        selectedClassName = allClasses.first().className
    }

    val classStudents = allStudents.filter { it.className == selectedClassName }
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredStudents = classStudents.filter {
        it.studentId.contains(searchQuery, ignoreCase = true) ||
        it.studentName.contains(searchQuery, ignoreCase = true)
    }

    var selectedStudent by remember { mutableStateOf<com.example.data.Student?>(null) }

    LaunchedEffect(selectedClassName, searchQuery, classStudents) {
        if (selectedStudent == null || selectedStudent!!.className != selectedClassName) {
            selectedStudent = filteredStudents.firstOrNull()
        } else {
            val fresh = classStudents.find { it.studentId == selectedStudent?.studentId }
            selectedStudent = fresh ?: filteredStudents.firstOrNull()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "👤 Student Personal Profile",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "ශිෂ්‍ය පුද්ගලික විස්තර කළමනාකරණය",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Class selector card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Select Class (පන්තිය තෝරන්න):",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Medium
                    )

                    if (allClasses.isEmpty()) {
                        Text(
                            text = "No Classes Available",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        var expandedClassDropdown by remember { mutableStateOf(false) }
                        Box {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { expandedClassDropdown = true }
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .fillMaxWidth()
                            ) {
                                Text(
                                    text = selectedClassName,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }
                            DropdownMenu(
                                expanded = expandedClassDropdown,
                                onDismissRequest = { expandedClassDropdown = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                allClasses.forEach { c ->
                                    DropdownMenuItem(
                                        text = { Text(c.className, fontWeight = FontWeight.Bold) },
                                        onClick = {
                                            selectedClassName = c.className
                                            expandedClassDropdown = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (allClasses.isNotEmpty()) {
            if (classStudents.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "⚠️ මෙම පන්තියට තවම සිසුන් ඇතුළත් කර නැත. Class Workspaces වෙතින් සිසුන් ඇතුළත් කරන්න.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "No students have been added to this class yet. Please add students from the Class Workspaces tab.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                // Search Bar and Student Selector
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Search Box
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                label = { Text("🔍 Search student by ID or Name (සොයන්න)") },
                                placeholder = { Text("e.g. ST001 or Kamal") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("student_profile_search_input"),
                                singleLine = true
                            )

                            // Selected Student Selector Dropdown
                            Text(
                                text = "Select Student (සිසුවා තෝරන්න):",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Medium
                            )

                            if (filteredStudents.isEmpty()) {
                                Text(
                                    text = "No matching students found",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            } else {
                                var expandedStudentDropdown by remember { mutableStateOf(false) }
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { expandedStudentDropdown = true }
                                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                                            .padding(horizontal = 16.dp, vertical = 12.dp)
                                            .fillMaxWidth()
                                    ) {
                                        Text(
                                            text = selectedStudent?.let { "[${it.studentId}] ${it.studentName}" } ?: "Select a student",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodyLarge,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                    DropdownMenu(
                                        expanded = expandedStudentDropdown,
                                        onDismissRequest = { expandedStudentDropdown = false },
                                        modifier = Modifier.fillMaxWidth(0.9f)
                                    ) {
                                        filteredStudents.forEach { s ->
                                            DropdownMenuItem(
                                                text = { Text("[${s.studentId}] ${s.studentName}", fontWeight = FontWeight.Bold) },
                                                onClick = {
                                                    selectedStudent = s
                                                    expandedStudentDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                selectedStudent?.let { student ->
                    val currentStudentId = student.studentId
                    item {
                        var dobInput by remember(currentStudentId) { mutableStateOf(student.dob) }
                        var genderInput by remember(currentStudentId) { mutableStateOf(student.gender) }
                        var addressInput by remember(currentStudentId) { mutableStateOf(student.address) }
                        var guardianInput by remember(currentStudentId) { mutableStateOf(student.guardian) }
                        var phoneInput by remember(currentStudentId) { mutableStateOf(student.phone) }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    // Image Thumbnail
                                    val studentBitmap = remember(student.photoBytes) {
                                        student.photoBytes?.let {
                                            android.graphics.BitmapFactory.decodeByteArray(it, 0, it.size)
                                        }?.asImageBitmap()
                                    }

                                    if (studentBitmap != null) {
                                        Image(
                                            bitmap = studentBitmap,
                                            contentDescription = "Student Photo",
                                            modifier = Modifier
                                                .size(80.dp)
                                                .clip(RoundedCornerShape(40.dp))
                                                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(40.dp)),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(80.dp)
                                                .clip(RoundedCornerShape(40.dp))
                                                .background(MaterialTheme.colorScheme.primaryContainer)
                                                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(40.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.size(36.dp)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = student.studentName,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Student ID: ${student.studentId}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "📝 Edit Personal Details (පුද්ගලික විස්තර ඇතුළත් කිරීම)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                // Form fields
                                OutlinedTextField(
                                    value = dobInput,
                                    onValueChange = { dobInput = it },
                                    label = { Text("📅 Date of Birth (YYYY-MM-DD)") },
                                    placeholder = { Text("e.g. 2010-05-12") },
                                    leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_dob_input"),
                                    singleLine = true
                                )

                                // Gender Dropdown
                                var genderDropdownExpanded by remember { mutableStateOf(false) }
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = genderInput,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("🚹🚺 Gender (ස්ත්‍රී / පුරුෂ භාවය)") },
                                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                        trailingIcon = {
                                            IconButton(onClick = { genderDropdownExpanded = true }) {
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { genderDropdownExpanded = true }
                                            .testTag("student_profile_gender_input")
                                    )
                                    DropdownMenu(
                                        expanded = genderDropdownExpanded,
                                        onDismissRequest = { genderDropdownExpanded = false },
                                        modifier = Modifier.fillMaxWidth(0.85f)
                                    ) {
                                        listOf("Male", "Female", "Other").forEach { gender ->
                                            DropdownMenuItem(
                                                text = { Text(gender) },
                                                onClick = {
                                                    genderInput = gender
                                                    genderDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = guardianInput,
                                    onValueChange = { guardianInput = it },
                                    label = { Text("👨‍👩‍👦 Guardian Name (භාරකරුගේ නම)") },
                                    leadingIcon = { Icon(Icons.Default.SupervisorAccount, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_guardian_input"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = phoneInput,
                                    onValueChange = { phoneInput = it },
                                    label = { Text("📞 Phone Number (දුරකථන අංකය)") },
                                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_phone_input"),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = addressInput,
                                    onValueChange = { addressInput = it },
                                    label = { Text("🏠 Home Address (ලිපිනය)") },
                                    leadingIcon = { Icon(Icons.Default.HomeWork, contentDescription = null) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("student_profile_address_input"),
                                    maxLines = 3
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = {
                                        viewModel.updateStudentProfile(
                                            studentId = student.studentId,
                                            dob = dobInput,
                                            gender = genderInput,
                                            address = addressInput,
                                            guardian = guardianInput,
                                            phone = phoneInput
                                        )
                                        Toast.makeText(context, "Profile saved successfully for ${student.studentName}!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("save_profile_button")
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Save Student Profile (පුද්ගලික විස්තර සුරකින්න)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoginLobbyScreen(
    viewModel: MainViewModel,
    selectedLanguage: String,
    onLoginSuccess: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                        MaterialTheme.colorScheme.surface
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 450.dp)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // School Master Icon and Title
                Icon(
                    imageVector = Icons.Default.School,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "🏫 පාසල් ප්‍රගති සහ ශ්‍රේණිගත කිරීමේ ද්වාරය"
                        "Tamil" -> "🏫 பள்ளி அறிக்கை மற்றும் தரவரிசை போர்டல்"
                        else -> "🏫 School Report & Ranking Portal"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "ගුරුවරුන්ගේ වැඩකටයුතු පහසු කරන උසස් කළමනාකරණ පද්ධතිය"
                        "Tamil" -> "ஆசிரியர்களின் வேலையை எளிதாக்கும் மேம்பட்ட மேலாண்மை அமைப்பு"
                        else -> "Advanced Management System that simplifies teachers' tasks"
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Form Fields
                val emailFontSize = when {
                    email.length > 30 -> 11.sp
                    email.length > 20 -> 13.sp
                    else -> 16.sp
                }
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("login_email_input"),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = emailFontSize),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; errorMessage = null },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingIcon = {
                        val image = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(imageVector = image, contentDescription = null)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("login_password_input"),
                    singleLine = true,
                    visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )

                // Messages
                errorMessage?.let {
                    Text(
                        text = "❌ $it",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                successMessage?.let {
                    Text(
                        text = "🎉 $it",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Submit Button
                Button(
                    onClick = {
                        if (email.isBlank() || password.isBlank()) {
                            errorMessage = "Fields cannot be empty."
                            return@Button
                        }
                        coroutineScope.launch {
                            val (success, errorMsg) = viewModel.login(email, password)
                            if (success) {
                                onLoginSuccess()
                            } else {
                                errorMessage = errorMsg ?: "Invalid Email or Password. Please try again."
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("auth_submit_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "පුරනය වන්න (Sign In)"
                            "Tamil" -> "உள்நுழைக"
                            else -> "Sign In"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }
}
