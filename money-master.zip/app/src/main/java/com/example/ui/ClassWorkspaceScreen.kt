package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.ClassConfig
import com.example.data.SchoolConfig
import com.example.data.Subject

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ClassWorkspacesTab(
    selectedClass: String,
    classes: List<ClassConfig>,
    subjects: List<Subject>,
    students: List<RankedStudent>,
    schoolConfig: SchoolConfig,
    viewModel: MainViewModel,
    selectedLanguage: String = "English"
) {
    val context = LocalContext.current
    var activeManagementMode by remember { mutableStateOf<String?>(null) } // null, "add", "update", "delete"
    var inlineClassName by remember { mutableStateOf("") }
    var inlineTeacherName by remember { mutableStateOf("") }

    var workspaceTabIndex by remember { mutableIntStateOf(0) }
    val workspaceTabs = listOf(
        Translation.dict[selectedLanguage]?.tabInput ?: "📝 Marks",
        Translation.dict[selectedLanguage]?.tabGrades ?: "📊 Grades",
        Translation.dict[selectedLanguage]?.tabRanks ?: "🏆 Rankings",
        Translation.dict[selectedLanguage]?.tabCharts ?: "📊 Charts"
    )

    val activeClassConfig = classes.firstOrNull { it.className == selectedClass }
    var teacherNameInput by remember(activeClassConfig) { mutableStateOf(activeClassConfig?.classTeacher ?: "") }

    var showAddSubjectSection by remember { mutableStateOf(false) }
    var newSubjectName by remember { mutableStateOf("") }
    var newSubjectPassMark by remember { mutableStateOf(35) }

    val unlockedSet by viewModel.unlockedClasses.collectAsState()
    val principalVerifiedState by viewModel.principalVerified.collectAsState()
    val isWorkspaceUnlocked = principalVerifiedState || unlockedSet.contains(selectedClass)

    var showUnlockDialog by remember { mutableStateOf(false) }

    // Auto trigger PIN dialog on class selection or if locked
    LaunchedEffect(selectedClass) {
        if (!isWorkspaceUnlocked) {
            showUnlockDialog = true
        }
    }

    // Trigger secure PIN Dialog on class selection/lock
    if (showUnlockDialog && !isWorkspaceUnlocked) {
        Dialog(onDismissRequest = { showUnlockDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .widthIn(max = 480.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                val isCheckingMasterPin by viewModel.isCheckingMasterPin.collectAsState()
                val principalPin by viewModel.principalPinState.collectAsState()
                val hasPrincipalPin = !principalPin.isNullOrBlank()

                if (isCheckingMasterPin) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(300.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else if (!hasPrincipalPin) {
                    PrincipalMasterPinSetupScreen(
                        viewModel = viewModel,
                        selectedLanguage = selectedLanguage,
                        onSetupComplete = {
                            viewModel.fetchPinsFromFirebase()
                        }
                    )
                } else {
                    ClassPINUnlockContent(
                        selectedClass = selectedClass,
                        viewModel = viewModel,
                        selectedLanguage = selectedLanguage,
                        onDismiss = { showUnlockDialog = false }
                    )
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Class Selection Dropdown - ALWAYS visible
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = when (selectedLanguage) {
                                    "Sinhala" -> "🎯 පන්තිය තෝරන්න (Select Class Workspace):"
                                    "Tamil" -> "🎯 வகுப்பைத் தேர்ந்தெடுக்கவும்:"
                                    else -> "🎯 Select Class Workspace:"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            if (classes.isEmpty()) {
                                Text(
                                    text = "No Classes Available",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            } else {
                                var expandedClassDropdown by remember { mutableStateOf(false) }
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { expandedClassDropdown = true }
                                            .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .padding(horizontal = 16.dp, vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = selectedClass,
                                            fontWeight = FontWeight.ExtraBold,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                    DropdownMenu(
                                        expanded = expandedClassDropdown,
                                        onDismissRequest = { expandedClassDropdown = false }
                                    ) {
                                        classes.forEach { c ->
                                            DropdownMenuItem(
                                                text = { Text(c.className, fontWeight = FontWeight.Bold) },
                                                onClick = {
                                                    viewModel.selectClass(c.className)
                                                    expandedClassDropdown = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Lock Button is only shown if unlocked and classes are not empty
                        if (classes.isNotEmpty() && isWorkspaceUnlocked) {
                            Button(
                                onClick = {
                                    viewModel.lockClass(selectedClass)
                                    showUnlockDialog = true
                                    Toast.makeText(context, "Workspace locked!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer,
                                    contentColor = MaterialTheme.colorScheme.onErrorContainer
                                ),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = "Lock", modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "ලොක් කරන්න"
                                        "Tamil" -> "பூட்டு"
                                        else -> "Lock"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }

                    // Inline Class Management: Add, Update, Delete Buttons
                    // Completely HIDDEN if workspace is locked!
                    if (isWorkspaceUnlocked) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val isAdd = activeManagementMode == "add"
                            val isUpdate = activeManagementMode == "update"
                            val isDelete = activeManagementMode == "delete"

                            // Add Button
                            Button(
                                onClick = { activeManagementMode = if (isAdd) null else "add" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isAdd) Color(0xFF10B981) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                    contentColor = if (isAdd) Color.White else MaterialTheme.colorScheme.onPrimaryContainer
                                ),
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "එක් කරන්න"
                                        "Tamil" -> "சேர்க்க"
                                        else -> "Add"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            // Update Button
                            Button(
                                onClick = { activeManagementMode = if (isUpdate) null else "update" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isUpdate) Color(0xFFF59E0B) else MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                                    contentColor = if (isUpdate) Color.White else MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "වෙනස් කරන්න"
                                        "Tamil" -> "புதுப்பிக்க"
                                        else -> "Update"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            // Delete Button
                            Button(
                                onClick = { activeManagementMode = if (isDelete) null else "delete" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isDelete) Color(0xFFEF4444) else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                                    contentColor = if (isDelete) Color.White else MaterialTheme.colorScheme.onErrorContainer
                                ),
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when (selectedLanguage) {
                                        "Sinhala" -> "මකන්න"
                                        "Tamil" -> "நீக்குக"
                                        else -> "Delete"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }

                        // Interactive Inline Editor Cards below the action row
                        AnimatedVisibility(
                            visible = activeManagementMode != null,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(
                                    containerColor = when (activeManagementMode) {
                                        "add" -> Color(0xFF10B981).copy(alpha = 0.08f)
                                        "update" -> Color(0xFFF59E0B).copy(alpha = 0.08f)
                                        else -> Color(0xFFEF4444).copy(alpha = 0.08f)
                                    }
                                ),
                                border = BorderStroke(
                                    width = 1.dp,
                                    color = when (activeManagementMode) {
                                        "add" -> Color(0xFF10B981).copy(alpha = 0.3f)
                                        "update" -> Color(0xFFF59E0B).copy(alpha = 0.3f)
                                        else -> Color(0xFFEF4444).copy(alpha = 0.3f)
                                    }
                                ),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    when (activeManagementMode) {
                                        "add" -> {
                                            Text(
                                                text = when (selectedLanguage) {
                                                    "Sinhala" -> "➕ නව පන්තියක් එක් කිරීම (Add New Class)"
                                                    "Tamil" -> "➕ புதிய வகுப்பு சேர்க்க"
                                                    else -> "➕ Add New Class"
                                                },
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF4CAF50)
                                            )
                                            OutlinedTextField(
                                                value = inlineClassName,
                                                onValueChange = { inlineClassName = it },
                                                label = { Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "පන්තියේ නම (උදා: 10-A)"
                                                        "Tamil" -> "வகுப்பு பெயர் (உதாரணம்: 10-A)"
                                                        else -> "Class Name (e.g., 10-A)"
                                                    }
                                                ) },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            OutlinedTextField(
                                                value = inlineTeacherName,
                                                onValueChange = { inlineTeacherName = it },
                                                label = { Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "පන්තිභාර ගුරුතුමා/ගුරුතුමිය"
                                                        "Tamil" -> "வகுப்பு ஆசிரியர் பெயர்"
                                                        else -> "Class Teacher Name"
                                                    }
                                                ) },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                TextButton(onClick = { activeManagementMode = null }) {
                                                    Text(
                                                        when (selectedLanguage) {
                                                            "Sinhala" -> "අවලංගු කරන්න"
                                                            "Tamil" -> "ரத்துசெய்"
                                                            else -> "Cancel"
                                                        }
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Button(
                                                    onClick = {
                                                        if (inlineClassName.isNotBlank()) {
                                                            viewModel.addClass(inlineClassName, inlineTeacherName)
                                                            inlineClassName = ""
                                                            inlineTeacherName = ""
                                                            activeManagementMode = null
                                                            Toast.makeText(context, "Class added successfully!", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                                                ) {
                                                    Text(
                                                        when (selectedLanguage) {
                                                            "Sinhala" -> "එකතු කරන්න"
                                                            "Tamil" -> "சேர்க்க"
                                                            else -> "Add Class"
                                                        },
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }
                                        "update" -> {
                                            Text(
                                                text = when (selectedLanguage) {
                                                    "Sinhala" -> "✏️ පන්තියේ තොරතුරු වෙනස් කිරීම (Update Class Details)"
                                                    "Tamil" -> "✏️ வகுப்பு விவரங்களை மாற்றவும்"
                                                    else -> "✏️ Update Class Details"
                                                },
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFFF9800)
                                            )

                                            var renameInput by remember(selectedClass) { mutableStateOf(selectedClass) }
                                            var teacherInput by remember(teacherNameInput) { mutableStateOf(teacherNameInput) }

                                            OutlinedTextField(
                                                value = renameInput,
                                                onValueChange = { renameInput = it },
                                                label = { Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "පන්තියේ නම වෙනස් කරන්න"
                                                        "Tamil" -> "வகுப்பு பெயரை மாற்றவும்"
                                                        else -> "Rename Class Name"
                                                    }
                                                ) },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            OutlinedTextField(
                                                value = teacherInput,
                                                onValueChange = { teacherInput = it },
                                                label = { Text(
                                                    when (selectedLanguage) {
                                                        "Sinhala" -> "ගුරුතුමා/ගුරුතුමිය වෙනස් කරන්න"
                                                        "Tamil" -> "வகுப்பு ஆசிரியரை மாற்றவும்"
                                                        else -> "Change Class Teacher"
                                                    }
                                                ) },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                TextButton(onClick = { activeManagementMode = null }) {
                                                    Text(
                                                        when (selectedLanguage) {
                                                            "Sinhala" -> "අවලංගු කරන්න"
                                                            "Tamil" -> "ரத்துசெய்"
                                                            else -> "Cancel"
                                                        }
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Button(
                                                    onClick = {
                                                        if (renameInput.isNotBlank()) {
                                                            if (renameInput != selectedClass) {
                                                                viewModel.renameClass(selectedClass, renameInput)
                                                            }
                                                            viewModel.updateClassTeacher(renameInput, teacherInput)
                                                            activeManagementMode = null
                                                            Toast.makeText(context, "Class updated successfully!", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF9800))
                                                ) {
                                                    Text(
                                                        when (selectedLanguage) {
                                                            "Sinhala" -> "වෙනස් කරන්න"
                                                            "Tamil" -> "புதுப்பிக்க"
                                                            else -> "Update"
                                                        },
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }
                                        "delete" -> {
                                            Text(
                                                text = when (selectedLanguage) {
                                                    "Sinhala" -> "🗑️ පන්තිය මකා දැමීම (Delete Class Workspace)"
                                                    "Tamil" -> "🗑️ வகுப்பு நீக்குதல்"
                                                    else -> "🗑️ Delete Class Workspace"
                                                },
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFF44336)
                                            )

                                            Text(
                                                text = when (selectedLanguage) {
                                                    "Sinhala" -> "අවධානය: ඔබට ස්ථිරවම '$selectedClass' පන්තිය සහ ඊට අදාළ සියලුම විෂයන් සහ සිසුන්ගේ දත්ත මකා දැමීමට අවශ්‍යද? මෙම ක්‍රියාව නැවත වෙනස් කළ නොහැක."
                                                    "Tamil" -> "எச்சரிக்கை: வகுப்பு '$selectedClass' மற்றும் அதனுடன் தொடர்புடைய அனைத்து பாடங்களையும் மாணவர்களின் தரவையும் நிரந்தரமாக நீக்க வேண்டுமா?"
                                                    else -> "Warning: Are you sure you want to delete class '$selectedClass'? This will permanently clear all subjects and students associated with this class. This action cannot be undone."
                                                },
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                TextButton(onClick = { activeManagementMode = null }) {
                                                    Text(
                                                        when (selectedLanguage) {
                                                            "Sinhala" -> "අවලංගු කරන්න"
                                                            "Tamil" -> "ரத்துசெய்"
                                                            else -> "Cancel"
                                                        }
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Button(
                                                    onClick = {
                                                        viewModel.deleteClass(selectedClass)
                                                        activeManagementMode = null
                                                        Toast.makeText(context, "Class deleted successfully!", Toast.LENGTH_SHORT).show()
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336))
                                                ) {
                                                    Text(
                                                        when (selectedLanguage) {
                                                            "Sinhala" -> "ඔව්, මකන්න"
                                                            "Tamil" -> "ஆம், நீக்கு"
                                                            else -> "Yes, Delete"
                                                        },
                                                        color = Color.White
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // HIDE everything else smoothly if not unlocked!
        if (isWorkspaceUnlocked && activeClassConfig != null) {
            // Subject Management Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📚 Subject Management",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(onClick = { showAddSubjectSection = !showAddSubjectSection }) {
                                Text(if (showAddSubjectSection) "Collapse" else "➕ Add Subject")
                            }
                        }

                        if (showAddSubjectSection) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = newSubjectName,
                                    onValueChange = { newSubjectName = it },
                                    label = { Text("Subject Name") },
                                    placeholder = { Text("e.g. Mathematics, Science") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                OutlinedTextField(
                                    value = newSubjectPassMark.toString(),
                                    onValueChange = { newSubjectPassMark = it.toIntOrNull() ?: 35 },
                                    label = { Text("Pass Mark") },
                                    modifier = Modifier.fillMaxWidth(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                Button(
                                    onClick = {
                                        if (newSubjectName.isNotBlank()) {
                                            viewModel.addSubject(newSubjectName, newSubjectPassMark, selectedClass)
                                            newSubjectName = ""
                                            showAddSubjectSection = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Add Subject to Class")
                                }
                            }
                        }

                        if (subjects.isEmpty()) {
                            Text(
                                text = "No subjects in this class yet. Add some subjects above to begin adding marks.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        } else {
                            Text(
                                text = "Active Class Subjects:",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                subjects.forEach { sub ->
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("${sub.name} (${sub.passMark})") }
                                    )
                                }
                            }

                            // Safe Subject Deletion with confirmation dropdown and checkbox (Subject Delete Protection)
                            Spacer(modifier = Modifier.height(8.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "🛡️ Delete Subject with Protection (විෂයන් මකා දැමීම):",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )

                            var selectedSubToDelete by remember { mutableStateOf<Subject?>(null) }
                            var isConfirmCheckboxChecked by remember { mutableStateOf(false) }
                            var expandedDeleteDropdown by remember { mutableStateOf(false) }

                            Box(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { expandedDeleteDropdown = true }
                                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = selectedSubToDelete?.name ?: "-- Select Subject to Delete --",
                                        fontWeight = FontWeight.Medium,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (selectedSubToDelete != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                }
                                DropdownMenu(
                                    expanded = expandedDeleteDropdown,
                                    onDismissRequest = { expandedDeleteDropdown = false },
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("-- Select Subject to Delete --") },
                                        onClick = {
                                            selectedSubToDelete = null
                                            isConfirmCheckboxChecked = false
                                            expandedDeleteDropdown = false
                                        }
                                    )
                                    subjects.forEach { sub ->
                                        DropdownMenuItem(
                                            text = { Text(sub.name) },
                                            onClick = {
                                                selectedSubToDelete = sub
                                                isConfirmCheckboxChecked = false
                                                expandedDeleteDropdown = false
                                            }
                                        )
                                    }
                                }
                            }

                            val activeSubToDel = selectedSubToDelete
                            if (activeSubToDel != null) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(
                                        checked = isConfirmCheckboxChecked,
                                        onCheckedChange = { isConfirmCheckboxChecked = it }
                                    )
                                    Text(
                                        text = "⚠️ මම ස්ථිරවම ${activeSubToDel.name} විෂය සහ එහි සියලුම ලකුණු මකා දැමීමට එකඟ වෙමි.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }

                                Button(
                                    onClick = {
                                        viewModel.removeSubject(activeSubToDel)
                                        Toast.makeText(context, "${activeSubToDel.name} deleted safely!", Toast.LENGTH_SHORT).show()
                                        selectedSubToDelete = null
                                        isConfirmCheckboxChecked = false
                                    },
                                    enabled = isConfirmCheckboxChecked,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Confirm Delete Subject")
                                }
                            }
                        }
                    }
                }
            }

            // Sub-Tabs within the workspace
            item {
                TabRow(
                    selectedTabIndex = workspaceTabIndex,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    workspaceTabs.forEachIndexed { index, label ->
                        Tab(
                            selected = workspaceTabIndex == index,
                            onClick = { workspaceTabIndex = index },
                            text = { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Render selected Workspace Sub-Tab
            item {
                when (workspaceTabIndex) {
                    0 -> WorkspaceStudentMarksView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        viewModel = viewModel
                    )
                    1 -> WorkspaceStudentGradesView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students
                    )
                    2 -> WorkspaceRankingsExportView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        classConfig = activeClassConfig,
                        selectedLanguage = selectedLanguage
                    )
                    3 -> WorkspaceSubjectChartsView(
                        selectedClass = selectedClass,
                        subjects = subjects,
                        students = students,
                        schoolConfig = schoolConfig,
                        selectedLanguage = selectedLanguage
                    )
                }
            }
        }
    }
}

@Composable
fun ClassPINUnlockContent(
    selectedClass: String,
    viewModel: MainViewModel,
    selectedLanguage: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val classPins by viewModel.classPinsState.collectAsState()
    var enteredPin by remember { mutableStateOf("") }
    var enteredPinError by remember { mutableStateOf(false) }

    // States for configuring a Class PIN (if this class doesn't have one)
    var newPinInput by remember { mutableStateOf("") }
    var confirmPinInput by remember { mutableStateOf("") }

    // Administrative Dialogs
    var showPrincipalDialog by remember { mutableStateOf(false) }
    var principalPinInput by remember { mutableStateOf("") }
    var principalPinError by remember { mutableStateOf(false) }

    var showResetClassPinDialog by remember { mutableStateOf(false) }
    var resetClassPinInput by remember { mutableStateOf("") }

    var showResetPrincipalPinDialog by remember { mutableStateOf(false) }
    var resetPrincipalPinInput by remember { mutableStateOf("") }

    val hasClassPin = classPins.containsKey(selectedClass)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Close Button at top-right
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(onClick = onDismiss) {
                Icon(Icons.Default.Close, contentDescription = "Close Dialog")
            }
        }

        // Header Icon
        Box(
            modifier = Modifier
                .size(64.dp)
                .background(
                    if (hasClassPin) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (hasClassPin) Icons.Default.Lock else Icons.Default.LockOpen,
                contentDescription = "Lock Icon",
                tint = if (hasClassPin) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(32.dp)
            )
        }

        // Header Title
        Text(
            text = if (!hasClassPin) {
                when (selectedLanguage) {
                    "Sinhala" -> "පันති PIN අංකය සකසන්න"
                    "Tamil" -> "வகுப்பு PIN ஐ அமைக்கவும்"
                    else -> "Configure Class PIN"
                }
            } else {
                when (selectedLanguage) {
                    "Sinhala" -> "$selectedClass පන්තිය අගුළු දමා ඇත"
                    "Tamil" -> "$selectedClass வகுப்பு பூட்டப்பட்டுள்ளது"
                    else -> "Class $selectedClass is Locked"
                }
            },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        // Subtitle/Instruction
        Text(
            text = if (!hasClassPin) {
                when (selectedLanguage) {
                    "Sinhala" -> "$selectedClass පන්තිය සඳහා තවම PIN එකක් සකසා නැත. මෙම වැඩතීරුව ආරක්ෂා කිරීමට කරුණාකර 4-6 digit PIN එකක් ඇතුළත් කරන්න."
                    "Tamil" -> "$selectedClass வகுப்பிற்கு இன்னும் PIN அமைக்கப்படவில்லை. பணிவிடத்தைப் பாதுகாக்க 4-6 இலக்க PIN ஐ அமைக்கவும்."
                    else -> "No PIN has been configured for Class $selectedClass yet. Set a 4-to-6 digit PIN to protect this workspace."
                }
            } else {
                when (selectedLanguage) {
                    "Sinhala" -> "ඉදිරියට යාමට කරුණාකර මෙම පන්තිය සඳහා නියමිත PIN අංකය හෝ විදුහල්පති PIN අංකය ඇතුළත් කරන්න."
                    "Tamil" -> "தொடர வகுப்பின் PIN அல்லது அதிபர் முதன்மை PIN ஐ உள்ளிடவும்."
                    else -> "Please enter the Class-Level PIN or the global Principal Master PIN to unlock this workspace."
                }
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Input Section based on state
        if (!hasClassPin) {
            // Class PIN Setup Inputs
            OutlinedTextField(
                value = newPinInput,
                onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) newPinInput = it },
                label = {
                    Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "නව පන්ති PIN අංකය"
                            "Tamil" -> "புதிய வகுப்பு PIN"
                            else -> "New Class PIN"
                        }
                    )
                },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            OutlinedTextField(
                value = confirmPinInput,
                onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirmPinInput = it },
                label = {
                    Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "PIN අංකය තහවුරු කරන්න"
                            "Tamil" -> "PIN ஐ உறுதிப்படுத்தவும்"
                            else -> "Confirm Class PIN"
                        }
                    )
                },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (newPinInput.length >= 4 && newPinInput == confirmPinInput) {
                        viewModel.saveClassPin(selectedClass, newPinInput, {
                            Toast.makeText(context, "PIN for Class $selectedClass Saved!", Toast.LENGTH_SHORT).show()
                            newPinInput = ""
                            confirmPinInput = ""
                        }, {
                            Toast.makeText(context, "Error: ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
                        })
                    } else {
                        Toast.makeText(context, "PINs must match and be at least 4 digits!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "පන්ති PIN එක සුරකින්න"
                        "Tamil" -> "வகுப்பு PIN ஐ சேமி"
                        else -> "Save Class PIN"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
        } else {
            // Standard PIN Input & Verification
            OutlinedTextField(
                value = enteredPin,
                onValueChange = {
                    if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                        enteredPin = it
                        enteredPinError = false
                    }
                },
                label = {
                    Text(
                        when (selectedLanguage) {
                            "Sinhala" -> "PIN අංකය"
                            "Tamil" -> "PIN குறியீடு"
                            else -> "Enter PIN"
                        }
                    )
                },
                isError = enteredPinError,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                trailingIcon = {
                    if (enteredPinError) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Error",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )

            if (enteredPinError) {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "වැරදි PIN අංකයකි. නැවත උත්සාහ කරන්න."
                        "Tamil" -> "தவறான PIN. மீண்டும் முயற்சிக்கவும்."
                        else -> "Invalid PIN. Please try again."
                    },
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.align(Alignment.Start)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    val success = viewModel.verifyClassPin(selectedClass, enteredPin)
                    if (success) {
                        Toast.makeText(context, "Class $selectedClass Unlocked!", Toast.LENGTH_SHORT).show()
                        enteredPin = ""
                        onDismiss() // Close Dialog!
                    } else {
                        enteredPinError = true
                        enteredPin = ""
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "වැඩතීරුව අගුළු හරින්න"
                        "Tamil" -> "பணிவிடத்தைத் திற"
                        else -> "Unlock Workspace"
                    },
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Principal Bypass and Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { showPrincipalDialog = true }
                ) {
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "🔑 විදුහල්පති Bypass"
                            "Tamil" -> "🔑 அதிபர் பைபாஸ்"
                            else -> "🔑 Principal Bypass"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                TextButton(
                    onClick = {
                        viewModel.sendMasterPinResetEmail { success ->
                            val schoolEmail = viewModel.currentSchoolEmail ?: ""
                            if (success) {
                                val msg = when (selectedLanguage) {
                                    "Sinhala" -> "විදුහල්පති PIN අංකය යළි පිහිටුවීමේ උපදෙස් $schoolEmail වෙත යවා ඇත."
                                    "Tamil" -> "அதிபர் PIN மீட்டமைப்பு வழிமுறைகள் $schoolEmail க்கு அனுப்பப்பட்டுள்ளன."
                                    else -> "Reset instructions have been sent to the school's official email address: $schoolEmail"
                                }
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            } else {
                                val msg = when (selectedLanguage) {
                                    "Sinhala" -> "ඊමේල් යැවීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න."
                                    "Tamil" -> "மின்னஞ்சலை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்."
                                    else -> "Failed to send reset email. Please try again."
                                }
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                ) {
                    Text(
                        text = "Forgot Master PIN? Reset via Email",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Dynamic dialog for Principal Login/Verification
    if (showPrincipalDialog) {
        AlertDialog(
            onDismissRequest = {
                showPrincipalDialog = false
                principalPinInput = ""
                principalPinError = false
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "විදුහල්පති තහවුරු කිරීම"
                        "Tamil" -> "அதிபர் சரிபார்ப்பு"
                        else -> "Verify as Principal"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = when (selectedLanguage) {
                            "Sinhala" -> "පන්තියේ PIN එක වෙනස් කිරීමට හෝ සෘජුවම ඇතුළු වීමට ප්‍රධාන විදුහල්පති PIN අංකය ඇතුළත් කරන්න."
                            "Tamil" -> "வகுப்பின் PIN ஐ மாற்ற அல்லது நேரடியாக நுழைய அதிபர் முதன்மை PIN ஐ உள்ளிடவும்."
                            else -> "Enter the global Principal Master PIN to manage or bypass class level configurations."
                        }
                    )
                    OutlinedTextField(
                        value = principalPinInput,
                        onValueChange = {
                            if (it.length <= 6 && it.all { c -> c.isDigit() }) {
                                principalPinInput = it
                                principalPinError = false
                            }
                        },
                        label = { Text("Principal Master PIN") },
                        isError = principalPinError,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    if (principalPinError) {
                        Text(
                            text = "Invalid Principal Master PIN!",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    TextButton(
                        onClick = {
                            viewModel.sendMasterPinResetEmail { success ->
                                val schoolEmail = viewModel.currentSchoolEmail ?: ""
                                if (success) {
                                    val msg = when (selectedLanguage) {
                                        "Sinhala" -> "විදුහල්පති PIN අංකය යළි පිහිටුවීමේ උපදෙස් $schoolEmail වෙත යවා ඇත."
                                        "Tamil" -> "அதிபர் PIN மீட்டமைப்பு வழிமுறைகள் $schoolEmail க்கு அனுப்பப்பட்டுள்ளன."
                                        else -> "Reset instructions have been sent to the school's official email address: $schoolEmail"
                                    }
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                } else {
                                    val msg = when (selectedLanguage) {
                                        "Sinhala" -> "ඊමේල් යැවීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න."
                                        "Tamil" -> "மின்னஞ்சலை அனுப்ப முடியவில்லை. மீண்டும் முயற்சிக்கவும்."
                                        else -> "Failed to send reset email. Please try again."
                                    }
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text(
                            text = "Forgot Master PIN? Reset via Email",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = viewModel.verifyPrincipalPin(principalPinInput)
                        if (success) {
                            Toast.makeText(context, "Principal Mode Active!", Toast.LENGTH_SHORT).show()
                            showPrincipalDialog = false
                            principalPinInput = ""
                            showResetClassPinDialog = true
                        } else {
                            principalPinError = true
                            principalPinInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Verify")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrincipalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog to let Principal reset or change the Class-Level PIN
    if (showResetClassPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showResetClassPinDialog = false
                resetClassPinInput = ""
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "$selectedClass PIN එක සකසන්න (විදුහල්පති)"
                        "Tamil" -> "$selectedClass வகுப்பு PIN ஐ அமை (அதிபர்)"
                        else -> "Set PIN for $selectedClass (Principal)"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Enter a new 4-to-6 digit PIN to protect Class $selectedClass workspace."
                    )
                    OutlinedTextField(
                        value = resetClassPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) resetClassPinInput = it },
                        label = { Text("New PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(4.dp))
                    TextButton(
                        onClick = {
                            showResetClassPinDialog = false
                            showResetPrincipalPinDialog = true
                        }
                    ) {
                        Text("🔑 Change Principal Master PIN")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetClassPinInput.length >= 4) {
                            viewModel.saveClassPin(selectedClass, resetClassPinInput, {
                                Toast.makeText(context, "PIN reset successfully!", Toast.LENGTH_SHORT).show()
                                showResetClassPinDialog = false
                                resetClassPinInput = ""
                            }, {
                                Toast.makeText(context, "Error: ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
                            })
                        } else {
                            Toast.makeText(context, "PIN must be at least 4 digits!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Reset PIN")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetClassPinDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog to let Principal reset the global Principal Master PIN
    if (showResetPrincipalPinDialog) {
        AlertDialog(
            onDismissRequest = {
                showResetPrincipalPinDialog = false
                resetPrincipalPinInput = ""
            },
            title = {
                Text(
                    text = when (selectedLanguage) {
                        "Sinhala" -> "නව විදුහල්පති PIN එකක් සැකසීම"
                        "Tamil" -> "புதிய அதிபர் முதன்மை PIN ஐ அமை"
                        else -> "Set New Principal Master PIN"
                    },
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Enter a new 4-to-6 digit global Principal Master PIN to protect the entire portal."
                    )
                    OutlinedTextField(
                        value = resetPrincipalPinInput,
                        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) resetPrincipalPinInput = it },
                        label = { Text("New Master PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (resetPrincipalPinInput.length >= 4) {
                            viewModel.savePrincipalPin(resetPrincipalPinInput, {
                                Toast.makeText(context, "Principal Master PIN changed successfully!", Toast.LENGTH_SHORT).show()
                                showResetPrincipalPinDialog = false
                                resetPrincipalPinInput = ""
                            }, {
                                Toast.makeText(context, "Error: ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
                            })
                        } else {
                            Toast.makeText(context, "PIN must be at least 4 digits!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetPrincipalPinDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}
