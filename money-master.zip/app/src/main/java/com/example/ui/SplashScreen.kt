package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    // Hold splash screen visible for 2 seconds then navigate to MainScreen
    LaunchedEffect(Unit) {
        delay(2000)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A365D)) // #1A365D Background from User's XML
            .testTag("splash_screen_root"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // school_logo ImageView: 120dp x 120dp
            Image(
                painter = painterResource(id = R.drawable.school_icon),
                contentDescription = "School Logo",
                modifier = Modifier
                    .size(120.dp)
                    .testTag("school_logo"),
                contentScale = ContentScale.Fit
            )
            
            Spacer(modifier = Modifier.height(20.dp)) // android:layout_marginTop="20dp"
            
            // TextView: "🏫 School Report Portal", size 24sp, bold, white
            Text(
                text = "🏫 School Report Portal",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("splash_title")
            )
            
            Spacer(modifier = Modifier.height(30.dp)) // android:layout_marginTop="30dp"
            
            // ProgressBar with White Indeterminate Tint
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 4.dp,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("splash_progress")
            )
        }
    }
}
