package com.example.utils

import android.content.Context
import android.telephony.SmsManager
import android.os.Build
import android.util.Log
import android.widget.Toast
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.example.data.Loan
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SmsSender {
    private const val TAG = "SmsSender"

    fun isPermissionGranted(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    suspend fun sendPaymentSms(
        context: Context,
        loan: Loan,
        paymentAmount: Double,
        summary: LoanSummary,
        isFullSettle: Boolean
    ) = withContext(Dispatchers.Main) {
        val phone = loan.borrowerPhone
        if (phone.isBlank()) {
            Log.e(TAG, "Cannot send SMS: phone number is blank")
            return@withContext
        }

        if (!isPermissionGranted(context)) {
            Toast.makeText(
                context,
                "⚠️ SMS Permission not granted. Cannot send transaction alert to ${loan.borrowerName}.",
                Toast.LENGTH_LONG
            ).show()
            return@withContext
        }

        val status = if (isFullSettle || loan.isSettled || summary.totalOutstanding <= 0.0) {
            "Settled"
        } else {
            "Partially Paid"
        }

        val message = """
            Money Master Payment Alert
            Customer: ${loan.borrowerName}
            Principal Amount: Rs. ${String.format("%.2f", loan.principalAmount)}
            Interest: ${loan.interestRate}% (${loan.interestPeriod}) [Outstanding: Rs. ${String.format("%.2f", summary.outstandingInterest)}]
            Paid Amount: Rs. ${String.format("%.2f", paymentAmount)}
            Remaining Balance: Rs. ${String.format("%.2f", summary.totalOutstanding)}
            Status: $status
        """.trimIndent()

        try {
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            
            if (smsManager != null) {
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
                Toast.makeText(
                    context,
                    "✓ SMS Alert sent to ${loan.borrowerName} successfully.",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Log.e(TAG, "SmsManager is null")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending SMS: ${e.message}", e)
            Toast.makeText(
                context,
                "❌ Failed to send SMS Alert: ${e.message}",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}
