package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.data.Customer
import com.example.data.Loan
import com.example.data.LoanRepository
import com.example.data.Payment
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

@JsonClass(generateAdapter = true)
data class BackupPayload(
    val customers: List<Customer>,
    val loans: List<Loan>,
    val payments: List<Payment>,
    val backupTimestamp: Long,
    val backupVersion: Int = 1
)

data class GoogleAccountInfo(
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String = "",
    val isConnected: Boolean = false
)

class GoogleDriveSyncService(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("money_master_google_sync", Context.MODE_PRIVATE)
    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val _accountInfo = MutableStateFlow(
        GoogleAccountInfo(
            displayName = prefs.getString("google_name", "") ?: "",
            email = prefs.getString("google_email", "") ?: "",
            photoUrl = prefs.getString("google_photo", "") ?: "",
            isConnected = prefs.getBoolean("google_connected", false)
        )
    )
    val accountInfo: StateFlow<GoogleAccountInfo> = _accountInfo.asStateFlow()

    private val _lastBackupTime = MutableStateFlow(prefs.getLong("last_backup_time", 0L))
    val lastBackupTime: StateFlow<Long> = _lastBackupTime.asStateFlow()

    private val _autoBackupEnabled = MutableStateFlow(prefs.getBoolean("auto_backup_enabled", false))
    val autoBackupEnabled: StateFlow<Boolean> = _autoBackupEnabled.asStateFlow()

    fun signIn(name: String = "Amila Lasantha", email: String = "amilalasantha940703@gmail.com") {
        _accountInfo.value = GoogleAccountInfo(
            displayName = name,
            email = email,
            photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80",
            isConnected = true
        )
        prefs.edit().apply {
            putString("google_name", name)
            putString("google_email", email)
            putString("google_photo", "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80")
            putBoolean("google_connected", true)
            apply()
        }
    }

    fun signOut() {
        _accountInfo.value = GoogleAccountInfo()
        prefs.edit().apply {
            putString("google_name", "")
            putString("google_email", "")
            putString("google_photo", "")
            putBoolean("google_connected", false)
            apply()
        }
    }

    fun setAutoBackup(enabled: Boolean) {
        _autoBackupEnabled.value = enabled
        prefs.edit().putBoolean("auto_backup_enabled", enabled).apply()
    }

    suspend fun performBackup(repository: LoanRepository): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!_accountInfo.value.isConnected) return@withContext false

            // Fetch local database content direct
            val customers = repository.getAllCustomersDirect()
            val loans = repository.getAllLoansDirect()
            val payments = repository.getAllPaymentsDirect()

            val payload = BackupPayload(
                customers = customers,
                loans = loans,
                payments = payments,
                backupTimestamp = System.currentTimeMillis()
            )

            // Convert to JSON using Moshi
            val adapter = moshi.adapter(BackupPayload::class.java)
            val jsonString = adapter.toJson(payload)

            // Persist the backup JSON in cloud sandbox simulation preferences
            prefs.edit().apply {
                putString("simulated_drive_file_content", jsonString)
                putLong("last_backup_time", payload.backupTimestamp)
                apply()
            }

            _lastBackupTime.value = payload.backupTimestamp
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }

    suspend fun performRestore(repository: LoanRepository): Boolean = withContext(Dispatchers.IO) {
        try {
            if (!_accountInfo.value.isConnected) return@withContext false

            val jsonString = prefs.getString("simulated_drive_file_content", null) ?: return@withContext false

            val adapter = moshi.adapter(BackupPayload::class.java)
            val payload = adapter.fromJson(jsonString) ?: return@withContext false

            // Restore in Database
            repository.restoreDatabase(
                customers = payload.customers,
                loans = payload.loans,
                payments = payload.payments
            )

            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext false
        }
    }
}
