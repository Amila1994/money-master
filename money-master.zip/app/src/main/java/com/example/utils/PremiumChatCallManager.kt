package com.example.utils

import android.content.Context
import android.widget.Toast
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import io.agora.rtc.IRtcEngineEventHandler
import io.agora.rtc.RtcEngine

class PremiumChatCallManager {

    private var mRtcEngine: RtcEngine? = null
    private val AGORA_APP_ID = "c4e26b154e784372842dbd1e8fa3ec95" // ඔයාගේ Agora ID එක

    // 1. 🔒 Admin Authority එක සක්රීයද කියා පරීක්ෂා කර පණිවිඩ/ෆයිල් යැවීමේ ආරක්ෂක වැට
    fun sendMessageWithAuthorityCheck(
        context: Context,
        ticketId: String,
        senderRole: String,
        messageData: Map<String, Any>,
        db: FirebaseFirestore
    ) {
        db.collection("support_tickets").document(ticketId)
            .get()
            .addOnSuccessListener { documentSnapshot ->
                if (documentSnapshot.exists()) {
                    // ඇඩ්මින් විසින් සියලුම සේවාවන් ක්රියාත්මක කිරීමට දෙන අවසරය (Admin Authority)
                    val isAuthorityOn = documentSnapshot.getBoolean("videoCallAllowed") // අපි කලින් පාවිච්චි කළ gate එකම authority එක ලෙස ක්රියා කරයි
                    
                    if (isAuthorityOn == true) {
                        // අවසරය සක්රීය නම් මැසේජ්/ඡායාරූපය Firestore එකට යවයි
                        db.collection("support_tickets").document(ticketId)
                            .collection("messages")
                            .add(messageData)
                        
                        // Unread ගණනය කිරීම් යාවත්කාලීන කිරීම (කාටද මැසේජ් එක ගියේ කියන එක මත)
                        if ("school" == senderRole) {
                            db.collection("support_tickets").document(ticketId).update(
                                "adminUnreadCount", FieldValue.increment(1),
                                "lastMessageTime", FieldValue.serverTimestamp()
                            )
                        } else {
                            db.collection("support_tickets").document(ticketId).update(
                                "schoolUnreadCount", FieldValue.increment(1),
                                "lastMessageTime", FieldValue.serverTimestamp()
                            )
                        }
                    } else {
                        // අවසරය නැත්නම් කිසිවක් කළ නොහැක
                        Toast.makeText(
                            context,
                            "🚫 ක්රියාව අත්හිටුවන ලදී! ඇඩ්මින් විසින් මෙවලම් තීරුව (Admin Authority) අක්රීය කර ඇත.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
    }

    // 2. 🎙️ 📞 AUDIO CALL එකකට පමණක් සම්බන්ධ වන කේතය (ඩේටා වැය වෙන්නේ විනාඩියට 0.5 MB වැනි ඉතාම සුළු ප්රමාණයකි)
    fun startAudioOnlyCall(context: Context, channelName: String) {
        try {
            mRtcEngine = RtcEngine.create(context, AGORA_APP_ID, object : IRtcEngineEventHandler() {
                override fun onUserJoined(uid: Int, elapsed: Int) {
                    // අනෙක් කෙනා ඕඩියෝ කෝල් එකට සම්බන්ධ වූ විට
                }

                override fun onUserOffline(uid: Int, reason: Int) {
                    stopCall()
                }
            })

            mRtcEngine?.disableVideo() // ❌ වීඩියෝ සම්පූර්ණයෙන්ම වසා දමයි
            mRtcEngine?.enableAudio() // 🟢 ඕඩියෝ පමණක් සක්රීය කරයි
            mRtcEngine?.setEnableSpeakerphone(true) // default ස්පීකර් ඔන් කිරීම
            
            // එකම Ticket ID චැනල් එකට සම්බන්ධ වීම
            mRtcEngine?.joinChannel(null, channelName, "", 0)
            Toast.makeText(context, "📞 සජීවී හඬ ඇමතුම ආරම්භ විය...", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // ❌ කෝල් එක විසන්ධි කිරීම
    fun stopCall() {
        if (mRtcEngine != null) {
            mRtcEngine?.leaveChannel()
            RtcEngine.destroy()
            mRtcEngine = null
        }
    }
}
