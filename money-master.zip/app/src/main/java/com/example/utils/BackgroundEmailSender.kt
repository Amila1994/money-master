package com.example.utils

import android.content.Context
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.activation.DataHandler
import javax.activation.FileDataSource

/**
 * Service to dynamically send automated emails with PDF attachments in the background
 * using Gmail's secure SMTP server with the user's custom credentials stored in settings.
 */
object BackgroundEmailSender {
    private const val TAG = "BackgroundEmailSender"

    /**
     * Sends an email with the generated PDF attachment in the background.
     */
    suspend fun sendEmailWithPdfAttachment(
        context: Context,
        recipientEmail: String,
        customerName: String,
        pdfFile: File,
        loanAmount: Double,
        rate: Double,
        period: String,
        startDateStr: String
    ) = withContext(Dispatchers.IO) {
        if (recipientEmail.isBlank()) {
            Log.e(TAG, "Recipient email address is blank. Cannot send PDF attachment.")
            return@withContext
        }

        // 1. Fetch saved Email configurations dynamically
        val emailPrefs = context.getSharedPreferences("money_master_email_prefs", Context.MODE_PRIVATE)
        val senderEmail = emailPrefs.getString("sender_email", "") ?: ""
        val appPassword = emailPrefs.getString("app_password", "") ?: ""

        // 2. ERROR HANDLING: Check if credentials are set
        if (senderEmail.isBlank() || appPassword.isBlank()) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Please configure Email Settings to send PDF", Toast.LENGTH_LONG).show()
            }
            Log.w(TAG, "SMTP credentials are not configured. Gracefully skipped background auto-email.")
            return@withContext
        }

        Log.d(TAG, "Preparing to send background SMTP email with PDF attachment to: $recipientEmail from: $senderEmail")

        try {
            // Compose email content
            val subject = "Money Master: Loan Summary for $customerName"
            val htmlBody = """
                <html>
                <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333333;">
                    <div style="max-width: 600px; margin: 0 auto; border: 1px solid #dddddd; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                        <div style="background-color: #FFB300; padding: 20px; text-align: center;">
                            <h2 style="color: #000000; margin: 0; font-size: 24px;">Money Master Loan Receipt</h2>
                        </div>
                        <div style="padding: 24px; background-color: #ffffff;">
                            <p style="font-size: 16px;">Dear <b>$customerName</b>,</p>
                            <p style="font-size: 15px;">Your new loan has been successfully created. Please find your detailed loan summary PDF report attached to this email.</p>
                            
                            <div style="background-color: #f9f9f9; border-left: 4px solid #FFB300; padding: 16px; margin: 20px 0; border-radius: 0 4px 4px 0;">
                                <h4 style="margin-top: 0; margin-bottom: 12px; font-size: 16px; color: #FFB300;">Loan Details:</h4>
                                <table style="width: 100%; font-size: 14px; border-collapse: collapse;">
                                    <tr>
                                        <td style="padding: 4px 0; font-weight: bold; width: 140px;">Loan Amount:</td>
                                        <td style="padding: 4px 0;">Rs. ${String.format(java.util.Locale.US, "%.2f", loanAmount)}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 4px 0; font-weight: bold;">Interest Rate:</td>
                                        <td style="padding: 4px 0;">$rate% ($period)</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 4px 0; font-weight: bold;">Start Date:</td>
                                        <td style="padding: 4px 0;">$startDateStr</td>
                                    </tr>
                                </table>
                            </div>
                            
                            <p style="font-size: 14px; color: #555555; margin-top: 24px;">Thank you for choosing <b>Money Master</b>.</p>
                            <p style="font-size: 14px; color: #777777; margin-bottom: 0;"><i>Best Regards,<br>Money Master Support Team</i></p>
                        </div>
                    </div>
                </body>
                </html>
            """.trimIndent()

            // 3. Setup standard JavaMail SMTP configurations for Gmail
            val props = Properties().apply {
                put("mail.smtp.host", "smtp.gmail.com")
                put("mail.smtp.socketFactory.port", "465")
                put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory")
                put("mail.smtp.auth", "true")
                put("mail.smtp.port", "465")
            }

            // 4. Authenticate SMTP Server Session
            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(senderEmail, appPassword)
                }
            })

            // 5. Build MimeMessage with PDF attachment
            val message = MimeMessage(session).apply {
                setFrom(InternetAddress(senderEmail, "Money Master Notifications"))
                addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
                setSubject(subject)

                val multipart = MimeMultipart()

                // Text body part
                val messageBodyPart = MimeBodyPart().apply {
                    setContent(htmlBody, "text/html; charset=utf-8")
                }
                multipart.addBodyPart(messageBodyPart)

                // PDF Attachment part
                if (pdfFile.exists() && pdfFile.length() > 0) {
                    val attachmentPart = MimeBodyPart().apply {
                        val source = FileDataSource(pdfFile)
                        dataHandler = DataHandler(source)
                        fileName = pdfFile.name
                    }
                    multipart.addBodyPart(attachmentPart)
                } else {
                    Log.w(TAG, "PDF attachment file does not exist or is empty.")
                }

                setContent(multipart)
            }

            // 6. Transmit Message through SMTP
            Transport.send(message)

            withContext(Dispatchers.Main) {
                val successMessage = "✓ Automated Email: Loan Summary PDF successfully emailed to $recipientEmail"
                Toast.makeText(context, successMessage, Toast.LENGTH_LONG).show()
                Log.i(TAG, "Email successfully sent to $recipientEmail via SMTP.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception occurred during background SMTP email sending: ${e.message}", e)
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "❌ Background Auto-Email Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
