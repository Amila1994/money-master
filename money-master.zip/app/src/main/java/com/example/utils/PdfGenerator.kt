package com.example.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import com.example.data.SchoolConfig
import com.example.ui.RankedStudent
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    fun generateReport(
        context: Context,
        config: SchoolConfig,
        className: String,
        classTeacher: String,
        subjects: List<String>,
        students: List<RankedStudent>,
        outputStream: OutputStream
    ) {
        val pdfDocument = PdfDocument()
        
        // Letter size in points: 612 x 792
        val pageWidth = 612
        val pageHeight = 792
        val margin = 36f // 0.5 inch margins
        
        // Paints
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val metaPaint = Paint().apply {
            color = Color.parseColor("#4A5568")
            textSize = 10f
            isAntiAlias = true
        }
        
        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val tableCellPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isAntiAlias = true
        }

        val tableCellBoldPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val bgHeaderPaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            style = Paint.Style.FILL
        }
        
        val bgRowEvenPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        
        val bgRowOddPaint = Paint().apply {
            color = Color.parseColor("#F7FAFC")
            style = Paint.Style.FILL
        }
        
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E0")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }

        // Divide students into pages
        val rowsPerPage = 18
        val totalStudents = students.size
        
        var studentIndex = 0
        var pageNum = 1
        
        while (studentIndex < totalStudents || totalStudents == 0) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            
            var currentY = margin + 20f
            
            // Only draw header on page 1
            if (pageNum == 1) {
                // School name
                canvas.drawText(config.schoolName, margin, currentY, titlePaint)
                currentY += 24f
                
                // Metadata
                val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                canvas.drawText("Exam Type: ${config.examType}", margin, currentY, metaPaint)
                canvas.drawText("Academic Year: ${config.academicYear}", pageWidth - margin - 180f, currentY, metaPaint)
                currentY += 16f
                
                canvas.drawText("Grade / Class: $className", margin, currentY, metaPaint)
                canvas.drawText("Class Teacher: $classTeacher", pageWidth - margin - 180f, currentY, metaPaint)
                currentY += 16f
                
                canvas.drawText("Report Generated Date: $dateStr", margin, currentY, metaPaint)
                currentY += 25f
                
                // Title for rankings
                val subtitlePaint = Paint(titlePaint).apply { textSize = 13f }
                canvas.drawText("Student Performance & Ranking List", margin, currentY, subtitlePaint)
                currentY += 15f
            } else {
                // Secondary page header
                canvas.drawText("${config.schoolName} - Student Rankings (Cont.)", margin, currentY, Paint(titlePaint).apply { textSize = 12f })
                currentY += 20f
            }
            
            // Draw Table!
            // Columns definition
            // Col 1: Rank, Col 2: ID, Col 3: Name, Col 4..N: Subjects, Col N+1: Total, Col N+2: Avg, Col N+3: Status
            val tableColumns = mutableListOf<String>()
            tableColumns.add("Rank")
            tableColumns.add("ID")
            tableColumns.add("Name")
            tableColumns.addAll(subjects)
            tableColumns.add("Total")
            tableColumns.add("Avg")
            tableColumns.add("Status")
            
            // Calculate column widths
            val tableWidth = pageWidth - (margin * 2)
            val rankWidth = 32f
            val idWidth = 42f
            val nameWidth = 100f
            val totalWidth = 38f
            val avgWidth = 38f
            val statusWidth = 72f
            
            val allocatedWidth = rankWidth + idWidth + nameWidth + totalWidth + avgWidth + statusWidth
            val remainingWidth = tableWidth - allocatedWidth
            val subjectColWidth = if (subjects.isNotEmpty()) remainingWidth / subjects.size else 0f
            
            val colWidths = mutableListOf<Float>()
            colWidths.add(rankWidth)
            colWidths.add(idWidth)
            colWidths.add(nameWidth)
            for (i in subjects.indices) {
                colWidths.add(subjectColWidth)
            }
            colWidths.add(totalWidth)
            colWidths.add(avgWidth)
            colWidths.add(statusWidth)
            
            // Draw table header background
            val headerHeight = 22f
            canvas.drawRect(margin, currentY, pageWidth - margin, currentY + headerHeight, bgHeaderPaint)
            
            // Draw table header text
            var currentX = margin
            for (i in tableColumns.indices) {
                val colText = tableColumns[i]
                val textBounds = Rect()
                tableHeaderPaint.getTextBounds(colText, 0, colText.length, textBounds)
                val textX = currentX + (colWidths[i] - textBounds.width()) / 2f
                val textY = currentY + (headerHeight + textBounds.height()) / 2f
                canvas.drawText(colText, textX, textY, tableHeaderPaint)
                currentX += colWidths[i]
            }
            
            currentY += headerHeight
            
            // Draw student rows
            val startY = currentY
            val rowHeight = 20f
            var pageRowIndex = 0
            
            while (studentIndex < totalStudents && pageRowIndex < rowsPerPage) {
                val student = students[studentIndex]
                val bgPaint = if (pageRowIndex % 2 == 0) bgRowEvenPaint else bgRowOddPaint
                
                // Draw row background
                canvas.drawRect(margin, currentY, pageWidth - margin, currentY + rowHeight, bgPaint)
                
                // Draw row contents
                currentX = margin
                
                // 1. Rank
                drawCenteredText(canvas, student.rank.toString(), currentX, colWidths[0], currentY, rowHeight, tableCellBoldPaint)
                currentX += colWidths[0]
                
                // 2. ID
                drawCenteredText(canvas, student.studentId, currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                currentX += colWidths[1]
                
                // 3. Name
                val nameBounds = Rect()
                tableCellPaint.getTextBounds(student.studentName, 0, student.studentName.length, nameBounds)
                val nameX = currentX + 6f
                val nameY = currentY + (rowHeight + nameBounds.height()) / 2f
                canvas.drawText(student.studentName, nameX, nameY, tableCellPaint)
                currentX += colWidths[2]
                
                // 4. Subject marks
                for (j in subjects.indices) {
                    val subName = subjects[j]
                    val mark = student.marks[subName] ?: 0
                    val grade = student.grades[subName] ?: "F"
                    val displayText = "$mark ($grade)"
                    drawCenteredText(canvas, displayText, currentX, colWidths[3 + j], currentY, rowHeight, tableCellPaint)
                    currentX += colWidths[3 + j]
                }
                
                // 5. Total
                val totalIdx = 3 + subjects.size
                drawCenteredText(canvas, student.total.toString(), currentX, colWidths[totalIdx], currentY, rowHeight, tableCellBoldPaint)
                currentX += colWidths[totalIdx]
                
                // 6. Avg
                val avgIdx = totalIdx + 1
                drawCenteredText(canvas, student.average.toString(), currentX, colWidths[avgIdx], currentY, rowHeight, tableCellPaint)
                currentX += colWidths[avgIdx]
                
                // 7. Status
                val statusIdx = avgIdx + 1
                drawCenteredText(canvas, student.status, currentX, colWidths[statusIdx], currentY, rowHeight, tableCellPaint)
                
                currentY += rowHeight
                studentIndex++
                pageRowIndex++
            }
            
            // Draw cell borders/grid lines
            currentX = margin
            for (i in colWidths.indices) {
                canvas.drawLine(currentX, startY - headerHeight, currentX, currentY, borderPaint)
                currentX += colWidths[i]
            }
            canvas.drawLine(pageWidth - margin, startY - headerHeight, pageWidth - margin, currentY, borderPaint)
            
            for (r in 0..pageRowIndex) {
                val rowY = startY + (r * rowHeight)
                canvas.drawLine(margin, rowY, pageWidth - margin, rowY, borderPaint)
            }
            
            // Draw signatures if it is the last page
            if (studentIndex >= totalStudents && totalStudents > 0) {
                currentY += 40f
                canvas.drawLine(margin + 20f, currentY, margin + 180f, currentY, borderPaint)
                canvas.drawLine(pageWidth - margin - 180f, currentY, pageWidth - margin - 20f, currentY, borderPaint)
                
                currentY += 15f
                canvas.drawText("Class Teacher's Signature", margin + 30f, currentY, metaPaint)
                canvas.drawText("Principal's Signature", pageWidth - margin - 150f, currentY, metaPaint)
            }
            
            // Footer
            canvas.drawText("Page $pageNum", pageWidth / 2f - 15f, pageHeight - margin + 10f, metaPaint)
            
            pdfDocument.finishPage(page)
            
            if (totalStudents == 0) break // Exit if no students
            
            pageNum++
        }
        
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }
    
    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        x: Float,
        colWidth: Float,
        y: Float,
        rowHeight: Float,
        paint: Paint
    ) {
        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)
        val textX = x + (colWidth - bounds.width()) / 2f
        val textY = y + (rowHeight + bounds.height()) / 2f
        canvas.drawText(text, textX, textY, paint)
    }
}
