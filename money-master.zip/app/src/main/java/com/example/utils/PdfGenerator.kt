package com.example.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import com.example.data.SchoolConfig
import com.example.ui.RankedStudent
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    fun generateReport(
        context: Context,
        config: SchoolConfig,
        className: String,
        classTeacher: String,
        subjects: List<String>,
        students: List<RankedStudent>,
        outputStream: OutputStream
    ) {
        val pdfDocument = PdfDocument()
        
        // Letter size in points: 612 x 792
        val pageWidth = 612
        val pageHeight = 792
        val margin = 36f // 0.5 inch margins
        
        // Paints
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val metaPaint = Paint().apply {
            color = Color.parseColor("#4A5568")
            textSize = 10f
            isAntiAlias = true
        }
        
        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val tableCellPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isAntiAlias = true
        }

        val tableCellBoldPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val bgHeaderPaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            style = Paint.Style.FILL
        }
        
        val bgRowEvenPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        
        val bgRowOddPaint = Paint().apply {
            color = Color.parseColor("#F7FAFC")
            style = Paint.Style.FILL
        }
        
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E0")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }

        // Divide students into pages
        val rowsPerPage = 18
        val totalStudents = students.size
        
        var studentIndex = 0
        var pageNum = 1
        
        while (studentIndex < totalStudents || totalStudents == 0) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            
            var currentY = margin + 20f
            
            // Only draw header on page 1
            if (pageNum == 1) {
                // School name
                canvas.drawText(config.schoolName, margin, currentY, titlePaint)
                currentY += 24f
                
                // Metadata
                val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                canvas.drawText("Exam Type: ${config.examType}", margin, currentY, metaPaint)
                canvas.drawText("Academic Year: ${config.academicYear}", pageWidth - margin - 180f, currentY, metaPaint)
                currentY += 16f
                
                canvas.drawText("Grade / Class: $className", margin, currentY, metaPaint)
                canvas.drawText("Class Teacher: $classTeacher", pageWidth - margin - 180f, currentY, metaPaint)
                currentY += 16f
                
                canvas.drawText("Report Generated Date: $dateStr", margin, currentY, metaPaint)
                currentY += 25f
                
                // Title for rankings
                val subtitlePaint = Paint(titlePaint).apply { textSize = 13f }
                canvas.drawText("Student Performance & Ranking List (With Photos)", margin, currentY, subtitlePaint)
                currentY += 15f
            } else {
                // Secondary page header
                canvas.drawText("${config.schoolName} - Student Rankings (Cont.)", margin, currentY, Paint(titlePaint).apply { textSize = 12f })
                currentY += 20f
            }
            
            // Draw Table!
            // Col 1: Rank, Col 2: Photo, Col 3: ID, Col 4: Name, Col 5..N: Subjects, Col N+1: Total, Col N+2: Avg, Col N+3: Status
            val tableColumns = mutableListOf<String>()
            tableColumns.add("Rank")
            tableColumns.add("Photo")
            tableColumns.add("ID")
            tableColumns.add("Name")
            tableColumns.addAll(subjects)
            tableColumns.add("Total")
            tableColumns.add("Avg")
            tableColumns.add("Status")
            
            // Calculate column widths
            val tableWidth = pageWidth - (margin * 2)
            val rankWidth = 28f
            val photoWidth = 28f
            val idWidth = 38f
            val nameWidth = 100f
            val totalWidth = 34f
            val avgWidth = 34f
            val statusWidth = 64f
            
            val allocatedWidth = rankWidth + photoWidth + idWidth + nameWidth + totalWidth + avgWidth + statusWidth
            val remainingWidth = tableWidth - allocatedWidth
            val subjectColWidth = if (subjects.isNotEmpty()) remainingWidth / subjects.size else 0f
            
            val colWidths = mutableListOf<Float>()
            colWidths.add(rankWidth)
            colWidths.add(photoWidth)
            colWidths.add(idWidth)
            colWidths.add(nameWidth)
            for (i in subjects.indices) {
                colWidths.add(subjectColWidth)
            }
            colWidths.add(totalWidth)
            colWidths.add(avgWidth)
            colWidths.add(statusWidth)
            
            // Draw table header background
            val headerHeight = 22f
            canvas.drawRect(margin, currentY, pageWidth - margin, currentY + headerHeight, bgHeaderPaint)
            
            // Draw table header text
            var currentX = margin
            for (i in tableColumns.indices) {
                val colText = tableColumns[i]
                val textBounds = Rect()
                tableHeaderPaint.getTextBounds(colText, 0, colText.length, textBounds)
                val textX = currentX + (colWidths[i] - textBounds.width()) / 2f
                val textY = currentY + (headerHeight + textBounds.height()) / 2f
                canvas.drawText(colText, textX, textY, tableHeaderPaint)
                currentX += colWidths[i]
            }
            
            currentY += headerHeight
            
            // Draw student rows
            val startY = currentY
            val rowHeight = 20f
            var pageRowIndex = 0
            
            while (studentIndex < totalStudents && pageRowIndex < rowsPerPage) {
                val student = students[studentIndex]
                val bgPaint = if (pageRowIndex % 2 == 0) bgRowEvenPaint else bgRowOddPaint
                
                // Draw row background
                canvas.drawRect(margin, currentY, pageWidth - margin, currentY + rowHeight, bgPaint)
                
                // Draw row contents
                currentX = margin
                
                // 1. Rank
                drawCenteredText(canvas, student.rank.toString(), currentX, colWidths[0], currentY, rowHeight, tableCellBoldPaint)
                currentX += colWidths[0]
                
                // 2. Photo (Stamp Size)
                val photoBytes = student.photoBytes
                if (photoBytes != null && photoBytes.isNotEmpty()) {
                    try {
                        val bitmap = android.graphics.BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.size)
                        if (bitmap != null) {
                            val photoSize = 16f
                            val leftOffset = currentX + (colWidths[1] - photoSize) / 2f
                            val topOffset = currentY + (rowHeight - photoSize) / 2f
                            val dstRect = android.graphics.RectF(leftOffset, topOffset, leftOffset + photoSize, topOffset + photoSize)
                            canvas.drawBitmap(bitmap, null, dstRect, Paint().apply { isAntiAlias = true })
                        } else {
                            drawCenteredText(canvas, "-", currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                        }
                    } catch (e: Exception) {
                        drawCenteredText(canvas, "-", currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                    }
                } else {
                    drawCenteredText(canvas, "-", currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                }
                currentX += colWidths[1]
                
                // 3. ID
                drawCenteredText(canvas, student.studentId, currentX, colWidths[2], currentY, rowHeight, tableCellPaint)
                currentX += colWidths[2]
                
                // 4. Name
                val nameBounds = Rect()
                tableCellPaint.getTextBounds(student.studentName, 0, student.studentName.length, nameBounds)
                val nameX = currentX + 6f
                val nameY = currentY + (rowHeight + nameBounds.height()) / 2f
                canvas.drawText(student.studentName, nameX, nameY, tableCellPaint)
                currentX += colWidths[3]
                
                // 5. Subject marks
                for (j in subjects.indices) {
                    val subName = subjects[j]
                    val mark = student.marks[subName] ?: 0
                    val grade = student.grades[subName] ?: "F"
                    val displayText = "$mark ($grade)"
                    drawCenteredText(canvas, displayText, currentX, colWidths[4 + j], currentY, rowHeight, tableCellPaint)
                    currentX += colWidths[4 + j]
                }
                
                // 6. Total
                val totalIdx = 4 + subjects.size
                drawCenteredText(canvas, student.total.toString(), currentX, colWidths[totalIdx], currentY, rowHeight, tableCellBoldPaint)
                currentX += colWidths[totalIdx]
                
                // 7. Avg
                val avgIdx = totalIdx + 1
                drawCenteredText(canvas, student.average.toString(), currentX, colWidths[avgIdx], currentY, rowHeight, tableCellPaint)
                currentX += colWidths[avgIdx]
                
                // 8. Status
                val statusIdx = avgIdx + 1
                drawCenteredText(canvas, student.status, currentX, colWidths[statusIdx], currentY, rowHeight, tableCellPaint)
                
                currentY += rowHeight
                studentIndex++
                pageRowIndex++
            }
            
            // Draw cell borders/grid lines
            currentX = margin
            for (i in colWidths.indices) {
                canvas.drawLine(currentX, startY - headerHeight, currentX, currentY, borderPaint)
                currentX += colWidths[i]
            }
            canvas.drawLine(pageWidth - margin, startY - headerHeight, pageWidth - margin, currentY, borderPaint)
            
            for (r in 0..pageRowIndex) {
                val rowY = startY + (r * rowHeight)
                canvas.drawLine(margin, rowY, pageWidth - margin, rowY, borderPaint)
            }
            
            // Draw signatures if it is the last page
            if (studentIndex >= totalStudents && totalStudents > 0) {
                currentY += 40f
                canvas.drawLine(margin + 20f, currentY, margin + 180f, currentY, borderPaint)
                canvas.drawLine(pageWidth - margin - 180f, currentY, pageWidth - margin - 20f, currentY, borderPaint)
                
                currentY += 15f
                canvas.drawText("Class Teacher's Signature", margin + 30f, currentY, metaPaint)
                canvas.drawText("Principal's Signature", pageWidth - margin - 150f, currentY, metaPaint)
            }
            
            // Footer
            canvas.drawText("Page $pageNum", pageWidth / 2f - 15f, pageHeight - margin + 10f, metaPaint)
            
            pdfDocument.finishPage(page)
            
            if (totalStudents == 0) break // Exit if no students
            
            pageNum++
        }
        
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }
    
    fun generateIndividualReport(
        context: Context,
        config: SchoolConfig,
        className: String,
        classTeacher: String,
        student: RankedStudent,
        subjects: List<String>,
        outputStream: OutputStream
    ) {
        val pdfDocument = PdfDocument()
        val pageWidth = 612
        val pageHeight = 792
        val margin = 54f // 0.75 inch margins
        
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        
        // Paint configurations
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            textSize = 22f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        
        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#4A5568")
            textSize = 12f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        
        val labelPaint = Paint().apply {
            color = Color.parseColor("#718096")
            textSize = 10f
            isAntiAlias = true
        }
        
        val valuePaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val rankLabelPaint = Paint().apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val rankValuePaint = Paint().apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 28f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val tableHeaderBgPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            style = Paint.Style.FILL
        }

        val tableCellPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 11f
            isAntiAlias = true
        }

        val tableCellBoldPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E0")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }
        
        var currentY = margin + 30f
        
        // 1. Header Block (School info)
        canvas.drawText(config.schoolName, pageWidth / 2f, currentY, titlePaint)
        currentY += 20f
        canvas.drawText("${config.examType} - ${config.academicYear}", pageWidth / 2f, currentY, subtitlePaint)
        currentY += 25f
        
        canvas.drawText("STUDENT PROGRESS REPORT", pageWidth / 2f, currentY, Paint(subtitlePaint).apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 13f
            isFakeBoldText = true
        })
        currentY += 30f
        
        // 2. Photo Section (Center, Rounded/Framed)
        val photoSize = 100f
        val photoLeft = (pageWidth - photoSize) / 2f
        val photoTop = currentY
        val photoRect = android.graphics.RectF(photoLeft, photoTop, photoLeft + photoSize, photoTop + photoSize)
        
        val photoBytes = student.photoBytes
        if (photoBytes != null && photoBytes.isNotEmpty()) {
            try {
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.size)
                if (bitmap != null) {
                    canvas.drawBitmap(bitmap, null, photoRect, Paint().apply { isAntiAlias = true })
                } else {
                    drawNoPhotoPlaceholder(canvas, photoRect, borderPaint, labelPaint)
                }
            } catch (e: Exception) {
                drawNoPhotoPlaceholder(canvas, photoRect, borderPaint, labelPaint)
            }
        } else {
            drawNoPhotoPlaceholder(canvas, photoRect, borderPaint, labelPaint)
        }
        
        currentY += photoSize + 30f
        
        // 3. Student Profile Info Layout
        val leftColumnX = margin
        val rightColumnX = pageWidth / 2f + 10f
        
        // Profile lines
        canvas.drawText("Student Name:", leftColumnX, currentY, labelPaint)
        canvas.drawText(student.studentName, leftColumnX + 80f, currentY, valuePaint)
        
        canvas.drawText("Grade / Class:", rightColumnX, currentY, labelPaint)
        canvas.drawText(className, rightColumnX + 80f, currentY, valuePaint)
        
        currentY += 20f
        
        canvas.drawText("Student ID:", leftColumnX, currentY, labelPaint)
        canvas.drawText(student.studentId, leftColumnX + 80f, currentY, valuePaint)
        
        canvas.drawText("Class Teacher:", rightColumnX, currentY, labelPaint)
        canvas.drawText(classTeacher, rightColumnX + 80f, currentY, valuePaint)
        
        currentY += 25f
        
        // Rank Highlight
        canvas.drawText("🏆 CLASS RANK:", leftColumnX, currentY, rankLabelPaint)
        canvas.drawText(student.rank.toString(), leftColumnX + 110f, currentY + 6f, rankValuePaint)
        
        currentY += 40f
        
        // 4. Subjects & Marks Table
        val tableWidth = 504f
        val colWidths = listOf(204f, 150f, 150f)
        val tableHeaders = listOf("Subject", "Marks", "Grade")
        val tableRowHeight = 24f
        
        // Header
        canvas.drawRect(margin, currentY, margin + tableWidth, currentY + tableRowHeight, tableHeaderBgPaint)
        var currentX = margin
        for (i in tableHeaders.indices) {
            drawCenteredText(canvas, tableHeaders[i], currentX, colWidths[i], currentY, tableRowHeight, tableCellBoldPaint)
            currentX += colWidths[i]
        }
        
        canvas.drawLine(margin, currentY, margin + tableWidth, currentY, borderPaint)
        canvas.drawLine(margin, currentY + tableRowHeight, margin + tableWidth, currentY + tableRowHeight, borderPaint)
        
        val startY = currentY
        currentY += tableRowHeight
        
        // Rows
        for (sub in subjects) {
            val score = student.marks[sub] ?: 0
            val grade = student.grades[sub] ?: "F"
            
            // Draw Subject Name (left-aligned, inset slightly)
            val nameBounds = Rect()
            tableCellPaint.getTextBounds(sub, 0, sub.length, nameBounds)
            canvas.drawText(sub, margin + 12f, currentY + (tableRowHeight + nameBounds.height()) / 2f, tableCellPaint)
            
            // Draw Marks and Grade centered
            drawCenteredText(canvas, score.toString(), margin + colWidths[0], colWidths[1], currentY, tableRowHeight, tableCellPaint)
            drawCenteredText(canvas, grade, margin + colWidths[0] + colWidths[1], colWidths[2], currentY, tableRowHeight, tableCellPaint)
            
            currentY += tableRowHeight
        }
        
        // Total / Average Row
        canvas.drawRect(margin, currentY, margin + tableWidth, currentY + tableRowHeight, tableHeaderBgPaint)
        
        val totalTextBounds = Rect()
        tableCellBoldPaint.getTextBounds("Total / Average", 0, "Total / Average".length, totalTextBounds)
        canvas.drawText("Total / Average", margin + 12f, currentY + (tableRowHeight + totalTextBounds.height()) / 2f, tableCellBoldPaint)
        
        drawCenteredText(canvas, student.total.toString(), margin + colWidths[0], colWidths[1], currentY, tableRowHeight, tableCellBoldPaint)
        drawCenteredText(canvas, "${student.average}%", margin + colWidths[0] + colWidths[1], colWidths[2], currentY, tableRowHeight, tableCellBoldPaint)
        
        currentY += tableRowHeight
        
        // Draw grid lines
        currentX = margin
        for (i in colWidths.indices) {
            canvas.drawLine(currentX, startY, currentX, currentY, borderPaint)
            currentX += colWidths[i]
        }
        canvas.drawLine(margin + tableWidth, startY, margin + tableWidth, currentY, borderPaint)
        
        for (r in 0..(subjects.size + 1)) {
            val rowY = startY + (r * tableRowHeight)
            canvas.drawLine(margin, rowY, margin + tableWidth, rowY, borderPaint)
        }
        
        // 5. Signature Area
        currentY += 60f
        canvas.drawLine(margin + 20f, currentY, margin + 180f, currentY, borderPaint)
        canvas.drawLine(pageWidth - margin - 180f, currentY, pageWidth - margin - 20f, currentY, borderPaint)
        
        currentY += 15f
        canvas.drawText("Class Teacher's Signature", margin + 30f, currentY, Paint(labelPaint).apply { textSize = 9f })
        canvas.drawText("Principal's Signature", pageWidth - margin - 150f, currentY, Paint(labelPaint).apply { textSize = 9f })
        
        pdfDocument.finishPage(page)
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }

    private fun drawNoPhotoPlaceholder(
        canvas: Canvas,
        rect: android.graphics.RectF,
        borderPaint: Paint,
        textPaint: Paint
    ) {
        canvas.drawRect(rect, borderPaint)
        val placeholderText = "[ No Photo ]"
        val bounds = Rect()
        textPaint.getTextBounds(placeholderText, 0, placeholderText.length, bounds)
        val textX = rect.left + (rect.width() - bounds.width()) / 2f
        val textY = rect.top + (rect.height() + bounds.height()) / 2f
        canvas.drawText(placeholderText, textX, textY, textPaint)
    }
    
    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        x: Float,
        colWidth: Float,
        y: Float,
        rowHeight: Float,
        paint: Paint
    ) {
        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)
        val textX = x + (colWidth - bounds.width()) / 2f
        val textY = y + (rowHeight + bounds.height()) / 2f
        canvas.drawText(text, textX, textY, paint)
    }
}
