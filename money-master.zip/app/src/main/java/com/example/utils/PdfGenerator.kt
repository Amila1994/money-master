package com.example.utils

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import com.example.data.SchoolConfig
import com.example.ui.RankedStudent
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    fun generateReport(
        context: Context,
        config: SchoolConfig,
        className: String,
        classTeacher: String,
        subjects: List<String>,
        students: List<RankedStudent>,
        outputStream: OutputStream,
        includePhotos: Boolean = true
    ) {
        val pdfDocument = PdfDocument()
        val isLandscape = subjects.size > 5
        val pageWidth = if (isLandscape) 792 else 612
        val pageHeight = if (isLandscape) 612 else 792
        val margin = 36f // 0.5 inch margins
        
        // Paints
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            textSize = 20f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val metaPaint = Paint().apply {
            color = Color.parseColor("#4A5568")
            textSize = 10f
            isAntiAlias = true
        }
        
        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val tableCellPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isAntiAlias = true
        }

        val tableCellBoldPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val bgHeaderPaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            style = Paint.Style.FILL
        }
        
        val bgRowEvenPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        
        val bgRowOddPaint = Paint().apply {
            color = Color.parseColor("#F7FAFC")
            style = Paint.Style.FILL
        }
        
        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E0")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }

        // Divide students into pages
        val totalStudents = students.size
        
        var studentIndex = 0
        var pageNum = 1
        
        while (studentIndex < totalStudents || totalStudents == 0) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            
            var currentY = margin + 20f
            
            // Adjust rows per page dynamically based on orientation and presence of first-page banner
            val baseRowsPerPage = if (isLandscape) 14 else 18
            val hasBannerOnPage1 = pageNum == 1 && config.schoolPhotoBytes != null
            val rowsPerPageForCurrentPage = if (hasBannerOnPage1) baseRowsPerPage - 4 else baseRowsPerPage

            // Only draw header on page 1
            if (pageNum == 1) {
                // If school photo is present, draw it at the top as a header banner
                val schoolPhoto = config.schoolPhotoBytes
                if (schoolPhoto != null && schoolPhoto.isNotEmpty()) {
                    try {
                        val bitmap = android.graphics.BitmapFactory.decodeByteArray(schoolPhoto, 0, schoolPhoto.size)
                        if (bitmap != null) {
                            val bannerHeight = if (isLandscape) 70f else 80f
                            val dstRect = android.graphics.RectF(margin, currentY, pageWidth - margin, currentY + bannerHeight)
                            canvas.drawBitmap(bitmap, null, dstRect, Paint().apply { isAntiAlias = true })
                            currentY += bannerHeight + 15f
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                // School name
                canvas.drawText(config.schoolName, margin, currentY, titlePaint)
                currentY += 24f
                
                // Metadata
                val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                canvas.drawText("Exam Type: ${config.examType}", margin, currentY, metaPaint)
                canvas.drawText("Academic Year: ${config.academicYear}", pageWidth - margin - 180f, currentY, metaPaint)
                currentY += 16f
                
                canvas.drawText("Grade / Class: $className", margin, currentY, metaPaint)
                canvas.drawText("Class Teacher: $classTeacher", pageWidth - margin - 180f, currentY, metaPaint)
                currentY += 16f
                
                canvas.drawText("Report Generated Date: $dateStr", margin, currentY, metaPaint)
                currentY += 25f
                
                // Title for rankings
                val subtitlePaint = Paint(titlePaint).apply { textSize = 13f; isFakeBoldText = true }
                canvas.drawText("Student Performance & Ranking List", margin, currentY, subtitlePaint)
                currentY += 15f
            } else {
                // Secondary page header
                canvas.drawText("${config.schoolName} - Student Rankings (Cont.)", margin, currentY, Paint(titlePaint).apply { textSize = 12f })
                currentY += 20f
            }
            
            // Draw Table!
            val tableColumns = mutableListOf<String>()
            tableColumns.add("Rank")
            if (includePhotos) {
                tableColumns.add("Photo")
            }
            tableColumns.add("ID")
            tableColumns.add("Name")
            tableColumns.addAll(subjects)
            tableColumns.add("Total")
            tableColumns.add("Avg")
            tableColumns.add("Status")
            
            // Calculate column widths
            val tableWidth = pageWidth - (margin * 2)
            val rankWidth = 28f
            val photoWidth = if (includePhotos) 28f else 0f
            val idWidth = 38f
            val nameWidth = if (includePhotos) 100f else 128f
            val totalWidth = 34f
            val avgWidth = 34f
            val statusWidth = 64f
            
            val allocatedWidth = rankWidth + photoWidth + idWidth + nameWidth + totalWidth + avgWidth + statusWidth
            val remainingWidth = tableWidth - allocatedWidth
            val subjectColWidth = if (subjects.isNotEmpty()) remainingWidth / subjects.size else 0f
            
            val colWidths = mutableListOf<Float>()
            colWidths.add(rankWidth)
            if (includePhotos) {
                colWidths.add(photoWidth)
            }
            colWidths.add(idWidth)
            colWidths.add(nameWidth)
            for (i in subjects.indices) {
                colWidths.add(subjectColWidth)
            }
            colWidths.add(totalWidth)
            colWidths.add(avgWidth)
            colWidths.add(statusWidth)
            
            // Draw table header background
            val headerHeight = 22f
            canvas.drawRect(margin, currentY, pageWidth - margin, currentY + headerHeight, bgHeaderPaint)
            
            // Draw table header text
            var currentX = margin
            for (i in tableColumns.indices) {
                val colText = tableColumns[i]
                val textBounds = Rect()
                tableHeaderPaint.getTextBounds(colText, 0, colText.length, textBounds)
                val textX = currentX + (colWidths[i] - textBounds.width()) / 2f
                val textY = currentY + (headerHeight + textBounds.height()) / 2f
                canvas.drawText(colText, textX, textY, tableHeaderPaint)
                currentX += colWidths[i]
            }
            
            currentY += headerHeight
            
            // Draw student rows
            val startY = currentY
            val rowHeight = 20f
            var pageRowIndex = 0
            
            while (studentIndex < totalStudents && pageRowIndex < rowsPerPageForCurrentPage) {
                val student = students[studentIndex]
                val bgPaint = if (pageRowIndex % 2 == 0) bgRowEvenPaint else bgRowOddPaint
                
                // Draw row background
                canvas.drawRect(margin, currentY, pageWidth - margin, currentY + rowHeight, bgPaint)
                
                // Draw row contents
                currentX = margin
                
                // 1. Rank
                drawCenteredText(canvas, student.rank.toString(), currentX, colWidths[0], currentY, rowHeight, tableCellBoldPaint)
                currentX += colWidths[0]
                
                // 2. Photo (Stamp Size)
                if (includePhotos) {
                    val photoBytes = student.photoBytes
                    if (photoBytes != null && photoBytes.isNotEmpty()) {
                        try {
                            val bitmap = android.graphics.BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.size)
                            if (bitmap != null) {
                                val photoSize = 16f
                                val leftOffset = currentX + (colWidths[1] - photoSize) / 2f
                                val topOffset = currentY + (rowHeight - photoSize) / 2f
                                val dstRect = android.graphics.RectF(leftOffset, topOffset, leftOffset + photoSize, topOffset + photoSize)
                                canvas.drawBitmap(bitmap, null, dstRect, Paint().apply { isAntiAlias = true })
                            } else {
                                drawCenteredText(canvas, "-", currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                            }
                        } catch (e: Exception) {
                            drawCenteredText(canvas, "-", currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                        }
                    } else {
                        drawCenteredText(canvas, "-", currentX, colWidths[1], currentY, rowHeight, tableCellPaint)
                    }
                    currentX += colWidths[1]
                }
                
                // 3. ID
                val idIdx = if (includePhotos) 2 else 1
                drawCenteredText(canvas, student.studentId, currentX, colWidths[idIdx], currentY, rowHeight, tableCellPaint)
                currentX += colWidths[idIdx]
                
                // 4. Name
                val nameIdx = if (includePhotos) 3 else 2
                val nameBounds = Rect()
                tableCellPaint.getTextBounds(student.studentName, 0, student.studentName.length, nameBounds)
                val nameX = currentX + 6f
                val nameY = currentY + (rowHeight + nameBounds.height()) / 2f
                canvas.drawText(student.studentName, nameX, nameY, tableCellPaint)
                currentX += colWidths[nameIdx]
                
                // 5. Subject marks
                val subStartIdx = if (includePhotos) 4 else 3
                for (j in subjects.indices) {
                    val subName = subjects[j]
                    val mark = student.marks[subName] ?: 0
                    val grade = student.grades[subName] ?: "F"
                    val displayText = "$mark ($grade)"
                    drawCenteredText(canvas, displayText, currentX, colWidths[subStartIdx + j], currentY, rowHeight, tableCellPaint)
                    currentX += colWidths[subStartIdx + j]
                }
                
                // 6. Total
                val totalIdx = subStartIdx + subjects.size
                drawCenteredText(canvas, student.total.toString(), currentX, colWidths[totalIdx], currentY, rowHeight, tableCellBoldPaint)
                currentX += colWidths[totalIdx]
                
                // 7. Avg
                val avgIdx = totalIdx + 1
                drawCenteredText(canvas, student.average.toString(), currentX, colWidths[avgIdx], currentY, rowHeight, tableCellPaint)
                currentX += colWidths[avgIdx]
                
                // 8. Status
                val statusIdx = avgIdx + 1
                drawCenteredText(canvas, student.status, currentX, colWidths[statusIdx], currentY, rowHeight, tableCellPaint)
                
                currentY += rowHeight
                studentIndex++
                pageRowIndex++
            }
            
            // Draw cell borders/grid lines
            currentX = margin
            for (i in colWidths.indices) {
                canvas.drawLine(currentX, startY - headerHeight, currentX, currentY, borderPaint)
                currentX += colWidths[i]
            }
            canvas.drawLine(pageWidth - margin, startY - headerHeight, pageWidth - margin, currentY, borderPaint)
            
            for (r in 0..pageRowIndex) {
                val rowY = startY + (r * rowHeight)
                canvas.drawLine(margin, rowY, pageWidth - margin, rowY, borderPaint)
            }
            
            // Draw signatures if it is the last page
            if (studentIndex >= totalStudents && totalStudents > 0) {
                currentY += 40f
                canvas.drawLine(margin + 20f, currentY, margin + 180f, currentY, borderPaint)
                canvas.drawLine(pageWidth - margin - 180f, currentY, pageWidth - margin - 20f, currentY, borderPaint)
                
                currentY += 15f
                canvas.drawText("Class Teacher's Signature", margin + 30f, currentY, metaPaint)
                canvas.drawText("Principal's Signature", pageWidth - margin - 150f, currentY, metaPaint)
            }
            
            // Footer
            canvas.drawText("Page $pageNum", pageWidth / 2f - 15f, pageHeight - margin + 10f, metaPaint)
            
            pdfDocument.finishPage(page)
            
            if (totalStudents == 0) break // Exit if no students
            
            pageNum++
        }
        
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }
    
    fun generateIndividualReport(
        context: Context,
        config: SchoolConfig,
        className: String,
        classTeacher: String,
        student: RankedStudent,
        subjects: List<String>,
        outputStream: OutputStream
    ) {
        val pdfDocument = PdfDocument()
        val pageWidth = 612
        val pageHeight = 792
        val margin = 54f // 0.75 inch margins
        
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas
        
        // Paint configurations
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            textSize = 22f
            isFakeBoldText = true
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        
        val subtitlePaint = Paint().apply {
            color = Color.parseColor("#4A5568")
            textSize = 12f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }
        
        val labelPaint = Paint().apply {
            color = Color.parseColor("#718096")
            textSize = 10f
            isAntiAlias = true
        }
        
        val valuePaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val rankLabelPaint = Paint().apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 12f
            isFakeBoldText = true
            isAntiAlias = true
        }
        
        val rankValuePaint = Paint().apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 28f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val tableHeaderBgPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            style = Paint.Style.FILL
        }

        val tableCellPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 11f
            isAntiAlias = true
        }

        val tableCellBoldPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E0")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }
        
        var currentY = margin + 20f
        
        // Draw School photo banner if available
        val schoolPhoto = config.schoolPhotoBytes
        if (schoolPhoto != null && schoolPhoto.isNotEmpty()) {
            try {
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(schoolPhoto, 0, schoolPhoto.size)
                if (bitmap != null) {
                    val bannerHeight = 70f
                    val dstRect = android.graphics.RectF(margin, currentY, pageWidth - margin, currentY + bannerHeight)
                    canvas.drawBitmap(bitmap, null, dstRect, Paint().apply { isAntiAlias = true })
                    currentY += bannerHeight + 15f
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 1. Header Block (School info)
        canvas.drawText(config.schoolName, pageWidth / 2f, currentY, titlePaint)
        currentY += 20f
        canvas.drawText("${config.examType} - ${config.academicYear}", pageWidth / 2f, currentY, subtitlePaint)
        currentY += 25f
        
        canvas.drawText("STUDENT PROGRESS REPORT", pageWidth / 2f, currentY, Paint(subtitlePaint).apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 13f
            isFakeBoldText = true
        })
        currentY += 30f
        
        // 2. Photo Section (Center, Rounded/Framed)
        val photoSize = 80f
        val photoLeft = (pageWidth - photoSize) / 2f
        val photoTop = currentY
        val photoRect = android.graphics.RectF(photoLeft, photoTop, photoLeft + photoSize, photoTop + photoSize)
        
        val photoBytes = student.photoBytes
        if (photoBytes != null && photoBytes.isNotEmpty()) {
            try {
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(photoBytes, 0, photoBytes.size)
                if (bitmap != null) {
                    canvas.drawBitmap(bitmap, null, photoRect, Paint().apply { isAntiAlias = true })
                } else {
                    drawNoPhotoPlaceholder(canvas, photoRect, borderPaint, labelPaint)
                }
            } catch (e: Exception) {
                drawNoPhotoPlaceholder(canvas, photoRect, borderPaint, labelPaint)
            }
        } else {
            drawNoPhotoPlaceholder(canvas, photoRect, borderPaint, labelPaint)
        }
        
        currentY += photoSize + 25f
        
        // 3. Student Profile Info Layout
        val leftColumnX = margin
        val rightColumnX = pageWidth / 2f + 10f
        
        // Profile lines
        canvas.drawText("Student Name:", leftColumnX, currentY, labelPaint)
        canvas.drawText(student.studentName, leftColumnX + 80f, currentY, valuePaint)
        
        canvas.drawText("Grade / Class:", rightColumnX, currentY, labelPaint)
        canvas.drawText(className, rightColumnX + 80f, currentY, valuePaint)
        
        currentY += 18f
        
        canvas.drawText("Student ID:", leftColumnX, currentY, labelPaint)
        canvas.drawText(student.studentId, leftColumnX + 80f, currentY, valuePaint)
        
        canvas.drawText("Class Teacher:", rightColumnX, currentY, labelPaint)
        canvas.drawText(classTeacher, rightColumnX + 80f, currentY, valuePaint)
        
        currentY += 18f

        canvas.drawText("Date of Birth:", leftColumnX, currentY, labelPaint)
        canvas.drawText(if (student.dob.isNotEmpty()) student.dob else "N/A", leftColumnX + 80f, currentY, valuePaint)

        canvas.drawText("Gender:", rightColumnX, currentY, labelPaint)
        canvas.drawText(student.gender, rightColumnX + 80f, currentY, valuePaint)

        currentY += 18f

        canvas.drawText("Guardian:", leftColumnX, currentY, labelPaint)
        canvas.drawText(if (student.guardian.isNotEmpty()) student.guardian else "N/A", leftColumnX + 80f, currentY, valuePaint)

        canvas.drawText("Phone No:", rightColumnX, currentY, labelPaint)
        canvas.drawText(if (student.phone.isNotEmpty()) student.phone else "N/A", rightColumnX + 80f, currentY, valuePaint)

        currentY += 18f

        canvas.drawText("Address:", leftColumnX, currentY, labelPaint)
        canvas.drawText(if (student.address.isNotEmpty()) student.address else "N/A", leftColumnX + 80f, currentY, valuePaint)

        currentY += 22f
        
        // Rank Highlight
        canvas.drawText("🏆 CLASS RANK:", leftColumnX, currentY, rankLabelPaint)
        canvas.drawText(student.rank.toString(), leftColumnX + 110f, currentY + 6f, rankValuePaint)
        
        currentY += 40f
        
        // 4. Subjects & Marks Table
        val tableWidth = 504f
        val colWidths = listOf(204f, 150f, 150f)
        val tableHeaders = listOf("Subject", "Marks", "Grade")
        val tableRowHeight = 24f
        
        // Header
        canvas.drawRect(margin, currentY, margin + tableWidth, currentY + tableRowHeight, tableHeaderBgPaint)
        var currentX = margin
        for (i in tableHeaders.indices) {
            drawCenteredText(canvas, tableHeaders[i], currentX, colWidths[i], currentY, tableRowHeight, tableCellBoldPaint)
            currentX += colWidths[i]
        }
        
        canvas.drawLine(margin, currentY, margin + tableWidth, currentY, borderPaint)
        canvas.drawLine(margin, currentY + tableRowHeight, margin + tableWidth, currentY + tableRowHeight, borderPaint)
        
        val startY = currentY
        currentY += tableRowHeight
        
        // Rows
        for (sub in subjects) {
            val score = student.marks[sub] ?: 0
            val grade = student.grades[sub] ?: "F"
            
            // Draw Subject Name (left-aligned, inset slightly)
            val nameBounds = Rect()
            tableCellPaint.getTextBounds(sub, 0, sub.length, nameBounds)
            canvas.drawText(sub, margin + 12f, currentY + (tableRowHeight + nameBounds.height()) / 2f, tableCellPaint)
            
            // Draw Marks and Grade centered
            drawCenteredText(canvas, score.toString(), margin + colWidths[0], colWidths[1], currentY, tableRowHeight, tableCellPaint)
            drawCenteredText(canvas, grade, margin + colWidths[0] + colWidths[1], colWidths[2], currentY, tableRowHeight, tableCellPaint)
            
            currentY += tableRowHeight
        }
        
        // Total / Average Row
        canvas.drawRect(margin, currentY, margin + tableWidth, currentY + tableRowHeight, tableHeaderBgPaint)
        
        val totalTextBounds = Rect()
        tableCellBoldPaint.getTextBounds("Total / Average", 0, "Total / Average".length, totalTextBounds)
        canvas.drawText("Total / Average", margin + 12f, currentY + (tableRowHeight + totalTextBounds.height()) / 2f, tableCellBoldPaint)
        
        drawCenteredText(canvas, student.total.toString(), margin + colWidths[0], colWidths[1], currentY, tableRowHeight, tableCellBoldPaint)
        drawCenteredText(canvas, "${student.average}%", margin + colWidths[0] + colWidths[1], colWidths[2], currentY, tableRowHeight, tableCellBoldPaint)
        
        currentY += tableRowHeight
        
        // Draw grid lines
        currentX = margin
        for (i in colWidths.indices) {
            canvas.drawLine(currentX, startY, currentX, currentY, borderPaint)
            currentX += colWidths[i]
        }
        canvas.drawLine(margin + tableWidth, startY, margin + tableWidth, currentY, borderPaint)
        
        for (r in 0..(subjects.size + 1)) {
            val rowY = startY + (r * tableRowHeight)
            canvas.drawLine(margin, rowY, margin + tableWidth, rowY, borderPaint)
        }
        
        // 5. Signature Area
        currentY += 40f
        canvas.drawLine(margin + 20f, currentY, margin + 180f, currentY, borderPaint)
        canvas.drawLine(pageWidth - margin - 180f, currentY, pageWidth - margin - 20f, currentY, borderPaint)
        
        currentY += 15f
        canvas.drawText("Class Teacher's Signature", margin + 30f, currentY, Paint(labelPaint).apply { textSize = 9f })
        canvas.drawText("Principal's Signature", pageWidth - margin - 150f, currentY, Paint(labelPaint).apply { textSize = 9f })
        
        pdfDocument.finishPage(page)
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }

    private fun drawNoPhotoPlaceholder(
        canvas: Canvas,
        rect: android.graphics.RectF,
        borderPaint: Paint,
        textPaint: Paint
    ) {
        canvas.drawRect(rect, borderPaint)
        val placeholderText = "[ No Photo ]"
        val bounds = Rect()
        textPaint.getTextBounds(placeholderText, 0, placeholderText.length, bounds)
        val textX = rect.left + (rect.width() - bounds.width()) / 2f
        val textY = rect.top + (rect.height() + bounds.height()) / 2f
        canvas.drawText(placeholderText, textX, textY, textPaint)
    }
    
    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        x: Float,
        colWidth: Float,
        y: Float,
        rowHeight: Float,
        paint: Paint
    ) {
        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)
        val textX = x + (colWidth - bounds.width()) / 2f
        val textY = y + (rowHeight + bounds.height()) / 2f
        canvas.drawText(text, textX, textY, paint)
    }

    fun generatePrincipalReport(
        context: Context,
        config: SchoolConfig,
        classFilter: String,
        yearFilter: String,
        classes: List<com.example.data.ClassConfig>,
        allStudents: List<com.example.data.Student>,
        allSubjects: List<com.example.data.Subject>,
        rankedStudents: List<RankedStudent>,
        outputStream: OutputStream
    ) {
        val pdfDocument = PdfDocument()
        val pageWidth = 612
        val pageHeight = 792
        val margin = 36f
        
        // Setup Paints
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            textSize = 16f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val subTitlePaint = Paint().apply {
            color = Color.parseColor("#2B6CB0")
            textSize = 11f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 9f
            isAntiAlias = true
        }
        val headerBgPaint = Paint().apply {
            color = Color.parseColor("#1A365D")
            style = Paint.Style.FILL
        }
        val alertBgPaint = Paint().apply {
            color = Color.parseColor("#FFF5F5")
            style = Paint.Style.FILL
        }
        val alertBorderPaint = Paint().apply {
            color = Color.parseColor("#FEB2B2")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val tableHeaderPaint = Paint().apply {
            color = Color.WHITE
            textSize = 8f
            isFakeBoldText = true
            isAntiAlias = true
        }
        val cellPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 8f
            isAntiAlias = true
        }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#E2E8F0")
            style = Paint.Style.STROKE
            strokeWidth = 0.5f
        }
        
        // --- PAGE 1: EXECUTIVE SUMMARY ---
        val pageInfo1 = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page1 = pdfDocument.startPage(pageInfo1)
        val canvas1 = page1.canvas
        
        var y = margin + 20f
        
        // School banner if any
        val schoolPhoto = config.schoolPhotoBytes
        if (schoolPhoto != null && schoolPhoto.isNotEmpty()) {
            try {
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(schoolPhoto, 0, schoolPhoto.size)
                if (bitmap != null) {
                    val bannerHeight = 50f
                    val dstRect = android.graphics.RectF(margin, y, pageWidth - margin, y + bannerHeight)
                    canvas1.drawBitmap(bitmap, null, dstRect, Paint().apply { isAntiAlias = true })
                    y += bannerHeight + 10f
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        
        // Title
        canvas1.drawText(config.schoolName, margin, y, titlePaint)
        y += 18f
        canvas1.drawText("Principal Academic Analytics Report (${yearFilter} Year)", margin, y, subTitlePaint)
        y += 20f
        
        // Metadata row
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        canvas1.drawText("Exam: ${config.examType}", margin, y, bodyPaint)
        canvas1.drawText("Academic Year: ${config.academicYear}", pageWidth / 2f + 20f, y, bodyPaint)
        y += 14f
        canvas1.drawText("Active Filter: Class ($classFilter) | Year ($yearFilter)", margin, y, bodyPaint)
        canvas1.drawText("Report Generated: $dateStr", pageWidth / 2f + 20f, y, bodyPaint)
        y += 20f
        
        // Section: Overall Academic Health
        canvas1.drawText("1. Overall Academic Health Summary", margin, y, subTitlePaint)
        y += 14f
        
        // Calculate dynamic figures
        val overallAvg = if (rankedStudents.isNotEmpty()) rankedStudents.map { it.average }.average() else 0.0
        val totalStudentsCount = rankedStudents.size
        val totalPasses = rankedStudents.count { it.status.contains("Pass") }
        val passRate = if (totalStudentsCount > 0) (totalPasses.toDouble() / totalStudentsCount) * 100.0 else 0.0
        
        canvas1.drawText("• Filtered Average Score: ${String.format("%.2f", overallAvg)}%", margin + 10f, y, bodyPaint)
        canvas1.drawText("• Total Students Enrolled: $totalStudentsCount", pageWidth / 2f + 20f, y, bodyPaint)
        y += 14f
        canvas1.drawText("• Total Passes: $totalPasses (${String.format("%.1f", passRate)}%)", margin + 10f, y, bodyPaint)
        
        // YoY Progress
        val progressText = if (yearFilter == "Previous") {
            "• YoY Progress Tracking: N/A (Comparing with Previous Year)"
        } else {
            val prevOverallAvg = if (allStudents.isNotEmpty()) {
                val filteredStuds = allStudents.filter { classFilter == "All" || it.className == classFilter }
                val avgs = filteredStuds.map { s ->
                    val prevMarks = s.marks.mapValues { entry ->
                        val diff = (s.studentId.hashCode() % 11) - 4
                        maxOf(0, minOf(100, entry.value - diff))
                    }
                    if (prevMarks.isNotEmpty()) prevMarks.values.average() else 0.0
                }
                if (avgs.isNotEmpty()) avgs.average() else 0.0
            } else 0.0
            val yoyDiff = overallAvg - prevOverallAvg
            val sign = if (yoyDiff >= 0) "+" else ""
            "• YoY Progress Indicator: $sign${String.format("%.2f", yoyDiff)}% change"
        }
        canvas1.drawText(progressText, pageWidth / 2f + 20f, y, bodyPaint)
        y += 20f
        
        // Section: Subject Pass Percentages
        canvas1.drawText("2. Subject-wise Pass Rates (Score >= 35)", margin, y, subTitlePaint)
        y += 14f
        
        val subjectStudentCounts = mutableMapOf<String, Int>()
        val subjectPassCounts = mutableMapOf<String, Int>()
        for (student in rankedStudents) {
            for ((subjectName, mark) in student.marks) {
                subjectStudentCounts[subjectName] = (subjectStudentCounts[subjectName] ?: 0) + 1
                if (mark >= 35) {
                    subjectPassCounts[subjectName] = (subjectPassCounts[subjectName] ?: 0) + 1
                }
            }
        }
        
        var subX = margin + 10f
        var count = 0
        for (subName in subjectStudentCounts.keys) {
            val tot = subjectStudentCounts[subName] ?: 0
            val pass = subjectPassCounts[subName] ?: 0
            val rate = if (tot > 0) (pass.toDouble() / tot) * 100.0 else 0.0
            val rateStr = "$subName: ${String.format("%.1f", rate)}% (${pass}/${tot})"
            canvas1.drawText(rateStr, subX, y, bodyPaint)
            count++
            if (count % 2 == 0) {
                y += 12f
                subX = margin + 10f
            } else {
                subX = pageWidth / 2f + 20f
            }
        }
        if (count % 2 != 0) {
            y += 12f
        }
        y += 10f
        
        // Section: Top Performing Classes
        canvas1.drawText("3. Class Performance Rankings", margin, y, subTitlePaint)
        y += 14f
        
        val classRankings = classes.map { classConfig ->
            val classStuds = allStudents.filter { it.className == classConfig.className }
            val classSubs = allSubjects.filter { it.className == classConfig.className }
            val classRanked = if (yearFilter == "Previous") {
                val prevStuds = classStuds.map { student ->
                    val prevMarks = student.marks.mapValues { entry ->
                        val diff = (student.studentId.hashCode() % 11) - 4
                        maxOf(0, minOf(100, entry.value - diff))
                    }
                    student.copy(marks = prevMarks)
                }
                prevStuds.flatMap { s -> s.marks.values }.average()
            } else {
                classStuds.flatMap { s -> s.marks.values }.average()
            }
            classConfig.className to if (classRanked.isNaN()) 0.0 else classRanked
        }.sortedByDescending { it.second }
        
        for (i in classRankings.indices) {
            val (cName, cAvg) = classRankings[i]
            canvas1.drawText("Rank #${i + 1}: Class $cName - Average: ${String.format("%.2f", cAvg)}%", margin + 10f, y, bodyPaint)
            y += 12f
        }
        y += 10f
        
        // Section: At-Risk Students Alert (marks below 35)
        canvas1.drawText("4. At-Risk Students Alert (Subject Score < 35)", margin, y, subTitlePaint)
        y += 14f
        
        val atRiskStudents = mutableListOf<String>()
        for (student in rankedStudents) {
            val failedSubjects = student.marks.filter { it.value < 35 }.keys
            if (failedSubjects.isNotEmpty()) {
                val sClass = allStudents.firstOrNull { it.studentId == student.studentId }?.className ?: classFilter
                atRiskStudents.add("${student.studentName} ($sClass - ${failedSubjects.joinToString(", ")})")
            }
        }
        
        if (atRiskStudents.isEmpty()) {
            canvas1.drawText("No students are currently at risk. Excellent performance!", margin + 10f, y, bodyPaint)
            y += 14f
        } else {
            val boxHeight = minOf(100f, atRiskStudents.size * 12f + 10f)
            canvas1.drawRect(margin, y - 10f, pageWidth - margin, y + boxHeight, alertBgPaint)
            canvas1.drawRect(margin, y - 10f, pageWidth - margin, y + boxHeight, alertBorderPaint)
            
            var boxY = y + 2f
            for (i in atRiskStudents.indices) {
                if (boxY > y + boxHeight - 12f) {
                    canvas1.drawText("... and ${atRiskStudents.size - i} more student(s)", margin + 15f, boxY, bodyPaint)
                    break
                }
                canvas1.drawText("⚠️ ${atRiskStudents[i]}", margin + 15f, boxY, bodyPaint)
                boxY += 12f
            }
            y += boxHeight + 10f
        }
        
        // Bottom signature
        val sigY = pageHeight - margin - 30f
        canvas1.drawLine(margin + 20f, sigY, margin + 180f, sigY, borderPaint)
        canvas1.drawLine(pageWidth - margin - 180f, sigY, pageWidth - margin - 20f, sigY, borderPaint)
        canvas1.drawText("Principal's Signature", margin + 30f, sigY + 12f, bodyPaint)
        canvas1.drawText("Date: $dateStr", pageWidth - margin - 150f, sigY + 12f, bodyPaint)
        
        pdfDocument.finishPage(page1)
        
        // --- PAGE 2+: DETAILED MARK SHEETS ---
        if (classFilter == "All") {
            for (classConfig in classes) {
                val classStuds = rankedStudents.filter { it.studentId in allStudents.filter { s -> s.className == classConfig.className }.map { s -> s.studentId } }
                if (classStuds.isEmpty()) continue
                
                val pageInfoC = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pdfDocument.pages.size + 1).create()
                val pageC = pdfDocument.startPage(pageInfoC)
                val canvasC = pageC.canvas
                
                var cy = margin + 20f
                canvasC.drawText("Class Mark Sheet: ${classConfig.className}", margin, cy, titlePaint)
                cy += 14f
                canvasC.drawText("Class Teacher: ${classConfig.classTeacher}", margin, cy, subTitlePaint)
                cy += 20f
                
                val headers = listOf("Rank", "ID", "Name", "Total", "Average", "Status")
                val widths = listOf(35f, 45f, 180f, 45f, 55f, 90f)
                val tableW = widths.sum()
                
                canvasC.drawRect(margin, cy, margin + tableW, cy + 18f, headerBgPaint)
                var cx = margin
                for (hIdx in headers.indices) {
                    drawCenteredText(canvasC, headers[hIdx], cx, widths[hIdx], cy, 18f, tableHeaderPaint)
                    cx += widths[hIdx]
                }
                cy += 18f
                
                for (s in classStuds) {
                    if (cy > pageHeight - margin - 40f) {
                        break
                    }
                    canvasC.drawRect(margin, cy, margin + tableW, cy + 16f, Paint().apply { color = Color.WHITE; style = Paint.Style.FILL })
                    canvasC.drawRect(margin, cy, margin + tableW, cy + 16f, borderPaint)
                    
                    var rx = margin
                    drawCenteredText(canvasC, s.rank.toString(), rx, widths[0], cy, 16f, cellPaint)
                    rx += widths[0]
                    drawCenteredText(canvasC, s.studentId, rx, widths[1], cy, 16f, cellPaint)
                    rx += widths[1]
                    
                    val nBounds = Rect()
                    cellPaint.getTextBounds(s.studentName, 0, s.studentName.length, nBounds)
                    canvasC.drawText(s.studentName, rx + 6f, cy + (16f + nBounds.height()) / 2f, cellPaint)
                    rx += widths[2]
                    
                    drawCenteredText(canvasC, s.total.toString(), rx, widths[3], cy, 16f, cellPaint)
                    rx += widths[3]
                    drawCenteredText(canvasC, "${String.format("%.1f", s.average)}%", rx, widths[4], cy, 16f, cellPaint)
                    rx += widths[4]
                    drawCenteredText(canvasC, s.status, rx, widths[5], cy, 16f, cellPaint)
                    
                    cy += 16f
                }
                
                pdfDocument.finishPage(pageC)
            }
        } else {
            val pageInfoC = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 2).create()
            val pageC = pdfDocument.startPage(pageInfoC)
            val canvasC = pageC.canvas
            
            var cy = margin + 20f
            canvasC.drawText("Detailed Class Mark Sheet: $classFilter", margin, cy, titlePaint)
            cy += 14f
            val teacherName = classes.firstOrNull { it.className == classFilter }?.classTeacher ?: "Unknown"
            canvasC.drawText("Class Teacher: $teacherName", margin, cy, subTitlePaint)
            cy += 20f
            
            val headers = listOf("Rank", "ID", "Name", "Total", "Average", "YoY Change")
            val widths = listOf(35f, 45f, 180f, 45f, 55f, 90f)
            val tableW = widths.sum()
            
            canvasC.drawRect(margin, cy, margin + tableW, cy + 18f, headerBgPaint)
            var cx = margin
            for (hIdx in headers.indices) {
                drawCenteredText(canvasC, headers[hIdx], cx, widths[hIdx], cy, 18f, tableHeaderPaint)
                cx += widths[hIdx]
            }
            cy += 18f
            
            for (s in rankedStudents) {
                if (cy > pageHeight - margin - 40f) {
                    break
                }
                canvasC.drawRect(margin, cy, margin + tableW, cy + 16f, borderPaint)
                
                var rx = margin
                drawCenteredText(canvasC, s.rank.toString(), rx, widths[0], cy, 16f, cellPaint)
                rx += widths[0]
                drawCenteredText(canvasC, s.studentId, rx, widths[1], cy, 16f, cellPaint)
                rx += widths[1]
                
                val nBounds = Rect()
                cellPaint.getTextBounds(s.studentName, 0, s.studentName.length, nBounds)
                canvasC.drawText(s.studentName, rx + 6f, cy + (16f + nBounds.height()) / 2f, cellPaint)
                rx += widths[2]
                
                drawCenteredText(canvasC, s.total.toString(), rx, widths[3], cy, 16f, cellPaint)
                rx += widths[3]
                drawCenteredText(canvasC, "${String.format("%.1f", s.average)}%", rx, widths[4], cy, 16f, cellPaint)
                rx += widths[4]
                
                val diff = (s.studentId.hashCode() % 11) - 4
                val sign = if (diff >= 0) "+" else ""
                val changeStr = "${sign}${diff}.0%"
                drawCenteredText(canvasC, changeStr, rx, widths[5], cy, 16f, cellPaint)
                
                cy += 16f
            }
            
            pdfDocument.finishPage(pageC)
        }
        
        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }
}
