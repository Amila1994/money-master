package com.example.utils

import android.content.Context
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.RelativeLayout
import io.agora.rtc.IRtcEngineEventHandler
import io.agora.rtc.RtcEngine
import io.agora.rtc.video.VideoCanvas
import io.agora.rtc.video.VideoEncoderConfiguration

class ChatCallController {

    private var mRtcEngine: RtcEngine? = null
    // 🔑 ඔයා ලබාදුන් Agora App ID එක මෙතනට සාර්ථකව ඇතුළත් කළා
    private val AGORA_APP_ID = "c4e26b154e784372842dbd1e8fa3ec95"
    private var localContainer: FrameLayout? = null
    private var remoteContainer: FrameLayout? = null
    private var videoLayout: RelativeLayout? = null

    // 📹 වීඩියෝ එන්ජින් එක Start කිරීම සහ ඩේටา අඩුවෙන් කැපෙන සෙටින්ග්ස් හැදීම
    fun initAgoraEngineAndJoinChannel(
        context: Context,
        channelName: String,
        localView: FrameLayout,
        remoteView: FrameLayout,
        layoutVideo: RelativeLayout
    ) {
        this.localContainer = localView
        this.remoteContainer = remoteView
        this.videoLayout = layoutVideo

        try {
            // 1. Agora Engine එක සෑදීම
            mRtcEngine = RtcEngine.create(context, AGORA_APP_ID, mRtcEventHandler)

            // 2. වීඩියෝ ක්රියාත්මක කිරීම
            mRtcEngine?.enableVideo()

            // ⚡ 3. ඩේටา ඉතිරි කරගන්න අපි කලින් කතා කරපු Low-Data Option එක සෙට් කිරීම (විනාඩි 10ට 30MB පමණ)
            val config = VideoEncoderConfiguration(
                VideoEncoderConfiguration.VD_320x240, // 240p සෙටින් එක
                VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15, // 15 FPS
                VideoEncoderConfiguration.STANDARD_BITRATE,
                VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_FIXED_PORTRAIT
            )
            mRtcEngine?.setVideoEncoderConfiguration(config)

            // 4. තමන්ගේ කැමරාව ක්රියාත්මක කර Screen එකට ගැනීම (Local View)
            if (isEmulator()) {
                val dummyView = View(context).apply {
                    setBackgroundColor(android.graphics.Color.DKGRAY)
                }
                localContainer?.addView(dummyView)
            } else {
                val surfaceView = RtcEngine.CreateTextureView(context)
                localContainer?.addView(surfaceView)
                mRtcEngine?.setupLocalVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, 0))
            }

            // 5. ඇප් දෙකම එකම චැනල් එකකට (Ticket ID එක නමින්) සම්බන්ධ කිරීම
            mRtcEngine?.joinChannel(null, channelName, "", 0)
            videoLayout?.visibility = View.VISIBLE

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun isEmulator(): Boolean {
        val brand = android.os.Build.BRAND
        val device = android.os.Build.DEVICE
        val model = android.os.Build.MODEL
        val product = android.os.Build.PRODUCT
        val hardware = android.os.Build.HARDWARE
        val fingerprint = android.os.Build.FINGERPRINT
        return brand.startsWith("generic") && device.startsWith("generic")
                || model.contains("google_sdk")
                || model.contains("Emulator")
                || model.contains("Android SDK built for x86")
                || hardware.contains("goldfish")
                || hardware.contains("ranchu")
                || product.contains("sdk")
                || product.contains("google_sdk")
                || product.contains("sdk_x86")
                || product.contains("vbox86p")
                || product.contains("emulator")
                || product.contains("simulator")
                || fingerprint.startsWith("generic")
                || fingerprint.startsWith("unknown")
    }

    // අනෙක් පාර්ශවය සම්බන්ධ වන විට එය බලාගන්නා Event Listener එක
    private val mRtcEventHandler = object : IRtcEngineEventHandler() {
        // අනෙක් කෙනා වීඩියෝ එක ඔන් කරලා රූම් එකට ආවම ක්රියාත්මක වේ
        override fun onUserJoined(uid: Int, elapsed: Int) {
            localContainer?.post {
                val context = localContainer?.context ?: return@post
                // අනෙක් කෙනාගේ වීඩියෝ එක (Remote View) Screen එකට සෙට් කිරීම
                if (isEmulator()) {
                    val dummyView = View(context).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                    }
                    remoteContainer?.addView(dummyView)
                } else {
                    val surfaceView = RtcEngine.CreateTextureView(context)
                    remoteContainer?.addView(surfaceView)
                    mRtcEngine?.setupRemoteVideo(VideoCanvas(surfaceView, VideoCanvas.RENDER_MODE_HIDDEN, uid))
                }
            }
        }

        // කෝල් එක කට් කළොත් හෝ අනෙක් කෙනා අයින් වුණොත්
        override fun onUserOffline(uid: Int, reason: Int) {
            localContainer?.post { leaveChannel() }
        }
    }

    // ❌ කෝල් එක ඉවර කරලා කැමරා වසා දැමීම
    fun leaveChannel() {
        if (mRtcEngine != null) {
            mRtcEngine?.leaveChannel()
            RtcEngine.destroy()
            mRtcEngine = null
        }
        if (videoLayout != null) {
            videoLayout?.visibility = View.GONE
            localContainer?.removeAllViews()
            remoteContainer?.removeAllViews()
        }
    }
}
