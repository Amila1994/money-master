package com.example.utils

import android.content.Context
import android.telephony.SmsManager
import android.os.Build
import android.util.Log
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object SmsService {
    private const val TAG = "SmsService"

    // Checks if the SEND_SMS permission is granted
    fun hasSmsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    // Sends the SMS using SmsManager in the background
    fun sendAutoSettleSms(
        context: Context,
        customerMobile: String,
        customerName: String,
        businessName: String
    ): SmsResult {
        if (!hasSmsPermission(context)) {
            Log.e(TAG, "❌ SEND_SMS permission is not granted.")
            return SmsResult.NoPermission
        }

        if (customerMobile.isBlank()) {
            Log.e(TAG, "❌ Customer mobile number is blank.")
            return SmsResult.Error("Mobile number is empty")
        }

        // Singlish message body as requested (under 160 characters to avoid extra costs)
        val messageBody = "Hithawath $customerName, oba $businessName ayathanayen labagath naya mudala sampurnayen berum kara atha. Obage wishwasayaata sthuthiyi! - Money Master"

        return try {
            @Suppress("DEPRECATION")
            val smsManager = SmsManager.getDefault()

            smsManager.sendTextMessage(customerMobile, null, messageBody, null, null)
            Log.d(TAG, "✓ SMS successfully sent to $customerMobile")
            SmsResult.Success
        } catch (e: Exception) {
            Log.e(TAG, "❌ Error sending SMS: ${e.message}", e)
            SmsResult.Error(e.message ?: "Unknown error")
        }
    }
}

sealed class SmsResult {
    object Success : SmsResult()
    object NoPermission : SmsResult()
    data class Error(val error: String) : SmsResult()
}
