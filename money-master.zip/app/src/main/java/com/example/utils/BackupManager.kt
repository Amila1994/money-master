package com.example.utils

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object BackupManager {
    private const val TAG = "BackupManager"
    private const val PREFS_NAME = "BackupManagerPrefs"
    private const val KEY_ACCESS_TOKEN = "google_access_token"
    private const val BACKUP_FILE_NAME = "school_app_backup.json"
    private const val FOLDER_NAME = "School App"

    /**
     * Save the Google OAuth2 access token.
     */
    fun saveAccessToken(context: Context, token: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ACCESS_TOKEN, token)
            .apply()
    }

    /**
     * Retrieve the Google OAuth2 access token.
     */
    fun getAccessToken(context: Context): String? {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACCESS_TOKEN, null)
    }

    /**
     * Backup the data. It first writes to local fallback file, then uploads/overwrites 
     * on Google Drive in the background if Google Drive access is configured.
     */
    suspend fun performBackup(context: Context, jsonStr: String): Boolean = withContext(Dispatchers.IO) {
        try {
            // 1. Save to local fallback file first
            val localFile = File(context.filesDir, BACKUP_FILE_NAME)
            localFile.writeText(jsonStr)
            Log.d(TAG, "Local backup saved successfully to ${localFile.absolutePath}")

            // 2. Check if Google Drive is configured
            val accessToken = getAccessToken(context)
            if (accessToken.isNullOrBlank()) {
                Log.d(TAG, "Google Drive access token not configured. Backup saved to local fallback.")
                return@withContext true
            }

            // 3. Search for "School App" folder
            var folderId = GoogleDriveService.searchFile(accessToken, FOLDER_NAME)
            if (folderId == null) {
                folderId = GoogleDriveService.createFolder(accessToken, FOLDER_NAME)
            }

            if (folderId == null) {
                Log.e(TAG, "Could not locate or create School App folder.")
                return@withContext true // return true since local backup succeeded
            }

            // 4. Search for "school_app_backup.json" inside that folder
            val fileId = GoogleDriveService.searchFile(accessToken, BACKUP_FILE_NAME, folderId)
            
            if (fileId != null) {
                // Overwrite/Update existing file
                val success = GoogleDriveService.updateFile(accessToken, fileId, "application/json", jsonStr)
                if (success) {
                    Log.d(TAG, "Google Drive backup updated successfully (Overwritten).")
                } else {
                    Log.e(TAG, "Google Drive backup overwrite failed.")
                }
            } else {
                // Create new file under the folder
                val newFileId = GoogleDriveService.uploadFile(accessToken, folderId, BACKUP_FILE_NAME, "application/json", jsonStr)
                if (newFileId != null) {
                    Log.d(TAG, "Google Drive backup created successfully inside School App folder.")
                } else {
                    Log.e(TAG, "Google Drive backup creation failed.")
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Backup failed: ${e.message}", e)
            false
        }
    }

    /**
     * Restore the data. It tries to fetch "school_app_backup.json" from Google Drive.
     * If Google Drive is not configured or fails, it falls back to the local backup file.
     */
    suspend fun performRestore(context: Context): String? = withContext(Dispatchers.IO) {
        try {
            // 1. Try Google Drive first if access token is configured
            val accessToken = getAccessToken(context)
            if (!accessToken.isNullOrBlank()) {
                val folderId = GoogleDriveService.searchFile(accessToken, FOLDER_NAME)
                if (folderId != null) {
                    val fileId = GoogleDriveService.searchFile(accessToken, BACKUP_FILE_NAME, folderId)
                    if (fileId != null) {
                        val driveContent = GoogleDriveService.downloadFile(accessToken, fileId)
                        if (driveContent != null) {
                            Log.d(TAG, "Data restored successfully from Google Drive.")
                            // Cache it locally too
                            val localFile = File(context.filesDir, BACKUP_FILE_NAME)
                            localFile.writeText(driveContent)
                            return@withContext driveContent
                        }
                    }
                }
            }

            // 2. Fallback to local backup file
            val localFile = File(context.filesDir, BACKUP_FILE_NAME)
            if (localFile.exists()) {
                Log.d(TAG, "Data restored successfully from local fallback file.")
                return@withContext localFile.readText()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Restore failed: ${e.message}", e)
        }
        null
    }
}
