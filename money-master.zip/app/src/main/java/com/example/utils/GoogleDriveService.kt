package com.example.utils

import android.content.Context
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileOutputStream
import java.util.Collections

object GoogleDriveService {
    private const val TAG = "GoogleDriveService"
    private const val BACKUP_FILE_NAME = "money_master_backup.db"

    private fun getDriveService(context: Context): Drive? {
        val account = GoogleSignIn.getLastSignedInAccount(context) ?: return null
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_APPDATA)
        ).setSelectedAccount(account.account)

        return Drive.Builder(
            com.google.api.client.http.javanet.NetHttpTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("Money Master").build()
    }

    suspend fun uploadBackup(context: Context, onResult: (Boolean, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(context)
            if (driveService == null) {
                onResult(false, "Google Drive not connected. Please connect first.")
                return@withContext
            }

            val dbFile = context.getDatabasePath("money_master_database")
            if (!dbFile.exists()) {
                onResult(false, "Local database does not exist.")
                return@withContext
            }

            // Find existing backup file in AppData folder
            val result = driveService.files().list()
                .setSpaces("appDataFolder")
                .setQ("name = '$BACKUP_FILE_NAME'")
                .execute()

            val existingFiles = result.files
            val fileMetadata = File().apply {
                name = BACKUP_FILE_NAME
                parents = Collections.singletonList("appDataFolder")
            }

            val mediaContent = FileContent("application/octet-stream", dbFile)

            if (!existingFiles.isNullOrEmpty()) {
                // Update existing file
                val existingFileId = existingFiles[0].id
                driveService.files().update(existingFileId, null, mediaContent).execute()
                onResult(true, "Database updated successfully on Google Drive AppData folder.")
            } else {
                // Create new file
                driveService.files().create(fileMetadata, mediaContent).execute()
                onResult(true, "Database backup uploaded successfully to Google Drive AppData folder.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error uploading backup", e)
            onResult(false, "Failed to upload: ${e.localizedMessage ?: e.message}")
        }
    }

    suspend fun restoreBackup(context: Context, onResult: (Boolean, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(context)
            if (driveService == null) {
                onResult(false, "Google Drive not connected. Please connect first.")
                return@withContext
            }

            val result = driveService.files().list()
                .setSpaces("appDataFolder")
                .setQ("name = '$BACKUP_FILE_NAME'")
                .execute()

            val files = result.files
            if (files.isNullOrEmpty()) {
                onResult(false, "No backup found in Google Drive AppData folder.")
                return@withContext
            }

            val fileId = files[0].id
            val dbFile = context.getDatabasePath("money_master_database")
            
            val outputStream = FileOutputStream(dbFile)
            driveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
            outputStream.close()

            // Delete wal and shm if they exist to prevent sync conflict
            val walFile = context.getDatabasePath("money_master_database-wal")
            if (walFile.exists()) walFile.delete()
            val shmFile = context.getDatabasePath("money_master_database-shm")
            if (shmFile.exists()) shmFile.delete()

            onResult(true, "Backup restored successfully. Restarting the app...")
        } catch (e: Exception) {
            Log.e(TAG, "Error restoring backup", e)
            onResult(false, "Failed to restore: ${e.localizedMessage ?: e.message}")
        }
    }
}
