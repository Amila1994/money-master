package com.example.utils

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

object GoogleDriveService {
    private const val TAG = "GoogleDriveService"
    private val client = OkHttpClient()

    /**
     * Search for a file or folder by name and optional parent ID.
     */
    suspend fun searchFile(accessToken: String, name: String, parentId: String? = null): String? = withContext(Dispatchers.IO) {
        try {
            var query = "name = '$name' and trashed = false"
            if (parentId != null) {
                query += " and '$parentId' in parents"
            }
            
            val url = "https://www.googleapis.com/drive/v3/files?q=${java.net.URLEncoder.encode(query, "UTF-8")}&fields=files(id, name)"
            
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()
                
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext null
                    val json = JSONObject(body)
                    val files = json.optJSONArray("files")
                    if (files != null && files.length() > 0) {
                        return@withContext files.getJSONObject(0).getString("id")
                    }
                } else {
                    Log.e(TAG, "Search file failed: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error searching file: ${e.message}", e)
        }
        null
    }

    /**
     * Create a folder in Google Drive.
     */
    suspend fun createFolder(accessToken: String, folderName: String, parentId: String? = null): String? = withContext(Dispatchers.IO) {
        try {
            val url = "https://www.googleapis.com/drive/v3/files"
            val metadata = JSONObject().apply {
                put("name", folderName)
                put("mimeType", "application/vnd.google-apps.folder")
                if (parentId != null) {
                    put("parents", org.json.JSONArray().put(parentId))
                }
            }
            
            val requestBody = metadata.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .post(requestBody)
                .build()
                
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext null
                    val json = JSONObject(body)
                    return@withContext json.getString("id")
                } else {
                    Log.e(TAG, "Create folder failed: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error creating folder: ${e.message}", e)
        }
        null
    }

    /**
     * Upload a new file (Multipart upload containing metadata + content).
     */
    suspend fun uploadFile(accessToken: String, parentId: String?, fileName: String, mimeType: String, content: String): String? = withContext(Dispatchers.IO) {
        try {
            val url = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
            val metadata = JSONObject().apply {
                put("name", fileName)
                if (parentId != null) {
                    put("parents", org.json.JSONArray().put(parentId))
                }
            }
            
            val multipartBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addPart(
                    metadata.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
                )
                .addPart(
                    content.toRequestBody(mimeType.toMediaTypeOrNull())
                )
                .build()
                
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .post(multipartBody)
                .build()
                
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: return@withContext null
                    val json = JSONObject(body)
                    return@withContext json.getString("id")
                } else {
                    Log.e(TAG, "Upload file failed: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error uploading file: ${e.message}", e)
        }
        null
    }

    /**
     * Overwrite/update an existing file's media content.
     */
    suspend fun updateFile(accessToken: String, fileId: String, mimeType: String, content: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val url = "https://www.googleapis.com/upload/drive/v3/files/$fileId?uploadType=media"
            val requestBody = content.toRequestBody(mimeType.toMediaTypeOrNull())
            
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .patch(requestBody)
                .build()
                
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    return@withContext true
                } else {
                    Log.e(TAG, "Update file failed: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating file: ${e.message}", e)
        }
        false
    }

    /**
     * Download a file's content by ID.
     */
    suspend fun downloadFile(accessToken: String, fileId: String): String? = withContext(Dispatchers.IO) {
        try {
            val url = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .get()
                .build()
                
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    return@withContext response.body?.string()
                } else {
                    Log.e(TAG, "Download file failed: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error downloading file: ${e.message}", e)
        }
        null
    }
}
