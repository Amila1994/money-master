package com.example.utils

import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Collections

object GoogleDriveService {

    private fun getDriveService(context: Context): Drive? {
        val googleSignInAccount = GoogleSignIn.getLastSignedInAccount(context) ?: return null
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_APPDATA)
        )
        credential.selectedAccount = googleSignInAccount.account
        return Drive.Builder(
            NetHttpTransport(),
            GsonFactory(),
            credential
        )
        .setApplicationName("Money Master")
        .build()
    }

    fun getAccessToken(context: Context): String? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return account?.idToken ?: account?.email
    }

    suspend fun uploadBackup(context: Context, onResult: (Boolean, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(context)
            if (driveService == null) {
                onResult(false, "Google Drive not connected. Please connect first.")
                return@withContext
            }

            val dbFile = context.getDatabasePath("money_master_database")
            if (!dbFile.exists()) {
                onResult(false, "Database file does not exist.")
                return@withContext
            }

            // Search if file already exists in AppData
            val query = "name = 'moneymaster_backup.db' and 'appDataFolder' in parents and trashed = false"
            val fileList = driveService.files().list()
                .setSpaces("appDataFolder")
                .setQ(query)
                .execute()

            val files = fileList.files
            val fileMetadata = com.google.api.services.drive.model.File().apply {
                name = "moneymaster_backup.db"
                parents = Collections.singletonList("appDataFolder")
            }
            val mediaContent = FileContent("application/x-sqlite3", dbFile)

            if (files != null && files.isNotEmpty()) {
                // Update existing file
                val existingFileId = files[0].id
                driveService.files().update(existingFileId, null, mediaContent).execute()
                onResult(true, "Database updated successfully on Google Drive AppData folder.")
            } else {
                // Create new file
                driveService.files().create(fileMetadata, mediaContent).execute()
                onResult(true, "Database backup uploaded successfully to Google Drive AppData folder.")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            onResult(false, "Failed to backup: ${e.message}")
        }
    }

    suspend fun restoreBackup(context: Context, onResult: (Boolean, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(context)
            if (driveService == null) {
                onResult(false, "Google Drive not connected. Please connect first.")
                return@withContext
            }

            // Search if backup file exists
            val query = "name = 'moneymaster_backup.db' and 'appDataFolder' in parents and trashed = false"
            val fileList = driveService.files().list()
                .setSpaces("appDataFolder")
                .setQ(query)
                .execute()

            val files = fileList.files
            if (files == null || files.isEmpty()) {
                onResult(false, "No backup found in Google Drive AppData folder.")
                return@withContext
            }

            val fileId = files[0].id
            val dbFile = context.getDatabasePath("money_master_database")

            val tempFile = File(context.cacheDir, "temp_backup.db")
            FileOutputStream(tempFile).use { outputStream ->
                driveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
            }

            // Overwrite actual DB files (including journal/wal files if exist)
            if (tempFile.exists() && tempFile.length() > 0) {
                val walFile = File(dbFile.path + "-wal")
                val shmFile = File(dbFile.path + "-shm")
                if (walFile.exists()) walFile.delete()
                if (shmFile.exists()) shmFile.delete()
                
                tempFile.copyTo(dbFile, overwrite = true)
                tempFile.delete()
                onResult(true, "Database restored successfully. Restarting app...")
            } else {
                onResult(false, "Downloaded backup file is empty.")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            onResult(false, "Failed to restore: ${e.message}")
        }
    }
}
