package com.example.utils

import android.content.Context
import android.util.Log
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object GoogleDriveService {
    private const val TAG = "GoogleDriveService"
    private val client = OkHttpClient()

    // Retrieve OAuth2 Token for Google Drive appdata scope
    fun getAccessToken(context: Context): String? {
        val account = GoogleSignIn.getLastSignedInAccount(context) ?: return null
        return try {
            GoogleAuthUtil.getToken(
                context,
                account.account ?: return null,
                "oauth2:https://www.googleapis.com/auth/drive.appdata"
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error getting access token", e)
            null
        }
    }

    // Upload backup file to Google Drive App Data folder
    fun uploadBackup(context: Context, onResult: (Boolean, String) -> Unit) {
        val dbFile = context.getDatabasePath("money_master_database")
        if (!dbFile.exists()) {
            onResult(false, "Database file does not exist")
            return
        }

        // Before uploading, force a checkpoint to ensure all WAL data is written to the main DB file
        try {
            val db = com.example.data.AppDatabase.getDatabase(context)
            db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to checkpoint WAL", e)
        }

        Thread {
            try {
                val token = getAccessToken(context)
                if (token == null) {
                    onResult(false, "Could not acquire access token. Please reconnect Google Drive.")
                    return@Thread
                }

                // First, query if there is an existing backup file to update it or delete it to avoid duplicates
                val existingFileId = findBackupFile(token)

                val metadataJson = JSONObject().apply {
                    put("name", "money_master_backup.db")
                    if (existingFileId == null) {
                        put("parents", listOf("appDataFolder"))
                    }
                }

                val boundary = "Boundary_" + System.currentTimeMillis()
                val mediaType = "multipart/related; boundary=$boundary".toMediaType()

                val metadataPart = "--$boundary\r\n" +
                        "Content-Type: application/json; charset=UTF-8\r\n\r\n" +
                        metadataJson.toString() + "\r\n"

                val fileHeader = "--$boundary\r\n" +
                        "Content-Type: application/octet-stream\r\n\r\n"

                val fileBytes = dbFile.readBytes()

                val footer = "\r\n--$boundary--\r\n"

                val requestBodyBytes = java.io.ByteArrayOutputStream()
                requestBodyBytes.write(metadataPart.toByteArray(Charsets.UTF_8))
                requestBodyBytes.write(fileHeader.toByteArray(Charsets.UTF_8))
                requestBodyBytes.write(fileBytes)
                requestBodyBytes.write(footer.toByteArray(Charsets.UTF_8))

                val requestBody = requestBodyBytes.toByteArray().toRequestBody(mediaType)

                val url = if (existingFileId != null) {
                    "https://www.googleapis.com/upload/drive/v3/files/$existingFileId?uploadType=multipart"
                } else {
                    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
                }

                val method = if (existingFileId != null) "PATCH" else "POST"

                val request = Request.Builder()
                    .url(url)
                    .header("Authorization", "Bearer $token")
                    .method(method, requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        onResult(true, "Backup uploaded successfully!")
                    } else {
                        onResult(false, "Server error: ${response.code} ${response.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Upload failed", e)
                onResult(false, "Upload failed: ${e.message}")
            }
        }.start()
    }

    private fun findBackupFile(token: String): String? {
        val request = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files?q=name='money_master_backup.db'+and+'appDataFolder'+in+parents&spaces=appDataFolder")
            .header("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val jsonStr = response.body?.string() ?: return null
                val files = JSONObject(jsonStr).optJSONArray("files")
                if (files != null && files.length() > 0) {
                    return files.getJSONObject(0).optString("id")
                }
            }
        }
        return null
    }

    // Restore database backup from Google Drive
    fun restoreBackup(context: Context, onResult: (Boolean, String) -> Unit) {
        Thread {
            try {
                val token = getAccessToken(context)
                if (token == null) {
                    onResult(false, "Could not acquire access token. Please reconnect Google Drive.")
                    return@Thread
                }

                val existingFileId = findBackupFile(token)
                if (existingFileId == null) {
                    onResult(false, "No backup found in Google Drive")
                    return@Thread
                }

                val request = Request.Builder()
                    .url("https://www.googleapis.com/drive/v3/files/$existingFileId?alt=media")
                    .header("Authorization", "Bearer $token")
                    .get()
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val bytes = response.body?.bytes() ?: throw IOException("Empty response body")
                        
                        // Close existing database instance before overwriting
                        try {
                            com.example.data.AppDatabase.getDatabase(context).close()
                        } catch (e: Exception) {
                            Log.e(TAG, "Error closing database", e)
                        }

                        val dbFile = context.getDatabasePath("money_master_database")
                        
                        // Delete WAL and SHM files to avoid conflicts with new DB
                        val walFile = File(dbFile.absolutePath + "-wal")
                        val shmFile = File(dbFile.absolutePath + "-shm")
                        if (walFile.exists()) walFile.delete()
                        if (shmFile.exists()) shmFile.delete()

                        FileOutputStream(dbFile).use { fos ->
                            fos.write(bytes)
                        }

                        onResult(true, "Database restored successfully!")
                    } else {
                        onResult(false, "Server error: ${response.code} ${response.message}")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Restore failed", e)
                onResult(false, "Restore failed: ${e.message}")
            }
        }.start()
    }
}
