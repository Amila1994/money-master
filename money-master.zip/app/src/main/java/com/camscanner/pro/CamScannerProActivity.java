package com.camscanner.pro;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import java.util.LinkedList;
import java.util.Queue;

public class CamScannerProActivity extends ComponentActivity {
    private ImageView ivPreview;
    private Bitmap finalDisplayBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.R.layout.activity_cam_scanner_pro);

        ivPreview = findViewById(com.example.R.id.ivPreview);
        
        // Smart Erase Listener (එක තැනක එබූ විට සම්පූර්ණ හැඩතලයම මැකීම)
        ivPreview.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                if (finalDisplayBitmap != null && ivPreview.getWidth() > 0 && ivPreview.getHeight() > 0) {
                    int x = (int) (event.getX() * (finalDisplayBitmap.getWidth() / (float) ivPreview.getWidth()));
                    int y = (int) (event.getY() * (finalDisplayBitmap.getHeight() / (float) ivPreview.getHeight()));
                    eraseObjectAt(x, y); // AI Eraser එක ක්‍රියාත්මක වේ
                }
            }
            return true;
        });
    }

    public void eraseObjectAt(int x, int y) {
        if (finalDisplayBitmap == null) return;
        if (x < 0 || x >= finalDisplayBitmap.getWidth() || y < 0 || y >= finalDisplayBitmap.getHeight()) return;
        
        int targetColor = finalDisplayBitmap.getPixel(x, y);
        // අපි මකන්න ඕනේ අකුරු (කළු පාට වගේ දේවල්). පසුබිම සුදු නම් ඒක මකන්නේ නැහැ.
        if (targetColor == Color.WHITE) return;

        // Queue-based BFS Flood Fill to prevent StackOverflow on Android
        floodFill(x, y, targetColor, Color.WHITE);
        ivPreview.setImageBitmap(finalDisplayBitmap);
        Toast.makeText(this, "Object Erased! / හැඩතලය මැකී ගියේය!", Toast.LENGTH_SHORT).show();
    }

    private void floodFill(int startX, int startY, int targetColor, int replacementColor) {
        if (targetColor == replacementColor) return;
        int width = finalDisplayBitmap.getWidth();
        int height = finalDisplayBitmap.getHeight();
        
        if (startX < 0 || startX >= width || startY < 0 || startY >= height) return;
        if (finalDisplayBitmap.getPixel(startX, startY) != targetColor) return;

        Queue<Point> queue = new LinkedList<>();
        queue.add(new Point(startX, startY));
        finalDisplayBitmap.setPixel(startX, startY, replacementColor);

        while (!queue.isEmpty()) {
            Point p = queue.poll();

            // 4-directional flood fill
            int[] dx = {1, -1, 0, 0};
            int[] dy = {0, 0, 1, -1};

            for (int i = 0; i < 4; i++) {
                int nx = p.x + dx[i];
                int ny = p.y + dy[i];

                if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
                    if (finalDisplayBitmap.getPixel(nx, ny) == targetColor) {
                        finalDisplayBitmap.setPixel(nx, ny, replacementColor);
                        queue.add(new Point(nx, ny));
                    }
                }
            }
        }
    }

    private static class Point {
        int x, y;
        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}
