package com.moneymaster.cleanapp.utils

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

object PdfReportService {
    private const val TAG = "PdfReportService"

    // Helper to format currency in PDF
    private fun formatCurrency(amount: Double): String {
        return String.format(Locale.getDefault(), "%s %,.2f", LocalizedText.selectedCurrencySymbol, amount)
    }

    private fun drawEmbeddedImage(context: Context, canvas: Canvas, uriStr: String, left: Float, top: Float, maxWidth: Float, maxHeight: Float) {
        if (uriStr.isEmpty()) return
        try {
            val imageUri = Uri.parse(uriStr)
            val inputStream = context.contentResolver.openInputStream(imageUri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            if (bitmap != null) {
                // Calculate scale to fit maxWidth and maxHeight while maintaining aspect ratio
                val scale = Math.min(maxWidth / bitmap.width, maxHeight / bitmap.height)
                val newWidth = (bitmap.width * scale).toInt()
                val newHeight = (bitmap.height * scale).toInt()
                val scaledBitmap = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
                
                // Draw image centered inside bounding box with filtering enabled
                canvas.drawBitmap(scaledBitmap, left + (maxWidth - newWidth)/2f, top + (maxHeight - newHeight)/2f, Paint().apply { isFilterBitmap = true })
                bitmap.recycle()
                scaledBitmap.recycle()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error drawing embedded image for URI $uriStr: ${e.message}")
        }
    }

    // Main function to generate PDF
    fun generatePdfReport(
        context: Context,
        loan: Loan,
        customer: Customer?,
        payments: List<Payment>,
        summary: LoanSummary,
        lang: Language,
        ownerName: String,
        ownerPhone: String,
        ownerPhotoUri: String = ""
    ): File? {
        val document = PdfDocument()
        
        // A4 page size in postscript points (595 x 842)
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        // Paints for drawing
        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val subTitlePaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val sectionPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val boldTextPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        val borderPaint = Paint().apply {
            color = Color.GRAY
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }

        val rectBgPaint = Paint().apply {
            color = Color.parseColor("#F5F5F5")
            style = Paint.Style.FILL
        }

        val tableHeaderPaint = Paint().apply {
            color = Color.parseColor("#E0E0E0")
            style = Paint.Style.FILL
        }

        // Draw page border
        canvas.drawRect(15f, 15f, 580f, 827f, borderPaint)

        var yPos = 45f

        // 1. BUSINESS HEADER
        val businessName = ownerName.ifEmpty { LocalizedText.get("business_name", lang) }
        val businessAddress = LocalizedText.get("business_address", lang)
        val businessPhone = if (ownerPhone.isNotEmpty()) "${LocalizedText.get("customer_phone_label", lang)}: $ownerPhone" else LocalizedText.get("business_phones", lang)

        // Draw Business Photo / Logo if present at top right
        if (ownerPhotoUri.isNotEmpty()) {
            try {
                val imageUri = Uri.parse(ownerPhotoUri)
                val inputStream = context.contentResolver.openInputStream(imageUri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bitmap != null) {
                    val size = 60
                    val scaledBitmap = Bitmap.createScaledBitmap(bitmap, size, size, true)
                    canvas.drawBitmap(scaledBitmap, 500f, 25f, Paint().apply { isFilterBitmap = true })
                }
            } catch (e: Exception) {
                Log.e("PdfReportService", "Error loading business photo for PDF: ${e.message}")
            }
        }

        canvas.drawText(businessName, 35f, yPos, titlePaint)
        yPos += 18f
        canvas.drawText(businessAddress, 35f, yPos, subTitlePaint)
        yPos += 14f
        canvas.drawText(businessPhone, 35f, yPos, subTitlePaint)
        
        yPos += 12f
        canvas.drawLine(35f, yPos, 560f, yPos, linePaint)
        
        // Document Title
        yPos += 22f
        val docTitle = LocalizedText.get("report_title", lang)
        canvas.drawText(docTitle, 35f, yPos, sectionPaint)

        // Loan ID (Top Right)
        val yearFormat = SimpleDateFormat("yyyy", Locale.getDefault())
        val yearStr = yearFormat.format(Date(loan.startDate))
        val formattedLoanId = "LN-$yearStr-${String.format(Locale.getDefault(), "%03d", loan.id)}"
        val idLabel = "Loan ID: $formattedLoanId"
        val idWidth = boldTextPaint.measureText(idLabel)
        canvas.drawText(idLabel, 560f - idWidth, yPos, boldTextPaint)
        
        // 2. CUSTOMER PROFILE CARD
        yPos += 15f
        val cardTop = yPos
        val cardHeight = 70f
        canvas.drawRoundRect(35f, cardTop, 560f, cardTop + cardHeight, 8f, 8f, rectBgPaint)
        
        val cName = customer?.name ?: loan.borrowerName
        val cNic = "${LocalizedText.get("customer_nic_label", lang)}${customer?.nic ?: "N/A"}"
        val cPhone = "${LocalizedText.get("customer_phone_label", lang)}${customer?.phone ?: loan.borrowerPhone}"
        val cAddress = "${LocalizedText.get("customer_address_label", lang)}${customer?.address ?: "N/A"}"

        canvas.drawText(cName, 45f, yPos + 18f, boldTextPaint)
        canvas.drawText(cNic, 45f, yPos + 32f, textPaint)
        canvas.drawText(cPhone, 45f, yPos + 46f, textPaint)
        canvas.drawText(cAddress, 45f, yPos + 60f, textPaint)

        yPos += cardHeight + 20f

        // 3. LOAN SUMMARY DETAILS
        canvas.drawText(LocalizedText.get("loan_summary_title", lang), 35f, yPos, sectionPaint)
        yPos += 12f
        
        // Grid Box
        val gridTop = yPos
        val gridHeight = 45f
        canvas.drawRoundRect(35f, gridTop, 560f, gridTop + gridHeight, 8f, 8f, rectBgPaint)
        
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val loanDateStr = dateFormat.format(Date(loan.startDate))
        val statusStr = if (loan.isSettled) LocalizedText.get("settled_status_label", lang) else LocalizedText.get("active_status_label", lang)
        
        // Column 1
        canvas.drawText(LocalizedText.get("total_loan_amount", lang), 45f, yPos + 16f, subTitlePaint)
        canvas.drawText(formatCurrency(loan.principalAmount), 45f, yPos + 32f, boldTextPaint)

        // Column 2
        canvas.drawText(LocalizedText.get("interest_rate", lang).replace(" (%)", ""), 180f, yPos + 16f, subTitlePaint)
        val periodLabel = when (loan.interestPeriod) {
            "Daily" -> LocalizedText.get("daily", lang)
            "Weekly" -> LocalizedText.get("weekly", lang)
            "Monthly" -> LocalizedText.get("monthly", lang)
            else -> loan.interestPeriod
        }
        canvas.drawText("${loan.interestRate}% ($periodLabel)", 180f, yPos + 32f, boldTextPaint)

        // Column 3
        canvas.drawText(LocalizedText.get("loan_date", lang), 320f, yPos + 16f, subTitlePaint)
        canvas.drawText(loanDateStr, 320f, yPos + 32f, boldTextPaint)

        // Column 4
        canvas.drawText(LocalizedText.get("current_status", lang), 450f, yPos + 16f, subTitlePaint)
        canvas.drawText(statusStr, 450f, yPos + 32f, boldTextPaint)

        yPos += gridHeight + 20f

        // Notes if any
        if (loan.notes.isNotEmpty()) {
            canvas.drawText(LocalizedText.get("notes", lang) + ": " + loan.notes, 35f, yPos, textPaint)
            yPos += 18f
        }

        // 4. TRANSACTION HISTORY TABLE
        canvas.drawText(LocalizedText.get("history_table_title", lang), 35f, yPos, sectionPaint)
        yPos += 12f

        // Table headers
        val tableTop = yPos
        canvas.drawRect(35f, tableTop, 560f, tableTop + 20f, tableHeaderPaint)
        
        val colDateX = 45f
        val colDescX = 180f
        val colAmountX = 480f

        canvas.drawText(LocalizedText.get("table_header_date", lang), colDateX, yPos + 14f, boldTextPaint)
        canvas.drawText(LocalizedText.get("table_header_desc", lang), colDescX, yPos + 14f, boldTextPaint)
        canvas.drawText(LocalizedText.get("table_header_amount", lang), colAmountX, yPos + 14f, boldTextPaint)

        yPos += 20f

        // Add disbursement row
        canvas.drawText(loanDateStr, colDateX, yPos + 14f, textPaint)
        canvas.drawText(LocalizedText.get("tx_loan_disbursed", lang), colDescX, yPos + 14f, textPaint)
        canvas.drawText(formatCurrency(loan.principalAmount), colAmountX, yPos + 14f, textPaint)
        canvas.drawLine(35f, yPos + 20f, 560f, yPos + 20f, linePaint)
        yPos += 20f

        // Payments
        payments.forEach { p ->
            // If yPos gets too close to the bottom, we should stop or handle it (standard payments list is typically small)
            if (yPos > 720f) {
                // Keep inside 1 page for safety
                return@forEach
            }
            val pDateStr = dateFormat.format(Date(p.paymentDate))
            val pDesc = when (p.type) {
                "Interest" -> LocalizedText.get("tx_interest_payment", lang)
                "Principal" -> LocalizedText.get("tx_principal_payment", lang)
                else -> LocalizedText.get("full_settle", lang)
            }
            
            canvas.drawText(pDateStr, colDateX, yPos + 14f, textPaint)
            canvas.drawText(pDesc, colDescX, yPos + 14f, textPaint)
            canvas.drawText(formatCurrency(p.amount), colAmountX, yPos + 14f, textPaint)
            canvas.drawLine(35f, yPos + 20f, 560f, yPos + 20f, linePaint)
            yPos += 20f
        }

        // Next pending interest row if not settled
        if (!loan.isSettled && yPos < 740f) {
            val todayStr = if (lang == Language.SINHALA) "අද දිනය" else "Today"
            canvas.drawText(todayStr, colDateX, yPos + 14f, textPaint)
            canvas.drawText(LocalizedText.get("tx_outstanding_interest", lang), colDescX, yPos + 14f, textPaint)
            canvas.drawText(formatCurrency(summary.outstandingInterest), colAmountX, yPos + 14f, textPaint)
            canvas.drawLine(35f, yPos + 20f, 560f, yPos + 20f, linePaint)
            yPos += 20f
        }

        // Totals summary section
        yPos += 15f
        if (yPos < 750f) {
            val totalPaidStr = if (lang == Language.SINHALA) "ගෙවූ මුළු මුදල" else "Total Paid Amount"
            val totalRemainingStr = if (lang == Language.SINHALA) "ගෙවීමට ඇති මුළු මුදල" else "Total Outstanding Amount"
            val totalPaidVal = summary.paidPrincipal + summary.paidInterest

            canvas.drawText("$totalPaidStr: ${formatCurrency(totalPaidVal)}", 350f, yPos, boldTextPaint)
            yPos += 16f
            canvas.drawText("$totalRemainingStr: ${formatCurrency(summary.totalOutstanding)}", 350f, yPos, boldTextPaint)
        }

        // Footer Thank You
        yPos = 780f
        canvas.drawText(LocalizedText.get("thank_you_title", lang), 297f - (sectionPaint.measureText(LocalizedText.get("thank_you_title", lang)) / 2f), yPos, sectionPaint)
        yPos += 14f
        val footerSub = LocalizedText.get("thank_you_sub", lang)
        canvas.drawText(footerSub, 297f - (subTitlePaint.measureText(footerSub) / 2f), yPos, subTitlePaint)

        document.finishPage(page)

        // 5. ATTACHMENTS PAGE (PAGE 2)
        val hasCustomerPhoto = !customer?.photoUri.isNullOrBlank()
        val hasNicPhoto = !customer?.nicPhotoUri.isNullOrBlank()
        val hasAgreementLetter = !customer?.agreementLetterUri.isNullOrBlank()

        if (hasCustomerPhoto || hasNicPhoto || hasAgreementLetter) {
            val pageInfo2 = PdfDocument.PageInfo.Builder(595, 842, 2).create()
            val page2 = document.startPage(pageInfo2)
            val canvas2 = page2.canvas

            // Draw border
            canvas2.drawRect(15f, 15f, 580f, 827f, borderPaint)

            // Header Section
            val attachmentsTitle = if (lang == Language.SINHALA) "ඇමුණුම් සහ පරිලෝකනය කරන ලද ලියකියවිලි" else if (lang == Language.TAMIL) "இணைப்புகள் மற்றும் ஸ்கேன் செய்யப்பட்ட ஆவணங்கள்" else "Attachments & Scanned Documents"
            canvas2.drawText(attachmentsTitle, 35f, 45f, sectionPaint)
            canvas2.drawLine(35f, 55f, 560f, 55f, linePaint)

            // Draw Customer Photo (Bounding box 150x150)
            if (hasCustomerPhoto) {
                val label = if (lang == Language.SINHALA) "පාරිභෝගික ඡායාරූපය (Customer Photo)" else if (lang == Language.TAMIL) "வாடிக்கையாளர் புகைப்படம் (Customer Photo)" else "Customer Photo"
                canvas2.drawText(label, 35f, 75f, boldTextPaint)
                canvas2.drawRoundRect(35f, 85f, 210f, 235f, 6f, 6f, rectBgPaint)
                drawEmbeddedImage(context, canvas2, customer!!.photoUri, 35f, 85f, 175f, 150f)
            } else {
                canvas2.drawText("Customer Photo: N/A", 35f, 75f, subTitlePaint)
            }

            // Draw NIC Photo (Bounding box 220x130)
            if (hasNicPhoto) {
                val label = if (lang == Language.SINHALA) "ජාතික හැඳුනුම්පත (NIC Photo)" else if (lang == Language.TAMIL) "தேசிய அடையாள அட்டை (NIC Photo)" else "National Identity Card (NIC)"
                canvas2.drawText(label, 35f, 265f, boldTextPaint)
                canvas2.drawRoundRect(35f, 275f, 255f, 405f, 6f, 6f, rectBgPaint)
                drawEmbeddedImage(context, canvas2, customer!!.nicPhotoUri, 35f, 275f, 220f, 130f)
            } else {
                canvas2.drawText("NIC Photo: N/A", 35f, 265f, subTitlePaint)
            }

            // Draw Scanned Agreement Letter (Bounding box 260x420)
            if (hasAgreementLetter) {
                val label = if (lang == Language.SINHALA) "ගිවිසුම් ලිපිය (Agreement Letter)" else if (lang == Language.TAMIL) "ஒப்பந்தக் கடிதம் (Agreement Letter)" else "Scanned Agreement Letter"
                canvas2.drawText(label, 295f, 75f, boldTextPaint)
                canvas2.drawRoundRect(295f, 85f, 560f, 505f, 6f, 6f, rectBgPaint)
                drawEmbeddedImage(context, canvas2, customer!!.agreementLetterUri, 295f, 85f, 265f, 420f)
            } else {
                canvas2.drawRoundRect(295f, 85f, 560f, 505f, 6f, 6f, rectBgPaint)
                canvas2.drawText("No Scanned Agreement Letter", 310f, 280f, subTitlePaint)
            }

            // Footer note for Page 2
            val pageFooter = if (lang == Language.SINHALA) "පරිලෝකනය කරන ලද ලිපි ලේඛනවල නිරවද්‍යතාවය සහතික කර ඇත." else if (lang == Language.TAMIL) "ஆவணங்களின் துல்லியம் சரிபார்க்கப்பட்டது." else "Document integrity and verification guaranteed."
            canvas2.drawText(pageFooter, 297f - (subTitlePaint.measureText(pageFooter) / 2f), 800f, subTitlePaint)

            document.finishPage(page2)
        }

        // Write the document to a file in cache
        val pdfFile = File(context.cacheDir, "Loan_Report_${loan.id}.pdf")
        return try {
            val outputStream = FileOutputStream(pdfFile)
            document.writeTo(outputStream)
            document.close()
            outputStream.close()
            pdfFile
        } catch (e: Exception) {
            Log.e(TAG, "Error writing PDF: ${e.message}", e)
            document.close()
            null
        }
    }

    // Prints the generated PDF file using PrintManager
    fun printPdf(context: Context, file: File) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val jobName = "${context.packageName} Document"
        
        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }

                val info = PrintDocumentInfo.Builder("loan_report.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                var input: FileInputStream? = null
                var output: FileOutputStream? = null
                try {
                    input = FileInputStream(file)
                    output = FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } >= 0) {
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    Log.e(TAG, "Error printing pdf", e)
                    callback?.onWriteFailed(e.message)
                } finally {
                    try {
                        input?.close()
                        output?.close()
                    } catch (e: IOException) {
                        Log.e(TAG, "Error closing stream", e)
                    }
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }

    // Shares the generated PDF file
    fun sharePdf(context: Context, file: File) {
        try {
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, file)
            
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            
            context.startActivity(Intent.createChooser(intent, "Share Loan Report PDF"))
        } catch (e: Exception) {
            Log.e(TAG, "Error sharing PDF: ${e.message}", e)
            Toast.makeText(context, "Error sharing PDF: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
