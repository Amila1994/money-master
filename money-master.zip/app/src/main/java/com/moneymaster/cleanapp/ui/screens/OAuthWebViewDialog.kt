package com.moneymaster.cleanapp.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.moneymaster.cleanapp.ui.LoanViewModel
import com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager
import kotlinx.coroutines.launch
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun OAuthWebViewDialog(
    viewModel: LoanViewModel,
    onDismiss: () -> Unit,
    onSuccess: (email: String, name: String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isLoadingPage by remember { mutableStateOf(true) }

    val clientId = "860546045626-osobv63vqt8sqa2lar6ha5emdlrqlt6c.apps.googleusercontent.com"
    val redirectUri = "http://localhost"
    val scopes = "https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/spreadsheets"
    
    val authUrl = remember {
        "https://accounts.google.com/o/oauth2/v2/auth?" +
                "client_id=$clientId" +
                "&redirect_uri=${URLEncoder.encode(redirectUri, "UTF-8")}" +
                "&response_type=token" +
                "&scope=${URLEncoder.encode(scopes, "UTF-8")}" +
                "&prompt=select_account"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0C101A)),
            color = Color(0xFF0C101A)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .background(Color(0xFF161C2C))
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Google Account Authorization",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Secure sign-in for Sheets & Drive sync",
                            color = Color(0xFF9EABB8),
                            fontSize = 10.sp
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color.White)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.userAgentString = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                                
                                webViewClient = object : WebViewClient() {
                                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                        super.onPageStarted(view, url, favicon)
                                        isLoadingPage = true
                                        if (url != null && url.startsWith(redirectUri)) {
                                            handleOAuthRedirect(url)
                                        }
                                    }

                                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                        val url = request?.url?.toString() ?: ""
                                        if (url.startsWith(redirectUri)) {
                                            handleOAuthRedirect(url)
                                            return true
                                        }
                                        return false
                                    }

                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        isLoadingPage = false
                                    }

                                    private fun handleOAuthRedirect(url: String) {
                                        val fragment = url.substringAfter("#", "")
                                        if (fragment.isNotBlank()) {
                                            val params = fragment.split("&").associate {
                                                val split = it.split("=")
                                                val key = split.getOrNull(0) ?: ""
                                                val value = split.getOrNull(1) ?: ""
                                                key to value
                                            }
                                            val accessToken = params["access_token"]
                                            val expiresIn = params["expires_in"]?.toLongOrNull() ?: 3600L
                                            if (!accessToken.isNullOrBlank()) {
                                                coroutineScope.launch {
                                                    val userInfo = GoogleSheetsSyncManager.fetchUserInfoAndSave(
                                                        context,
                                                        accessToken,
                                                        expiresIn
                                                    )
                                                    if (userInfo != null) {
                                                        // Update the viewmodel so that sheets/drive sync uses the manual token
                                                        viewModel.saveEmailConfig(userInfo.first, "")
                                                        // Update other details in VM
                                                        viewModel.updateOwnerDetails(
                                                            name = userInfo.second,
                                                            phone = viewModel.ownerPhone.value,
                                                            photoUri = viewModel.ownerPhotoUri.value,
                                                            currency = viewModel.currentCurrency.value
                                                        )
                                                        onSuccess(userInfo.first, userInfo.second)
                                                    } else {
                                                        Toast.makeText(context, "Failed to retrieve Google profile details.", Toast.LENGTH_SHORT).show()
                                                    }
                                                    onDismiss()
                                                }
                                            }
                                        }
                                    }
                                }
                                loadUrl(authUrl)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    if (isLoadingPage) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter),
                            color = Color(0xFFFFBF00),
                            trackColor = Color(0xFF161C2C)
                        )
                    }
                }
            }
        }
    }
}
