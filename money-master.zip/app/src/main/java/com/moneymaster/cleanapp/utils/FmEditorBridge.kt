package com.moneymaster.cleanapp.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class FmEditorBridge(
    private val context: Context,
    private val onClose: () -> Unit,
    private val onPickFromCamera: () -> Unit,
    private val onPickFromGallery: () -> Unit
) {

    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    @JavascriptInterface
    fun closeEditor() {
        onClose()
    }

    @JavascriptInterface
    fun pickFromCamera() {
        onPickFromCamera()
    }

    @JavascriptInterface
    fun pickFromGallery() {
        onPickFromGallery()
    }

    @JavascriptInterface
    fun saveDocx(base64Data: String, filename: String) {
        saveBytesToFile(base64Data, filename, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    }

    @JavascriptInterface
    fun savePdf(base64Data: String, filename: String) {
        saveBytesToFile(base64Data, filename, "application/pdf")
    }

    private fun saveBytesToFile(base64Data: String, filename: String, mimeType: String) {
        try {
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)

            // 1. Save to Local Cache Directory for Sharing
            val cacheDir = File(context.cacheDir, "documents")
            if (!cacheDir.exists()) {
                cacheDir.mkdirs()
            }
            val cacheFile = File(cacheDir, filename)
            FileOutputStream(cacheFile).use { fos ->
                fos.write(bytes)
            }

            // 2. Save to Public Downloads folder
            var savedPublicUri: Uri? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(bytes)
                    }
                    savedPublicUri = uri
                }
            } else {
                // Legacy saving
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs()
                }
                val targetFile = File(downloadsDir, filename)
                FileOutputStream(targetFile).use { fos ->
                    fos.write(bytes)
                }
                savedPublicUri = Uri.fromFile(targetFile)
            }

            Toast.makeText(context, "Document saved to Downloads folder!", Toast.LENGTH_LONG).show()

            // 3. Trigger Share Intent using cacheFile and FileProvider
            val authority = "${context.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(context, authority, cacheFile)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, filename)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(shareIntent, "Share Document")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Error saving file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
