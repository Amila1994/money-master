package com.moneymaster.cleanapp.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.moneymaster.cleanapp.data.AppDatabase
import java.util.Calendar

class TransactionCleanupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val database = AppDatabase.getDatabase(applicationContext)
            
            // Calculate 1 year ago timestamp
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.YEAR, -1)
            val oneYearAgoMillis = calendar.timeInMillis
            
            database.loanDao().deleteSettledLoansOlderThanOneYear(oneYearAgoMillis)
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }
}
