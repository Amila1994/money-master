package com.moneymaster.cleanapp.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneymaster.cleanapp.ui.LoanViewModel
import com.moneymaster.cleanapp.utils.Language

private val ThemeDarkBg = Color(0xFF0C101A)
private val CardBg = Color(0xFF161C2C)
private val BorderColor = Color(0xFF232B3F)
private val AccentAmber = Color(0xFFFFBF00)
private val TextGray = Color(0xFF9EABB8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LenderRegistrationScreen(
    viewModel: LoanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by viewModel.currentLanguage.collectAsState()

    var lenderId by remember { mutableStateOf(viewModel.lenderId.value) }
    var ownerName by remember { mutableStateOf(viewModel.ownerName.value) }
    var ownerPhone by remember { mutableStateOf(viewModel.ownerPhone.value) }
    var securityPin by remember { mutableStateOf(viewModel.savedPin.value ?: "") }
    var securityQuestion by remember { mutableStateOf(viewModel.savedQuestion.value ?: "What is your first pet's name?") }
    var securityAnswer by remember { mutableStateOf(viewModel.savedAnswer.value ?: "") }

    var isRestoring by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ThemeDarkBg)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Security Setup",
                tint = AccentAmber,
                modifier = Modifier.size(72.dp)
            )

            Text(
                text = if (lang == Language.ENGLISH) "LENDER REGISTRATION" else "ණය දෙන්නාගේ ලියාපදිංචිය",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Text(
                text = if (lang == Language.ENGLISH) {
                    "Set up your unique Lender ID and profile details to secure your local phone database."
                } else {
                    "ඔබගේ දත්ත සුරක්ෂිතව තබා ගැනීමට ඔබගේ අනන්‍ය Lender ID එක සහ පැතිකඩ විස්තර සකසන්න."
                },
                color = TextGray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (lang == Language.ENGLISH) "Account Settings" else "ගිණුම් සැකසුම්",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    OutlinedTextField(
                        value = lenderId,
                        onValueChange = { lenderId = it },
                        label = { Text(if (lang == Language.ENGLISH) "Lender ID (e.g. NIC or Reg No)" else "ණය දෙන්නාගේ හැඳුනුම්පත (Lender ID)", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_lender_id_input")
                    )

                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text(if (lang == Language.ENGLISH) "Owner Name" else "හිමිකරුගේ නම", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_owner_name_input")
                    )

                    OutlinedTextField(
                        value = ownerPhone,
                        onValueChange = { ownerPhone = it },
                        label = { Text(if (lang == Language.ENGLISH) "Owner Phone" else "හිමිකරුගේ දුරකථනය", color = TextGray) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_owner_phone_input")
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (lang == Language.ENGLISH) "Security PIN Setup" else "ආරක්ෂක PIN සැකසුම",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    OutlinedTextField(
                        value = securityPin,
                        onValueChange = { if (it.length <= 4) securityPin = it },
                        label = { Text(if (lang == Language.ENGLISH) "Security PIN (4 digits)" else "ආරක්ෂක PIN අංකය (අංක 4)", color = TextGray) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_pin_input")
                    )

                    OutlinedTextField(
                        value = securityQuestion,
                        onValueChange = { securityQuestion = it },
                        label = { Text(if (lang == Language.ENGLISH) "Security Question (For recovery)" else "ආරක්ෂක ප්‍රශ්නය (නැවත ලබා ගැනීමට)", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_question_input")
                    )

                    OutlinedTextField(
                        value = securityAnswer,
                        onValueChange = { securityAnswer = it },
                        label = { Text(if (lang == Language.ENGLISH) "Security Answer" else "ආරක්ෂක පිළිතුර", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_answer_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Register Button
            Button(
                onClick = {
                    if (lenderId.isBlank() || ownerName.isBlank() || securityPin.length != 4) {
                        Toast.makeText(context, if (lang == Language.ENGLISH) "Please fill out Lender ID, Owner Name, and set a 4-digit PIN!" else "කරුණාකර Lender ID, හිමිකරුගේ නම පුරවා අංක 4ක PIN එකක් සකසන්න!", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    viewModel.saveRegistrationDetails(lenderId, "", ownerName, ownerPhone, "", "")
                    viewModel.savePinSecurity(securityPin, securityQuestion, securityAnswer)
                    viewModel.setAppUnlocked(true)
                    Toast.makeText(context, if (lang == Language.ENGLISH) "🎉 Setup successful!" else "🎉 ලියාපදිංචිය සාර්ථකයි!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("reg_submit_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentAmber,
                    contentColor = Color.Black
                )
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (lang == Language.ENGLISH) "Register New Profile" else "ලියාපදිංචි වන්න", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
