package com.moneymaster.cleanapp.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moneymaster.cleanapp.ui.LoanViewModel
import com.moneymaster.cleanapp.utils.Language

private val ThemeDarkBg = Color(0xFF0C101A)
private val CardBg = Color(0xFF161C2C)
private val BorderColor = Color(0xFF232B3F)
private val AccentAmber = Color(0xFFFFBF00)
private val TextGray = Color(0xFF9EABB8)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LenderRegistrationScreen(
    viewModel: LoanViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lang by viewModel.currentLanguage.collectAsState()

    var lenderId by remember { mutableStateOf(viewModel.lenderId.value) }
    var spreadsheetLink by remember { mutableStateOf(viewModel.spreadsheetLink.value) }
    var webAppUrl by remember { mutableStateOf(viewModel.webAppUrl.value) }
    var ownerName by remember { mutableStateOf(viewModel.ownerName.value) }
    var ownerPhone by remember { mutableStateOf(viewModel.ownerPhone.value) }
    var securityPin by remember { mutableStateOf(viewModel.savedPin.value ?: "") }
    var securityQuestion by remember { mutableStateOf(viewModel.savedQuestion.value ?: "What is your first pet's name?") }
    var securityAnswer by remember { mutableStateOf(viewModel.savedAnswer.value ?: "") }

    var isRestoring by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ThemeDarkBg)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            Icon(
                imageVector = Icons.Default.CloudSync,
                contentDescription = "Cloud Setup",
                tint = AccentAmber,
                modifier = Modifier.size(72.dp)
            )

            Text(
                text = if (lang == Language.ENGLISH) "LENDER CLOUD REGISTRATION" else "ණය දෙන්නාගේ ක්ලවුඩ් ලියාපදිංචිය",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Text(
                text = if (lang == Language.ENGLISH) {
                    "Set up your unique Lender ID and link your personal Google Sheet. Click 'Cloud Auto-Restore' to recover data from an existing sheet instantly."
                } else {
                    "ඔබගේ අනන්‍ය Lender ID සහ ගූගල් පැතුරුම්පත සම්බන්ධ කරන්න. පැරණි දත්ත නැවත ලබා ගැනීමට 'Cloud Auto-Restore' ක්ලික් කරන්න."
                },
                color = TextGray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (lang == Language.ENGLISH) "Account & Sync Settings" else "ගිණුම් සහ සමමුහුර්තකරණ සැකසුම්",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    OutlinedTextField(
                        value = webAppUrl,
                        onValueChange = { webAppUrl = it },
                        label = { Text(if (lang == Language.ENGLISH) "Google Web App URL" else "ගූගල් වෙබ් ඇප් ලින්ක් එක (Google Web App URL)", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_webapp_url_input")
                    )

                    OutlinedTextField(
                        value = lenderId,
                        onValueChange = { lenderId = it },
                        label = { Text(if (lang == Language.ENGLISH) "Lender ID (e.g. NIC or Reg No)" else "ණය දෙන්නාගේ හැඳුනුම්පත (Lender ID)", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_lender_id_input")
                    )

                    OutlinedTextField(
                        value = spreadsheetLink,
                        onValueChange = { spreadsheetLink = it },
                        label = { Text(if (lang == Language.ENGLISH) "Google Spreadsheet Link / ID" else "ගූගල් පැතුරුම්පත් ලින්ක් / ID", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_spreadsheet_link_input")
                    )

                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text(if (lang == Language.ENGLISH) "Owner Name" else "හිමිකරුගේ නම", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_owner_name_input")
                    )

                    OutlinedTextField(
                        value = ownerPhone,
                        onValueChange = { ownerPhone = it },
                        label = { Text(if (lang == Language.ENGLISH) "Owner Phone" else "හිමිකරුගේ දුරකථනය", color = TextGray) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_owner_phone_input")
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (lang == Language.ENGLISH) "Security PIN Setup" else "ආරක්ෂක PIN සැකසුම",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    OutlinedTextField(
                        value = securityPin,
                        onValueChange = { if (it.length <= 4) securityPin = it },
                        label = { Text(if (lang == Language.ENGLISH) "Security PIN (4 digits)" else "ආරක්ෂක PIN අංකය (අංක 4)", color = TextGray) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_pin_input")
                    )

                    OutlinedTextField(
                        value = securityQuestion,
                        onValueChange = { securityQuestion = it },
                        label = { Text(if (lang == Language.ENGLISH) "Security Question (For recovery)" else "ආරක්ෂක ප්‍රශ්නය (නැවත ලබා ගැනීමට)", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_question_input")
                    )

                    OutlinedTextField(
                        value = securityAnswer,
                        onValueChange = { securityAnswer = it },
                        label = { Text(if (lang == Language.ENGLISH) "Security Answer" else "ආරක්ෂක පිළිතුර", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("reg_answer_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Row
            if (isRestoring) {
                CircularProgressIndicator(color = AccentAmber)
                Text(
                    text = if (lang == Language.ENGLISH) "Connecting and recovering cloud data..." else "සම්බන්ධ වෙමින් සහ දත්ත නැවත ලබා ගනිමින්...",
                    color = AccentAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Google Sheets Cloud Restore Button
                    Button(
                        onClick = {
                            if (lenderId.isBlank() || spreadsheetLink.isBlank()) {
                                Toast.makeText(context, if (lang == Language.ENGLISH) "Lender ID and Spreadsheet Link are required for Cloud Restore!" else "දත්ත ලබා ගැනීමට Lender ID සහ පැතුරුම්පත් ලින්ක් එක අවශ්‍ය වේ!", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            isRestoring = true
                            viewModel.cloudRestore(spreadsheetLink, lenderId) { success, msg ->
                                isRestoring = false
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                if (success) {
                                    val pinToSave = securityPin.ifBlank { "1234" }
                                    viewModel.savePinSecurity(pinToSave, securityQuestion, securityAnswer)
                                    viewModel.setAppUnlocked(true)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("reg_cloud_restore_button"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1A2E1A),
                            contentColor = Color(0xFF2ECC71)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2ECC71))
                    ) {
                        Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(if (lang == Language.ENGLISH) "Sheets Sync" else "පැතුරුම්පත්", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    // Google Drive Backup Restore Button
                    Button(
                        onClick = {
                            isRestoring = true
                            viewModel.restoreFromDrive { success, msg ->
                                isRestoring = false
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                if (success) {
                                    val pinToSave = securityPin.ifBlank { "1234" }
                                    viewModel.savePinSecurity(pinToSave, securityQuestion, securityAnswer)
                                    viewModel.setAppUnlocked(true)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("reg_drive_restore_button"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1A243F),
                            contentColor = Color(0xFF3498DB)
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3498DB))
                    ) {
                        Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(if (lang == Language.ENGLISH) "Drive Restore" else "ඩ්‍රයිව් උපස්ථය", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    // Register New Button
                    Button(
                        onClick = {
                            if (lenderId.isBlank() || spreadsheetLink.isBlank() || ownerName.isBlank() || securityPin.length != 4) {
                                Toast.makeText(context, if (lang == Language.ENGLISH) "Please fill out all fields and set a 4-digit PIN!" else "කරුණාකර සියලු විස්තර පුරවා අංක 4ක PIN එකක් සකසන්න!", Toast.LENGTH_LONG).show()
                                return@Button
                            }
                            viewModel.saveRegistrationDetails(lenderId, spreadsheetLink, ownerName, ownerPhone, "", webAppUrl)
                            viewModel.savePinSecurity(securityPin, securityQuestion, securityAnswer)
                            viewModel.setAppUnlocked(true)
                            Toast.makeText(context, if (lang == Language.ENGLISH) "🎉 Setup successful!" else "🎉 ලියාපදිංචිය සාර්ථකයි!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("reg_submit_button"),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentAmber,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(if (lang == Language.ENGLISH) "Register New" else "ලියාපදිංචි වන්න", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
