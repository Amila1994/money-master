package com.moneymaster.cleanapp.ui.screens

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

@Composable
fun AdmobBannerAd(
    isPremium: Boolean,
    modifier: Modifier = Modifier,
    adUnitId: String = "ca-app-pub-3940256099942544/6300978111" // Official Google Test Banner Ad Unit ID
) {
    if (isPremium) return
    AndroidView(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp),
        factory = { context ->
            // Pre-create cache directories right before WebView engine initialization inside AdView
            try {
                val cacheDir = context.cacheDir
                val webViewCacheDirJs = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/js")
                val webViewCacheDirWasm = java.io.File(cacheDir, "WebView/Default/HTTP Cache/Code Cache/wasm")
                if (!webViewCacheDirJs.exists()) {
                    webViewCacheDirJs.mkdirs()
                }
                if (!webViewCacheDirWasm.exists()) {
                    webViewCacheDirWasm.mkdirs()
                }
                val jsDummy = java.io.File(webViewCacheDirJs, "dummy")
                if (!jsDummy.exists()) {
                    jsDummy.createNewFile()
                }
                val wasmDummy = java.io.File(webViewCacheDirWasm, "dummy")
                if (!wasmDummy.exists()) {
                    wasmDummy.createNewFile()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                setAdUnitId(adUnitId)
                loadAd(AdRequest.Builder().build())
            }
        },
        update = { adView ->
            // Automatically handled
        }
    )
}
