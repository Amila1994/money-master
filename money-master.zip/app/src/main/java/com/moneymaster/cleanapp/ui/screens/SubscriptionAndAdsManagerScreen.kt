package com.moneymaster.cleanapp.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.scale
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.moneymaster.cleanapp.ui.LoanViewModel
import com.moneymaster.cleanapp.ui.theme.*
import com.moneymaster.cleanapp.utils.Language
import com.moneymaster.cleanapp.utils.LocalizedText

@Composable
fun SubscriptionAndAdsManagerScreen(
    viewModel: LoanViewModel,
    lang: Language,
    innerPadding: PaddingValues,
    onWatchAdClick: () -> Unit,
    onBuyPackageClick: (String, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    // Collect ViewModel Premium & Ads State
    val isPremiumUser by viewModel.isPremiumUser.collectAsStateWithLifecycle()
    val watchedAdsToday by viewModel.watchedAdsToday.collectAsStateWithLifecycle()
    val isBlockedFromFreeFeatures by viewModel.isBlockedFromFreeFeatures.collectAsStateWithLifecycle()

    // Local transient states
    var backNextCounter by remember { mutableStateOf(0) }
    var showAdDialogText by remember { mutableStateOf<String?>(null) }

    // Sinhala and English Text maps for premium
    val textTitle = if (lang == Language.ENGLISH) "MONEY MASTER PREMIUM" else "MONEY MASTER PREMIUM"
    val textPackageHeader = if (lang == Language.ENGLISH) "Select Subscription Package" else "පැකේජ තෝරාගන්න (Subscription Packages)"
    val textFreeHeader = if (lang == Language.ENGLISH) "Free Users Control" else "නොමිලේ භාවිත කරන ක්‍රම (Free Users Control)"
    val textWatchAdTitle = if (lang == Language.ENGLISH) "📺 Watch Ads for Free Access" else "📺 ඇඩ්ස් බලලා නොමිලේ ලබාගන්න"
    val textWatchAdDesc = if (lang == Language.ENGLISH) 
        "Watch 25 ads today to instantly unlock all premium features for 2 days. No more ads will be shown once completed."
        else "අද දින ඇඩ්ස් 25ම නැරඹීමෙන් පසු සියලුම ප්‍රීමියම් පහසුකම් දින 2කට සම්පූර්ණයෙන් නොමිලේ විවෘත වේ. ඉන්පසු ඇඩ්ස් පෙන්වනු නොලැබේ."
    val textAdsWatchedToday = if (lang == Language.ENGLISH) "Ads watched today: $watchedAdsToday / 25" else "අද බැලූ ඇඩ්ස්: $watchedAdsToday / 25"
    val textWatchAdBtn = if (lang == Language.ENGLISH) "Watch Ad" else "Ad එකක් බලන්න"
    val textBlockedAlert = if (lang == Language.ENGLISH) 
        "⚠️ Restricted: All features blocked. Watch 25 ads for 2 days free access, or watch an ad to get 45 seconds TEMPORARY ACCESS." 
        else "⚠️ සීමා කර ඇත: සියලුම විශේෂාංග අවහිර වී ඇත. දින 2ක නොමිලේ ප්‍රවේශය සඳහා ඇඩ්ස් 25ක් නරඹන්න, නැතහොත් තත්පර 45ක තාවකාලික ප්‍රවේශයක් ලබා ගැනීමට ඇඩ් එකක් නරඹන්න."
    val textNavHeader = if (lang == Language.ENGLISH) "Navigation Ads Testing" else "පිටු අතර මාරුවීමේ ඇඩ්ස් පරීක්ෂාව (Navigation Ads)"
    val textBackBtn = if (lang == Language.ENGLISH) "Back Action" else "Back කරන්න"
    val textNextBtn = if (lang == Language.ENGLISH) "Next Action" else "Next කරන්න"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = textTitle,
                    color = AccentAmber,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        // ================= 1. PREMIUM PACKAGES UI =================
        item {
            Text(
                text = textPackageHeader,
                color = TextGray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Card 1
        item {
            PackageCard(
                title = if (lang == Language.ENGLISH) "First Month (Promo Price)" else "පළමු මාසය (ප්‍රවර්ධන මිල)",
                price = "Rs. 500.00",
                description = if (lang == Language.ENGLISH) "Previous price Rs. 750 (Rs. 1000 from next month)" else "කලින් මිල Rs. 750 (ලබන මාසයේ සිට Rs. 1000)",
                buyButtonText = if (lang == Language.ENGLISH) "Buy Now" else "මිලදී ගන්න",
                onBuyClick = {
                    val pkgName = if (lang == Language.ENGLISH) "Promo Monthly Package" else "පළමු මාසයේ පැකේජය"
                    onBuyPackageClick(pkgName, 500.0)
                }
            )
        }

        // Card 2
        item {
            PackageCard(
                title = if (lang == Language.ENGLISH) "6 Months Package" else "මාස 6 ක පැකේජය",
                price = "Rs. 2,300.00",
                description = if (lang == Language.ENGLISH) "Previous price Rs. 3000 (Special discount)" else "කලින් මිල Rs. 3000 (විශේෂ වට්ටමක්)",
                buyButtonText = if (lang == Language.ENGLISH) "Buy Now" else "මිලදී ගන්න",
                onBuyClick = {
                    val pkgName = if (lang == Language.ENGLISH) "6 Months Package" else "මාස 6 පැකේජය"
                    onBuyPackageClick(pkgName, 2300.0)
                }
            )
        }

        // Card 3
        item {
            PackageCard(
                title = if (lang == Language.ENGLISH) "Annual Package (Full Year)" else "වාර්ෂික පැකේජය (අවුරුද්දටම)",
                price = "Rs. 10,000.00",
                description = if (lang == Language.ENGLISH) "Ads completely removed" else "ඇඩ්ස් සම්පූර්ණයෙන්ම ඉවත් වේ",
                buyButtonText = if (lang == Language.ENGLISH) "Buy Now" else "මිලදී ගන්න",
                onBuyClick = {
                    val pkgName = if (lang == Language.ENGLISH) "Annual Package" else "වාර්ෂික පැකේජය"
                    onBuyPackageClick(pkgName, 10000.0)
                }
            )
        }

        // Divider
        item {
            HorizontalDivider(color = BorderColor, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))
        }

        // ================= 2. REWARDED ADS & STREAK SYSTEM UI =================
        item {
            Text(
                text = textFreeHeader,
                color = TextGray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            val outlineColor = if (isBlockedFromFreeFeatures) Color.Red else BorderColor
            val cardBgColor = if (isBlockedFromFreeFeatures) Color.Red.copy(alpha = 0.05f) else CardBg
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(cardBgColor, shape = RoundedCornerShape(16.dp))
                    .border(1.dp, outlineColor, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = textWatchAdTitle,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = textWatchAdDesc,
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = textAdsWatchedToday,
                            color = AccentAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        
                        Button(
                            onClick = {
                                if (watchedAdsToday < 25) {
                                    onWatchAdClick()
                                } else {
                                    Toast.makeText(context, if (lang == Language.ENGLISH) "You have already completed all 25 ads for today." else "ඔබ අද දිනට අදාළ ඇඩ්ස් 25ම බලා අවසන් කර ඇත.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF00C853),
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.Black)
                                Text(text = textWatchAdBtn, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    if (isBlockedFromFreeFeatures) {
                        Text(
                            text = textBlockedAlert,
                            color = Color.Red,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }



        // Simulation Buttons
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(
                    onClick = {
                        viewModel.simulateComplete25Ads()
                        Toast.makeText(context, if (lang == Language.ENGLISH) "🎉 Simulation: Completed all 25 ads! 2 days free access activated." else "🎉 සිමියුලේෂන්: ඇඩ්ස් 25ම නැරඹුවා! දින 2ක නොමිලේ ප්‍රවේශය සක්‍රීයයි.", Toast.LENGTH_LONG).show()
                    }
                ) {
                    Text(
                        text = if (lang == Language.ENGLISH) "📊 (Simulation) Complete 25 ads today" else "📊 (Simulation) අද දින ඇඩ්ස් 25ම නැරඹුවා සේ සලකන්න",
                        color = Color(0xFF00E676),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }

                TextButton(
                    onClick = {
                        viewModel.simulateResetAds()
                        Toast.makeText(context, if (lang == Language.ENGLISH) "🔄 Simulation: Ad count and status reset to RESTRICTED." else "🔄 සිමියුලේෂන්: ඇඩ්ස් ගණන සහ තත්ත්වය නැවත සකසන ලදී.", Toast.LENGTH_LONG).show()
                    }
                ) {
                    Text(
                        text = if (lang == Language.ENGLISH) "🔄 (Simulation) Reset ad status (Restricted)" else "🔄 (Simulation) ඇඩ්ස් තත්ත්වය මුල සිට සකසන්න",
                        color = Color.Red,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }

    // Interactive Google AdMob Ad Simulated Dialog
    showAdDialogText?.let { adType ->
        AlertDialog(
            onDismissRequest = { showAdDialogText = null },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Movie, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(24.dp))
                    Text(
                        text = "Google AdMob Ad",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Text(
                    text = if (lang == Language.ENGLISH) "A $adType is playing here..." else "මෙතැනදී $adType එකක් ධාවනය වේ...",
                    color = Color.LightGray,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = { showAdDialogText = null }
                ) {
                    Text(
                        text = "Close Ad",
                        color = AccentAmber,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = CardBg,
            modifier = Modifier.border(1.dp, BorderColor, RoundedCornerShape(16.dp))
        )
    }
}

@Composable
fun PackageCard(
    title: String,
    price: String,
    description: String,
    buyButtonText: String,
    onBuyClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = price,
                    color = AccentAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = description,
                    color = TextGray,
                    fontSize = 11.sp
                )
            }
            
            Button(
                onClick = onBuyClick,
                colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = buyButtonText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}
