package com.moneymaster.cleanapp.utils

import android.content.Context
import android.os.Build
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object NotificationOrchestrator {
    private const val TAG = "NotificationOrchestrator"

    private fun getNotificationMode(context: Context): String {
        val ownerPrefs = context.getSharedPreferences("money_master_owner_prefs", Context.MODE_PRIVATE)
        return ownerPrefs.getString("notification_mode", "BOTH") ?: "BOTH"
    }

    private fun isSmsEnabled(context: Context): Boolean {
        val mode = getNotificationMode(context)
        return mode == "BOTH" || mode == "SMS_ONLY"
    }

    private fun isEmailEnabled(context: Context): Boolean {
        val mode = getNotificationMode(context)
        return mode == "BOTH" || mode == "EMAIL_ONLY"
    }

    fun sendSmsInBackground(context: Context, phone: String, message: String) {
        if (phone.isBlank()) {
            Log.e(TAG, "Cannot send SMS: phone number is empty")
            return
        }

        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "SEND_SMS permission not granted. Background SMS skipped.")
            return
        }

        try {
            val ownerPrefs = context.getSharedPreferences("money_master_owner_prefs", Context.MODE_PRIVATE)
            val selectedSlot = ownerPrefs.getInt("selected_sim_slot", 0) // SIM 1 = 0, SIM 2 = 1

            var subId: Int? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                try {
                    if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_PHONE_STATE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
                        if (subscriptionManager != null) {
                            val activeList = subscriptionManager.activeSubscriptionInfoList
                            if (activeList != null) {
                                val info = activeList.find { it.simSlotIndex == selectedSlot }
                                if (info != null) {
                                    subId = info.subscriptionId
                                    Log.d(TAG, "Selected SIM Slot $selectedSlot mapped to Subscription ID $subId")
                                } else {
                                    Log.w(TAG, "No active subscription found for SIM Slot $selectedSlot. Fallback to default.")
                                }
                            }
                        }
                    } else {
                        Log.w(TAG, "READ_PHONE_STATE permission not granted. SMS will send from default SIM.")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Exception reading SubscriptionInfo: ${e.localizedMessage}")
                }
            }

            val smsManager: SmsManager? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1 && subId != null) {
                try {
                    @Suppress("DEPRECATION")
                    SmsManager.getSmsManagerForSubscriptionId(subId)
                } catch (e: Exception) {
                    Log.e(TAG, "Exception getting targeted SmsManager, fallback to default: ${e.localizedMessage}")
                    getDefaultSmsManager(context)
                }
            } else {
                getDefaultSmsManager(context)
            }

            if (smsManager != null) {
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
                Log.d(TAG, "SMS alert sent to $phone successfully using SIM Slot $selectedSlot.")
            } else {
                Log.e(TAG, "SmsManager is null. Failed to send background SMS.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception in background SMS transmission: ${e.localizedMessage}", e)
        }
    }

    private fun getDefaultSmsManager(context: Context): SmsManager? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }
    }

    /**
     * Trigger notification for Customer profile Registration or Modification
     */
    suspend fun triggerCustomerNotification(context: Context, customer: Customer) = withContext(Dispatchers.IO) {
        val mode = getNotificationMode(context)
        if (mode == "DISABLED") {
            Log.d(TAG, "Notifications are disabled. Skipping customer alert.")
            return@withContext
        }

        // Generate dual-language message body
        val smsMessage = """
            [Money Master / මනි මාස්ටර්]
            පාරිභෝගික ගිණුම සාර්ථකව යාවත්කාලීන කරන ලදී.
            නම: ${customer.name}
            හැඳුනුම්පත (NIC): ${customer.nic}
            
            Customer profile successfully registered/updated.
            Name: ${customer.name}
            NIC: ${customer.nic}
            - Thank you / ස්තුතියි!
        """.trimIndent()

        val htmlEmailBody = """
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333333;">
                <div style="max-width: 600px; margin: 0 auto; border: 1px solid #dddddd; border-radius: 8px; overflow: hidden;">
                    <div style="background-color: #FFB300; padding: 20px; text-align: center;">
                        <h2 style="color: #000000; margin: 0;">Money Master Profile Update</h2>
                    </div>
                    <div style="padding: 24px;">
                        <p>ගරු <b>${customer.name}</b>,</p>
                        <p>මනි මාස්ටර් පද්ධතියේ ඔබගේ පාරිභෝගික ගිණුම සාර්ථකව යාවත්කාලීන කර ඇත.</p>
                        
                        <hr style="border: 0; border-top: 1px solid #eeeeee; margin: 20px 0;"/>
                        
                        <p>Dear <b>${customer.name}</b>,</p>
                        <p>Your customer profile has been successfully registered or updated in our system.</p>
                        
                        <div style="background-color: #f9f9f9; padding: 16px; border-radius: 4px; margin-top: 20px;">
                            <table style="width: 100%; font-size: 14px;">
                                <tr><td><b>Name / නම:</b></td><td>${customer.name}</td></tr>
                                <tr><td><b>Address / ලිපිනය:</b></td><td>${customer.address}</td></tr>
                                <tr><td><b>Phone / දුරකථන:</b></td><td>${customer.phone}</td></tr>
                                <tr><td><b>NIC / හැඳුනුම්පත:</b></td><td>${customer.nic}</td></tr>
                                <tr><td><b>Email / විද්‍යුත් තැපෑල:</b></td><td>${customer.email ?: "N/A"}</td></tr>
                            </table>
                        </div>
                        <p style="margin-top: 24px; font-size: 13px; color: #777777;">Sincerely,<br/>Money Master Team</p>
                    </div>
                </div>
            </body>
            </html>
        """.trimIndent()

        if (isSmsEnabled(context) && customer.phone.isNotBlank()) {
            sendSmsInBackground(context, customer.phone, smsMessage)
        }

        if (isEmailEnabled(context) && !customer.email.isNullOrBlank()) {
            BackgroundEmailSender.sendHtmlEmail(
                context = context,
                recipientEmail = customer.email,
                subject = "Money Master: Customer Profile Registration/Update",
                htmlBody = htmlEmailBody
            )
        }
    }

    /**
     * Trigger notification for Loan Created or Loan Status Change
     */
    suspend fun triggerLoanNotification(
        context: Context,
        loan: Loan,
        customer: Customer?,
        pdfFile: File? = null
    ) = withContext(Dispatchers.IO) {
        val mode = getNotificationMode(context)
        if (mode == "DISABLED") {
            Log.d(TAG, "Notifications are disabled. Skipping loan alert.")
            return@withContext
        }

        val phone = customer?.phone ?: loan.borrowerPhone
        val email = customer?.email ?: ""
        val name = customer?.name ?: loan.borrowerName

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val dateStr = sdf.format(Date(loan.startDate))

        val statusLabelSi = if (loan.isSettled) "සම්පූර්ණ කරන ලදී (Settle)" else "ක්‍රියාකාරී (Active)"
        val statusLabelEn = if (loan.isSettled) "Settled & Closed" else "Active"

        // Generate dual-language SMS
        val smsMessage = """
            [Money Master / මනි මාස්ටර්]
            ණය ගිණුම් විස්තරය / Loan Account Details:
            ණයකරු / Borrower: $name
            ණය මුදල / Principal: Rs. ${String.format(Locale.US, "%.2f", loan.principalAmount)}
            පොලිය / Interest: ${loan.interestRate}% (${loan.interestPeriod})
            දිනය / Date: $dateStr
            තත්ත්වය / Status: $statusLabelSi / $statusLabelEn
            - Thank you / ස්තුතියි!
        """.trimIndent()

        // Generate dual-language HTML email
        val htmlEmailBody = """
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333333;">
                <div style="max-width: 600px; margin: 0 auto; border: 1px solid #dddddd; border-radius: 8px; overflow: hidden;">
                    <div style="background-color: #FFB300; padding: 20px; text-align: center;">
                        <h2 style="color: #000000; margin: 0;">Money Master Loan Agreement</h2>
                    </div>
                    <div style="padding: 24px;">
                        <p>ගරු <b>$name</b>,</p>
                        <p>ඔබගේ නව ණය ගිණුම සාර්ථකව ආරම්භ කර ඇත. විස්තර පහත දැක්වේ.</p>
                        
                        <hr style="border: 0; border-top: 1px solid #eeeeee; margin: 20px 0;"/>
                        
                        <p>Dear <b>$name</b>,</p>
                        <p>Your loan account has been successfully created/updated in our system. The details are shown below.</p>
                        
                        <div style="background-color: #f9f9f9; padding: 16px; border-radius: 4px; margin-top: 20px;">
                            <table style="width: 100%; font-size: 14px;">
                                <tr><td><b>Borrower / ණයකරු:</b></td><td>$name</td></tr>
                                <tr><td><b>Loan Amount / ණය මුදල:</b></td><td>Rs. ${String.format(Locale.US, "%.2f", loan.principalAmount)}</td></tr>
                                <tr><td><b>Interest Rate / පොලී අනුපාතය:</b></td><td>${loan.interestRate}% (${loan.interestPeriod})</td></tr>
                                <tr><td><b>Start Date / ආරම්භක දිනය:</b></td><td>$dateStr</td></tr>
                                <tr><td><b>Status / තත්ත්වය:</b></td><td><b>$statusLabelSi / $statusLabelEn</b></td></tr>
                            </table>
                        </div>
                        <p style="margin-top: 24px; font-size: 13px; color: #777777;">Sincerely,<br/>Money Master Team</p>
                    </div>
                </div>
            </body>
            </html>
        """.trimIndent()

        if (isSmsEnabled(context) && phone.isNotBlank()) {
            sendSmsInBackground(context, phone, smsMessage)
        }

        if (isEmailEnabled(context) && email.isNotBlank()) {
            BackgroundEmailSender.sendHtmlEmail(
                context = context,
                recipientEmail = email,
                subject = "Money Master: Loan Transaction Notification",
                htmlBody = htmlEmailBody,
                pdfFile = pdfFile
            )
        }
    }

    /**
     * Trigger notification for Payment Recorded
     */
    suspend fun triggerPaymentNotification(
        context: Context,
        loan: Loan,
        customer: Customer?,
        payment: Payment,
        remainingOutstanding: Double,
        pdfFile: File? = null
    ) = withContext(Dispatchers.IO) {
        val mode = getNotificationMode(context)
        if (mode == "DISABLED") {
            Log.d(TAG, "Notifications are disabled. Skipping payment alert.")
            return@withContext
        }

        val phone = customer?.phone ?: loan.borrowerPhone
        val email = customer?.email ?: ""
        val name = customer?.name ?: loan.borrowerName

        // Generate dual-language SMS
        val smsMessage = """
            [Money Master / මනි මාස්ටර්]
            ගෙවීම් ලැබුණි / Payment Received!
            ගෙවූ මුදල / Paid: Rs. ${String.format(Locale.US, "%.2f", payment.amount)}
            වර්ගය / Type: ${payment.type}
            ඉතිරි මුළු ණය / Remaining Bal: Rs. ${String.format(Locale.US, "%.2f", remainingOutstanding)}
            ණයකරු / Customer: $name
            - Thank you / ස්තුතියි!
        """.trimIndent()

        // Generate dual-language HTML email
        val htmlEmailBody = """
            <html>
            <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333333;">
                <div style="max-width: 600px; margin: 0 auto; border: 1px solid #dddddd; border-radius: 8px; overflow: hidden;">
                    <div style="background-color: #2E7D32; padding: 20px; text-align: center;">
                        <h2 style="color: #ffffff; margin: 0;">Money Master Payment Receipt</h2>
                    </div>
                    <div style="padding: 24px;">
                        <p>ගරු <b>$name</b>,</p>
                        <p>ඔබගේ ණය ගෙවීමක් සාර්ථකව පද්ධතියේ සටහන් කරගෙන ඇත.</p>
                        
                        <hr style="border: 0; border-top: 1px solid #eeeeee; margin: 20px 0;"/>
                        
                        <p>Dear <b>$name</b>,</p>
                        <p>A loan payment has been recorded successfully. Please find the details below.</p>
                        
                        <div style="background-color: #f1f8e9; padding: 16px; border-radius: 4px; margin-top: 20px; border-left: 4px solid #2E7D32;">
                            <table style="width: 100%; font-size: 14px;">
                                <tr><td><b>Borrower / ණයකරු:</b></td><td>$name</td></tr>
                                <tr><td><b>Payment Amount / ගෙවූ මුදල:</b></td><td><b style="color: #2E7D32;">Rs. ${String.format(Locale.US, "%.2f", payment.amount)}</b></td></tr>
                                <tr><td><b>Payment Type / ගෙවීම් වර්ගය:</b></td><td>${payment.type}</td></tr>
                                <tr><td><b>Remaining Balance / ඉතිරි ලැබීමට ඇති මුදල:</b></td><td>Rs. ${String.format(Locale.US, "%.2f", remainingOutstanding)}</td></tr>
                                <tr><td><b>Notes / විශේෂ සටහන:</b></td><td>${payment.notes.ifBlank { "N/A" }}</td></tr>
                            </table>
                        </div>
                        <p style="margin-top: 24px; font-size: 13px; color: #777777;">Sincerely,<br/>Money Master Team</p>
                    </div>
                </div>
            </body>
            </html>
        """.trimIndent()

        if (isSmsEnabled(context) && phone.isNotBlank()) {
            sendSmsInBackground(context, phone, smsMessage)
        }

        if (isEmailEnabled(context) && email.isNotBlank()) {
            BackgroundEmailSender.sendHtmlEmail(
                context = context,
                recipientEmail = email,
                subject = "Money Master: Loan Payment Notification",
                htmlBody = htmlEmailBody,
                pdfFile = pdfFile
            )
        }
    }
}
