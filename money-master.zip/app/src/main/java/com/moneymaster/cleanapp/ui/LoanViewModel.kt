package com.moneymaster.cleanapp.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.LoanRepository
import com.moneymaster.cleanapp.data.Payment
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.utils.Language
import com.moneymaster.cleanapp.utils.LoanCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardSummary(
    val totalLent: Double,
    val totalInterestEarned: Double,
    val totalOutstanding: Double
)

@OptIn(ExperimentalCoroutinesApi::class)
class LoanViewModel(
    private val repository: LoanRepository,
    private val context: android.content.Context
) : ViewModel() {

    private val sharedPrefs = context.getSharedPreferences("money_master_security", android.content.Context.MODE_PRIVATE)
    private val adPrefs = context.getSharedPreferences("money_master_ads_premium", android.content.Context.MODE_PRIVATE)

    // Ad and Premium States
    private val _isPremiumUser = MutableStateFlow(true)
    private val _watchedAdsToday = MutableStateFlow(25)
    private val _lastAdTimestamp = MutableStateFlow(System.currentTimeMillis())



    private val _daysSinceLastStreak = MutableStateFlow(0)
    val daysSinceLastStreakState: StateFlow<Int> = _daysSinceLastStreak.asStateFlow()

    private fun updateDaysSinceLastStreak() {
        val lastDateStr = adPrefs.getString("last_completed_25_ads_date", "") ?: ""
        if (lastDateStr.isEmpty()) {
            _daysSinceLastStreak.value = 9999
            return
        }
        try {
            val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
            val lastDate = sdf.parse(lastDateStr) ?: run { _daysSinceLastStreak.value = 9999; return }
            val currentDate = sdf.parse(getCurrentDateString()) ?: run { _daysSinceLastStreak.value = 9999; return }
            val diffInMillis = currentDate.time - lastDate.time
            val diffInDays = (diffInMillis / (1000 * 60 * 60 * 24)).toInt()
            _daysSinceLastStreak.value = if (diffInDays < 0) 0 else diffInDays
        } catch (e: Exception) {
            _daysSinceLastStreak.value = 9999
        }
    }

    init {
        checkDailyAdReset()
        updateDaysSinceLastStreak()
    }

    fun getDaysSinceLastStreak(): Int {
        return _daysSinceLastStreak.value
    }

    val isPremiumUser: StateFlow<Boolean> = _isPremiumUser.asStateFlow()

    val watchedAdsToday: StateFlow<Int> = _watchedAdsToday.asStateFlow()

    fun getLastAdSecondsAgo(): Long {
        val lastTime = _lastAdTimestamp.value
        if (lastTime == 0L) return 9999L
        val diffMs = System.currentTimeMillis() - lastTime
        val seconds = diffMs / 1000
        return if (seconds < 0) 0 else seconds
    }

    private val _timerTick = MutableStateFlow(0)

    fun refreshAccessState() {
        _timerTick.value += 1
    }

    val isBlockedFromFreeFeatures: StateFlow<Boolean> = MutableStateFlow(false).asStateFlow()

    fun buyPremiumPackage(packageName: String, price: Double) {
        _isPremiumUser.value = true
        adPrefs.edit().putBoolean("is_premium_user", true).apply()
    }

    fun setPremiumUser(isPremium: Boolean) {
        _isPremiumUser.value = isPremium
        adPrefs.edit().putBoolean("is_premium_user", isPremium).apply()
    }

    private fun getCurrentDateString(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return sdf.format(java.util.Calendar.getInstance().time)
    }

    fun checkDailyAdReset() {
        val currentDate = getCurrentDateString()
        val savedDate = adPrefs.getString("ad_date", "") ?: ""
        if (savedDate != currentDate) {
            adPrefs.edit().apply {
                putString("ad_date", currentDate)
                putInt("ad_count", 0)
                apply()
            }
            _watchedAdsToday.value = 0
            updateDaysSinceLastStreak()
        }
    }

    fun incrementWatchedAds(): Boolean {
        checkDailyAdReset()
        if (_watchedAdsToday.value < 25) {
            val newVal = _watchedAdsToday.value + 1
            _watchedAdsToday.value = newVal
            val currentTimestamp = System.currentTimeMillis()
            _lastAdTimestamp.value = currentTimestamp
            
            adPrefs.edit().apply {
                putInt("ad_count", newVal)
                putLong("last_ad_timestamp", currentTimestamp)
                if (newVal == 25) {
                    putString("last_completed_25_ads_date", getCurrentDateString())
                }
                apply()
            }
            updateDaysSinceLastStreak()
            return true
        }
        return false
    }

    fun simulateComplete25Ads() {
        _watchedAdsToday.value = 25
        val currentTimestamp = System.currentTimeMillis()
        _lastAdTimestamp.value = currentTimestamp
        
        adPrefs.edit().apply {
            putInt("ad_count", 25)
            putLong("last_ad_timestamp", currentTimestamp)
            putString("last_completed_25_ads_date", getCurrentDateString())
            apply()
        }
        updateDaysSinceLastStreak()
    }

    fun simulateResetAds() {
        _watchedAdsToday.value = 0
        _lastAdTimestamp.value = 0L
        adPrefs.edit().apply {
            putInt("ad_count", 0)
            putLong("last_ad_timestamp", 0L)
            remove("last_completed_25_ads_date")
            apply()
        }
        updateDaysSinceLastStreak()
    }

    // PIN security configuration
    private val _savedPin = MutableStateFlow<String?>(sharedPrefs.getString("saved_pin", null))
    val savedPin: StateFlow<String?> = _savedPin.asStateFlow()

    private val _savedQuestion = MutableStateFlow<String?>(sharedPrefs.getString("saved_question", null))
    val savedQuestion: StateFlow<String?> = _savedQuestion.asStateFlow()

    private val _savedAnswer = MutableStateFlow<String?>(sharedPrefs.getString("saved_answer", null))
    val savedAnswer: StateFlow<String?> = _savedAnswer.asStateFlow()

    private val _isAppUnlocked = MutableStateFlow(false)
    val isAppUnlocked: StateFlow<Boolean> = _isAppUnlocked.asStateFlow()

    fun setAppUnlocked(unlocked: Boolean) {
        _isAppUnlocked.value = unlocked
    }

    fun savePinSecurity(pin: String, question: String, answer: String) {
        sharedPrefs.edit().apply {
            putString("saved_pin", pin)
            putString("saved_question", question)
            putString("saved_answer", answer.trim().lowercase())
            apply()
        }
        _savedPin.value = pin
        _savedQuestion.value = question
        _savedAnswer.value = answer.trim().lowercase()
    }

    fun clearPinSecurity() {
        sharedPrefs.edit().apply {
            remove("saved_pin")
            remove("saved_question")
            remove("saved_answer")
            apply()
        }
        _savedPin.value = null
        _savedQuestion.value = null
        _savedAnswer.value = null
        _isAppUnlocked.value = false
    }

    // Language configuration
    private val _currentLanguage = MutableStateFlow(Language.SINHALA)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    // Owner/Admin profile configuration with persistence
    private val ownerPrefs = context.getSharedPreferences("money_master_owner_prefs", android.content.Context.MODE_PRIVATE)

    private val _showOAuthDialog = MutableStateFlow(false)
    val showOAuthDialog: StateFlow<Boolean> = _showOAuthDialog.asStateFlow()

    fun setShowOAuthDialog(show: Boolean) {
        _showOAuthDialog.value = show
    }

    private val _lenderId = MutableStateFlow(ownerPrefs.getString("lender_id", "") ?: "")
    val lenderId: StateFlow<String> = _lenderId.asStateFlow()

    private val _spreadsheetLink = MutableStateFlow(ownerPrefs.getString("spreadsheet_link", "") ?: "")
    val spreadsheetLink: StateFlow<String> = _spreadsheetLink.asStateFlow()

    private val _webAppUrl = MutableStateFlow(ownerPrefs.getString("web_app_url", "") ?: "")
    val webAppUrl: StateFlow<String> = _webAppUrl.asStateFlow()

    private val _ownerName = MutableStateFlow(ownerPrefs.getString("owner_name", "ණය දෙන පුද්ගලයා (Owner)") ?: "ණය දෙන පුද්ගලයා (Owner)")
    val ownerName: StateFlow<String> = _ownerName.asStateFlow()

    private val _ownerPhone = MutableStateFlow(ownerPrefs.getString("owner_phone", "0771234567") ?: "0771234567")
    val ownerPhone: StateFlow<String> = _ownerPhone.asStateFlow()

    private val _ownerPhotoUri = MutableStateFlow(ownerPrefs.getString("owner_photo_uri", "") ?: "")
    val ownerPhotoUri: StateFlow<String> = _ownerPhotoUri.asStateFlow()

    private val _currentCurrency = MutableStateFlow(ownerPrefs.getString("current_currency", "LKR (Rs.)") ?: "LKR (Rs.)")
    val currentCurrency: StateFlow<String> = _currentCurrency.asStateFlow()

    private val _notificationMode = MutableStateFlow(ownerPrefs.getString("notification_mode", "BOTH") ?: "BOTH")
    val notificationMode: StateFlow<String> = _notificationMode.asStateFlow()

    private val _selectedSimSlot = MutableStateFlow(ownerPrefs.getInt("selected_sim_slot", 0))
    val selectedSimSlot: StateFlow<Int> = _selectedSimSlot.asStateFlow()

    fun saveSelectedSimSlot(slotId: Int) {
        _selectedSimSlot.value = slotId
        ownerPrefs.edit()
            .putInt("selected_sim_slot", slotId)
            .apply()
    }

    fun saveRegistrationDetails(lenderId: String, spreadsheetLink: String, ownerName: String, ownerPhone: String, email: String = "", webAppUrl: String = "") {
        _lenderId.value = lenderId
        _spreadsheetLink.value = spreadsheetLink
        _ownerName.value = ownerName
        _ownerPhone.value = ownerPhone
        _webAppUrl.value = webAppUrl
        ownerPrefs.edit()
            .putString("lender_id", lenderId)
            .putString("spreadsheet_link", spreadsheetLink)
            .putString("owner_name", ownerName)
            .putString("owner_phone", ownerPhone)
            .putString("web_app_url", webAppUrl)
            .apply()
        if (email.isNotBlank()) {
            saveEmailConfig(email, "")
        }
    }

    fun cloudRestore(spreadsheetLinkOrId: String, lenderId: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val (customers, loans, payments) = com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager.restoreFromCloud(context, spreadsheetLinkOrId, lenderId)
                
                if (customers.isEmpty() && loans.isEmpty() && payments.isEmpty()) {
                    viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                        onResult(false, "No matching records found for Lender ID: $lenderId")
                    }
                    return@launch
                }

                repository.restoreDatabase(customers, loans, payments)

                saveRegistrationDetails(lenderId, spreadsheetLinkOrId, _ownerName.value, _ownerPhone.value)

                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    onResult(true, "Successfully restored ${customers.size} Customers, ${loans.size} Loans, and ${payments.size} Transactions from cloud!")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    onResult(false, "Restore failed: ${e.localizedMessage}")
                }
            }
        }
    }

    fun restoreFromDrive(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val success = com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager.restoreDatabaseFromDrive(context)
                if (success) {
                    // Refresh values from the newly restored database SharedPreferences
                    val sharedPrefsOwner = context.getSharedPreferences("money_master_owner_prefs", android.content.Context.MODE_PRIVATE)
                    val lId = sharedPrefsOwner.getString("lender_id", "") ?: ""
                    val sLink = sharedPrefsOwner.getString("spreadsheet_link", "") ?: ""
                    val wUrl = sharedPrefsOwner.getString("web_app_url", "") ?: ""
                    val oName = sharedPrefsOwner.getString("owner_name", "") ?: ""
                    val oPhone = sharedPrefsOwner.getString("owner_phone", "") ?: ""
                    val oPhoto = sharedPrefsOwner.getString("owner_photo_uri", "") ?: ""
                    val oCurrency = sharedPrefsOwner.getString("current_currency", "LKR (Rs.)") ?: "LKR (Rs.)"

                    _lenderId.value = lId
                    _spreadsheetLink.value = sLink
                    _webAppUrl.value = wUrl
                    _ownerName.value = oName
                    _ownerPhone.value = oPhone
                    _ownerPhotoUri.value = oPhoto
                    _currentCurrency.value = oCurrency

                    viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                        onResult(true, "Database successfully restored from Google Drive!")
                    }
                } else {
                    viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                        onResult(false, "No backup file found in Google Drive.")
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    onResult(false, "Drive restore failed: ${e.localizedMessage}")
                }
            }
        }
    }

    init {
        // Initialize currency symbol
        com.moneymaster.cleanapp.utils.LocalizedText.selectedCurrencySymbol = when {
            _currentCurrency.value.contains("$") -> "$"
            _currentCurrency.value.contains("€") -> "€"
            else -> "Rs."
        }
    }

    // Email Configuration persistence
    private val emailPrefs = context.getSharedPreferences("money_master_email_prefs", android.content.Context.MODE_PRIVATE)

    private val _senderEmail = MutableStateFlow(emailPrefs.getString("sender_email", "") ?: "")
    val senderEmail: StateFlow<String> = _senderEmail.asStateFlow()

    private val _appPassword = MutableStateFlow(emailPrefs.getString("app_password", "") ?: "")
    val appPassword: StateFlow<String> = _appPassword.asStateFlow()

    fun saveEmailConfig(email: String, password: String) {
        _senderEmail.value = email
        _appPassword.value = password
        emailPrefs.edit()
            .putString("sender_email", email)
            .putString("app_password", password)
            .apply()
    }

    fun updateOwnerDetails(name: String, phone: String, photoUri: String, currency: String) {
        _ownerName.value = name
        _ownerPhone.value = phone
        _ownerPhotoUri.value = photoUri
        _currentCurrency.value = currency
        com.moneymaster.cleanapp.utils.LocalizedText.selectedCurrencySymbol = when {
            currency.contains("$") -> "$"
            currency.contains("€") -> "€"
            else -> "Rs."
        }
        ownerPrefs.edit()
            .putString("owner_name", name)
            .putString("owner_phone", phone)
            .putString("owner_photo_uri", photoUri)
            .putString("current_currency", currency)
            .apply()
    }

    fun updateNotificationMode(mode: String) {
        _notificationMode.value = mode
        ownerPrefs.edit()
            .putString("notification_mode", mode)
            .apply()
    }

    fun setLanguage(lang: Language) {
        _currentLanguage.value = lang
        ownerPrefs.edit()
            .putString("current_language", lang.name)
            .apply()
    }

    // Selected loan ID for detail view / bottom sheet
    private val _selectedLoanId = MutableStateFlow<Int?>(null)
    val selectedLoanId: StateFlow<Int?> = _selectedLoanId.asStateFlow()

    // Flows from database
    val allLoans: StateFlow<List<Loan>> = repository.allLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeLoans: StateFlow<List<Loan>> = repository.activeLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<Payment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCustomers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected loan flow
    val selectedLoan: StateFlow<Loan?> = _selectedLoanId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getLoanById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Payments for selected loan
    val selectedLoanPayments: StateFlow<List<Payment>> = _selectedLoanId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getPaymentsForLoan(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined dashboard summary
    val dashboardSummary: StateFlow<DashboardSummary> = combine(activeLoans, allPayments) { loans, payments ->
        var totalLent = 0.0
        var totalInterest = 0.0
        var totalOutstanding = 0.0

        totalLent = loans.sumOf { it.principalAmount }
        totalInterest = payments.filter { it.type == "Interest" }.sumOf { it.amount }

        loans.forEach { loan ->
            val loanPayments = payments.filter { it.loanId == loan.id }
            val summary = LoanCalculator.calculateLoanSummary(loan, loanPayments)
            totalOutstanding += summary.totalOutstanding
        }

        DashboardSummary(
            totalLent = totalLent,
            totalInterestEarned = totalInterest,
            totalOutstanding = totalOutstanding
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary(0.0, 0.0, 0.0))

    fun toggleLanguage() {
        _currentLanguage.update {
            if (it == Language.ENGLISH) Language.SINHALA else Language.ENGLISH
        }
    }

    fun selectLoan(id: Int?) {
        _selectedLoanId.value = id
    }

    fun addCustomer(
        name: String,
        address: String,
        phone: String,
        nic: String,
        photoUri: String = "",
        nicPhotoUri: String = "",
        email: String? = null,
        agreementLetterUri: String = "",
        onResult: ((Boolean, String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            try {
                val resolvedEmail = email?.ifBlank { null }
                val customer = Customer(
                    name = name,
                    address = address,
                    phone = phone,
                    nic = nic,
                    photoUri = photoUri,
                    nicPhotoUri = nicPhotoUri,
                    email = resolvedEmail,
                    agreementLetterUri = agreementLetterUri
                )
                val customerId = repository.insertCustomer(customer).toInt()
                val registeredCustomer = customer.copy(id = customerId)
                if (spreadsheetLink.value.isNotBlank() && lenderId.value.isNotBlank()) {
                    com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager.appendCustomer(
                        context,
                        spreadsheetLink.value,
                        lenderId.value,
                        registeredCustomer
                    )
                }
                try {
                    com.moneymaster.cleanapp.utils.NotificationOrchestrator.triggerCustomerNotification(context, registeredCustomer)
                } catch (e: Exception) {
                    android.util.Log.e("NotificationOrchestrator", "Error sending customer registered notification: ${e.message}")
                }
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    onResult?.invoke(true, "Customer successfully registered!")
                }
            } catch (e: android.database.sqlite.SQLiteConstraintException) {
                e.printStackTrace()
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    onResult?.invoke(false, "Duplicate entry: Phone, NIC, or Email is already registered to another customer.")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    onResult?.invoke(false, "Failed to register customer: ${e.localizedMessage}")
                }
            }
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    fun addLoan(
        customerId: Int? = null,
        name: String,
        phone: String,
        principal: Double,
        rate: Double,
        period: String,
        notes: String,
        startDate: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            val loan = Loan(
                customerId = customerId,
                borrowerName = name,
                borrowerPhone = phone,
                principalAmount = principal,
                interestRate = rate,
                interestPeriod = period,
                startDate = startDate,
                notes = notes,
                isSettled = false
            )
            val loanId = repository.insertLoan(loan).toInt()
            val insertedLoan = loan.copy(id = loanId)

            if (spreadsheetLink.value.isNotBlank() && lenderId.value.isNotBlank()) {
                com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager.appendLoan(
                    context,
                    spreadsheetLink.value,
                    lenderId.value,
                    insertedLoan
                )
            }

            var pdfFile: java.io.File? = null
            var customer: com.moneymaster.cleanapp.data.Customer? = null
            if (customerId != null) {
                try {
                    customer = repository.getCustomerByIdDirect(customerId)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            if (customer == null) {
                customer = com.moneymaster.cleanapp.data.Customer(
                    name = name,
                    address = "",
                    phone = phone,
                    nic = "",
                    email = null
                )
            }

            try {
                val payments = emptyList<com.moneymaster.cleanapp.data.Payment>()
                val summary = com.moneymaster.cleanapp.utils.LoanCalculator.calculateLoanSummary(insertedLoan, payments)
                pdfFile = com.moneymaster.cleanapp.utils.PdfReportService.generatePdfReport(
                    context = context,
                    loan = insertedLoan,
                    customer = customer,
                    payments = payments,
                    summary = summary,
                    lang = _currentLanguage.value,
                    ownerName = _ownerName.value,
                    ownerPhone = _ownerPhone.value,
                    ownerPhotoUri = _ownerPhotoUri.value
                )
                if (pdfFile != null) {
                    android.util.Log.i("PDF_GENERATION", "Loan Invoice PDF successfully generated: ${pdfFile.absolutePath}")
                }
            } catch (e: Exception) {
                e.printStackTrace()
                android.util.Log.e("PDF_GENERATION", "Error generating loan invoice PDF: ${e.message}")
            }

            try {
                com.moneymaster.cleanapp.utils.NotificationOrchestrator.triggerLoanNotification(
                    context = context,
                    loan = insertedLoan,
                    customer = customer,
                    pdfFile = pdfFile
                )
            } catch (e: Exception) {
                e.printStackTrace()
                android.util.Log.e("NOTIFICATION", "Error triggering loan notification: ${e.message}")
            }
        }
    }

    fun recordPayment(loanId: Int, amount: Double, type: String, notes: String, paymentDate: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            val payment = Payment(
                loanId = loanId,
                amount = amount,
                paymentDate = paymentDate,
                type = type,
                notes = notes
            )
            val paymentId = repository.insertPayment(payment).toInt()
            val insertedPayment = payment.copy(id = paymentId)
            
            if (spreadsheetLink.value.isNotBlank() && lenderId.value.isNotBlank()) {
                com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager.appendPayment(
                    context,
                    spreadsheetLink.value,
                    lenderId.value,
                    insertedPayment
                )
            }
            
            val isFull = type == "Full Settle"
            val loan = repository.getLoanById(loanId).firstOrNull()
            if (loan != null && isFull) {
                repository.updateLoan(loan.copy(isSettled = true))
            }

            triggerSmsAlert(loanId, amount, type)
        }
    }

    fun settleLoan(loanId: Int, notes: String = "") {
        viewModelScope.launch {
            repository.getLoanById(loanId).firstOrNull()?.let { loan ->
                val payments = repository.getPaymentsForLoan(loanId).firstOrNull() ?: emptyList()
                val summary = LoanCalculator.calculateLoanSummary(loan, payments)
                val outstanding = summary.totalOutstanding
                
                if (outstanding > 0) {
                    val p = Payment(
                        loanId = loanId,
                        amount = outstanding,
                        paymentDate = System.currentTimeMillis(),
                        type = "Full Settle",
                        notes = notes.ifEmpty { "Manual Full Settlement" }
                    )
                    val paymentId = repository.insertPayment(p).toInt()
                    val insertedPayment = p.copy(id = paymentId)
                    if (spreadsheetLink.value.isNotBlank() && lenderId.value.isNotBlank()) {
                        com.moneymaster.cleanapp.utils.GoogleSheetsSyncManager.appendPayment(
                            context,
                            spreadsheetLink.value,
                            lenderId.value,
                            insertedPayment
                        )
                    }
                }
                
                repository.updateLoan(loan.copy(isSettled = true))

                triggerSmsAlert(loanId, outstanding, "Full Settle")
            }
        }
    }

    private fun triggerSmsAlert(loanId: Int, paidAmount: Double, type: String) {
        viewModelScope.launch {
            try {
                val loan = repository.getLoanById(loanId).firstOrNull() ?: return@launch
                val customer = loan.customerId?.let { repository.getCustomerById(it).firstOrNull() }
                val payments = repository.getPaymentsForLoan(loanId).firstOrNull() ?: emptyList()
                val summary = LoanCalculator.calculateLoanSummary(loan, payments)
                
                val payment = payments.lastOrNull() ?: Payment(
                    loanId = loanId,
                    amount = paidAmount,
                    paymentDate = System.currentTimeMillis(),
                    type = type,
                    notes = ""
                )

                val isEmailEnabled = _notificationMode.value == "EMAIL_ONLY" || _notificationMode.value == "BOTH"
                var pdfFile: java.io.File? = null
                if (isEmailEnabled && customer != null && !customer.email.isNullOrBlank()) {
                    pdfFile = com.moneymaster.cleanapp.utils.PdfReportService.generatePdfReport(
                        context = context,
                        loan = loan,
                        customer = customer,
                        payments = payments,
                        summary = summary,
                        lang = _currentLanguage.value,
                        ownerName = _ownerName.value,
                        ownerPhone = _ownerPhone.value,
                        ownerPhotoUri = _ownerPhotoUri.value
                    )
                }

                com.moneymaster.cleanapp.utils.NotificationOrchestrator.triggerPaymentNotification(
                    context = context,
                    loan = loan,
                    customer = customer,
                    payment = payment,
                    remainingOutstanding = summary.totalOutstanding,
                    pdfFile = pdfFile
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun sendSmsDirectly(phone: String, message: String) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.SEND_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try {
                val smsManager = context.getSystemService(android.telephony.SmsManager::class.java) 
                    ?: @Suppress("DEPRECATION") android.telephony.SmsManager.getDefault()
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
                android.util.Log.d("SMS_ALERT", "SMS alert successfully sent to $phone directly.")
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    android.widget.Toast.makeText(context, "✓ SMS Alert sent to $phone successfully.", android.widget.Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                android.util.Log.e("SMS_ALERT", "Error sending SMS directly: ${e.message}")
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                    android.widget.Toast.makeText(context, "❌ Direct SMS failed: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            android.util.Log.d("SMS_ALERT", "SEND_SMS permission not granted. Background SMS alert could not be sent.")
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.Main) {
                android.widget.Toast.makeText(context, "⚠️ SMS Permission not granted. Automatic SMS alert skipped.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    fun deleteLoan(loanId: Int) {
        viewModelScope.launch {
            repository.getLoanById(loanId).firstOrNull()?.let { loan ->
                repository.deleteLoan(loan)
                if (_selectedLoanId.value == loanId) {
                    _selectedLoanId.value = null
                }
            }
        }
    }

    class Factory(
        private val repository: LoanRepository,
        private val context: android.content.Context
    ) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoanViewModel::class.java)) {
                @Suppress("UNCHECKED_CAST")
                return LoanViewModel(repository, context.applicationContext) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
