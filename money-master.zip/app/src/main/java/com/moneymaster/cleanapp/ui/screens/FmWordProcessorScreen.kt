package com.moneymaster.cleanapp.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.moneymaster.cleanapp.utils.FmEditorBridge
import com.moneymaster.cleanapp.utils.Language

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun FmWordProcessorScreen(
    currentLang: Language,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isLoading by remember { mutableStateOf(true) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showScanner by remember { mutableStateOf(false) }

    // Launcher for Gallery Picking
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val base64 = getBase64FromUri(context, uri)
            if (base64 != null) {
                webViewRef?.post {
                    webViewRef?.evaluateJavascript(
                        "javascript:insertImage('data:image/jpeg;base64,$base64')",
                        null
                    )
                }
            } else {
                Toast.makeText(context, "Failed to load gallery image data", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Direct inline overlay display of Document Camera Scanner
    if (showScanner) {
        DocumentScannerView(
            onImageCaptured = { uri ->
                showScanner = false
                val base64 = getBase64FromUri(context, uri)
                if (base64 != null) {
                    webViewRef?.post {
                        webViewRef?.evaluateJavascript(
                            "javascript:insertImage('data:image/jpeg;base64,$base64')",
                            null
                        )
                    }
                } else {
                    Toast.makeText(context, "Failed to read scanned image", Toast.LENGTH_SHORT).show()
                }
            },
            onClose = {
                showScanner = false
            }
        )
        return
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        AndroidView(
            factory = { ctx ->
                WebView(ctx).apply {
                    webViewRef = this
                    
                    // Native HTML Editor configuration options
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.allowFileAccess = true
                    settings.allowContentAccess = true

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            if (newProgress >= 100) {
                                isLoading = false
                            }
                        }
                    }

                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            isLoading = false
                        }
                    }

                    // Add Javascript bridge with thread-safe UI Handler dispatches
                    addJavascriptInterface(
                        FmEditorBridge(
                            context = ctx,
                            onClose = onDismiss,
                            onPickFromCamera = {
                                Handler(Looper.getMainLooper()).post {
                                    showScanner = true
                                }
                            },
                            onPickFromGallery = {
                                Handler(Looper.getMainLooper()).post {
                                    galleryLauncher.launch("image/*")
                                }
                            }
                        ),
                        "Android"
                    )

                    // Load our local editor HTML
                    loadUrl("file:///android_asset/fm_editor.html")
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { webView ->
                // WebView state is internally driven by the HTML content
            }
        )

        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF121212)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFFFFB300)
                    )
                    Text(
                        text = if (currentLang == Language.SINHALA) "සකසනය සූදානම් කරමින්..." else "Initializing Office Writer...",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

/**
 * Utility method to parse Uri from media storage content resolver and encode as Base64.
 */
private fun getBase64FromUri(context: android.content.Context, uri: Uri): String? {
    return try {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            val bytes = inputStream.readBytes()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
