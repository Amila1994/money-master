package com.moneymaster.cleanapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Money Master Premium Dark Colors
val DarkBg = Color(0xFF0F111A)
val CardBg = Color(0xFF161B22)
val AccentAmber = Color(0xFFFFA000)
val SoftGold = Color(0xFFFFD54F)
val EmeraldGreen = Color(0xFF00E676)
val SoftGreenBg = Color(0xFF142B20)
val DarkGreyBg = Color(0xFF1F2633)
val TextLight = Color(0xFFF0F2F5)
val TextGray = Color(0xFF9EA3AE)
val BorderColor = Color(0xFF2A2E3D)

