package com.moneymaster.cleanapp.utils

import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import java.util.concurrent.TimeUnit
import kotlin.math.max

object LoanCalculator {
    fun calculateLoanSummary(loan: Loan, payments: List<Payment>, currentTime: Long = System.currentTimeMillis()): LoanSummary {
        val loanPayments = payments.filter { it.loanId == loan.id }
        
        // Sum payments by type
        val paidPrincipal = loanPayments.filter { (it.type == "Principal" || it.type == "Full Settle") && it.paymentDate <= currentTime }.sumOf { it.amount }
        val paidInterest = loanPayments.filter { it.type == "Interest" && it.paymentDate <= currentTime }.sumOf { it.amount }
        
        // Find the date of the last "Interest" payment that is <= currentTime
        val lastInterestPayment = loanPayments.filter { it.type == "Interest" && it.paymentDate <= currentTime }.maxByOrNull { it.paymentDate }
        val lastPaymentDate = lastInterestPayment?.paymentDate ?: loan.startDate
        
        // Time elapsed since last interest payment
        val timeDiffMillis = max(0L, currentTime - lastPaymentDate)
        val daysElapsed = TimeUnit.MILLISECONDS.toDays(timeDiffMillis)
        
        // Convert days to period units
        val periodUnits = when (loan.interestPeriod) {
            "Daily" -> daysElapsed.toDouble()
            "Weekly" -> daysElapsed / 7.0
            "Monthly" -> daysElapsed / 30.0
            else -> daysElapsed / 30.0 // Default to monthly
        }
        
        // Simple Interest calculation: Remaining Principal * (Rate / 100) * Time
        val remainingPrincipal = max(0.0, loan.principalAmount - paidPrincipal)
        val interestRateFraction = loan.interestRate / 100.0
        val accruedInterest = remainingPrincipal * interestRateFraction * periodUnits
        
        // Outstanding interest is simply the accrued interest since the last interest payment
        val outstandingInterest = max(0.0, accruedInterest)
        
        val totalOutstanding = if (loan.isSettled) 0.0 else (remainingPrincipal + outstandingInterest)
        
        return LoanSummary(
            accruedInterest = accruedInterest,
            paidPrincipal = paidPrincipal,
            paidInterest = paidInterest,
            remainingPrincipal = remainingPrincipal,
            outstandingInterest = outstandingInterest,
            totalOutstanding = totalOutstanding,
            daysElapsed = daysElapsed,
            periodUnits = periodUnits
        )
    }
}

data class LoanSummary(
    val accruedInterest: Double,
    val paidPrincipal: Double,
    val paidInterest: Double,
    val remainingPrincipal: Double,
    val outstandingInterest: Double,
    val totalOutstanding: Double,
    val daysElapsed: Long,
    val periodUnits: Double
)
