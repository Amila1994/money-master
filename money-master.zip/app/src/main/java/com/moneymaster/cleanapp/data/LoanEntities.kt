package com.moneymaster.cleanapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["phone"], unique = true),
        Index(value = ["nic"], unique = true),
        Index(value = ["email"], unique = true)
    ]
)
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val address: String,
    val phone: String,
    val nic: String,
    val photoUri: String = "",
    val nicPhotoUri: String = "",
    val email: String? = null,
    val agreementLetterUri: String = ""
)

@Entity(tableName = "loans")
data class Loan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int? = null, // link to customer optional
    val borrowerName: String,
    val borrowerPhone: String,
    val principalAmount: Double,
    val interestRate: Double, // percentage, e.g., 5.0 for 5%
    val interestPeriod: String, // "Monthly", "Weekly", "Daily"
    val startDate: Long, // timestamp
    val notes: String = "",
    val isSettled: Boolean = false
)

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Loan::class,
            parentColumns = ["id"],
            childColumns = ["loanId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["loanId"])]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val loanId: Int,
    val amount: Double,
    val paymentDate: Long,
    val type: String, // "Interest", "Principal", "Full Settle"
    val notes: String = ""
)
