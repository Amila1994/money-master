package com.moneymaster.cleanapp.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import com.moneymaster.cleanapp.ui.LoanViewModel
import com.moneymaster.cleanapp.ui.theme.*
import kotlinx.coroutines.launch
import com.moneymaster.cleanapp.utils.Language
import com.moneymaster.cleanapp.utils.LoanCalculator
import com.moneymaster.cleanapp.utils.LocalizedText
import com.moneymaster.cleanapp.utils.PdfReportService
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: LoanViewModel,
    modifier: Modifier = Modifier,
    countdownSeconds: Int = 45,
    onWatchAdClick: () -> Unit = {},
    onBuyPackageClick: (String, Double) -> Unit = { _, _ -> },
    onDriveConnectClick: () -> Unit = {},
    onDriveBackupClick: () -> Unit = {},
    onDriveRestoreClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val activeLoans by viewModel.activeLoans.collectAsStateWithLifecycle()
    val allLoans by viewModel.allLoans.collectAsStateWithLifecycle()
    val allPayments by viewModel.allPayments.collectAsStateWithLifecycle()
    val customers by viewModel.allCustomers.collectAsStateWithLifecycle()

    val selectedLoan by viewModel.selectedLoan.collectAsStateWithLifecycle()
    val selectedPayments by viewModel.selectedLoanPayments.collectAsStateWithLifecycle()
    val ownerName by viewModel.ownerName.collectAsStateWithLifecycle()
    val ownerPhone by viewModel.ownerPhone.collectAsStateWithLifecycle()
    val ownerPhotoUri by viewModel.ownerPhotoUri.collectAsStateWithLifecycle()
    val isPremiumUser by viewModel.isPremiumUser.collectAsStateWithLifecycle()
    val watchedAdsToday by viewModel.watchedAdsToday.collectAsStateWithLifecycle()
    val isBlocked by viewModel.isBlockedFromFreeFeatures.collectAsStateWithLifecycle()
    
    val isFreePlan = !isPremiumUser && watchedAdsToday < 25
    var showRestrictionDialog by remember { mutableStateOf(false) }

    // Main Bottom Navigation: 0 = Summary, 1 = Customers, 2 = Loan Ledger (Default to 2)
    var currentBottomTab by remember { mutableStateOf(2) }

    // Tab state: 0 = Active Loans, 1 = All Loans, 2 = Calculator
    var selectedTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var customerSearchQuery by remember { mutableStateOf("") }
    var selectedFilterKey by remember { mutableStateOf("all") }

    // Dialog flags
    var showAddLoanDialog by remember { mutableStateOf(false) }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showPaymentDialogLoanId by remember { mutableStateOf<Int?>(null) }
    var showDetailsDialog by remember { mutableStateOf(false) }
    var showSettleConfirmationLoanId by remember { mutableStateOf<Int?>(null) }

    // View image state
    var viewImageUriAndTitle by remember { mutableStateOf<Pair<String, String>?>(null) }

    // Prefill states for new loans
    var prefilledName by remember { mutableStateOf("") }
    var prefilledPhone by remember { mutableStateOf("") }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBg,
                    titleContentColor = AccentAmber
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wallet,
                            contentDescription = "Wallet Icon",
                            tint = AccentAmber,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = LocalizedText.get("app_title", currentLang),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp
                            )
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = { viewModel.toggleLanguage() },
                        modifier = Modifier.testTag("language_toggle_button")
                    ) {
                        Text(
                            text = if (currentLang == Language.ENGLISH) "සිංහල" else "English",
                            color = AccentAmber,
                            fontWeight = FontWeight.Bold,
                            fontStyle = FontStyle.Italic,
                            fontSize = 16.sp
                        )
                    }
                }
            )
        },
        bottomBar = {
            Column {
                AdmobBannerAd(isPremium = isPremiumUser)
                NavigationBar(
                    containerColor = DarkBg,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentBottomTab == 0,
                        onClick = { currentBottomTab = 0 },
                        icon = { Icon(Icons.Default.GridView, contentDescription = "Summary") },
                        label = { Text(LocalizedText.get("tab_summary", currentLang), fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AccentAmber,
                            indicatorColor = AccentAmber,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 1,
                        onClick = { currentBottomTab = 1 },
                        icon = { Icon(Icons.Default.Group, contentDescription = "Customers") },
                        label = { Text(LocalizedText.get("tab_customers", currentLang), fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AccentAmber,
                            indicatorColor = AccentAmber,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 2,
                        onClick = { currentBottomTab = 2 },
                        icon = { Icon(Icons.Default.Description, contentDescription = "Loan Ledger") },
                        label = { Text(LocalizedText.get("tab_loan_ledger", currentLang), fontSize = 12.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AccentAmber,
                            indicatorColor = AccentAmber,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 3,
                        onClick = { currentBottomTab = 3 },
                        icon = { Icon(Icons.Default.Person, contentDescription = "My Profile") },
                        label = { Text(LocalizedText.get("tab_profile", currentLang), fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AccentAmber,
                            indicatorColor = AccentAmber,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                    NavigationBarItem(
                        selected = currentBottomTab == 4,
                        onClick = { currentBottomTab = 4 },
                        icon = { Icon(Icons.Default.Star, contentDescription = "Premium & Ads") },
                        label = { Text(LocalizedText.get("tab_premium", currentLang), fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black,
                            selectedTextColor = AccentAmber,
                            indicatorColor = AccentAmber,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentBottomTab == 2 && selectedTab != 2) {
                FloatingActionButton(
                    onClick = {
                        prefilledName = ""
                        prefilledPhone = ""
                        showAddLoanDialog = true
                    },
                    containerColor = AccentAmber,
                    contentColor = Color.Black,
                    modifier = Modifier
                        .padding(16.dp)
                        .testTag("add_loan_fab"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Loan",
                        modifier = Modifier.size(28.dp)
                    )
                }
            } else if (currentBottomTab == 1) {
                FloatingActionButton(
                    onClick = {
                        if (isFreePlan && customers.size >= 3) {
                            showRestrictionDialog = true
                        } else {
                            showAddCustomerDialog = true
                        }
                    },
                    containerColor = AccentAmber,
                    contentColor = Color.Black,
                    modifier = Modifier
                        .padding(16.dp)
                        .testTag("add_customer_fab"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = "Add Customer",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        },
        containerColor = DarkBg
    ) { innerPadding ->
        when (currentBottomTab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        // Workspace Info Box
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = CardBg),
                            shape = RoundedCornerShape(16.dp),
                            border = CardDefaults.outlinedCardBorder()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = LocalizedText.get("workspace_title", currentLang),
                                    color = AccentAmber,
                                    fontWeight = FontWeight.Bold,
                                    fontStyle = FontStyle.Italic,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = LocalizedText.get("workspace_desc", currentLang),
                                    color = TextGray,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }

                    item {
                        Text(
                            text = LocalizedText.get("summary", currentLang),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }

                    // Summary Cards
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Card 1: Total Lent Amount
                            SummaryCard(
                                title = LocalizedText.get("total_lent", currentLang),
                                amount = formatRupees(summary.totalLent),
                                icon = Icons.Default.TrendingUp,
                                cardColor = DarkGreyBg,
                                iconBgColor = Color(0xFF141923),
                                iconColor = AccentAmber
                            )

                            // Card 2: Received Interest Income
                            SummaryCard(
                                title = LocalizedText.get("total_interest", currentLang),
                                amount = formatRupees(summary.totalInterestEarned),
                                icon = Icons.Default.Savings,
                                cardColor = SoftGreenBg,
                                iconBgColor = Color(0xFF0D1F16),
                                iconColor = EmeraldGreen
                            )

                            // Card 3: Total Outstanding Balance
                            SummaryCard(
                                title = LocalizedText.get("total_outstanding", currentLang),
                                amount = formatRupees(summary.totalOutstanding),
                                icon = Icons.Default.AccountBalanceWallet,
                                cardColor = Color(0xFF1B223C),
                                iconBgColor = Color(0xFF111526),
                                iconColor = SoftGold
                            )
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
            1 -> {
                val filteredCustomers = customers.filter {
                        it.name.contains(customerSearchQuery, ignoreCase = true) ||
                                it.phone.contains(customerSearchQuery) ||
                                it.nic.contains(customerSearchQuery)
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = LocalizedText.get("tab_customers", currentLang),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = customerSearchQuery,
                            onValueChange = { customerSearchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("customer_search_field"),
                            placeholder = { Text("සොයන්න (නම, දුරකතන, NIC)...", color = TextGray) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextGray) },
                            trailingIcon = {
                                if (customerSearchQuery.isNotEmpty()) {
                                    IconButton(onClick = { customerSearchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextGray)
                                    }
                                }
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = AccentAmber,
                                unfocusedBorderColor = BorderColor,
                                focusedContainerColor = CardBg,
                                unfocusedContainerColor = CardBg
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }

                    if (filteredCustomers.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 40.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Group,
                                    contentDescription = "No Customers",
                                    tint = TextGray,
                                    modifier = Modifier.size(48.dp)
                                )
                                Text(
                                    text = LocalizedText.get("no_customers", currentLang),
                                    color = TextGray,
                                    textAlign = TextAlign.Center,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    } else {
                        items(filteredCustomers, key = { it.id }) { customer ->
                            CustomerCard(
                                customer = customer,
                                lang = currentLang,
                                onViewImage = { uri, title ->
                                    viewImageUriAndTitle = Pair(uri, title)
                                },
                                onAddLoanClick = {
                                    prefilledName = customer.name
                                    prefilledPhone = customer.phone
                                    showAddLoanDialog = true
                                },
                                onDeleteClick = {
                                    viewModel.deleteCustomer(customer)
                                    Toast.makeText(context, "Customer deleted", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
            2 -> {
                LazyColumn(
                    modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = LocalizedText.get("tab_loan_ledger", currentLang),
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        )
                    }

                    item {
                        TabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = Color.Transparent,
                            contentColor = AccentAmber,
                            divider = {},
                            modifier = Modifier.padding(vertical = 8.dp)
                        ) {
                            Tab(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                text = {
                                    Text(
                                        LocalizedText.get("active_loans", currentLang),
                                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                            )
                            Tab(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                text = {
                                    Text(
                                        LocalizedText.get("all_loans", currentLang),
                                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                            )
                            Tab(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                text = {
                                    Text(
                                        LocalizedText.get("calculator", currentLang),
                                        fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                            )
                        }
                    }

                    if (selectedTab == 2) {
                        item {
                            InterestCalculatorView(currentLang)
                        }
                    } else {
                        val calendar = Calendar.getInstance()
                        val todayCal = Calendar.getInstance()
                        val yearFormat = SimpleDateFormat("yyyy", Locale.getDefault())

                        val loansToDisplay = if (selectedTab == 0) activeLoans else allLoans
                        var filteredLoans = loansToDisplay.filter { loan ->
                            // 1. Advanced Multi-Search (Loan ID, Name, Phone, or NIC)
                            val customer = customers.find { it.id == loan.customerId }
                            val sDate = Date(loan.startDate)
                            val yearStr = yearFormat.format(sDate)
                            val formattedLoanId = "LN-$yearStr-${String.format(Locale.getDefault(), "%03d", loan.id)}"

                            val matchesSearch = searchQuery.isBlank() ||
                                    formattedLoanId.contains(searchQuery, ignoreCase = true) ||
                                    loan.borrowerName.contains(searchQuery, ignoreCase = true) ||
                                    loan.borrowerPhone.contains(searchQuery) ||
                                    (customer != null && customer.nic.contains(searchQuery, ignoreCase = true))

                            // 2. Dropdown Filter logic
                            val loanCal = Calendar.getInstance().apply { timeInMillis = loan.startDate }
                            val matchesFilter = when (selectedFilterKey) {
                                "today" -> {
                                    loanCal.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR) &&
                                            loanCal.get(Calendar.DAY_OF_YEAR) == todayCal.get(Calendar.DAY_OF_YEAR)
                                }
                                "monthly" -> {
                                    loanCal.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR) &&
                                            loanCal.get(Calendar.MONTH) == todayCal.get(Calendar.MONTH)
                                }
                                "yearly" -> {
                                    loanCal.get(Calendar.YEAR) == todayCal.get(Calendar.YEAR)
                                }
                                "active" -> {
                                    !loan.isSettled
                                }
                                else -> true // "all" and "highest" don't restrict by date/status
                            }

                            matchesSearch && matchesFilter
                        }

                        // 3. Sorting (Highest Loan Amount)
                        if (selectedFilterKey == "highest") {
                            filteredLoans = filteredLoans.sortedByDescending { loan -> loan.principalAmount }
                        }

                        item {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("loan_search_field"),
                                placeholder = { Text(LocalizedText.get("search_advanced_placeholder", currentLang), color = TextGray) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextGray) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextGray)
                                        }
                                    }
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = AccentAmber,
                                    unfocusedBorderColor = BorderColor,
                                    focusedContainerColor = CardBg,
                                    unfocusedContainerColor = CardBg
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        // 🎛️ Filter Dropdown Card
                        item {
                            var expandedFilterDropdown by remember { mutableStateOf(false) }
                            val filterOptions = listOf(
                                "all" to LocalizedText.get("filter_all", currentLang),
                                "today" to LocalizedText.get("filter_today", currentLang),
                                "monthly" to LocalizedText.get("filter_monthly", currentLang),
                                "yearly" to LocalizedText.get("filter_yearly", currentLang),
                                "active" to LocalizedText.get("filter_active", currentLang),
                                "highest" to LocalizedText.get("filter_highest_amount", currentLang)
                            )
                            val selectedOptionText = filterOptions.find { it.first == selectedFilterKey }?.second ?: ""

                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(CardBg, shape = RoundedCornerShape(12.dp))
                                    .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                                    .clickable { expandedFilterDropdown = true }
                                    .padding(horizontal = 16.dp, vertical = 14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Tune,
                                            contentDescription = "Filter",
                                            tint = AccentAmber,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = selectedOptionText,
                                            color = Color.White,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Dropdown",
                                        tint = TextGray
                                    )
                                }

                                DropdownMenu(
                                    expanded = expandedFilterDropdown,
                                    onDismissRequest = { expandedFilterDropdown = false },
                                    modifier = Modifier
                                        .background(CardBg)
                                        .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                                ) {
                                    filterOptions.forEach { option ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = option.second,
                                                    color = if (selectedFilterKey == option.first) AccentAmber else Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = if (selectedFilterKey == option.first) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            onClick = {
                                                selectedFilterKey = option.first
                                                expandedFilterDropdown = false
                                            }
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        if (filteredLoans.isEmpty()) {
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 40.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "No Loans",
                                        tint = TextGray,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Text(
                                        text = LocalizedText.get("no_loans", currentLang),
                                        color = TextGray,
                                        textAlign = TextAlign.Center,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        } else {
                            items(filteredLoans, key = { it.id }) { loan ->
                                val loanPayments = allPayments.filter { it.loanId == loan.id }
                                val calcSummary = LoanCalculator.calculateLoanSummary(loan, loanPayments)

                                LoanCard(
                                    loan = loan,
                                    summary = calcSummary,
                                    lang = currentLang,
                                    onDetailsClick = {
                                        viewModel.selectLoan(loan.id)
                                        showDetailsDialog = true
                                    },
                                    onAddPaymentClick = {
                                        showPaymentDialogLoanId = loan.id
                                    },
                                    onSettleClick = {
                                        showSettleConfirmationLoanId = loan.id
                                    },
                                    onCallClick = {
                                        if (loan.borrowerPhone.isNotEmpty()) {
                                            try {
                                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                                    data = Uri.parse("tel:${loan.borrowerPhone}")
                                                }
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Cannot open dialer", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            Toast.makeText(context, LocalizedText.get("phone_empty", currentLang), Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                        }
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
            3 -> {
                AdminProfileTab(
                    viewModel = viewModel,
                    lang = currentLang,
                    innerPadding = innerPadding,
                    onDriveConnectClick = onDriveConnectClick,
                    onDriveBackupClick = onDriveBackupClick,
                    onDriveRestoreClick = onDriveRestoreClick
                )
            }
            4 -> {
                SubscriptionAndAdsManagerScreen(
                    viewModel = viewModel,
                    lang = currentLang,
                    innerPadding = innerPadding,
                    onWatchAdClick = onWatchAdClick,
                    onBuyPackageClick = onBuyPackageClick
                )
            }
        }
    }

    // Dialogs Implementation
    if (showRestrictionDialog) {
        AlertDialog(
            onDismissRequest = { showRestrictionDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = if (currentLang == Language.ENGLISH) "Feature Restricted" else "ප්‍රවේශය සීමා කර ඇත",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            text = {
                Text(
                    text = if (currentLang == Language.ENGLISH)
                        "This is an advanced feature. Please upgrade to Premium or watch 25 ads to unlock full access."
                        else "මෙය උසස් විශේෂාංගයකි. සම්පූර්ණ ප්‍රවේශය ලබා ගැනීමට කරුණාකර ප්‍රිමියම් වෙත යාවත්කාලීන කරන්න හෝ ඇඩ්ස් 25ක් නරඹන්න.",
                    color = Color.LightGray,
                    fontSize = 15.sp
                )
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            showRestrictionDialog = false
                            onWatchAdClick()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFFB300),
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (currentLang == Language.ENGLISH)
                                "Watch Ad (Timer: ${countdownSeconds}s)"
                                else "Ad එකක් බලන්න (Timer: ${countdownSeconds}s)",
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Button(
                        onClick = {
                            showRestrictionDialog = false
                            currentBottomTab = 4
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2196F3),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (currentLang == Language.ENGLISH) "Upgrade to Premium" else "Premium මිලදී ගන්න",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showRestrictionDialog = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (currentLang == Language.ENGLISH) "Cancel" else "අවලංගු කරන්න",
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            containerColor = CardBg,
            shape = RoundedCornerShape(16.dp)
        )
    }

    if (showAddLoanDialog) {
        AddLoanDialog(
            lang = currentLang,
            initialName = prefilledName,
            initialPhone = prefilledPhone,
            allCustomers = customers,
            onDismiss = { showAddLoanDialog = false },
            onSave = { customerId, name, phone, principal, rate, period, notes, startDate ->
                if (isFreePlan && customerId == null && customers.size >= 3) {
                    showRestrictionDialog = true
                } else {
                    viewModel.addLoan(customerId, name, phone, principal, rate, period, notes, startDate)
                    showAddLoanDialog = false
                    Toast.makeText(context, "Loan saved successfully!", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    if (showAddCustomerDialog) {
        AddCustomerDialog(
            lang = currentLang,
            onDismiss = { showAddCustomerDialog = false },
            onSave = { name, address, phone, email, nic, photoUri, nicPhotoUri ->
                viewModel.addCustomer(name, address, phone, nic, photoUri, nicPhotoUri, email) { success, msg ->
                    if (success) {
                        showAddCustomerDialog = false
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    viewImageUriAndTitle?.let { (uri, title) ->
        ViewImageDialog(
            imageUri = uri,
            title = title,
            onDismiss = { viewImageUriAndTitle = null }
        )
    }

    showPaymentDialogLoanId?.let { loanId ->
        val loan = allLoans.find { it.id == loanId }
        if (loan != null) {
            val loanPayments = allPayments.filter { it.loanId == loanId }
            AddPaymentDialog(
                loan = loan,
                payments = loanPayments,
                lang = currentLang,
                onDismiss = { showPaymentDialogLoanId = null },
                onSave = { amount, type, notes, paymentDate ->
                    viewModel.recordPayment(loanId, amount, type, notes, paymentDate)
                    showPaymentDialogLoanId = null
                    Toast.makeText(context, "Payment recorded successfully!", Toast.LENGTH_SHORT).show()
                    if (type == "Full Settle") {
                        Toast.makeText(context, "ණය මුදල සාර්ථකව පියවන ලදී!", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    if (showDetailsDialog && selectedLoan != null) {
        val loan = selectedLoan!!
        val calcSummary = LoanCalculator.calculateLoanSummary(loan, selectedPayments)
        val customer = customers.find { it.id == loan.customerId }

        LoanDetailsDialog(
            loan = loan,
            summary = calcSummary,
            payments = selectedPayments,
            lang = currentLang,
            ownerName = ownerName,
            ownerPhone = ownerPhone,
            ownerPhotoUri = ownerPhotoUri,
            customer = customer,
            isFreePlan = isFreePlan,
            onRestrictionClick = { showRestrictionDialog = true },
            onDismiss = {
                showDetailsDialog = false
                viewModel.selectLoan(null)
            },
            onDeleteClick = {
                viewModel.deleteLoan(loan.id)
                showDetailsDialog = false
                viewModel.selectLoan(null)
                Toast.makeText(context, "Loan deleted successfully", Toast.LENGTH_SHORT).show()
            },
            onAddPayment = {
                showPaymentDialogLoanId = loan.id
            }
        )
    }

    showSettleConfirmationLoanId?.let { loanId ->
        val loan = allLoans.find { it.id == loanId }
        if (loan != null) {
            SettleLoanConfirmationDialog(
                loanId = loanId,
                borrowerName = loan.borrowerName,
                lang = currentLang,
                onDismiss = { showSettleConfirmationLoanId = null },
                onConfirm = {
                    viewModel.settleLoan(loanId, "Settled from dashboard quick action")
                    showSettleConfirmationLoanId = null
                    Toast.makeText(context, "ණය මුදල සාර්ථකව පියවන ලදී!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

// Summary Card Composable
@Composable
fun SummaryCard(
    title: String,
    amount: String,
    icon: ImageVector,
    cardColor: Color,
    iconBgColor: Color,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = title,
                    color = TextGray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = amount,
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

// Loan Card Composable
@Composable
fun LoanCard(
    loan: Loan,
    summary: com.moneymaster.cleanapp.utils.LoanSummary,
    lang: Language,
    onDetailsClick: () -> Unit,
    onAddPaymentClick: () -> Unit,
    onSettleClick: () -> Unit,
    onCallClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val startDateStr = dateFormat.format(Date(loan.startDate))

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("loan_card_${loan.id}"),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val yearFormat = remember { SimpleDateFormat("yyyy", Locale.getDefault()) }
                val loanYear = yearFormat.format(Date(loan.startDate))
                val formattedLoanId = "LN-$loanYear-${String.format(Locale.getDefault(), "%03d", loan.id)}"

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = loan.borrowerName,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formattedLoanId,
                            color = AccentAmber,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "•",
                            color = TextGray,
                            fontSize = 12.sp
                        )
                        Text(
                            text = if (loan.borrowerPhone.isNotEmpty()) loan.borrowerPhone else LocalizedText.get("phone_empty", lang),
                            color = TextGray,
                            fontSize = 13.sp
                        )
                    }
                }

                // Status chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (loan.isSettled) Color(0xFF0F3622) else Color(0xFF3B2F0F)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (loan.isSettled) LocalizedText.get("settled_status", lang) else LocalizedText.get("active_status", lang),
                        color = if (loan.isSettled) EmeraldGreen else AccentAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(color = BorderColor, thickness = 0.5.dp)

            // Dynamic Details Block
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = LocalizedText.get("principal_amount", lang).replace(" (රු.)", "").replace(" (Rs.)", ""),
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = formatRupees(loan.principalAmount),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.End) {
                    Text(
                        text = LocalizedText.get("interest_rate", lang).replace(" (%)", "") + " (${getPeriodLabel(loan.interestPeriod, lang)})",
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${loan.interestRate}%",
                        color = AccentAmber,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Real-time Accruals details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = LocalizedText.get("accrued", lang),
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = formatRupees(summary.accruedInterest),
                        color = SoftGold,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.End) {
                    Text(
                        text = LocalizedText.get("calc_days", lang),
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${summary.daysElapsed} " + if (lang == Language.ENGLISH) "Days" else "දින",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F111A), shape = RoundedCornerShape(8.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LocalizedText.get("remaining", lang),
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = formatRupees(summary.totalOutstanding),
                    color = if (loan.isSettled) EmeraldGreen else SoftGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "${LocalizedText.get("lent_on", lang)}: $startDateStr",
                color = TextGray,
                fontSize = 11.sp,
                fontStyle = FontStyle.Italic
            )

            // Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Call Phone Action
                IconButton(
                    onClick = onCallClick,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF1B223C), shape = RoundedCornerShape(8.dp))
                        .testTag("loan_call_button_${loan.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call",
                        tint = SoftGold,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (!loan.isSettled) {
                    // Quick pay button
                    Button(
                        onClick = onAddPaymentClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .testTag("loan_pay_button_${loan.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payment,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = LocalizedText.get("repay", lang),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Settle Button
                    Button(
                        onClick = onSettleClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentAmber,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("loan_settle_button_${loan.id}")
                    ) {
                        Text(
                            text = LocalizedText.get("settle", lang),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Details Button (Full Width if Settled)
                IconButton(
                    onClick = onDetailsClick,
                    modifier = Modifier
                        .size(40.dp)
                        .background(DarkGreyBg, shape = RoundedCornerShape(8.dp))
                        .testTag("loan_details_button_${loan.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Details",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// Add Loan Dialog Composable
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddLoanDialog(
    lang: Language,
    initialName: String = "",
    initialPhone: String = "",
    allCustomers: List<Customer> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (customerId: Int?, name: String, phone: String, principal: Double, rate: Double, period: String, notes: String, startDate: Long) -> Unit
) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    var phone by remember(initialPhone) { mutableStateOf(initialPhone) }
    var principal by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var selectedPeriod by remember { mutableStateOf("Monthly") }
    var notes by remember { mutableStateOf("") }

    val context = LocalContext.current
    var startDate by remember { mutableStateOf(System.currentTimeMillis()) }
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    var selectedCustomerId by remember(initialName, initialPhone) {
        mutableStateOf<Int?>(allCustomers.find { it.name == initialName && it.phone == initialPhone }?.id)
    }

    var hasError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
                    .heightIn(max = 450.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = LocalizedText.get("add_loan", lang),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    )
                )

                Divider(color = BorderColor)

                var isExistingCustomerMode by remember { mutableStateOf(selectedCustomerId != null || allCustomers.isNotEmpty()) }

                // Segmented Toggle for Mode Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { isExistingCustomerMode = true },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isExistingCustomerMode) AccentAmber else Color(0xFF1E2330),
                            contentColor = if (isExistingCustomerMode) Color.Black else Color.White
                        )
                    ) {
                        Text("Existing Customer", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { 
                            isExistingCustomerMode = false 
                            name = ""
                            phone = ""
                            selectedCustomerId = null
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isExistingCustomerMode) AccentAmber else Color(0xFF1E2330),
                            contentColor = if (!isExistingCustomerMode) Color.Black else Color.White
                        )
                    ) {
                        Text("New Borrower", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Select Customer Profile
                if (isExistingCustomerMode) {
                    if (allCustomers.isNotEmpty()) {
                        Text(
                            text = LocalizedText.get("select_customer", lang),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        androidx.compose.foundation.lazy.LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(allCustomers) { customer ->
                                val isSelected = customer.id == selectedCustomerId
                                AssistChip(
                                    onClick = {
                                        name = customer.name
                                        phone = customer.phone
                                        selectedCustomerId = customer.id
                                    },
                                    label = { Text(customer.name, color = if (isSelected) Color.Black else Color.White) },
                                    colors = AssistChipDefaults.assistChipColors(
                                        containerColor = if (isSelected) AccentAmber else CardBg
                                    )
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "No existing customers registered. Switch to 'New Borrower' mode.",
                            color = TextGray,
                            fontSize = 12.sp
                        )
                    }
                }

                // Input Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { if (!isExistingCustomerMode) name = it },
                    label = { Text(LocalizedText.get("borrower_name", lang), color = TextGray) },
                    singleLine = true,
                    readOnly = isExistingCustomerMode,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = if (isExistingCustomerMode) Color.Gray else AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_loan_name_input")
                )

                // Input Phone
                OutlinedTextField(
                    value = phone,
                    onValueChange = { if (!isExistingCustomerMode) phone = it },
                    label = { Text(LocalizedText.get("borrower_phone", lang), color = TextGray) },
                    singleLine = true,
                    readOnly = isExistingCustomerMode,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = if (isExistingCustomerMode) Color.Gray else AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_loan_phone_input")
                )

                // Principal Amount
                OutlinedTextField(
                    value = principal,
                    onValueChange = { principal = it },
                    label = { Text(LocalizedText.get("principal_amount", lang), color = TextGray) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_loan_principal_input")
                )

                // Interest Rate
                OutlinedTextField(
                    value = rate,
                    onValueChange = { rate = it },
                    label = { Text(LocalizedText.get("interest_rate", lang), color = TextGray) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_loan_rate_input")
                )

                // Loan Start Date Selection
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = LocalizedText.get("lent_on", lang),
                        color = TextGray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )

                    val calendar = Calendar.getInstance().apply { timeInMillis = startDate }
                    val year = calendar.get(Calendar.YEAR)
                    val month = calendar.get(Calendar.MONTH)
                    val day = calendar.get(Calendar.DAY_OF_MONTH)

                    val datePickerDialog = remember {
                        android.app.DatePickerDialog(
                            context,
                            { _, selectedYear, selectedMonth, selectedDay ->
                                val newCalendar = Calendar.getInstance().apply {
                                    set(Calendar.YEAR, selectedYear)
                                    set(Calendar.MONTH, selectedMonth)
                                    set(Calendar.DAY_OF_MONTH, selectedDay)
                                    set(Calendar.HOUR_OF_DAY, 12)
                                    set(Calendar.MINUTE, 0)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                startDate = newCalendar.timeInMillis
                            },
                            year,
                            month,
                            day
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBg)
                            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                            .clickable { datePickerDialog.show() }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("loan_date_picker_trigger"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dateFormat.format(Date(startDate)),
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = "Select Date",
                            tint = AccentAmber
                        )
                    }
                }

                // Interest Period Radio Buttons
                Column {
                    Text(
                        text = LocalizedText.get("interest_period", lang),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Daily", "Weekly", "Monthly").forEach { period ->
                            val label = when (period) {
                                "Daily" -> LocalizedText.get("daily", lang)
                                "Weekly" -> LocalizedText.get("weekly", lang)
                                else -> LocalizedText.get("monthly", lang)
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (selectedPeriod == period) Color(0xFF221C11) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedPeriod = period }
                                    .padding(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                RadioButton(
                                    selected = selectedPeriod == period,
                                    onClick = { selectedPeriod = period },
                                    colors = RadioButtonDefaults.colors(selectedColor = AccentAmber)
                                )
                                Text(
                                    text = label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(LocalizedText.get("notes", lang), color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_loan_notes_input")
                )

                if (hasError) {
                    Text(
                        text = LocalizedText.get("invalid_input", lang),
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp
                    )
                }

                // Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(LocalizedText.get("cancel", lang), color = TextGray)
                    }

                    Button(
                        onClick = {
                            val pDouble = principal.toDoubleOrNull()
                            val rDouble = rate.toDoubleOrNull()
                            if (name.trim().isNotEmpty() && pDouble != null && rDouble != null) {
                                onSave(selectedCustomerId, name.trim(), phone.trim(), pDouble, rDouble, selectedPeriod, notes.trim(), startDate)
                            } else {
                                hasError = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentAmber,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("add_loan_save_button")
                    ) {
                        Text(LocalizedText.get("save", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// Add Payment Dialog Composable
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPaymentDialog(
    loan: Loan,
    payments: List<Payment>,
    lang: Language,
    onDismiss: () -> Unit,
    onSave: (amount: Double, type: String, notes: String, paymentDate: Long) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf("Interest") } // "Interest", "Principal", "Full Settle"
    var notes by remember { mutableStateOf("") }
    var hasError by remember { mutableStateOf(false) }

    val context = LocalContext.current
    var paymentDate by remember { mutableStateOf(System.currentTimeMillis()) }
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "✓ SMS Permission Granted! Alerts will be sent automatically.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "⚠️ SMS Permission Denied. Automatic background SMS alert might fail.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.SEND_SMS
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(android.Manifest.permission.SEND_SMS)
        }
    }

    LaunchedEffect(paymentDate, selectedType) {
        if (selectedType == "Interest") {
            val summary = LoanCalculator.calculateLoanSummary(loan, payments, paymentDate)
            amount = String.format(Locale.US, "%.2f", summary.outstandingInterest)
        } else {
            amount = ""
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = LocalizedText.get("add_payment", lang),
                    color = EmeraldGreen,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    )
                )

                Divider(color = BorderColor)

                // Input Payment Amount
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text(LocalizedText.get("payment_amount", lang), color = TextGray) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = EmeraldGreen,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_payment_amount_input")
                )

                // Payment Date Selection
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = LocalizedText.get("payment_date", lang),
                        color = TextGray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )

                    val calendar = Calendar.getInstance().apply { timeInMillis = paymentDate }
                    val year = calendar.get(Calendar.YEAR)
                    val month = calendar.get(Calendar.MONTH)
                    val day = calendar.get(Calendar.DAY_OF_MONTH)

                    val datePickerDialog = remember {
                        android.app.DatePickerDialog(
                            context,
                            { _, selectedYear, selectedMonth, selectedDay ->
                                val newCalendar = Calendar.getInstance().apply {
                                    set(Calendar.YEAR, selectedYear)
                                    set(Calendar.MONTH, selectedMonth)
                                    set(Calendar.DAY_OF_MONTH, selectedDay)
                                    set(Calendar.HOUR_OF_DAY, 12)
                                    set(Calendar.MINUTE, 0)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                paymentDate = newCalendar.timeInMillis
                            },
                            year,
                            month,
                            day
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBg)
                            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                            .clickable { datePickerDialog.show() }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("payment_date_picker_trigger"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = dateFormat.format(Date(paymentDate)),
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = "Select Date",
                            tint = EmeraldGreen
                        )
                    }
                }

                // Payment Type Selection
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = LocalizedText.get("payment_type", lang),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Interest", "Principal").forEach { type ->
                            val label = if (type == "Interest") {
                                LocalizedText.get("interest_only", lang).replace(" Payment", "").replace(" ගෙවීම්", "")
                            } else {
                                LocalizedText.get("principal_only", lang).replace(" Reduction", "").replace(" ණය මුදල අඩු කිරීම", "මුදලින්")
                            }
                            Button(
                                onClick = { selectedType = type },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedType == type) EmeraldGreen else Color(0xFF222633),
                                    contentColor = if (selectedType == type) Color.Black else Color.White
                                )
                            ) {
                                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text(LocalizedText.get("notes", lang), color = TextGray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = EmeraldGreen,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_payment_notes_input")
                )

                if (hasError) {
                    Text(
                        text = LocalizedText.get("invalid_input", lang),
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp
                    )
                }

                // Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(LocalizedText.get("cancel", lang), color = TextGray)
                    }

                    Button(
                        onClick = {
                            val aDouble = amount.toDoubleOrNull()
                            if (aDouble != null && aDouble > 0) {
                                onSave(aDouble, selectedType, notes.trim(), paymentDate)
                            } else {
                                hasError = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldGreen,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("add_payment_save_button")
                    ) {
                        Text(LocalizedText.get("save", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// Loan Details & Payments History Dialog Composable
@Composable
fun LoanDetailsDialog(
    loan: Loan,
    summary: com.moneymaster.cleanapp.utils.LoanSummary,
    payments: List<Payment>,
    lang: Language,
    ownerName: String,
    ownerPhone: String,
    ownerPhotoUri: String,
    customer: Customer?,
    isFreePlan: Boolean,
    onRestrictionClick: () -> Unit,
    onDismiss: () -> Unit,
    onDeleteClick: () -> Unit,
    onAddPayment: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val context = LocalContext.current

    var pendingSmsData by remember { mutableStateOf<Pair<String, String>?>(null) }

    val reportSmsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "✓ SMS Permission Granted!", Toast.LENGTH_SHORT).show()
            pendingSmsData?.let { (phone, msg) ->
                try {
                    val smsManager = context.getSystemService(android.telephony.SmsManager::class.java)
                        ?: @Suppress("DEPRECATION") android.telephony.SmsManager.getDefault()
                    val parts = smsManager.divideMessage(msg)
                    smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
                    Toast.makeText(context, "✓ SMS Report sent directly!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "❌ Error sending SMS directly: ${e.message}", Toast.LENGTH_LONG).show()
                }
                pendingSmsData = null
            }
        } else {
            Toast.makeText(context, "⚠️ SMS Permission Denied. Cannot send background SMS.", Toast.LENGTH_LONG).show()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(4.dp)
                .testTag("loan_details_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = LocalizedText.get("report_title", lang),
                        color = AccentAmber,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Divider(color = BorderColor)

                // Scrollable details inside dialog
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        // ================= 1. ණය දෙන ආයතනයේ / අයිතිකරුගේ විස්තර (Business Header) =================
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF161B22), shape = RoundedCornerShape(16.dp))
                                .border(1.dp, AccentAmber.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .background(AccentAmber.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                    .border(1.5.dp, AccentAmber, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (ownerPhotoUri.isNotEmpty()) {
                                    AsyncImage(
                                        model = ownerPhotoUri,
                                        contentDescription = "Business Photo",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Business,
                                        contentDescription = "Business Logo",
                                        tint = AccentAmber,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ownerName.ifEmpty { LocalizedText.get("business_name", lang) },
                                    color = AccentAmber,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = LocalizedText.get("business_address", lang),
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (ownerPhone.isNotEmpty()) "${LocalizedText.get("customer_phone_label", lang)}: $ownerPhone" else LocalizedText.get("business_phones", lang),
                                    color = TextGray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    item {
                        // ================= 2. පාරිභෝගිකයාගේ පුද්ගලික විස්තර (Customer Profile Card) =================
                        Column {
                            Text(
                                text = LocalizedText.get("customer_profile_title", lang),
                                color = TextGray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF161B22), shape = RoundedCornerShape(16.dp))
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .background(AccentAmber, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (customer != null && customer.photoUri.isNotEmpty()) {
                                        AsyncImage(
                                            model = customer.photoUri,
                                            contentDescription = "Customer Photo",
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(CircleShape)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = "Customer Avatar",
                                            tint = Color.Black,
                                            modifier = Modifier.size(35.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = customer?.name ?: loan.borrowerName,
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${LocalizedText.get("customer_nic_label", lang)}${customer?.nic ?: "N/A"}",
                                        color = TextGray,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${LocalizedText.get("customer_address_label", lang)}${customer?.address ?: "N/A"}",
                                        color = TextGray,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "${LocalizedText.get("customer_phone_label", lang)}${customer?.phone ?: loan.borrowerPhone}",
                                        color = TextGray,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    item {
                        // ================= 3. ණය මුදලේ මූලික තොරතුරු (Loan Summary Grid) =================
                        Column {
                            Text(
                                text = LocalizedText.get("loan_summary_title", lang),
                                color = TextGray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(Color(0xFF161B22), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(LocalizedText.get("total_loan_amount", lang), color = TextGray, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(formatRupees(loan.principalAmount), color = Color(0xFFFFAB40), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(Color(0xFF161B22), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(LocalizedText.get("interest_rate", lang).replace(" (%)", ""), color = TextGray, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text("${loan.interestRate}% (${getPeriodLabel(loan.interestPeriod, lang)})", color = AccentAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(Color(0xFF161B22), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(LocalizedText.get("loan_date", lang), color = TextGray, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(dateFormat.format(Date(loan.startDate)), color = Color(0xFF448AFF), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(Color(0xFF161B22), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(LocalizedText.get("current_status", lang), color = TextGray, fontSize = 11.sp)
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = if (loan.isSettled) LocalizedText.get("settled_status_label", lang) else LocalizedText.get("active_status_label", lang),
                                            color = if (loan.isSettled) SoftGold else EmeraldGreen,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (loan.notes.isNotEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(LocalizedText.get("notes", lang), color = TextGray, fontSize = 12.sp)
                                Text(
                                    text = loan.notes,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontStyle = FontStyle.Italic,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF161B22), shape = RoundedCornerShape(8.dp))
                                        .padding(8.dp)
                                )
                            }
                        }
                    }

                    item {
                        // ================= 4. ගෙවීම් සහ පොලී විස්තර වගුව (The Beautiful Table) =================
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = LocalizedText.get("history_table_title", lang),
                                    color = TextGray,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.Default.DateRange, contentDescription = null, tint = AccentAmber, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(0.5.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                    .background(Color(0xFF161B22), RoundedCornerShape(12.dp))
                            ) {
                                // Header Row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF222831), RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                                        .padding(vertical = 12.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = LocalizedText.get("table_header_date", lang),
                                        color = AccentAmber,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.weight(2.5f)
                                    )
                                    Text(
                                        text = LocalizedText.get("table_header_desc", lang),
                                        color = AccentAmber,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.weight(3.5f)
                                    )
                                    Text(
                                        text = LocalizedText.get("table_header_amount", lang),
                                        color = AccentAmber,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier.weight(3.0f)
                                    )
                                }

                                // 1. Initial Loan disbursement
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(0.5.dp, Color.White.copy(alpha = 0.08f))
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = dateFormat.format(Date(loan.startDate)),
                                        color = Color.White.copy(alpha = 0.7f),
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.weight(2.5f)
                                    )
                                    Text(
                                        text = LocalizedText.get("tx_loan_disbursed", lang),
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        modifier = Modifier.weight(3.5f)
                                    )
                                    Text(
                                        text = formatRupees(loan.principalAmount),
                                        color = Color(0xFFFFAB40),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontStyle = FontStyle.Italic,
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier.weight(3.0f)
                                    )
                                }

                                // 2. Payments
                                payments.forEach { payment ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(0.5.dp, Color.White.copy(alpha = 0.08f))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = dateFormat.format(Date(payment.paymentDate)),
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 12.sp,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.weight(2.5f)
                                        )
                                        Text(
                                            text = when (payment.type) {
                                                "Interest" -> LocalizedText.get("tx_interest_payment", lang)
                                                "Principal" -> LocalizedText.get("tx_principal_payment", lang)
                                                else -> LocalizedText.get("full_settle", lang)
                                            },
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            modifier = Modifier.weight(3.5f)
                                        )
                                        Text(
                                            text = formatRupees(payment.amount),
                                            color = EmeraldGreen,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontStyle = FontStyle.Italic,
                                            textAlign = TextAlign.Right,
                                            modifier = Modifier.weight(3.0f)
                                        )
                                    }
                                }

                                // 3. Outstanding interest (Next Pending Interest) if not settled
                                if (!loan.isSettled) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (lang == Language.SINHALA) "අද දිනය" else "Today",
                                            color = Color.White.copy(alpha = 0.7f),
                                            fontSize = 12.sp,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.weight(2.5f)
                                        )
                                        Text(
                                            text = LocalizedText.get("tx_outstanding_interest", lang),
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            modifier = Modifier.weight(3.5f)
                                        )
                                        Text(
                                            text = formatRupees(summary.outstandingInterest),
                                            color = TextGray,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontStyle = FontStyle.Italic,
                                            textAlign = TextAlign.Right,
                                            modifier = Modifier.weight(3.0f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        // ================= 5. ස්තූති පණිවිඩය (Thank You Section) =================
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = AccentAmber,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = LocalizedText.get("thank_you_title", lang),
                                color = AccentAmber.copy(alpha = 0.9f),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = LocalizedText.get("thank_you_sub", lang),
                                color = TextGray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                        }
                    }
                }

                Divider(color = BorderColor)

                // Actions Block
                if (showDeleteConfirm) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF2C1B1E), shape = RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = LocalizedText.get("confirm_delete", lang),
                            color = Color.White,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { showDeleteConfirm = false }) {
                                Text(LocalizedText.get("cancel", lang), color = TextGray)
                            }
                            Button(
                                onClick = onDeleteClick,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red, contentColor = Color.White)
                            ) {
                                Text(LocalizedText.get("delete", lang), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { showDeleteConfirm = true },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0xFF2B1414), shape = RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                        }

                        // Native Send SMS Button
                        val borrowerPhone = customer?.phone ?: loan.borrowerPhone
                        val businessName = ownerName.ifEmpty { LocalizedText.get("business_name", lang) }
                        val borrowerName = customer?.name ?: loan.borrowerName

                        val smsIntro = String.format(LocalizedText.get("sms_body_template_intro", lang), borrowerName, businessName)
                        val smsTotal = String.format(LocalizedText.get("sms_body_total_loan", lang), formatRupees(loan.principalAmount))
                        val smsRate = String.format(LocalizedText.get("sms_body_rate", lang), "${loan.interestRate}% (${getPeriodLabel(loan.interestPeriod, lang)})")
                        val smsDays = String.format(LocalizedText.get("sms_body_days", lang), summary.daysElapsed.toString())
                        val smsAccrued = String.format(LocalizedText.get("sms_body_accrued", lang), formatRupees(summary.accruedInterest))
                        val smsPaid = String.format(LocalizedText.get("sms_body_paid", lang), formatRupees(summary.paidInterest))
                        val smsRemaining = String.format(LocalizedText.get("sms_body_remaining", lang), formatRupees(summary.totalOutstanding))
                        val smsThanks = LocalizedText.get("sms_body_thanks", lang)

                        val smsText = smsIntro + smsTotal + smsRate + smsDays + smsAccrued + smsPaid + smsRemaining + smsThanks

                        IconButton(
                            onClick = {
                                if (androidx.core.content.ContextCompat.checkSelfPermission(
                                        context,
                                        android.Manifest.permission.SEND_SMS
                                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                ) {
                                    try {
                                        val smsManager = context.getSystemService(android.telephony.SmsManager::class.java)
                                            ?: @Suppress("DEPRECATION") android.telephony.SmsManager.getDefault()
                                        val parts = smsManager.divideMessage(smsText)
                                        smsManager.sendMultipartTextMessage(borrowerPhone, null, parts, null, null)
                                        Toast.makeText(context, "✓ SMS Report sent directly!", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "❌ Error sending SMS directly: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                } else {
                                    pendingSmsData = Pair(borrowerPhone, smsText)
                                    reportSmsPermissionLauncher.launch(android.Manifest.permission.SEND_SMS)
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(AccentAmber.copy(alpha = 0.15f), shape = RoundedCornerShape(10.dp))
                                .border(1.dp, AccentAmber, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send SMS", tint = AccentAmber)
                        }

                        // Print PDF Report Button
                        IconButton(
                            onClick = {
                                if (isFreePlan) {
                                    onRestrictionClick()
                                } else {
                                    try {
                                        val pdfFile = PdfReportService.generatePdfReport(
                                            context = context,
                                            loan = loan,
                                            customer = customer,
                                            payments = payments,
                                            summary = summary,
                                            lang = lang,
                                            ownerName = ownerName,
                                            ownerPhone = ownerPhone,
                                            ownerPhotoUri = ownerPhotoUri
                                        )
                                        if (pdfFile != null) {
                                            PdfReportService.printPdf(context, pdfFile)
                                        } else {
                                            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Error printing: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(AccentAmber.copy(alpha = 0.15f), shape = RoundedCornerShape(10.dp))
                                .border(1.dp, AccentAmber, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.Description, contentDescription = "Print PDF Statement", tint = AccentAmber)
                        }

                        // Share PDF Report Button
                        IconButton(
                            onClick = {
                                if (isFreePlan) {
                                    onRestrictionClick()
                                } else {
                                    try {
                                        val pdfFile = PdfReportService.generatePdfReport(
                                            context = context,
                                            loan = loan,
                                            customer = customer,
                                            payments = payments,
                                            summary = summary,
                                            lang = lang,
                                            ownerName = ownerName,
                                            ownerPhone = ownerPhone,
                                            ownerPhotoUri = ownerPhotoUri
                                        )
                                        if (pdfFile != null) {
                                            PdfReportService.sharePdf(context, pdfFile)
                                        } else {
                                            Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Error sharing: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(AccentAmber.copy(alpha = 0.15f), shape = RoundedCornerShape(10.dp))
                                .border(1.dp, AccentAmber, RoundedCornerShape(10.dp))
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share PDF Statement", tint = AccentAmber)
                        }

                        if (!loan.isSettled) {
                            Button(
                                onClick = {
                                    onDismiss()
                                    onAddPayment()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldGreen,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            ) {
                                Icon(Icons.Default.Payment, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(LocalizedText.get("add_payment", lang), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(
    label: String,
    value: String,
    valueColor: Color = Color.White,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = TextGray, fontSize = 13.sp)
        Text(
            text = value,
            color = valueColor,
            fontSize = 14.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium
        )
    }
}

// Interactive Interest Calculator View
@Composable
fun InterestCalculatorView(
    lang: Language,
    modifier: Modifier = Modifier
) {
    var calcPrincipal by remember { mutableStateOf("10000") }
    var calcRate by remember { mutableStateOf("5") }
    var calcPeriod by remember { mutableStateOf("Monthly") }
    var calcDays by remember { mutableStateOf("30") }

    val principal = calcPrincipal.toDoubleOrNull() ?: 0.0
    val rate = calcRate.toDoubleOrNull() ?: 0.0
    val days = calcDays.toDoubleOrNull() ?: 0.0

    // Compute dynamic calculation
    val periodUnits = when (calcPeriod) {
        "Daily" -> days
        "Weekly" -> days / 7.0
        "Monthly" -> days / 30.0
        else -> days / 30.0
    }
    val rateFraction = rate / 100.0
    val computedInterest = principal * rateFraction * periodUnits
    val totalAmount = principal + computedInterest

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = LocalizedText.get("calc_title", lang),
                color = AccentAmber,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )

            Divider(color = BorderColor)

            OutlinedTextField(
                value = calcPrincipal,
                onValueChange = { calcPrincipal = it },
                label = { Text(LocalizedText.get("principal_amount", lang), color = TextGray) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = AccentAmber,
                    unfocusedBorderColor = BorderColor
                ),
                modifier = Modifier.fillMaxWidth().testTag("calc_principal_input")
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = calcRate,
                    onValueChange = { calcRate = it },
                    label = { Text(LocalizedText.get("interest_rate", lang).replace(" (%)", ""), color = TextGray) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.weight(1f).testTag("calc_rate_input")
                )

                OutlinedTextField(
                    value = calcDays,
                    onValueChange = { calcDays = it },
                    label = { Text(LocalizedText.get("calc_days", lang), color = TextGray) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = AccentAmber,
                        unfocusedBorderColor = BorderColor
                    ),
                    modifier = Modifier.weight(1f).testTag("calc_days_input")
                )
            }

            // Period selection
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Daily", "Weekly", "Monthly").forEach { period ->
                    val label = when (period) {
                        "Daily" -> LocalizedText.get("daily", lang)
                        "Weekly" -> LocalizedText.get("weekly", lang)
                        else -> LocalizedText.get("monthly", lang)
                    }
                    Button(
                        onClick = { calcPeriod = period },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (calcPeriod == period) AccentAmber else Color(0xFF1E2330),
                            contentColor = if (calcPeriod == period) Color.Black else Color.White
                        )
                    ) {
                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Results summary display
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F111A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = LocalizedText.get("calc_result", lang),
                        color = TextGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Divider(color = BorderColor)
                    DetailRow(LocalizedText.get("principal_amount", lang).replace(" (රු.)", "").replace(" (Rs.)", ""), formatRupees(principal))
                    DetailRow(LocalizedText.get("accrued", lang), formatRupees(computedInterest), valueColor = AccentAmber)
                    Divider(color = BorderColor)
                    DetailRow(
                        if (lang == Language.ENGLISH) "Total Payback" else "මුළු මුදල",
                        formatRupees(totalAmount),
                        valueColor = SoftGold,
                        isBold = true
                    )
                }
            }
        }
    }
}

// Helpers
fun formatRupees(amount: Double): String {
    return String.format(Locale.getDefault(), "%s %,.2f", LocalizedText.selectedCurrencySymbol, amount)
}

fun getPeriodLabel(period: String, lang: Language): String {
    return when (period) {
        "Daily" -> LocalizedText.get("daily", lang)
        "Weekly" -> LocalizedText.get("weekly", lang)
        else -> LocalizedText.get("monthly", lang)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerDialog(
    lang: Language,
    onDismiss: () -> Unit,
    onSave: (name: String, address: String, phone: String, email: String, nic: String, photoUri: String, nicPhotoUri: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var nic by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf("") }
    var nicPhotoUri by remember { mutableStateOf("") }

    val context = LocalContext.current

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {}
            photoUri = it.toString()
        }
    }

    val nicPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {}
            nicPhotoUri = it.toString()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = LocalizedText.get("customer_profile", lang),
                        color = AccentAmber,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = BorderColor)
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(LocalizedText.get("customer_name", lang), color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_customer_name_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text(LocalizedText.get("customer_address", lang), color = TextGray) },
                        singleLine = false,
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_customer_address_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text(LocalizedText.get("customer_phone", lang), color = TextGray) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_customer_phone_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text(LocalizedText.get("customer_email", lang), color = TextGray) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_customer_email_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = nic,
                        onValueChange = { nic = it },
                        label = { Text(LocalizedText.get("customer_nic", lang), color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("add_customer_nic_input")
                    )
                }

                item {
                    Text(
                        text = LocalizedText.get("customer_photo", lang),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { photoLauncher.launch("image/*") },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentAmber),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(AccentAmber, AccentAmber)))
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Add Photo")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select")
                        }
                        if (photoUri.isNotEmpty()) {
                            AsyncImage(
                                model = photoUri,
                                contentDescription = "Selected Photo",
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CardBg)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.DarkGray),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = "Placeholder", tint = Color.LightGray)
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = LocalizedText.get("nic_photo", lang),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { nicPhotoLauncher.launch("image/*") },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentAmber),
                            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(AccentAmber, AccentAmber)))
                        ) {
                            Icon(Icons.Default.CreditCard, contentDescription = "Add NIC Image")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select")
                        }
                        if (nicPhotoUri.isNotEmpty()) {
                            AsyncImage(
                                model = nicPhotoUri,
                                contentDescription = "Selected NIC",
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CardBg)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.DarkGray),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.CreditCard, contentDescription = "Placeholder", tint = Color.LightGray)
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(LocalizedText.get("cancel", lang), color = TextGray)
                        }
                        Button(
                            onClick = {
                                if (name.isNotBlank() && phone.isNotBlank()) {
                                    onSave(name, address, phone, email, nic, photoUri, nicPhotoUri)
                                } else {
                                    Toast.makeText(context, LocalizedText.get("invalid_input", lang), Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                            modifier = Modifier.weight(1f).testTag("add_customer_save_button")
                        ) {
                            Text(LocalizedText.get("save", lang), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ViewImageDialog(
    imageUri: String,
    title: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CardBg),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, color = AccentAmber, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                AsyncImage(
                    model = imageUri,
                    contentDescription = title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black)
                )
            }
        }
    }
}

@Composable
fun CustomerCard(
    customer: Customer,
    lang: Language,
    onViewImage: (uri: String, title: String) -> Unit,
    onAddLoanClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (customer.photoUri.isNotEmpty()) {
                    AsyncImage(
                        model = customer.photoUri,
                        contentDescription = "Customer Photo",
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(DarkBg)
                            .clickable { onViewImage(customer.photoUri, customer.name) }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF221C11)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = customer.name.firstOrNull()?.toString()?.uppercase() ?: "?",
                            color = AccentAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = customer.name,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${LocalizedText.get("customer_nic", lang)}: ${customer.nic.ifEmpty { "-" }}",
                        color = TextGray,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${LocalizedText.get("customer_phone", lang)}: ${customer.phone}",
                        color = TextGray,
                        fontSize = 12.sp
                    )
                }
            }

            if (customer.address.isNotEmpty()) {
                Text(
                    text = "${LocalizedText.get("customer_address", lang)}: ${customer.address}",
                    color = TextGray,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            HorizontalDivider(color = BorderColor, thickness = 0.5.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (customer.photoUri.isNotEmpty()) {
                        SuggestionChip(
                            onClick = { onViewImage(customer.photoUri, "${customer.name} - ${LocalizedText.get("customer_photo", lang)}") },
                            label = { Text(LocalizedText.get("customer_photo", lang), fontSize = 10.sp) },
                            icon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(12.dp)) }
                        )
                    }
                    if (customer.nicPhotoUri.isNotEmpty()) {
                        SuggestionChip(
                            onClick = { onViewImage(customer.nicPhotoUri, "${customer.name} - ${LocalizedText.get("nic_photo", lang)}") },
                            label = { Text("NIC", fontSize = 10.sp) },
                            icon = { Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(12.dp)) }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = {
                            if (customer.phone.isNotEmpty()) {
                                try {
                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                        data = Uri.parse("tel:${customer.phone}")
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Cannot dial", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = "Call", tint = AccentAmber)
                    }

                    IconButton(onClick = onAddLoanClick) {
                        Icon(Icons.Default.Add, contentDescription = "Add Loan for Customer", tint = EmeraldGreen)
                    }

                    IconButton(onClick = onDeleteClick) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminProfileTab(
    viewModel: LoanViewModel,
    lang: Language,
    innerPadding: PaddingValues,
    onDriveConnectClick: () -> Unit = {},
    onDriveBackupClick: () -> Unit = {},
    onDriveRestoreClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val ownerName by viewModel.ownerName.collectAsStateWithLifecycle()
    val ownerPhone by viewModel.ownerPhone.collectAsStateWithLifecycle()
    val ownerPhotoUri by viewModel.ownerPhotoUri.collectAsStateWithLifecycle()
    val currentCurrency by viewModel.currentCurrency.collectAsStateWithLifecycle()
    val savedPin by viewModel.savedPin.collectAsStateWithLifecycle()
    val senderEmail by viewModel.senderEmail.collectAsStateWithLifecycle()
    val appPassword by viewModel.appPassword.collectAsStateWithLifecycle()
    val notificationMode by viewModel.notificationMode.collectAsStateWithLifecycle()

    val allLoans by viewModel.allLoans.collectAsStateWithLifecycle()
    val allPayments by viewModel.allPayments.collectAsStateWithLifecycle()

    // Advanced analytics metrics calculations using structured data class
    val totalDisbursed = allLoans.sumOf { it.principalAmount }
    val totalRecovered = allPayments.sumOf { it.amount }
    
    data class AnalyticsResult(
        val remainingOutstanding: Double,
        val overdueCount: Int,
        val activeDebtorsList: List<Triple<String, Double, Double>>
    )

    val analyticsResult = remember(allLoans, allPayments) {
        val list = mutableListOf<Triple<String, Double, Double>>()
        var outstandingSum = 0.0
        var overdueSum = 0
        
        allLoans.forEach { loan ->
            val loanPayments = allPayments.filter { it.loanId == loan.id }
            val summary = LoanCalculator.calculateLoanSummary(loan, loanPayments)
            
            if (!loan.isSettled) {
                outstandingSum += summary.totalOutstanding
                
                // Overdue logic: if active days elapsed since start exceeds a sensible period-based limit
                val daysElapsed = java.util.concurrent.TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - loan.startDate)
                val isOverdue = when (loan.interestPeriod) {
                    "Daily", "Daily (Interest Only)" -> daysElapsed > 1
                    "Weekly", "Weekly (Interest Only)" -> daysElapsed > 7
                    "Monthly", "Monthly (Interest Only)" -> daysElapsed > 30
                    else -> daysElapsed > 30
                }
                if (isOverdue) {
                    overdueSum++
                }
                list.add(Triple(loan.borrowerName, loan.principalAmount, summary.totalOutstanding))
            }
        }
        AnalyticsResult(
            remainingOutstanding = outstandingSum,
            overdueCount = overdueSum,
            activeDebtorsList = list
        )
    }

    val lenderIdSetting by viewModel.lenderId.collectAsStateWithLifecycle()
    val spreadsheetLinkSetting by viewModel.spreadsheetLink.collectAsStateWithLifecycle()

    var nameInput by remember { mutableStateOf(ownerName) }
    var phoneInput by remember { mutableStateOf(ownerPhone) }
    var photoUriInput by remember { mutableStateOf(ownerPhotoUri) }
    var currencyInput by remember { mutableStateOf(currentCurrency) }
    var lenderIdInput by remember { mutableStateOf(lenderIdSetting) }
    var spreadsheetLinkInput by remember { mutableStateOf(spreadsheetLinkSetting) }
    var senderEmailInput by remember(senderEmail) { mutableStateOf(senderEmail) }
    var appPasswordInput by remember(appPassword) { mutableStateOf(appPassword) }

    var quickDebtorName by remember { mutableStateOf("Priyadarshani Nangi") }
    var quickAmount by remember { mutableStateOf("70000") }
    var quickInterestRate by remember { mutableStateOf("10.0") }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            try {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {}
            photoUriInput = it.toString()
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Box(contentAlignment = Alignment.BottomEnd) {
                if (photoUriInput.isNotEmpty()) {
                    AsyncImage(
                        model = photoUriInput,
                        contentDescription = "Business Logo",
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(CardBg)
                            .border(2.dp, AccentAmber, CircleShape)
                            .clickable { photoLauncher.launch("image/*") }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF221C11))
                            .border(2.dp, AccentAmber, CircleShape)
                            .clickable { photoLauncher.launch("image/*") },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = "Business Logo Placeholder",
                            tint = AccentAmber,
                            modifier = Modifier.size(60.dp)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(AccentAmber)
                        .clickable { photoLauncher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Change Business Logo",
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (lang == Language.ENGLISH) "Business Branding & Cloud Setup" else "ව්‍යාපාරික නාමය සහ ක්ලවුඩ් සැකසුම",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text(LocalizedText.get("customer_name", lang), color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                    )

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text(LocalizedText.get("my_phone", lang), color = TextGray) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("profile_phone_input")
                    )

                    OutlinedTextField(
                        value = lenderIdInput,
                        onValueChange = { lenderIdInput = it },
                        label = { Text(if (lang == Language.ENGLISH) "Lender ID (NIC/Reg No)" else "ණය දෙන්නාගේ හැඳුනුම්පත (Lender ID)", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("profile_lender_id_input")
                    )

                    OutlinedTextField(
                        value = spreadsheetLinkInput,
                        onValueChange = { spreadsheetLinkInput = it },
                        label = { Text(if (lang == Language.ENGLISH) "Google Spreadsheet ID / Link" else "ගූගල් පැතුරුම්පත් ID / ලින්ක් එක", color = TextGray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("profile_spreadsheet_link_input")
                    )

                    // Language Selector
                    Text(
                        text = LocalizedText.get("language_label", lang),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Language.values().forEach { languageOption ->
                            val label = if (languageOption == Language.ENGLISH) "English" else "සිංහල"
                            val isSelected = lang == languageOption
                            Button(
                                onClick = { viewModel.setLanguage(languageOption) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) AccentAmber else Color(0xFF1E2330),
                                    contentColor = if (isSelected) Color.Black else Color.White
                                )
                            ) {
                                Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Currency Selector
                    Text(
                        text = LocalizedText.get("currency_label", lang),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    val currencies = listOf("LKR (Rs.)", "USD ($)", "EUR (€)")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        currencies.forEach { currency ->
                            val isSelected = currencyInput == currency
                            Button(
                                onClick = { currencyInput = currency },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) AccentAmber else Color(0xFF1E2330),
                                    contentColor = if (isSelected) Color.Black else Color.White
                                )
                            ) {
                                Text(currency, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            viewModel.updateOwnerDetails(nameInput, phoneInput, photoUriInput, currencyInput)
                            viewModel.saveRegistrationDetails(lenderIdInput, spreadsheetLinkInput, nameInput, phoneInput)
                            Toast.makeText(context, LocalizedText.get("settings_saved", lang), Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth().testTag("profile_save_button")
                    ) {
                        Text(LocalizedText.get("save_settings", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("drive_cloud_sync_card"),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudQueue,
                            contentDescription = "Drive Sync Settings",
                            tint = AccentAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (lang == Language.ENGLISH) "Google Drive Cloud Sync" else "ගූගල් ඩ්‍රයිව් ක්ලවුඩ් උපස්ථය",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (lang == Language.ENGLISH) 
                            "Securely backup your offline database directly to your personal Google Drive or restore any previously saved backup instantly." 
                            else "ඔබේ දත්ත සමුදාය ආරක්ෂිතව ඔබගේ පෞද්ගලික ගූගල් ඩ්‍රයිව් ගිණුමට උපස්ථ කරන්න හෝ ඕනෑම වෙලාවක නැවත ලබා ගන්න.",
                        color = TextGray,
                        fontSize = 12.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { onDriveBackupClick() },
                            modifier = Modifier.weight(1f).testTag("drive_backup_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1E2F1E),
                                contentColor = Color(0xFF2ECC71)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2ECC71))
                        ) {
                            Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (lang == Language.ENGLISH) "Backup Now" else "උපස්ථ කරන්න", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onDriveRestoreClick() },
                            modifier = Modifier.weight(1f).testTag("drive_restore_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1E2638),
                                contentColor = Color(0xFF3498DB)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3498DB))
                        ) {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (lang == Language.ENGLISH) "Restore" else "නැවත ලබා ගන්න", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("email_configuration_card"),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = "Email Settings",
                            tint = AccentAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = LocalizedText.get("email_config_title", lang),
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = senderEmailInput,
                        onValueChange = { senderEmailInput = it },
                        label = { Text(LocalizedText.get("sender_email", lang), color = TextGray) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("email_config_sender_email_input")
                    )

                    OutlinedTextField(
                        value = appPasswordInput,
                        onValueChange = { appPasswordInput = it },
                        label = { Text(LocalizedText.get("app_password", lang), color = TextGray) },
                        singleLine = true,
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentAmber,
                            unfocusedBorderColor = BorderColor
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("email_config_app_password_input")
                    )

                    Button(
                        onClick = {
                            viewModel.saveEmailConfig(senderEmailInput, appPasswordInput)
                            Toast.makeText(context, LocalizedText.get("email_config_saved", lang), Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth().testTag("email_config_save_button")
                    ) {
                        Text(LocalizedText.get("save_settings", lang), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("notification_settings_card"),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notification Settings",
                            tint = AccentAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (lang == Language.ENGLISH) "Notification Alerts" else "ස්වයංක්‍රීය දැනුම්දීම්",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (lang == Language.ENGLISH) {
                            "Select the transmission channel for automated transaction receipts and loan updates."
                        } else {
                            "ණය සහ ගෙවීම් වාර්තා සේවාලාභියා වෙත ස්වයංක්‍රීයව යවන ආකාරය තෝරන්න."
                        },
                        color = TextGray,
                        fontSize = 12.sp
                    )

                    val modes = listOf(
                        "BOTH" to if (lang == Language.ENGLISH) "Both SMS & Email" else "SMS සහ Email දෙකම",
                        "SMS_ONLY" to if (lang == Language.ENGLISH) "Auto SMS Only" else "SMS පමණක්",
                        "EMAIL_ONLY" to if (lang == Language.ENGLISH) "Auto Email Only" else "Email පමණක්",
                        "DISABLED" to if (lang == Language.ENGLISH) "Disabled" else "අක්‍රීය කරන්න"
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        modes.forEach { (modeKey, modeLabel) ->
                            val isSelected = notificationMode == modeKey
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = if (isSelected) AccentAmber.copy(alpha = 0.15f) else Color(0xFF131722),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) AccentAmber else BorderColor,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable {
                                        viewModel.updateNotificationMode(modeKey)
                                        Toast.makeText(context, if (lang == Language.ENGLISH) "Notification mode updated!" else "දැනුම්දීම් ක්‍රමය යාවත්කාලීන කරන ලදී!", Toast.LENGTH_SHORT).show()
                                    }
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = modeLabel,
                                    color = if (isSelected) Color.White else TextGray,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.updateNotificationMode(modeKey)
                                        Toast.makeText(context, if (lang == Language.ENGLISH) "Notification mode updated!" else "දැනුම්දීම් ක්‍රමය යාවත්කාලීන කරන ලදී!", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = AccentAmber,
                                        unselectedColor = TextGray
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            val savedPin by viewModel.savedPin.collectAsStateWithLifecycle()
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Lock",
                            tint = AccentAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = LocalizedText.get("security_settings", lang),
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = if (savedPin != null) {
                            LocalizedText.get("pin_status_configured", lang)
                        } else {
                            LocalizedText.get("pin_status_not_configured", lang)
                        },
                        color = TextGray,
                        fontSize = 14.sp
                    )

                    if (savedPin != null) {
                        Button(
                            onClick = {
                                viewModel.clearPinSecurity()
                                Toast.makeText(context, if (lang == Language.ENGLISH) "PIN Security disabled" else "PIN ආරක්ෂාව අක්‍රීය කරන ලදී", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.2f), contentColor = Color.Red),
                            modifier = Modifier.fillMaxWidth().testTag("disable_pin_security_button")
                        ) {
                            Text(LocalizedText.get("disable_pin_btn", lang), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.clearPinSecurity() // Force show setup
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentAmber, contentColor = Color.Black),
                            modifier = Modifier.fillMaxWidth().testTag("enable_pin_security_button")
                        ) {
                            Text(LocalizedText.get("enable_pin_btn", lang), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 3. ADVANCED ANALYTICS DASHBOARD (INSIDE SETTINGS EXCLUSIVELY)
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("advanced_analytics_dashboard_card"),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = "Analytics Icon",
                            tint = AccentAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (lang == Language.ENGLISH) "All Loans Analytics" else "සියලුම ණය විශ්ලේෂණය",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Ratio Bar Chart: Disbursed vs Recovered
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (lang == Language.ENGLISH) "Disbursed vs Recovered" else "නිකුත්කල මුදල සහ අයකරගත් මුදල",
                                color = TextGray,
                                fontSize = 11.sp
                            )
                            val percent = if (totalDisbursed > 0) ((totalRecovered / totalDisbursed) * 100).toInt() else 0
                            Text(
                                text = "Recovery Rate: $percent%",
                                color = EmeraldGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Horizontal Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF221C11))
                        ) {
                            val totalSum = totalDisbursed + totalRecovered
                            val disbursedWeight = if (totalSum > 0) (totalDisbursed / totalSum).toFloat() else 0.5f
                            val recoveredWeight = if (totalSum > 0) (totalRecovered / totalSum).toFloat() else 0.5f

                            if (disbursedWeight > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(disbursedWeight)
                                        .background(AccentAmber)
                                )
                            }
                            if (recoveredWeight > 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(recoveredWeight)
                                        .background(EmeraldGreen)
                                )
                            }
                        }

                        // Chart Legend
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(AccentAmber))
                                Text(
                                    text = if (lang == Language.ENGLISH) "Disbursed" else "නිකුත් කල",
                                    color = TextGray,
                                    fontSize = 10.sp
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldGreen))
                                Text(
                                    text = if (lang == Language.ENGLISH) "Recovered" else "අයකරගත්",
                                    color = TextGray,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = BorderColor, thickness = 0.5.dp)

                    // Grid Statistics
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Col 1: Disbursed
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF131722), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = if (lang == Language.ENGLISH) "Total Disbursed" else "මුළු නිකුත්කල",
                                    color = TextGray,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = formatRupees(totalDisbursed),
                                    color = AccentAmber,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            // Col 2: Recovered
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF131722), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = if (lang == Language.ENGLISH) "Total Recovered" else "මුළු ලැබුණු",
                                    color = TextGray,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = formatRupees(totalRecovered),
                                    color = EmeraldGreen,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Col 3: Outstanding
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF131722), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = if (lang == Language.ENGLISH) "Remaining Outstanding" else "ඉතිරි ලැබීමට ඇති",
                                    color = TextGray,
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = formatRupees(analyticsResult.remainingOutstanding),
                                    color = SoftGold,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            // Col 4: Overdue Counts
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Color(0xFF131722), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = if (lang == Language.ENGLISH) "Overdue Loans" else "ප්‍රමාද වූ ණය ගණන",
                                    color = TextGray,
                                    fontSize = 10.sp
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = analyticsResult.overdueCount.toString(),
                                        color = if (analyticsResult.overdueCount > 0) Color.Red else Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (analyticsResult.overdueCount > 0) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(Color.Red)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = BorderColor, thickness = 0.5.dp)

                    // Active Debtors Table
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (lang == Language.ENGLISH) "Active Debtors Ledger" else "ක්‍රියාකාරී ණයකරුවන්ගේ ලේඛනය",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        if (analyticsResult.activeDebtorsList.isEmpty()) {
                            Text(
                                text = if (lang == Language.ENGLISH) "No active loans found." else "ක්‍රියාකාරී ණය ගිණුම් කිසිවක් නැත.",
                                color = TextGray,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0F121C), RoundedCornerShape(8.dp))
                                    .border(0.5.dp, BorderColor, RoundedCornerShape(8.dp))
                            ) {
                                // Table Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1A1F2E))
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (lang == Language.ENGLISH) "Name" else "නම",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(2f)
                                    )
                                    Text(
                                        text = if (lang == Language.ENGLISH) "Disbursed" else "නිකුත්කල",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.End,
                                        modifier = Modifier.weight(1.5f)
                                    )
                                    Text(
                                        text = if (lang == Language.ENGLISH) "Outstanding" else "හිඟ මුදල",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.End,
                                        modifier = Modifier.weight(1.5f)
                                    )
                                }

                                // Table Rows (limit to first 15 for clean layout, or show all with nice spacing)
                                analyticsResult.activeDebtorsList.take(15).forEach { (borrowerName, disbursedAmt, outstandingAmt) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = borrowerName,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(2f)
                                        )
                                        Text(
                                            text = formatRupees(disbursedAmt),
                                            color = AccentAmber,
                                            fontSize = 11.sp,
                                            textAlign = TextAlign.End,
                                            modifier = Modifier.weight(1.5f)
                                        )
                                        Text(
                                            text = formatRupees(outstandingAmt),
                                            color = SoftGold,
                                            fontSize = 11.sp,
                                            textAlign = TextAlign.End,
                                            modifier = Modifier.weight(1.5f)
                                        )
                                    }
                                    HorizontalDivider(color = BorderColor, thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettleLoanConfirmationDialog(
    loanId: Int,
    borrowerName: String,
    lang: Language,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "✓ SMS Permission Granted! Alerts will be sent automatically.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "⚠️ SMS Permission Denied. Automatic background SMS alert might fail.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.SEND_SMS
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(android.Manifest.permission.SEND_SMS)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentAmber,
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("confirm_settle_button")
            ) {
                Text(
                    text = LocalizedText.get("yes_confirm", lang),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_settle_button")
            ) {
                Text(
                    text = LocalizedText.get("no", lang),
                    color = TextGray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Warning",
                    tint = AccentAmber,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = LocalizedText.get("settle_confirm_title", lang),
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Text(
                text = "${LocalizedText.get("settle_confirm_desc", lang)} ($borrowerName)",
                color = TextLight,
                fontSize = 14.sp
            )
        },
        shape = RoundedCornerShape(16.dp),
        containerColor = CardBg,
        modifier = Modifier.border(1.dp, BorderColor, RoundedCornerShape(16.dp))
    )
}
