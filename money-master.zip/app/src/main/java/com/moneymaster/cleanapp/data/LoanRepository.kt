package com.moneymaster.cleanapp.data

import kotlinx.coroutines.flow.Flow

class LoanRepository(private val loanDao: LoanDao) {
    val allLoans: Flow<List<Loan>> = loanDao.getAllLoans()
    val activeLoans: Flow<List<Loan>> = loanDao.getActiveLoans()
    val allPayments: Flow<List<Payment>> = loanDao.getAllPayments()
    val allCustomers: Flow<List<Customer>> = loanDao.getAllCustomers()

    fun getLoanById(id: Int): Flow<Loan?> = loanDao.getLoanById(id)

    fun getPaymentsForLoan(loanId: Int): Flow<List<Payment>> = loanDao.getPaymentsForLoan(loanId)

    fun getCustomerById(id: Int): Flow<Customer?> = loanDao.getCustomerById(id)

    suspend fun getCustomerByIdDirect(id: Int): Customer? = loanDao.getCustomerByIdDirect(id)

    suspend fun insertCustomer(customer: Customer): Long = loanDao.insertCustomer(customer)

    suspend fun updateCustomer(customer: Customer) = loanDao.updateCustomer(customer)

    suspend fun deleteCustomer(customer: Customer) = loanDao.deleteCustomer(customer)

    suspend fun insertLoan(loan: Loan): Long = loanDao.insertLoan(loan)

    suspend fun updateLoan(loan: Loan) = loanDao.updateLoan(loan)

    suspend fun deleteLoan(loan: Loan) = loanDao.deleteLoan(loan)

    suspend fun insertPayment(payment: Payment): Long = loanDao.insertPayment(payment)

    suspend fun deletePayment(payment: Payment) = loanDao.deletePayment(payment)

    // Direct backup and restore methods
    suspend fun getAllCustomersDirect(): List<Customer> = loanDao.getAllCustomersDirect()
    suspend fun getAllLoansDirect(): List<Loan> = loanDao.getAllLoansDirect()
    suspend fun getAllPaymentsDirect(): List<Payment> = loanDao.getAllPaymentsDirect()

    suspend fun restoreDatabase(customers: List<Customer>, loans: List<Loan>, payments: List<Payment>) {
        loanDao.clearAllPayments()
        loanDao.clearAllLoans()
        loanDao.clearAllCustomers()

        loanDao.insertCustomers(customers)
        loanDao.insertLoans(loans)
        loanDao.insertPayments(payments)
    }

}
