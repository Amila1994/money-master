package com.moneymaster.cleanapp.utils

import android.content.Context
import android.util.Log
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File
import com.google.api.client.http.FileContent
import com.google.api.client.json.gson.GsonFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileOutputStream
import java.util.Collections

object GoogleDriveService {
    private const val TAG = "GoogleDriveService"
    private const val BACKUP_FILE_NAME = "money_master_backup.db"

    suspend fun exchangeCodeAndSave(context: Context, serverAuthCode: String, webClientId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest(
                com.google.api.client.http.javanet.NetHttpTransport(),
                GsonFactory.getDefaultInstance(),
                "https://oauth2.googleapis.com/token",
                webClientId,
                "", // client secret is empty for native/web public clients
                serverAuthCode,
                ""
            ).execute()

            val accessToken = response.accessToken
            val refreshToken = response.refreshToken

            val prefs = context.getSharedPreferences("money_master_drive_prefs", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString("access_token", accessToken)
                if (refreshToken != null) {
                    putString("refresh_token", refreshToken)
                }
                putLong("token_expiry", System.currentTimeMillis() + (response.expiresInSeconds ?: 3600L) * 1000)
                apply()
            }
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Error exchanging server auth code", e)
            return@withContext false
        }
    }

    suspend fun getValidAccessToken(context: Context): String? = withContext(Dispatchers.IO) {
        val prefs = context.getSharedPreferences("money_master_drive_prefs", Context.MODE_PRIVATE)
        val accessToken = prefs.getString("access_token", null) ?: return@withContext null
        val refreshToken = prefs.getString("refresh_token", null)
        val expiry = prefs.getLong("token_expiry", 0L)

        // If not expired, return it (with a 5-minute buffer)
        if (System.currentTimeMillis() < expiry - 300 * 1000) {
            return@withContext accessToken
        }

        // If expired but we have a refresh token, refresh it
        if (refreshToken != null) {
            val webClientId = "860546045626-osobv63vqt8sqa2lar6ha5emdlrqlt6c.apps.googleusercontent.com"

            if (webClientId.isNotEmpty()) {
                try {
                    val response = com.google.api.client.googleapis.auth.oauth2.GoogleRefreshTokenRequest(
                        com.google.api.client.http.javanet.NetHttpTransport(),
                        GsonFactory.getDefaultInstance(),
                        refreshToken,
                        webClientId,
                        ""
                    ).execute()

                    val newAccessToken = response.accessToken
                    prefs.edit().apply {
                        putString("access_token", newAccessToken)
                        putLong("token_expiry", System.currentTimeMillis() + (response.expiresInSeconds ?: 3600L) * 1000)
                        apply()
                    }
                    return@withContext newAccessToken
                } catch (e: Exception) {
                    Log.e(TAG, "Error refreshing token", e)
                }
            }
        }
        return@withContext accessToken // Return existing as fallback
    }

    private suspend fun getDriveService(context: Context): Drive? {
        val accessToken = getValidAccessToken(context) ?: return null
        
        val requestInitializer = com.google.api.client.http.HttpRequestInitializer { request ->
            request.headers.authorization = "Bearer $accessToken"
        }

        return Drive.Builder(
            com.google.api.client.http.javanet.NetHttpTransport(),
            GsonFactory.getDefaultInstance(),
            requestInitializer
        ).setApplicationName("Money Master").build()
    }

    suspend fun uploadBackup(context: Context, onResult: (Boolean, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(context)
            if (driveService == null) {
                onResult(false, "Google Drive not connected. Please connect first.")
                return@withContext
            }

            val dbFile = context.getDatabasePath("money_master_database")
            if (!dbFile.exists()) {
                onResult(false, "Local database does not exist.")
                return@withContext
            }

            // Find existing backup file in AppData folder
            val result = driveService.files().list()
                .setSpaces("appDataFolder")
                .setQ("name = '$BACKUP_FILE_NAME'")
                .execute()

            val existingFiles = result.files
            val fileMetadata = File().apply {
                name = BACKUP_FILE_NAME
                parents = Collections.singletonList("appDataFolder")
            }

            val mediaContent = FileContent("application/octet-stream", dbFile)

            if (!existingFiles.isNullOrEmpty()) {
                // Update existing file
                val existingFileId = existingFiles[0].id
                driveService.files().update(existingFileId, null, mediaContent).execute()
                onResult(true, "Database updated successfully on Google Drive AppData folder.")
            } else {
                // Create new file
                driveService.files().create(fileMetadata, mediaContent).execute()
                onResult(true, "Database backup uploaded successfully to Google Drive AppData folder.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error uploading backup", e)
            onResult(false, "Failed to upload: ${e.localizedMessage ?: e.message}")
        }
    }

    suspend fun restoreBackup(context: Context, onResult: (Boolean, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(context)
            if (driveService == null) {
                onResult(false, "Google Drive not connected. Please connect first.")
                return@withContext
            }

            val result = driveService.files().list()
                .setSpaces("appDataFolder")
                .setQ("name = '$BACKUP_FILE_NAME'")
                .execute()

            val files = result.files
            if (files.isNullOrEmpty()) {
                onResult(false, "No backup found in Google Drive AppData folder.")
                return@withContext
            }

            val fileId = files[0].id
            val dbFile = context.getDatabasePath("money_master_database")
            
            val outputStream = FileOutputStream(dbFile)
            driveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
            outputStream.close()

            // Delete wal and shm if they exist to prevent sync conflict
            val walFile = context.getDatabasePath("money_master_database-wal")
            if (walFile.exists()) walFile.delete()
            val shmFile = context.getDatabasePath("money_master_database-shm")
            if (shmFile.exists()) shmFile.delete()

            onResult(true, "Backup restored successfully. Restarting the app...")
        } catch (e: Exception) {
            Log.e(TAG, "Error restoring backup", e)
            onResult(false, "Failed to restore: ${e.localizedMessage ?: e.message}")
        }
    }
}
