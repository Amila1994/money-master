package com.moneymaster.cleanapp.utils

import android.content.Context
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URLDecoder
import java.net.URLEncoder

object GoogleSheetsSyncManager {

    private val client = OkHttpClient()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    // Hardcoded production credentials
    private const val WEB_CLIENT_ID = "860546045626-osobv63vqt8sqa2lar6ha5emdlrqlt6c.apps.googleusercontent.com"
    private const val ANDROID_API_KEY = "AIzaSyBDDhUcgsEFyADGg7NO310sDP8V8kzVtyA"
    private const val PACKAGE_NAME = "com.moneymaster.cleanapp"

    fun extractSpreadsheetId(input: String): String {
        if (input.isBlank()) return ""
        val trimmed = input.trim()
        return try {
            val decoded = URLDecoder.decode(trimmed, "UTF-8")
            val dIndex = decoded.indexOf("/d/")
            if (dIndex != -1) {
                val afterD = decoded.substring(dIndex + 3)
                val slashIndex = afterD.indexOf("/")
                if (slashIndex != -1) {
                    afterD.substring(0, slashIndex)
                } else {
                    val qIndex = afterD.indexOf("?")
                    if (qIndex != -1) {
                        afterD.substring(0, qIndex)
                    } else {
                        afterD
                    }
                }
            } else if (decoded.contains("spreadsheets/d/")) {
                val regex = "spreadsheets/d/([a-zA-Z0-9-_]+)".toRegex()
                val match = regex.find(decoded)
                match?.groupValues?.get(1) ?: trimmed
            } else {
                val regex = "/d/([a-zA-Z0-9-_]+)".toRegex()
                val match = regex.find(decoded)
                if (match != null) {
                    match.groupValues[1]
                } else if (!trimmed.contains("/") && trimmed.length > 20) {
                    trimmed
                } else {
                    trimmed
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to extract spreadsheet ID: ${e.localizedMessage}")
            trimmed
        }
    }

    /**
     * Retrieves the OAuth2 Access Token for Drive and Sheets using GoogleAuthUtil.
     */
    suspend fun getAccessToken(context: Context): String? = withContext(Dispatchers.IO) {
        try {
            val account = com.google.android.gms.auth.api.signin.GoogleSignIn.getLastSignedInAccount(context)
                ?: return@withContext null
            val email = account.email ?: return@withContext null
            val scope = "oauth2:https://www.googleapis.com/auth/drive.file https://www.googleapis.com/auth/spreadsheets"
            com.google.android.gms.auth.GoogleAuthUtil.getToken(context, email, scope)
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to retrieve access token: ${e.localizedMessage}", e)
            null
        }
    }

    /**
     * Performs an asynchronous restore of data matching the Lender ID from Google Sheet tabs.
     */
    suspend fun restoreFromCloud(
        context: Context,
        spreadsheetLinkOrId: String,
        lenderId: String
    ): Triple<List<Customer>, List<Loan>, List<Payment>> = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) {
            throw IllegalArgumentException("Invalid Spreadsheet Link or ID")
        }

        val customers = mutableListOf<Customer>()
        val loans = mutableListOf<Loan>()
        val payments = mutableListOf<Payment>()

        try {
            // Automatically check or create three distinct tabs
            ensureTabsExist(context, spreadsheetId)

            // Fetch each tab
            val customerRows = fetchTabRows(context, spreadsheetId, "Customers")
            val loanRows = fetchTabRows(context, spreadsheetId, "Loans")
            val paymentRows = fetchTabRows(context, spreadsheetId, "Transactions")

            // Parse Customers
            customerRows.forEach { row ->
                if (row.size >= 3 && row[0].equals(lenderId, ignoreCase = true)) {
                    val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                    val name = row.getOrNull(2) ?: ""
                    val address = row.getOrNull(3) ?: ""
                    val phone = row.getOrNull(4) ?: ""
                    val nic = row.getOrNull(5) ?: ""
                    val email = row.getOrNull(6)?.ifBlank { null }
                    val photo = row.getOrNull(7) ?: ""
                    val nicPhoto = row.getOrNull(8) ?: ""
                    if (name.isNotBlank()) {
                        customers.add(Customer(id = id, name = name, address = address, phone = phone, nic = nic, photoUri = photo, nicPhotoUri = nicPhoto, email = email))
                    }
                }
            }

            // Parse Loans
            loanRows.forEach { row ->
                if (row.size >= 4 && row[0].equals(lenderId, ignoreCase = true)) {
                    val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                    val customerId = row.getOrNull(2)?.toIntOrNull()
                    val borrowerName = row.getOrNull(3) ?: ""
                    val borrowerPhone = row.getOrNull(4) ?: ""
                    val principal = row.getOrNull(5)?.toDoubleOrNull() ?: 0.0
                    val rate = row.getOrNull(6)?.toDoubleOrNull() ?: 0.0
                    val period = row.getOrNull(7) ?: "Monthly"
                    val startDate = row.getOrNull(8)?.toLongOrNull() ?: System.currentTimeMillis()
                    val notes = row.getOrNull(9) ?: ""
                    val isSettled = row.getOrNull(10)?.toBoolean() ?: false
                    if (borrowerName.isNotBlank()) {
                        loans.add(Loan(id = id, customerId = customerId, borrowerName = borrowerName, borrowerPhone = borrowerPhone, principalAmount = principal, interestRate = rate, interestPeriod = period, startDate = startDate, notes = notes, isSettled = isSettled))
                    }
                }
            }

            // Parse Payments
            paymentRows.forEach { row ->
                if (row.size >= 4 && row[0].equals(lenderId, ignoreCase = true)) {
                    val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                    val loanId = row.getOrNull(2)?.toIntOrNull() ?: 0
                    val amount = row.getOrNull(3)?.toDoubleOrNull() ?: 0.0
                    val paymentDate = row.getOrNull(4)?.toLongOrNull() ?: System.currentTimeMillis()
                    val type = row.getOrNull(5) ?: "Principal"
                    val notes = row.getOrNull(6) ?: ""
                    payments.add(Payment(id = id, loanId = loanId, amount = amount, paymentDate = paymentDate, type = type, notes = notes))
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Error restoring from cloud: ${e.localizedMessage}", e)
        }

        Triple(customers, loans, payments)
    }

    private suspend fun fetchTabRows(context: Context, spreadsheetId: String, tabName: String): List<List<String>> {
        val resultRows = mutableListOf<List<String>>()

        // Strategy A: Sheets API v4 with OAuth2 Access Token
        try {
            val accessToken = getAccessToken(context)
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}"
            val requestBuilder = Request.Builder()
                .addHeader("X-Android-Package", PACKAGE_NAME)

            if (accessToken != null) {
                requestBuilder.url(url).addHeader("Authorization", "Bearer $accessToken")
            } else {
                requestBuilder.url("$url?key=$ANDROID_API_KEY")
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: ""
                    val json = JSONObject(bodyStr)
                    val valuesArray = json.optJSONArray("values")
                    if (valuesArray != null) {
                        for (i in 0 until valuesArray.length()) {
                            val rowArray = valuesArray.optJSONArray(i)
                            if (rowArray != null) {
                                val row = mutableListOf<String>()
                                for (j in 0 until rowArray.length()) {
                                    row.add(rowArray.optString(j, ""))
                                }
                                resultRows.add(row)
                            }
                        }
                        return resultRows
                    }
                } else {
                    android.util.Log.e("GoogleSheetsSync", "Sheets API v4 GET failed for $tabName: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in fetchTabRows Sheets API v4 for $tabName: ${e.localizedMessage}", e)
        }

        // Strategy B: Fallback to CSV public export
        try {
            val url = "https://docs.google.com/spreadsheets/d/$spreadsheetId/export?format=csv&sheet=${URLEncoder.encode(tabName, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val csvText = response.body?.string() ?: ""
                    return parseCsvRows(csvText)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in fetchTabRows Strategy B for $tabName: ${e.localizedMessage}", e)
        }

        return resultRows
    }

    private fun parseCsvRows(csvText: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val lines = csvText.split("\n")
        for (line in lines) {
            if (line.isBlank()) continue
            val tokens = mutableListOf<String>()
            var inQuotes = false
            var sb = java.lang.StringBuilder()
            for (c in line) {
                if (c == '"') {
                    inQuotes = !inQuotes
                } else if (c == ',' && !inQuotes) {
                    tokens.add(sb.toString().trim())
                    sb = java.lang.StringBuilder()
                } else {
                    sb.append(c)
                }
            }
            tokens.add(sb.toString().trim())

            val cleanedTokens = tokens.map {
                var t = it
                if (t.startsWith("\"") && t.endsWith("\"")) {
                    t = t.substring(1, t.length - 1)
                }
                t.replace("\"\"", "\"")
            }
            rows.add(cleanedTokens)
        }
        return rows
    }

    /**
     * Appends a customer row to the Google Sheet in real-time.
     */
    suspend fun appendCustomer(context: Context, spreadsheetLinkOrId: String, lenderId: String, customer: Customer) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            customer.id.toString(),
            customer.name,
            customer.address,
            customer.phone,
            customer.nic,
            customer.email ?: "",
            customer.photoUri,
            customer.nicPhotoUri
        )

        appendRowToSheet(context, spreadsheetId, "Customers", rowValues)
        // Auto-backup local database to Google Drive as well
        backupDatabaseToDrive(context)
    }

    /**
     * Appends a loan row to the Google Sheet in real-time.
     */
    suspend fun appendLoan(context: Context, spreadsheetLinkOrId: String, lenderId: String, loan: Loan) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            loan.id.toString(),
            (loan.customerId ?: "").toString(),
            loan.borrowerName,
            loan.borrowerPhone,
            loan.principalAmount.toString(),
            loan.interestRate.toString(),
            loan.interestPeriod,
            loan.startDate.toString(),
            loan.notes,
            loan.isSettled.toString()
        )

        appendRowToSheet(context, spreadsheetId, "Loans", rowValues)
        // Auto-backup local database to Google Drive as well
        backupDatabaseToDrive(context)
    }

    /**
     * Appends a payment row to the Google Sheet in real-time.
     */
    suspend fun appendPayment(context: Context, spreadsheetLinkOrId: String, lenderId: String, payment: Payment) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            payment.id.toString(),
            payment.loanId.toString(),
            payment.amount.toString(),
            payment.paymentDate.toString(),
            payment.type,
            payment.notes
        )

        appendRowToSheet(context, spreadsheetId, "Transactions", rowValues)
        // Auto-backup local database to Google Drive as well
        backupDatabaseToDrive(context)
    }

    private suspend fun ensureTabsExist(context: Context, spreadsheetId: String) {
        try {
            val accessToken = getAccessToken(context)
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId"
            val requestBuilder = Request.Builder()
                .addHeader("X-Android-Package", PACKAGE_NAME)

            if (accessToken != null) {
                requestBuilder.url(url).addHeader("Authorization", "Bearer $accessToken")
            } else {
                requestBuilder.url("$url?key=$ANDROID_API_KEY")
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    android.util.Log.e("GoogleSheetsSync", "Failed to inspect spreadsheet metadata: ${response.code} ${response.message}")
                    return
                }
                val bodyStr = response.body?.string() ?: ""
                val json = JSONObject(bodyStr)
                val sheets = json.optJSONArray("sheets") ?: return
                val existingTabs = mutableSetOf<String>()
                for (i in 0 until sheets.length()) {
                    val sheetObj = sheets.optJSONObject(i)
                    val props = sheetObj?.optJSONObject("properties")
                    val title = props?.optString("title")
                    if (title != null) {
                        existingTabs.add(title)
                    }
                }

                val requiredTabs = listOf("Customers", "Loans", "Transactions")
                val missingTabs = requiredTabs.filter { !existingTabs.contains(it) }

                if (missingTabs.isNotEmpty()) {
                    createTabs(context, spreadsheetId, missingTabs)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in ensureTabsExist: ${e.localizedMessage}", e)
        }
    }

    private suspend fun createTabs(context: Context, spreadsheetId: String, tabsToCreate: List<String>) {
        try {
            val accessToken = getAccessToken(context)
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId:batchUpdate"
            val requestsArray = JSONArray()
            tabsToCreate.forEach { tabName ->
                val addSheetReq = JSONObject().apply {
                    put("addSheet", JSONObject().apply {
                        put("properties", JSONObject().apply {
                            put("title", tabName)
                        })
                    })
                }
                requestsArray.put(addSheetReq)
            }

            val jsonPayload = JSONObject().apply {
                put("requests", requestsArray)
            }

            val requestBuilder = Request.Builder()
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))

            if (accessToken != null) {
                requestBuilder.url(url).addHeader("Authorization", "Bearer $accessToken")
            } else {
                requestBuilder.url("$url?key=$ANDROID_API_KEY")
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                if (response.isSuccessful) {
                    android.util.Log.d("GoogleSheetsSync", "Successfully created tabs: $tabsToCreate")
                    // Initialize headers for newly created tabs
                    tabsToCreate.forEach { tabName ->
                        if (tabName == "Customers") {
                            appendRowToSheetDirect(context, spreadsheetId, "Customers", listOf("Lender ID", "Customer ID", "Name", "Address", "Phone", "NIC", "Email", "Photo URI", "NIC Photo URI"))
                        } else if (tabName == "Loans") {
                            appendRowToSheetDirect(context, spreadsheetId, "Loans", listOf("Lender ID", "Loan ID", "Customer ID", "Borrower Name", "Borrower Phone", "Principal Amount", "Interest Rate", "Interest Period", "Start Date", "Notes", "Is Settled"))
                        } else if (tabName == "Transactions") {
                            appendRowToSheetDirect(context, spreadsheetId, "Transactions", listOf("Lender ID", "Transaction ID", "Loan ID", "Amount", "Date", "Type", "Notes"))
                        }
                    }
                } else {
                    android.util.Log.e("GoogleSheetsSync", "Failed to create missing tabs: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in createTabs: ${e.localizedMessage}", e)
        }
    }

    private suspend fun appendRowToSheetDirect(context: Context, spreadsheetId: String, tabName: String, values: List<String>) {
        try {
            val accessToken = getAccessToken(context)
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED"
            val jsonPayload = JSONObject().apply {
                put("range", tabName)
                put("majorDimension", "ROWS")
                put("values", JSONArray().apply {
                    put(JSONArray().apply {
                        values.forEach { put(it) }
                    })
                })
            }

            val requestBuilder = Request.Builder()
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))

            if (accessToken != null) {
                requestBuilder.url(url).addHeader("Authorization", "Bearer $accessToken")
            } else {
                requestBuilder.url("https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED&key=$ANDROID_API_KEY")
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                android.util.Log.d("GoogleSheetsSync", "Append to $tabName response: ${response.code}")
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to append row to $tabName: ${e.localizedMessage}", e)
        }
    }

    private suspend fun appendRowToSheet(context: Context, spreadsheetId: String, tabName: String, values: List<String>) {
        try {
            // First make sure the tabs exist before appending
            ensureTabsExist(context, spreadsheetId)

            val accessToken = getAccessToken(context)
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED"
            val jsonPayload = JSONObject().apply {
                put("range", tabName)
                put("majorDimension", "ROWS")
                put("values", JSONArray().apply {
                    put(JSONArray().apply {
                        values.forEach { put(it) }
                    })
                })
            }

            val requestBuilder = Request.Builder()
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))

            if (accessToken != null) {
                requestBuilder.url(url).addHeader("Authorization", "Bearer $accessToken")
            } else {
                requestBuilder.url("https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED&key=$ANDROID_API_KEY")
            }

            client.newCall(requestBuilder.build()).execute().use { response ->
                android.util.Log.d("GoogleSheetsSync", "Append to $tabName response: ${response.code} ${response.message}")
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to append to Google Sheet $tabName: ${e.localizedMessage}", e)
        }
    }

    // ==========================================
    // GOOGLE DRIVE BACKUP & AUTO-RESTORE REST API
    // ==========================================

    suspend fun backupDatabaseToDrive(context: Context): Boolean = withContext(Dispatchers.IO) {
        val accessToken = getAccessToken(context)
        if (accessToken == null) {
            android.util.Log.e("GoogleDriveBackup", "No access token found for backup")
            return@withContext false
        }

        // Zip database files
        val zipFile = zipDatabaseFiles(context) ?: return@withContext false

        try {
            // Find or Create "MoneyMaster_Backup" folder
            val folderId = findOrCreateDriveFolder(accessToken, "MoneyMaster_Backup")
            if (folderId == null) {
                android.util.Log.e("GoogleDriveBackup", "Failed to find or create MoneyMaster_Backup folder")
                return@withContext false
            }

            // Find if "money_master_backup.zip" already exists in that folder
            val fileId = findDriveFile(accessToken, "money_master_backup.zip", folderId)
            if (fileId != null) {
                // Delete existing file
                deleteDriveFile(accessToken, fileId)
            }

            // Upload new file
            val success = uploadDriveFileMultipart(accessToken, "money_master_backup.zip", folderId, zipFile)
            
            // Delete temp zip file
            try { zipFile.delete() } catch (e: Exception) {}

            success
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error during backup: ${e.localizedMessage}", e)
            false
        }
    }

    suspend fun restoreDatabaseFromDrive(context: Context): Boolean = withContext(Dispatchers.IO) {
        val accessToken = getAccessToken(context)
        if (accessToken == null) {
            android.util.Log.e("GoogleDriveBackup", "No access token found for restore")
            return@withContext false
        }

        try {
            // Find the "MoneyMaster_Backup" folder
            val folderId = findDriveFolder(accessToken, "MoneyMaster_Backup") ?: return@withContext false

            // Find the "money_master_backup.zip" file in that folder
            val fileId = findDriveFile(accessToken, "money_master_backup.zip", folderId) ?: return@withContext false

            // Download the file bytes to a temp zip file
            val tempZipFile = File(context.cacheDir, "temp_restore_backup.zip")
            if (tempZipFile.exists()) tempZipFile.delete()

            val downloaded = downloadDriveFile(accessToken, fileId, tempZipFile)
            if (!downloaded) {
                android.util.Log.e("GoogleDriveBackup", "Failed to download backup zip")
                return@withContext false
            }

            // Close database, unzip files, and reload
            try {
                com.moneymaster.cleanapp.data.AppDatabase.getDatabase(context).close()
            } catch (e: Exception) {}

            val success = unzipDatabaseFiles(context, tempZipFile)
            
            // Cleanup temp file
            try { tempZipFile.delete() } catch (e: Exception) {}

            success
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error during restore: ${e.localizedMessage}", e)
            false
        }
    }

    private fun findDriveFolder(accessToken: String, folderName: String): String? {
        try {
            val query = URLEncoder.encode("name='$folderName' and mimeType='application/vnd.google-apps.folder' and trashed=false", "UTF-8")
            val url = "https://www.googleapis.com/drive/v3/files?q=$query"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    val files = json.optJSONArray("files")
                    if (files != null && files.length() > 0) {
                        return files.getJSONObject(0).optString("id")
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error finding folder: ${e.localizedMessage}")
        }
        return null
    }

    private fun findOrCreateDriveFolder(accessToken: String, folderName: String): String? {
        val existingId = findDriveFolder(accessToken, folderName)
        if (existingId != null) return existingId

        try {
            val url = "https://www.googleapis.com/drive/v3/files"
            val payload = JSONObject().apply {
                put("name", folderName)
                put("mimeType", "application/vnd.google-apps.folder")
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    return json.optString("id")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error creating folder: ${e.localizedMessage}")
        }
        return null
    }

    private fun findDriveFile(accessToken: String, fileName: String, folderId: String): String? {
        try {
            val query = URLEncoder.encode("name='$fileName' and '$folderId' in parents and trashed=false", "UTF-8")
            val url = "https://www.googleapis.com/drive/v3/files?q=$query"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val json = JSONObject(body)
                    val files = json.optJSONArray("files")
                    if (files != null && files.length() > 0) {
                        return files.getJSONObject(0).optString("id")
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error finding file: ${e.localizedMessage}")
        }
        return null
    }

    private fun deleteDriveFile(accessToken: String, fileId: String): Boolean {
        try {
            val url = "https://www.googleapis.com/drive/v3/files/$fileId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                return response.isSuccessful
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error deleting file: ${e.localizedMessage}")
        }
        return false
    }

    private fun uploadDriveFileMultipart(accessToken: String, fileName: String, folderId: String, file: File): Boolean {
        try {
            val url = "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart"
            
            val metadataPart = JSONObject().apply {
                put("name", fileName)
                put("parents", JSONArray().put(folderId))
            }.toString().toRequestBody("application/json; charset=UTF-8".toMediaType())

            val mediaType = "application/zip".toMediaType()
            val filePart = file.readBytes().toRequestBody(mediaType)

            val body = okhttp3.MultipartBody.Builder()
                .setType(okhttp3.MultipartBody.FORM)
                .addPart(
                    okhttp3.Headers.Builder().add("Content-Type", "application/json; charset=UTF-8").build(),
                    metadataPart
                )
                .addPart(
                    okhttp3.Headers.Builder().add("Content-Type", "application/zip").build(),
                    filePart
                )
                .build()

            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    android.util.Log.d("GoogleDriveBackup", "Upload successful: ${response.code}")
                    return true
                } else {
                    android.util.Log.e("GoogleDriveBackup", "Upload failed: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error uploading file: ${e.localizedMessage}", e)
        }
        return false
    }

    private fun downloadDriveFile(accessToken: String, fileId: String, targetFile: File): Boolean {
        try {
            val url = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $accessToken")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    response.body?.byteStream()?.use { input ->
                        FileOutputStream(targetFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    return true
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Error downloading file: ${e.localizedMessage}")
        }
        return false
    }

    private fun zipDatabaseFiles(context: Context): File? {
        val dbFile = context.getDatabasePath("money_master_database")
        val shmFile = context.getDatabasePath("money_master_database-shm")
        val walFile = context.getDatabasePath("money_master_database-wal")

        val filesToZip = listOf(dbFile, shmFile, walFile).filter { it.exists() }
        if (filesToZip.isEmpty()) return null

        val zipFile = File(context.cacheDir, "money_master_backup.zip")
        if (zipFile.exists()) {
            zipFile.delete()
        }

        try {
            java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(FileOutputStream(zipFile))).use { out ->
                val data = ByteArray(1024)
                for (file in filesToZip) {
                    FileInputStream(file).use { fi ->
                        java.io.BufferedInputStream(fi).use { origin ->
                            val entry = java.util.zip.ZipEntry(file.name)
                            out.putNextEntry(entry)
                            var count: Int
                            while (origin.read(data, 0, 1024).also { count = it } != -1) {
                                out.write(data, 0, count)
                            }
                        }
                    }
                }
            }
            return zipFile
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Failed to zip database files: ${e.localizedMessage}", e)
            return null
        }
    }

    private fun unzipDatabaseFiles(context: Context, zipFile: File): Boolean {
        val dbDir = context.getDatabasePath("money_master_database").parentFile ?: return false
        if (!dbDir.exists()) {
            dbDir.mkdirs()
        }
        try {
            java.util.zip.ZipInputStream(java.io.BufferedInputStream(zipFile.inputStream())).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val targetFile = File(dbDir, entry.name)
                    if (targetFile.exists()) {
                        targetFile.delete()
                    }
                    FileOutputStream(targetFile).use { fos ->
                        val buffer = ByteArray(1024)
                        var count: Int
                        while (zis.read(buffer).also { count = it } != -1) {
                            fos.write(buffer, 0, count)
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            return true
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Failed to unzip database files: ${e.localizedMessage}", e)
            return false
        }
    }
}
