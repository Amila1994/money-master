package com.moneymaster.cleanapp.utils

import android.content.Context
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder

object GoogleSheetsSyncManager {

    private val client = OkHttpClient()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    // Hardcoded production credentials
    private const val WEB_CLIENT_ID = "860546045626-osobv63vqt8sqa2lar6ha5emdlrqlt6c.apps.googleusercontent.com"
    private const val ANDROID_API_KEY = "AIzaSyBDDhUcgsEFyADGg7NO310sDP8V8kzVtyA"
    private const val PACKAGE_NAME = "com.moneymaster.cleanapp"

    fun extractSpreadsheetId(input: String): String {
        if (input.isBlank()) return ""
        val trimmed = input.trim()
        return try {
            val decoded = URLDecoder.decode(trimmed, "UTF-8")
            val regex = "/d/([a-zA-Z0-9-_]+)".toRegex()
            val match = regex.find(decoded)
            if (match != null) {
                match.groupValues[1]
            } else if (!trimmed.contains("/") && trimmed.length > 20) {
                trimmed
            } else {
                trimmed
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to extract spreadsheet ID: ${e.localizedMessage}")
            trimmed
        }
    }

    /**
     * Performs an asynchronous restore of data matching the Lender ID from Google Sheet tabs.
     */
    suspend fun restoreFromCloud(
        spreadsheetLinkOrId: String,
        lenderId: String
    ): Triple<List<Customer>, List<Loan>, List<Payment>> = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) {
            throw IllegalArgumentException("Invalid Spreadsheet Link or ID")
        }

        val customers = mutableListOf<Customer>()
        val loans = mutableListOf<Loan>()
        val payments = mutableListOf<Payment>()

        try {
            // Automatically check or create three distinct tabs
            ensureTabsExist(spreadsheetId)

            // Fetch each tab
            val customerRows = fetchTabRows(spreadsheetId, "Customers")
            val loanRows = fetchTabRows(spreadsheetId, "Loans")
            val paymentRows = fetchTabRows(spreadsheetId, "Transactions")

            // Parse Customers
            customerRows.forEach { row ->
                if (row.size >= 3 && row[0].equals(lenderId, ignoreCase = true)) {
                    val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                    val name = row.getOrNull(2) ?: ""
                    val address = row.getOrNull(3) ?: ""
                    val phone = row.getOrNull(4) ?: ""
                    val nic = row.getOrNull(5) ?: ""
                    val email = row.getOrNull(6)?.ifBlank { null }
                    val photo = row.getOrNull(7) ?: ""
                    val nicPhoto = row.getOrNull(8) ?: ""
                    if (name.isNotBlank()) {
                        customers.add(Customer(id = id, name = name, address = address, phone = phone, nic = nic, photoUri = photo, nicPhotoUri = nicPhoto, email = email))
                    }
                }
            }

            // Parse Loans
            loanRows.forEach { row ->
                if (row.size >= 4 && row[0].equals(lenderId, ignoreCase = true)) {
                    val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                    val customerId = row.getOrNull(2)?.toIntOrNull()
                    val borrowerName = row.getOrNull(3) ?: ""
                    val borrowerPhone = row.getOrNull(4) ?: ""
                    val principal = row.getOrNull(5)?.toDoubleOrNull() ?: 0.0
                    val rate = row.getOrNull(6)?.toDoubleOrNull() ?: 0.0
                    val period = row.getOrNull(7) ?: "Monthly"
                    val startDate = row.getOrNull(8)?.toLongOrNull() ?: System.currentTimeMillis()
                    val notes = row.getOrNull(9) ?: ""
                    val isSettled = row.getOrNull(10)?.toBoolean() ?: false
                    if (borrowerName.isNotBlank()) {
                        loans.add(Loan(id = id, customerId = customerId, borrowerName = borrowerName, borrowerPhone = borrowerPhone, principalAmount = principal, interestRate = rate, interestPeriod = period, startDate = startDate, notes = notes, isSettled = isSettled))
                    }
                }
            }

            // Parse Payments
            paymentRows.forEach { row ->
                if (row.size >= 4 && row[0].equals(lenderId, ignoreCase = true)) {
                    val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                    val loanId = row.getOrNull(2)?.toIntOrNull() ?: 0
                    val amount = row.getOrNull(3)?.toDoubleOrNull() ?: 0.0
                    val paymentDate = row.getOrNull(4)?.toLongOrNull() ?: System.currentTimeMillis()
                    val type = row.getOrNull(5) ?: "Principal"
                    val notes = row.getOrNull(6) ?: ""
                    payments.add(Payment(id = id, loanId = loanId, amount = amount, paymentDate = paymentDate, type = type, notes = notes))
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Error restoring from cloud: ${e.localizedMessage}", e)
        }

        Triple(customers, loans, payments)
    }

    private fun fetchTabRows(spreadsheetId: String, tabName: String): List<List<String>> {
        val resultRows = mutableListOf<List<String>>()

        // Strategy A: Sheets API v4 with API Key
        try {
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}?key=$ANDROID_API_KEY"
            val request = Request.Builder()
                .url(url)
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyStr = response.body?.string() ?: ""
                    val json = JSONObject(bodyStr)
                    val valuesArray = json.optJSONArray("values")
                    if (valuesArray != null) {
                        for (i in 0 until valuesArray.length()) {
                            val rowArray = valuesArray.optJSONArray(i)
                            if (rowArray != null) {
                                val row = mutableListOf<String>()
                                for (j in 0 until rowArray.length()) {
                                    row.add(rowArray.optString(j, ""))
                                }
                                resultRows.add(row)
                            }
                        }
                        return resultRows
                    }
                } else {
                    android.util.Log.e("GoogleSheetsSync", "Sheets API v4 GET failed for $tabName: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in fetchTabRows Sheets API v4 for $tabName: ${e.localizedMessage}", e)
        }

        // Strategy B: Fallback to CSV public export
        try {
            val url = "https://docs.google.com/spreadsheets/d/$spreadsheetId/export?format=csv&sheet=${URLEncoder.encode(tabName, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val csvText = response.body?.string() ?: ""
                    return parseCsvRows(csvText)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in fetchTabRows Strategy B for $tabName: ${e.localizedMessage}", e)
        }

        return resultRows
    }

    private fun parseCsvRows(csvText: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val lines = csvText.split("\n")
        for (line in lines) {
            if (line.isBlank()) continue
            val tokens = mutableListOf<String>()
            var inQuotes = false
            var sb = java.lang.StringBuilder()
            for (c in line) {
                if (c == '"') {
                    inQuotes = !inQuotes
                } else if (c == ',' && !inQuotes) {
                    tokens.add(sb.toString().trim())
                    sb = java.lang.StringBuilder()
                } else {
                    sb.append(c)
                }
            }
            tokens.add(sb.toString().trim())

            val cleanedTokens = tokens.map {
                var t = it
                if (t.startsWith("\"") && t.endsWith("\"")) {
                    t = t.substring(1, t.length - 1)
                }
                t.replace("\"\"", "\"")
            }
            rows.add(cleanedTokens)
        }
        return rows
    }

    /**
     * Appends a customer row to the Google Sheet in real-time.
     */
    suspend fun appendCustomer(spreadsheetLinkOrId: String, lenderId: String, customer: Customer) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            customer.id.toString(),
            customer.name,
            customer.address,
            customer.phone,
            customer.nic,
            customer.email ?: "",
            customer.photoUri,
            customer.nicPhotoUri
        )

        appendRowToSheet(spreadsheetId, "Customers", rowValues)
    }

    /**
     * Appends a loan row to the Google Sheet in real-time.
     */
    suspend fun appendLoan(spreadsheetLinkOrId: String, lenderId: String, loan: Loan) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            loan.id.toString(),
            (loan.customerId ?: "").toString(),
            loan.borrowerName,
            loan.borrowerPhone,
            loan.principalAmount.toString(),
            loan.interestRate.toString(),
            loan.interestPeriod,
            loan.startDate.toString(),
            loan.notes,
            loan.isSettled.toString()
        )

        appendRowToSheet(spreadsheetId, "Loans", rowValues)
    }

    /**
     * Appends a payment row to the Google Sheet in real-time.
     */
    suspend fun appendPayment(spreadsheetLinkOrId: String, lenderId: String, payment: Payment) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            payment.id.toString(),
            payment.loanId.toString(),
            payment.amount.toString(),
            payment.paymentDate.toString(),
            payment.type,
            payment.notes
        )

        appendRowToSheet(spreadsheetId, "Transactions", rowValues)
    }

    private fun ensureTabsExist(spreadsheetId: String) {
        try {
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId?key=$ANDROID_API_KEY"
            val request = Request.Builder()
                .url(url)
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    android.util.Log.e("GoogleSheetsSync", "Failed to inspect spreadsheet metadata: ${response.code} ${response.message}")
                    return
                }
                val bodyStr = response.body?.string() ?: ""
                val json = JSONObject(bodyStr)
                val sheets = json.optJSONArray("sheets") ?: return
                val existingTabs = mutableSetOf<String>()
                for (i in 0 until sheets.length()) {
                    val sheetObj = sheets.optJSONObject(i)
                    val props = sheetObj?.optJSONObject("properties")
                    val title = props?.optString("title")
                    if (title != null) {
                        existingTabs.add(title)
                    }
                }

                val requiredTabs = listOf("Customers", "Loans", "Transactions")
                val missingTabs = requiredTabs.filter { !existingTabs.contains(it) }

                if (missingTabs.isNotEmpty()) {
                    createTabs(spreadsheetId, missingTabs)
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in ensureTabsExist: ${e.localizedMessage}", e)
        }
    }

    private fun createTabs(spreadsheetId: String, tabsToCreate: List<String>) {
        try {
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId:batchUpdate?key=$ANDROID_API_KEY"
            val requestsArray = JSONArray()
            tabsToCreate.forEach { tabName ->
                val addSheetReq = JSONObject().apply {
                    put("addSheet", JSONObject().apply {
                        put("properties", JSONObject().apply {
                            put("title", tabName)
                        })
                    })
                }
                requestsArray.put(addSheetReq)
            }

            val jsonPayload = JSONObject().apply {
                put("requests", requestsArray)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    android.util.Log.d("GoogleSheetsSync", "Successfully created tabs: $tabsToCreate")
                    // Initialize headers for newly created tabs
                    tabsToCreate.forEach { tabName ->
                        if (tabName == "Customers") {
                            appendRowToSheetDirect(spreadsheetId, "Customers", listOf("Lender ID", "Customer ID", "Name", "Address", "Phone", "NIC", "Email", "Photo URI", "NIC Photo URI"))
                        } else if (tabName == "Loans") {
                            appendRowToSheetDirect(spreadsheetId, "Loans", listOf("Lender ID", "Loan ID", "Customer ID", "Borrower Name", "Borrower Phone", "Principal Amount", "Interest Rate", "Interest Period", "Start Date", "Notes", "Is Settled"))
                        } else if (tabName == "Transactions") {
                            appendRowToSheetDirect(spreadsheetId, "Transactions", listOf("Lender ID", "Transaction ID", "Loan ID", "Amount", "Date", "Type", "Notes"))
                        }
                    }
                } else {
                    android.util.Log.e("GoogleSheetsSync", "Failed to create missing tabs: ${response.code} ${response.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Exception in createTabs: ${e.localizedMessage}", e)
        }
    }

    private fun appendRowToSheetDirect(spreadsheetId: String, tabName: String, values: List<String>) {
        try {
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED&key=$ANDROID_API_KEY"
            val jsonPayload = JSONObject().apply {
                put("range", tabName)
                put("majorDimension", "ROWS")
                put("values", JSONArray().apply {
                    put(JSONArray().apply {
                        values.forEach { put(it) }
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                android.util.Log.d("GoogleSheetsSync", "Append to $tabName response: ${response.code}")
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to append row to $tabName: ${e.localizedMessage}", e)
        }
    }

    private fun appendRowToSheet(spreadsheetId: String, tabName: String, values: List<String>) {
        try {
            // First make sure the tabs exist before appending
            ensureTabsExist(spreadsheetId)

            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED&key=$ANDROID_API_KEY"
            val jsonPayload = JSONObject().apply {
                put("range", tabName)
                put("majorDimension", "ROWS")
                put("values", JSONArray().apply {
                    put(JSONArray().apply {
                        values.forEach { put(it) }
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("X-Android-Package", PACKAGE_NAME)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                android.util.Log.d("GoogleSheetsSync", "Append to $tabName response: ${response.code} ${response.message}")
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to append to Google Sheet $tabName: ${e.localizedMessage}", e)
        }
    }
}
