package com.moneymaster.cleanapp.utils

import android.content.Context
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URLDecoder

object GoogleSheetsSyncManager {

    private val client = OkHttpClient()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    fun extractSpreadsheetId(input: String): String {
        if (input.isBlank()) return ""
        val trimmed = input.trim()
        return try {
            val decoded = URLDecoder.decode(trimmed, "UTF-8")
            val dIndex = decoded.indexOf("/d/")
            if (dIndex != -1) {
                val afterD = decoded.substring(dIndex + 3)
                val slashIndex = afterD.indexOf("/")
                if (slashIndex != -1) {
                    afterD.substring(0, slashIndex)
                } else {
                    val qIndex = afterD.indexOf("?")
                    if (qIndex != -1) {
                        afterD.substring(0, qIndex)
                    } else {
                        afterD
                    }
                }
            } else if (decoded.contains("spreadsheets/d/")) {
                val regex = "spreadsheets/d/([a-zA-Z0-9-_]+)".toRegex()
                val match = regex.find(decoded)
                match?.groupValues?.get(1) ?: trimmed
            } else {
                val regex = "/d/([a-zA-Z0-9-_]+)".toRegex()
                val match = regex.find(decoded)
                if (match != null) {
                    match.groupValues[1]
                } else if (!trimmed.contains("/") && trimmed.length > 20) {
                    trimmed
                } else {
                    trimmed
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to extract spreadsheet ID: ${e.localizedMessage}")
            trimmed
        }
    }

    private fun getWebAppUrl(context: Context): String {
        val prefs = context.getSharedPreferences("money_master_owner_prefs", Context.MODE_PRIVATE)
        return prefs.getString("web_app_url", "") ?: ""
    }

    private fun getSpreadsheetId(context: Context): String {
        val prefs = context.getSharedPreferences("money_master_owner_prefs", Context.MODE_PRIVATE)
        val linkOrId = prefs.getString("spreadsheet_link", "") ?: ""
        return extractSpreadsheetId(linkOrId)
    }

    private fun getLenderId(context: Context): String {
        val prefs = context.getSharedPreferences("money_master_owner_prefs", Context.MODE_PRIVATE)
        return prefs.getString("lender_id", "") ?: ""
    }

    private suspend fun sendWebAppPost(context: Context, payload: JSONObject): String? = withContext(Dispatchers.IO) {
        val webAppUrl = getWebAppUrl(context)
        if (webAppUrl.isBlank()) {
            android.util.Log.e("GoogleSheetsSync", "Web App URL is blank!")
            return@withContext null
        }
        var currentUrl = webAppUrl
        var attempts = 0
        val maxRedirects = 5
        var responseString: String? = null

        while (attempts < maxRedirects) {
            val request = Request.Builder()
                .url(currentUrl)
                .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            try {
                // Disable automatic redirect following in OkHttpClient for this specific call to handle 302/307 manually
                val redirectFollowClient = client.newBuilder()
                    .followRedirects(false)
                    .followSslRedirects(false)
                    .build()

                redirectFollowClient.newCall(request).execute().use { response ->
                    val code = response.code
                    if (code == 302 || code == 301 || code == 303 || code == 307 || code == 308) {
                        val location = response.header("Location")
                        if (location != null) {
                            currentUrl = location
                            attempts++
                            android.util.Log.d("GoogleSheetsSync", "Following redirect to: $currentUrl")
                            return@use // continue loop
                        }
                    }
                    
                    if (response.isSuccessful) {
                        responseString = response.body?.string()
                        return@withContext responseString
                    } else {
                        android.util.Log.e("GoogleSheetsSync", "Web App POST failed with code $code: ${response.message}")
                        responseString = response.body?.string()
                        return@withContext responseString
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("GoogleSheetsSync", "Exception in sendWebAppPost: ${e.localizedMessage}", e)
                return@withContext null
            }
        }
        responseString
    }

    suspend fun appendCustomer(context: Context, spreadsheetLinkOrId: String, lenderId: String, customer: Customer): Boolean = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        val dataArray = JSONArray().apply {
            put(lenderId)
            put(customer.id.toString())
            put(customer.name)
            put(customer.address)
            put(customer.phone)
            put(customer.nic)
            put(customer.email ?: "")
            put(customer.photoUri)
            put(customer.nicPhotoUri)
        }
        val payload = JSONObject().apply {
            put("action", "sync_row")
            put("spreadsheetId", spreadsheetId)
            put("table", "Customers")
            put("data", dataArray)
        }
        val response = sendWebAppPost(context, payload)
        if (response != null) {
            val json = JSONObject(response)
            json.optBoolean("success", false)
        } else {
            false
        }
    }

    suspend fun appendLoan(context: Context, spreadsheetLinkOrId: String, lenderId: String, loan: Loan): Boolean = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        val dataArray = JSONArray().apply {
            put(lenderId)
            put(loan.id.toString())
            put((loan.customerId ?: "").toString())
            put(loan.borrowerName)
            put(loan.borrowerPhone)
            put(loan.principalAmount.toString())
            put(loan.interestRate.toString())
            put(loan.interestPeriod)
            put(loan.startDate.toString())
            put(loan.notes)
            put(loan.isSettled.toString())
        }
        val payload = JSONObject().apply {
            put("action", "sync_row")
            put("spreadsheetId", spreadsheetId)
            put("table", "Loans")
            put("data", dataArray)
        }
        val response = sendWebAppPost(context, payload)
        if (response != null) {
            val json = JSONObject(response)
            json.optBoolean("success", false)
        } else {
            false
        }
    }

    suspend fun appendPayment(context: Context, spreadsheetLinkOrId: String, lenderId: String, payment: Payment): Boolean = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        val dataArray = JSONArray().apply {
            put(lenderId)
            put(payment.id.toString())
            put(payment.loanId.toString())
            put(payment.amount.toString())
            put(payment.paymentDate.toString())
            put(payment.type)
            put(payment.notes)
        }
        val payload = JSONObject().apply {
            put("action", "sync_row")
            put("spreadsheetId", spreadsheetId)
            put("table", "Transactions")
            put("data", dataArray)
        }
        val response = sendWebAppPost(context, payload)
        if (response != null) {
            val json = JSONObject(response)
            json.optBoolean("success", false)
        } else {
            false
        }
    }

    suspend fun restoreFromCloud(
        context: Context,
        spreadsheetLinkOrId: String,
        lenderId: String
    ): Triple<List<Customer>, List<Loan>, List<Payment>> = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        val customers = mutableListOf<Customer>()
        val loans = mutableListOf<Loan>()
        val payments = mutableListOf<Payment>()

        if (spreadsheetId.isBlank()) {
            return@withContext Triple(customers, loans, payments)
        }

        try {
            val payload = JSONObject().apply {
                put("action", "get_sheets_data")
                put("spreadsheetId", spreadsheetId)
            }
            val responseText = sendWebAppPost(context, payload)
            if (responseText != null) {
                val jsonResponse = JSONObject(responseText)
                if (jsonResponse.optBoolean("success", false)) {
                    // Parse Customers
                    val customersArray = jsonResponse.optJSONArray("Customers")
                    if (customersArray != null) {
                        for (i in 0 until customersArray.length()) {
                            val rowArray = customersArray.optJSONArray(i)
                            if (rowArray != null && rowArray.length() >= 3) {
                                val rowLenderId = rowArray.optString(0)
                                if (rowLenderId.equals(lenderId, ignoreCase = true)) {
                                    val id = rowArray.optString(1).toIntOrNull() ?: 0
                                    val name = rowArray.optString(2)
                                    val address = rowArray.optString(3, "")
                                    val phone = rowArray.optString(4, "")
                                    val nic = rowArray.optString(5, "")
                                    val email = rowArray.optString(6, "").ifBlank { null }
                                    val photo = rowArray.optString(7, "")
                                    val nicPhoto = rowArray.optString(8, "")
                                    if (name.isNotBlank()) {
                                        customers.add(Customer(id = id, name = name, address = address, phone = phone, nic = nic, photoUri = photo, nicPhotoUri = nicPhoto, email = email))
                                    }
                                }
                            }
                        }
                    }

                    // Parse Loans
                    val loansArray = jsonResponse.optJSONArray("Loans")
                    if (loansArray != null) {
                        for (i in 0 until loansArray.length()) {
                            val rowArray = loansArray.optJSONArray(i)
                            if (rowArray != null && rowArray.length() >= 4) {
                                val rowLenderId = rowArray.optString(0)
                                if (rowLenderId.equals(lenderId, ignoreCase = true)) {
                                    val id = rowArray.optString(1).toIntOrNull() ?: 0
                                    val customerId = rowArray.optString(2).toIntOrNull()
                                    val borrowerName = rowArray.optString(3)
                                    val borrowerPhone = rowArray.optString(4, "")
                                    val principal = rowArray.optString(5).toDoubleOrNull() ?: 0.0
                                    val rate = rowArray.optString(6).toDoubleOrNull() ?: 0.0
                                    val period = rowArray.optString(7, "Monthly")
                                    val startDate = rowArray.optString(8).toLongOrNull() ?: System.currentTimeMillis()
                                    val notes = rowArray.optString(9, "")
                                    val isSettled = rowArray.optString(10).toBoolean()
                                    if (borrowerName.isNotBlank()) {
                                        loans.add(Loan(id = id, customerId = customerId, borrowerName = borrowerName, borrowerPhone = borrowerPhone, principalAmount = principal, interestRate = rate, interestPeriod = period, startDate = startDate, notes = notes, isSettled = isSettled))
                                    }
                                }
                            }
                        }
                    }

                    // Parse Payments
                    val transactionsArray = jsonResponse.optJSONArray("Transactions")
                    if (transactionsArray != null) {
                        for (i in 0 until transactionsArray.length()) {
                            val rowArray = transactionsArray.optJSONArray(i)
                            if (rowArray != null && rowArray.length() >= 4) {
                                val rowLenderId = rowArray.optString(0)
                                if (rowLenderId.equals(lenderId, ignoreCase = true)) {
                                    val id = rowArray.optString(1).toIntOrNull() ?: 0
                                    val loanId = rowArray.optString(2).toIntOrNull() ?: 0
                                    val amount = rowArray.optString(3).toDoubleOrNull() ?: 0.0
                                    val paymentDate = rowArray.optString(4).toLongOrNull() ?: System.currentTimeMillis()
                                    val type = rowArray.optString(5, "Principal")
                                    val notes = rowArray.optString(6, "")
                                    payments.add(Payment(id = id, loanId = loanId, amount = amount, paymentDate = paymentDate, type = type, notes = notes))
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleSheetsSync", "Failed to restore from cloud: ${e.localizedMessage}", e)
        }

        Triple(customers, loans, payments)
    }

    suspend fun backupDatabaseToDrive(context: Context): Boolean = withContext(Dispatchers.IO) {
        val zipFile = zipDatabaseFiles(context) ?: return@withContext false
        try {
            val fileBytes = zipFile.readBytes()
            val base64Data = android.util.Base64.encodeToString(fileBytes, android.util.Base64.NO_WRAP)
            
            val payload = JSONObject().apply {
                put("action", "upload_backup")
                put("folderName", "MoneyMaster_Backup")
                put("fileName", "db_backup.zip")
                put("fileData", base64Data)
            }
            
            val responseText = sendWebAppPost(context, payload)
            if (responseText != null) {
                val jsonResponse = JSONObject(responseText)
                jsonResponse.optBoolean("success", false)
            } else {
                false
            }
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Failed to backup database to Web App: ${e.localizedMessage}", e)
            false
        } finally {
            if (zipFile.exists()) {
                zipFile.delete()
            }
        }
    }

    suspend fun restoreDatabaseFromDrive(context: Context): Boolean = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("action", "get_backup")
                put("folderName", "MoneyMaster_Backup")
            }
            
            val responseText = sendWebAppPost(context, payload) ?: return@withContext false
            val jsonResponse = JSONObject(responseText)
            if (!jsonResponse.optBoolean("success", false)) {
                android.util.Log.e("GoogleDriveBackup", "Restore request reported failure in JSON")
                return@withContext false
            }
            
            val base64Data = jsonResponse.optString("fileData").ifBlank { jsonResponse.optString("data") }
            if (base64Data.isNullOrBlank()) {
                android.util.Log.e("GoogleDriveBackup", "Restore payload contains no fileData or data")
                return@withContext false
            }
            
            val fileBytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT)
            val tempZipFile = File(context.cacheDir, "money_master_restore.zip")
            if (tempZipFile.exists()) {
                tempZipFile.delete()
            }
            
            tempZipFile.writeBytes(fileBytes)
            val success = unzipDatabaseFiles(context, tempZipFile)
            if (tempZipFile.exists()) {
                tempZipFile.delete()
            }
            success
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Failed to restore database from Web App: ${e.localizedMessage}", e)
            false
        }
    }

    private fun zipDatabaseFiles(context: Context): File? {
        val dbFile = context.getDatabasePath("money_master_database")
        val shmFile = context.getDatabasePath("money_master_database-shm")
        val walFile = context.getDatabasePath("money_master_database-wal")

        val filesToZip = listOf(dbFile, shmFile, walFile).filter { it.exists() }
        if (filesToZip.isEmpty()) return null

        val zipFile = File(context.cacheDir, "money_master_backup.zip")
        if (zipFile.exists()) {
            zipFile.delete()
        }

        try {
            java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(FileOutputStream(zipFile))).use { out ->
                val data = ByteArray(1024)
                for (file in filesToZip) {
                    FileInputStream(file).use { fi ->
                        java.io.BufferedInputStream(fi).use { origin ->
                            val entry = java.util.zip.ZipEntry(file.name)
                            out.putNextEntry(entry)
                            var count: Int
                            while (origin.read(data, 0, 1024).also { count = it } != -1) {
                                out.write(data, 0, count)
                            }
                        }
                    }
                }
            }
            return zipFile
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Failed to zip database files: ${e.localizedMessage}", e)
            return null
        }
    }

    private fun unzipDatabaseFiles(context: Context, zipFile: File): Boolean {
        val dbDir = context.getDatabasePath("money_master_database").parentFile ?: return false
        if (!dbDir.exists()) {
            dbDir.mkdirs()
        }
        try {
            java.util.zip.ZipInputStream(java.io.BufferedInputStream(zipFile.inputStream())).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val targetFile = File(dbDir, entry.name)
                    if (targetFile.exists()) {
                        targetFile.delete()
                    }
                    FileOutputStream(targetFile).use { fos ->
                        val buffer = ByteArray(1024)
                        var count: Int
                        while (zis.read(buffer).also { count = it } != -1) {
                            fos.write(buffer, 0, count)
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            return true
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveBackup", "Failed to unzip database files: ${e.localizedMessage}", e)
            return false
        }
    }
}
