package com.moneymaster.cleanapp.utils

import android.content.Context
import com.moneymaster.cleanapp.data.Customer
import com.moneymaster.cleanapp.data.Loan
import com.moneymaster.cleanapp.data.Payment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder

object GoogleSheetsSyncManager {

    private val client = OkHttpClient()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    fun extractSpreadsheetId(input: String): String {
        if (input.isBlank()) return ""
        return try {
            val decoded = URLDecoder.decode(input, "UTF-8")
            val regex = "docs\\.google\\.com/spreadsheets/d/([^/]+)".toRegex()
            val match = regex.find(decoded)
            match?.groupValues?.get(1) ?: input
        } catch (e: Exception) {
            input
        }
    }

    /**
     * Performs an asynchronous restore of data matching the Lender ID from Google Sheet tabs.
     */
    suspend fun restoreFromCloud(
        spreadsheetLinkOrId: String,
        lenderId: String
    ): Triple<List<Customer>, List<Loan>, List<Payment>> = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) {
            throw IllegalArgumentException("Invalid Spreadsheet Link or ID")
        }

        val customers = mutableListOf<Customer>()
        val loans = mutableListOf<Loan>()
        val payments = mutableListOf<Payment>()

        // Fetch each tab
        val customerRows = fetchTabRows(spreadsheetId, "Customers")
        val loanRows = fetchTabRows(spreadsheetId, "Loans")
        val paymentRows = fetchTabRows(spreadsheetId, "Transactions")

        // Parse Customers
        customerRows.forEach { row ->
            if (row.size >= 6 && row[0].equals(lenderId, ignoreCase = true)) {
                val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                val name = row.getOrNull(2) ?: ""
                val address = row.getOrNull(3) ?: ""
                val phone = row.getOrNull(4) ?: ""
                val nic = row.getOrNull(5) ?: ""
                val email = row.getOrNull(6)?.ifBlank { null }
                val photo = row.getOrNull(7) ?: ""
                val nicPhoto = row.getOrNull(8) ?: ""
                if (name.isNotBlank()) {
                    customers.add(Customer(id = id, name = name, address = address, phone = phone, nic = nic, photoUri = photo, nicPhotoUri = nicPhoto, email = email))
                }
            }
        }

        // Parse Loans
        loanRows.forEach { row ->
            if (row.size >= 8 && row[0].equals(lenderId, ignoreCase = true)) {
                val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                val customerId = row.getOrNull(2)?.toIntOrNull()
                val borrowerName = row.getOrNull(3) ?: ""
                val borrowerPhone = row.getOrNull(4) ?: ""
                val principal = row.getOrNull(5)?.toDoubleOrNull() ?: 0.0
                val rate = row.getOrNull(6)?.toDoubleOrNull() ?: 0.0
                val period = row.getOrNull(7) ?: "Monthly"
                val startDate = row.getOrNull(8)?.toLongOrNull() ?: System.currentTimeMillis()
                val notes = row.getOrNull(9) ?: ""
                val isSettled = row.getOrNull(10)?.toBoolean() ?: false
                if (borrowerName.isNotBlank()) {
                    loans.add(Loan(id = id, customerId = customerId, borrowerName = borrowerName, borrowerPhone = borrowerPhone, principalAmount = principal, interestRate = rate, interestPeriod = period, startDate = startDate, notes = notes, isSettled = isSettled))
                }
            }
        }

        // Parse Payments
        paymentRows.forEach { row ->
            if (row.size >= 6 && row[0].equals(lenderId, ignoreCase = true)) {
                val id = row.getOrNull(1)?.toIntOrNull() ?: 0
                val loanId = row.getOrNull(2)?.toIntOrNull() ?: 0
                val amount = row.getOrNull(3)?.toDoubleOrNull() ?: 0.0
                val paymentDate = row.getOrNull(4)?.toLongOrNull() ?: System.currentTimeMillis()
                val type = row.getOrNull(5) ?: "Principal"
                val notes = row.getOrNull(6) ?: ""
                payments.add(Payment(id = id, loanId = loanId, amount = amount, paymentDate = paymentDate, type = type, notes = notes))
            }
        }

        Triple(customers, loans, payments)
    }

    private fun fetchTabRows(spreadsheetId: String, tabName: String): List<List<String>> {
        val resultRows = mutableListOf<List<String>>()
        
        // Strategy A: Try Sheets API v4 Public Read (if sheet is shared with "Anyone with the link can view")
        // No OAuth or API Key is needed to export a public spreadsheet as CSV!
        try {
            val url = "https://docs.google.com/spreadsheets/d/$spreadsheetId/gviz/tq?tqx=out:csv&sheet=${URLEncoder.encode(tabName, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val csvText = response.body?.string() ?: ""
                    return parseCsvRows(csvText)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Strategy B: Fallback to direct download
        try {
            val url = "https://docs.google.com/spreadsheets/d/$spreadsheetId/export?format=csv&sheet=${URLEncoder.encode(tabName, "UTF-8")}"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val csvText = response.body?.string() ?: ""
                    return parseCsvRows(csvText)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return resultRows
    }

    private fun parseCsvRows(csvText: String): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        val lines = csvText.split("\n")
        for (line in lines) {
            if (line.isBlank()) continue
            val tokens = mutableListOf<String>()
            var inQuotes = false
            var sb = java.lang.StringBuilder()
            for (c in line) {
                if (c == '"') {
                    inQuotes = !inQuotes
                } else if (c == ',' && !inQuotes) {
                    tokens.add(sb.toString().trim())
                    sb = java.lang.StringBuilder()
                } else {
                    sb.append(c)
                }
            }
            tokens.add(sb.toString().trim())
            
            // Post-process tokens to remove leading/trailing quotes
            val cleanedTokens = tokens.map { 
                var t = it
                if (t.startsWith("\"") && t.endsWith("\"")) {
                    t = t.substring(1, t.length - 1)
                }
                t.replace("\"\"", "\"")
            }
            rows.add(cleanedTokens)
        }
        return rows
    }

    /**
     * Appends a customer row to the Google Sheet in real-time.
     */
    suspend fun appendCustomer(spreadsheetLinkOrId: String, lenderId: String, customer: Customer) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            customer.id.toString(),
            customer.name,
            customer.address,
            customer.phone,
            customer.nic,
            customer.email ?: "",
            customer.photoUri,
            customer.nicPhotoUri
        )

        appendRowToSheet(spreadsheetId, "Customers", rowValues)
    }

    /**
     * Appends a loan row to the Google Sheet in real-time.
     */
    suspend fun appendLoan(spreadsheetLinkOrId: String, lenderId: String, loan: Loan) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            loan.id.toString(),
            (loan.customerId ?: "").toString(),
            loan.borrowerName,
            loan.borrowerPhone,
            loan.principalAmount.toString(),
            loan.interestRate.toString(),
            loan.interestPeriod,
            loan.startDate.toString(),
            loan.notes,
            loan.isSettled.toString()
        )

        appendRowToSheet(spreadsheetId, "Loans", rowValues)
    }

    /**
     * Appends a payment row to the Google Sheet in real-time.
     */
    suspend fun appendPayment(spreadsheetLinkOrId: String, lenderId: String, payment: Payment) = withContext(Dispatchers.IO) {
        val spreadsheetId = extractSpreadsheetId(spreadsheetLinkOrId)
        if (spreadsheetId.isBlank()) return@withContext

        val rowValues = listOf(
            lenderId,
            payment.id.toString(),
            payment.loanId.toString(),
            payment.amount.toString(),
            payment.paymentDate.toString(),
            payment.type,
            payment.notes
        )

        appendRowToSheet(spreadsheetId, "Transactions", rowValues)
    }

    private fun appendRowToSheet(spreadsheetId: String, tabName: String, values: List<String>) {
        try {
            // Sheets API v4 Append endpoint format
            val url = "https://sheets.googleapis.com/v4/spreadsheets/$spreadsheetId/values/${URLEncoder.encode(tabName, "UTF-8")}:append?valueInputOption=USER_ENTERED"
            
            // Build the Sheets API append JSON payload
            val jsonPayload = JSONObject().apply {
                put("range", tabName)
                put("majorDimension", "ROWS")
                put("values", JSONArray().apply {
                    put(JSONArray().apply {
                        values.forEach { put(it) }
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonPayload.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            // If the user's spreadsheet is set to have an Apps Script or custom webhook integration, we also try sending a POST to backup!
            // But we can run this asynchronously and catch any 401/403 OAuth errors gracefully, logging to console
            client.newCall(request).execute().use { response ->
                android.util.Log.d("SheetsSync", "Append to $tabName response: ${response.code} ${response.message}")
            }
        } catch (e: Exception) {
            android.util.Log.e("SheetsSync", "Failed to append to Google Sheet $tabName: ${e.localizedMessage}")
        }
    }
}
