package com.moneymaster.cleanapp.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

// Model for managing scanned document metadata on the Pro Dashboard
data class ScannedFile(
    val file: File,
    val name: String,
    val dateString: String,
    val sizeString: String,
    val isPdf: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScannerView(
    requirePdf: Boolean = false,
    onImageCaptured: (Uri) -> Unit = {},
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Standalone States
    var viewMode by remember { mutableStateOf("DASHBOARD") } // "DASHBOARD", "EDITOR", "PROCESSING"
    var scannedPages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var scannedPdfUri by remember { mutableStateOf<Uri?>(null) }
    
    // Editor State variables
    var selectedFilter by remember { mutableStateOf("MAGIC_COLOR") } // "ORIGINAL", "MAGIC_COLOR", "HIGH_CONTRAST", "GRAYSCALE"
    var applyWatermark by remember { mutableStateOf(true) }
    var customFileName by remember { mutableStateOf("") }
    var currentPageIndex by remember { mutableStateOf(0) }
    var processedPreviewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isFilterProcessing by remember { mutableStateOf(false) }

    // Dashboard Saved Files state
    var savedFilesList by remember { mutableStateOf<List<ScannedFile>>(emptyList()) }
    var fileSearchQuery by remember { mutableStateOf("") }

    // User preferences
    var prefContinuousScan by remember { mutableStateOf(true) }
    var prefDefaultFilter by remember { mutableStateOf("MAGIC_COLOR") }
    var prefApplyWatermarkDefault by remember { mutableStateOf(true) }

    // Hardcoded Full Access parameter for CamScanner Pro
    val accessStatus = "FULL_ACCESS"

    // Load saved scans from folder
    val refreshSavedFiles = {
        savedFilesList = getScannedFiles(context)
    }

    LaunchedEffect(Unit) {
        refreshSavedFiles()
    }

    // Load & Process live filtered bitmap preview for current page
    LaunchedEffect(scannedPages, currentPageIndex, selectedFilter, applyWatermark) {
        if (scannedPages.isNotEmpty() && currentPageIndex in scannedPages.indices) {
            isFilterProcessing = true
            coroutineScope.launch(Dispatchers.Default) {
                val processed = applyFilters(
                    context = context,
                    sourceUri = scannedPages[currentPageIndex],
                    filterType = selectedFilter,
                    applyWatermark = applyWatermark
                )
                withContext(Dispatchers.Main) {
                    processedPreviewBitmap = processed
                    isFilterProcessing = false
                }
            }
        }
    }

    // ML Kit Scanner Launcher Setup
    val scannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            if (scanResult != null) {
                val pages = scanResult.pages
                val pdf = scanResult.pdf

                // If called from Loan workflow, bypass and return immediately
                if (requirePdf) {
                    if (pdf != null) {
                        onImageCaptured(pdf.uri)
                        onClose()
                    } else if (pages != null && pages.isNotEmpty()) {
                        onImageCaptured(pages[0].imageUri)
                        onClose()
                    } else {
                        Toast.makeText(context, "No scan result found", Toast.LENGTH_SHORT).show()
                    }
                    return@rememberLauncherForActivityResult
                }

                // Standalone flow: Store results and open filter editor screen
                if (pages != null && pages.isNotEmpty()) {
                    scannedPages = pages.map { it.imageUri }
                    scannedPdfUri = pdf?.uri
                    currentPageIndex = 0
                    selectedFilter = prefDefaultFilter
                    applyWatermark = prefApplyWatermarkDefault
                    
                    val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    customFileName = "Scan_${sdf.format(Date())}"
                    viewMode = "EDITOR"
                } else {
                    Toast.makeText(context, "No pages scanned", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Failed to retrieve scan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Trigger GMS ML Kit Document Scanner
    val triggerScan = {
        val activity = getComponentActivity(context)
        if (activity == null) {
            Toast.makeText(context, "Activity context not found", Toast.LENGTH_SHORT).show()
        } else {
            val builder = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(if (prefContinuousScan) 100 else 1)
                .setResultFormats(
                    GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                    GmsDocumentScannerOptions.RESULT_FORMAT_PDF
                )
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            
            val options = builder.build()
            val scanner = GmsDocumentScanning.getClient(options)
            scanner.getStartScanIntent(activity)
                .addOnSuccessListener { intentSender ->
                    val intentSenderRequest = IntentSenderRequest.Builder(intentSender).build()
                    scannerLauncher.launch(intentSenderRequest)
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Scanner Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
        }
    }

    // Handle Document Export process
    val exportDocument = {
        viewMode = "PROCESSING"
        coroutineScope.launch(Dispatchers.Default) {
            try {
                // Apply enhancements to all scanned pages
                val processedBitmaps = mutableListOf<Bitmap>()
                for (pageUri in scannedPages) {
                    val bmp = applyFilters(context, pageUri, selectedFilter, applyWatermark)
                    if (bmp != null) {
                        processedBitmaps.add(bmp)
                    }
                }

                if (processedBitmaps.isNotEmpty()) {
                    val baseName = if (customFileName.isNotBlank()) customFileName else "Scan_${System.currentTimeMillis()}"
                    val savedFiles = saveScannedDocument(context, processedBitmaps, baseName)
                    
                    withContext(Dispatchers.Main) {
                        viewMode = "DASHBOARD"
                        refreshSavedFiles()
                        if (savedFiles != null) {
                            Toast.makeText(context, "Document successfully exported to Documents/CamScannerPro!", Toast.LENGTH_LONG).show()
                            // Open success preview dialog
                            openFile(context, savedFiles.first, "application/pdf")
                        } else {
                            Toast.makeText(context, "Error saving document files", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        viewMode = "EDITOR"
                        Toast.makeText(context, "Failed to process images", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    viewMode = "EDITOR"
                    Toast.makeText(context, "Export failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // Render Views based on active mode
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F14))
            .testTag("camscanner_pro_container")
    ) {
        when (viewMode) {
            "DASHBOARD" -> {
                // Standalone Premium Pro Dashboard UI
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Header Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF1E1E26), Color(0xFF0F0F14))
                                )
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFFFB300), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DocumentScanner,
                                        contentDescription = "CamScanner Pro",
                                        tint = Color.Black,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "CamScanner",
                                            color = Color.White,
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Pro",
                                            color = Color(0xFFFFB300),
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.WorkspacePremium,
                                            contentDescription = "Premium Badge",
                                            tint = Color(0xFFFFB300),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = "PREMIUM ACTIVE ($accessStatus)",
                                            color = Color(0xFFFFB300),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            IconButton(
                                onClick = onClose,
                                modifier = Modifier.background(Color(0xFF262633), CircleShape)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close Scanner", tint = Color.White)
                            }
                        }
                    }

                    // Dashboard stats & configuration card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "ස්කෑනර් සැකසුම් (Scanner Settings)",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // Continuous scan setting
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.LibraryBooks, contentDescription = "Batch Mode", tint = Color.LightGray)
                                    Column {
                                        Text("බහු පිටු මාදිලිය (Batch Continuous Scan)", color = Color.White, fontSize = 13.sp)
                                        Text("Scan up to 100 pages continuously", color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                                Switch(
                                    checked = prefContinuousScan,
                                    onCheckedChange = { prefContinuousScan = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFFFB300)
                                    )
                                )
                            }

                            Divider(color = Color(0xFF2E2E38))

                            // Smart watermark setting
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = "Watermark", tint = Color.LightGray)
                                    Column {
                                        Text("ස්මාර්ට් වෝටර්මාර්ක් (Smart Watermark)", color = Color.White, fontSize = 13.sp)
                                        Text("Overlay subtle signature", color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                                Switch(
                                    checked = prefApplyWatermarkDefault,
                                    onCheckedChange = { prefApplyWatermarkDefault = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFFFB300)
                                    )
                                )
                            }

                            Divider(color = Color(0xFF2E2E38))

                            // Default filter selection
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("පෙරනිමි පිරිපහදුව (Default Scan Enhancer)", color = Color.LightGray, fontSize = 12.sp)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf(
                                        "MAGIC_COLOR" to "Magic Color Pro",
                                        "HIGH_CONTRAST" to "High-Contrast",
                                        "ORIGINAL" to "Original"
                                    ).forEach { (filter, label) ->
                                        val isSelected = prefDefaultFilter == filter
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .background(
                                                    if (isSelected) Color(0xFFFFB300) else Color(0xFF2E2E38),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable { prefDefaultFilter = filter }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) Color.Black else Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Scanned files List Section
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        // Search bar
                        OutlinedTextField(
                            value = fileSearchQuery,
                            onValueChange = { fileSearchQuery = it },
                            placeholder = { Text("සෙවීම... (Search scans...)", color = Color.Gray, fontSize = 14.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFFFB300),
                                unfocusedBorderColor = Color(0xFF2E2E38),
                                focusedContainerColor = Color(0xFF1E1E26),
                                unfocusedContainerColor = Color(0xFF1E1E26)
                            ),
                            singleLine = true
                        )

                        Text(
                            text = "සුරකින ලද ලේඛන (Saved Documents)",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                        )

                        val filteredList = savedFilesList.filter {
                            it.name.contains(fileSearchQuery, ignoreCase = true)
                        }

                        if (filteredList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FolderOpen,
                                        contentDescription = "Empty",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(64.dp)
                                    )
                                    Text(
                                        text = "කිසිදු ලේඛනයක් හමු නොවීය\n(No documents scanned yet)",
                                        color = Color.Gray,
                                        fontSize = 14.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(bottom = 80.dp)
                            ) {
                                items(filteredList) { doc ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, Color(0xFF2E2E38), RoundedCornerShape(12.dp)),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(44.dp)
                                                        .background(
                                                            if (doc.isPdf) Color(0xFFE57373) else Color(0xFF64B5F6),
                                                            RoundedCornerShape(8.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = if (doc.isPdf) Icons.Default.Description else Icons.Default.Image,
                                                        contentDescription = null,
                                                        tint = Color.White
                                                    )
                                                }
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = doc.name,
                                                        color = Color.White,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Row(
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = doc.dateString, color = Color.Gray, fontSize = 11.sp)
                                                        Text(text = "•", color = Color.Gray, fontSize = 11.sp)
                                                        Text(text = doc.sizeString, color = Color(0xFFFFB300), fontSize = 11.sp)
                                                    }
                                                }
                                            }

                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // View Open
                                                IconButton(
                                                    onClick = {
                                                        val mime = if (doc.isPdf) "application/pdf" else "image/jpeg"
                                                        openFile(context, doc.file, mime)
                                                    },
                                                    modifier = Modifier.background(Color(0xFF22222E), CircleShape).size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.OpenInNew, contentDescription = "Open", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                                }

                                                // Share chooser
                                                IconButton(
                                                    onClick = {
                                                        val mime = if (doc.isPdf) "application/pdf" else "image/jpeg"
                                                        shareFile(context, doc.file, mime)
                                                    },
                                                    modifier = Modifier.background(Color(0xFF22222E), CircleShape).size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                                                }

                                                // Delete document
                                                IconButton(
                                                    onClick = {
                                                        try {
                                                            if (doc.file.delete()) {
                                                                Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show()
                                                                refreshSavedFiles()
                                                            }
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "Delete failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    modifier = Modifier.background(Color(0xFF331E24), CircleShape).size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF5350), modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Floating Scan Button Row
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Button(
                            onClick = { triggerScan() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFB300),
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(28.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("start_scan_fab"),
                            elevation = ButtonDefaults.buttonElevation(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Scan Document", tint = Color.Black)
                                Text(
                                    text = "නව ස්කෑන් එකක් ඇරඹීමට (Start New Scan)",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            "EDITOR" -> {
                // Standalone premium editor page with live custom filters
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Header Area
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { viewMode = "DASHBOARD" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                            Text("Enhancement Engine", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { exportDocument() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300), contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Save", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("සුරකින්න (Save)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // Live Filter Preview Window
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF16161E)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isFilterProcessing) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(color = Color(0xFFFFB300))
                                Text("පෙරහන් සකසමින්... (Processing Filter...)", color = Color.Gray, fontSize = 12.sp)
                            }
                        } else {
                            if (processedPreviewBitmap != null) {
                                androidx.compose.foundation.Image(
                                    bitmap = processedPreviewBitmap!!.asImageBitmap(),
                                    contentDescription = "Scan Preview",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                AsyncImage(
                                    model = scannedPages.getOrNull(currentPageIndex),
                                    contentDescription = "Fallback Raw Scan",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }

                        // Watermark preview indicator overlay
                        if (applyWatermark) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(12.dp)
                                    .background(Color(0x99000000), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Watermarked", color = Color(0xFFFFB300), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Multi page selector indicators
                        if (scannedPages.size > 1) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(12.dp)
                                    .background(Color(0x99000000), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { if (currentPageIndex > 0) currentPageIndex-- },
                                    enabled = currentPageIndex > 0,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Prev", tint = if (currentPageIndex > 0) Color.White else Color.DarkGray, modifier = Modifier.size(16.dp))
                                }
                                Text("පිටුව ${currentPageIndex + 1} / ${scannedPages.size}", color = Color.White, fontSize = 12.sp)
                                IconButton(
                                    onClick = { if (currentPageIndex < scannedPages.size - 1) currentPageIndex++ },
                                    enabled = currentPageIndex < scannedPages.size - 1,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = if (currentPageIndex < scannedPages.size - 1) Color.White else Color.DarkGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Configuration & Filtering Controls Dock
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // File naming input
                            OutlinedTextField(
                                value = customFileName,
                                onValueChange = { customFileName = it },
                                label = { Text("ලේඛන නාමය (File Name)", color = Color.Gray) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFFFFB300),
                                    unfocusedBorderColor = Color(0xFF2E2E38)
                                )
                            )

                            // Advanced Filter row
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("අත්අකුරු පැහැදිලි කරන පෙරහන් (Handwriting Enhancement Filters)", color = Color.LightGray, fontSize = 12.sp)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf(
                                        "MAGIC_COLOR" to "Magic Color Pro ✨",
                                        "HIGH_CONTRAST" to "High-Contrast 🖨️",
                                        "GRAYSCALE" to "Grayscale 📄",
                                        "ORIGINAL" to "Original"
                                    ).forEach { (filter, label) ->
                                        val isSelected = selectedFilter == filter
                                        Box(
                                            modifier = Modifier
                                                .weight(1.0f)
                                                .background(
                                                    if (isSelected) Color(0xFFFFB300) else Color(0xFF2E2E38),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable { selectedFilter = filter }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) Color.Black else Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                textAlign = TextAlign.Center,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }

                            // Watermark apply option
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Pro වෝටර්මාර්ක් යොදන්න (Apply Pro Watermark)", color = Color.White, fontSize = 13.sp)
                                Switch(
                                    checked = applyWatermark,
                                    onCheckedChange = { applyWatermark = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFFFB300)
                                    )
                                )
                            }
                        }
                    }
                }
            }

            "PROCESSING" -> {
                // High performance full page scanning export state loader
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(color = Color(0xFFFFB300), modifier = Modifier.size(64.dp))
                        Text(
                            text = "ලේඛන පිරිසැකසුම් කර අපනයනය කරමින්...\n(Enhancing & Exporting PDF / JPEGs...)",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// Custom pixel manipulation algorithm running in thread safe Coroutine background context
// Bleaches background to white, sharpens pencil/pen handwriting strokes
fun applyFilters(
    context: Context,
    sourceUri: Uri,
    filterType: String,
    applyWatermark: Boolean
): Bitmap? {
    var inputStream: InputStream? = null
    return try {
        inputStream = context.contentResolver.openInputStream(sourceUri) ?: return null
        val originalBitmap = BitmapFactory.decodeStream(inputStream) ?: return null
        val width = originalBitmap.width
        val height = originalBitmap.height
        val processedBitmap = originalBitmap.copy(Bitmap.Config.ARGB_8888, true)

        when (filterType) {
            "MAGIC_COLOR" -> {
                val pixels = IntArray(width * height)
                processedBitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                for (i in pixels.indices) {
                    val color = pixels[i]
                    val r = (color shr 16) and 0xFF
                    val g = (color shr 8) and 0xFF
                    val b = color and 0xFF

                    // High efficiency luminance formula
                    val luma = (0.299 * r + 0.587 * g + 0.114 * b).toInt()

                    // Bleach background grey shadows to pure white, keep pen details dark
                    if (luma > 165) {
                        pixels[i] = 0xFFFFFFFF.toInt()
                    } else {
                        // High Contrast amplification of ink/pencil strokes
                        val factor = 0.40
                        val nr = (r * factor).toInt().coerceIn(0, 255)
                        val ng = (g * factor).toInt().coerceIn(0, 255)
                        val nb = (b * factor).toInt().coerceIn(0, 255)
                        pixels[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                    }
                }
                processedBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            }
            "HIGH_CONTRAST" -> {
                val pixels = IntArray(width * height)
                processedBitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                for (i in pixels.indices) {
                    val color = pixels[i]
                    val r = (color shr 16) and 0xFF
                    val g = (color shr 8) and 0xFF
                    val b = color and 0xFF

                    val luma = (0.299 * r + 0.587 * g + 0.114 * b).toInt()

                    // Strict digital document threshold sharpener
                    if (luma > 135) {
                        pixels[i] = 0xFFFFFFFF.toInt()
                    } else {
                        pixels[i] = 0xFF000000.toInt()
                    }
                }
                processedBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            }
            "GRAYSCALE" -> {
                val pixels = IntArray(width * height)
                processedBitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                for (i in pixels.indices) {
                    val color = pixels[i]
                    val r = (color shr 16) and 0xFF
                    val g = (color shr 8) and 0xFF
                    val b = color and 0xFF

                    var luma = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
                    
                    // Boost grayscale contrast dynamically
                    luma = if (luma > 185) 255 else if (luma < 75) 0 else ((luma - 75) * 255 / 110).coerceIn(0, 255)

                    pixels[i] = (0xFF shl 24) or (luma shl 16) or (luma shl 8) or luma
                }
                processedBitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            }
        }

        // Apply dynamic watermark overlay at the bottom right corner
        if (applyWatermark) {
            val canvas = Canvas(processedBitmap)
            val paint = Paint().apply {
                color = android.graphics.Color.argb(130, 160, 160, 160)
                textSize = (height * 0.018f).coerceAtLeast(18f)
                isAntiAlias = true
                style = Paint.Style.FILL
                textAlign = Paint.Align.RIGHT
            }
            val marginX = width * 0.05f
            val marginY = height * 0.04f
            canvas.drawText("Scanned with CamScanner Pro", width - marginX, height - marginY, paint)
        }

        processedBitmap
    } catch (e: Exception) {
        e.printStackTrace()
        null
    } finally {
        try {
            inputStream?.close()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }
}

// Secure fallback saving pipeline targeting public directories with local files fallback
fun saveScannedDocument(
    context: Context,
    bitmaps: List<Bitmap>,
    baseFileName: String
): Pair<File, File>? {
    return try {
        // Find public Documents folder
        var outputDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
        if (!outputDir.exists()) {
            val created = outputDir.mkdirs()
            if (!created) {
                // Scoped fallback if public path fails permissions checks
                outputDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
                outputDir.mkdirs()
            }
        }

        // 1. Export JPG array (saves page 1 as Scan.jpg and subsequent pages as Scan_page_x.jpg)
        val mainJpgFile = File(outputDir, "$baseFileName.jpg")
        FileOutputStream(mainJpgFile).use { out ->
            bitmaps[0].compress(Bitmap.CompressFormat.JPEG, 95, out)
        }

        if (bitmaps.size > 1) {
            for (i in 1 until bitmaps.size) {
                val pageFile = File(outputDir, "${baseFileName}_page_${i + 1}.jpg")
                FileOutputStream(pageFile).use { out ->
                    bitmaps[i].compress(Bitmap.CompressFormat.JPEG, 95, out)
                }
            }
        }

        // 2. Export professional PDF
        val pdfFile = File(outputDir, "$baseFileName.pdf")
        val pdfDocument = PdfDocument()
        for (i in bitmaps.indices) {
            val bitmap = bitmaps[i]
            val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, i + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawBitmap(bitmap, 0f, 0f, null)
            pdfDocument.finishPage(page)
        }

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        Pair(pdfFile, mainJpgFile)
    } catch (e: Exception) {
        e.printStackTrace()
        // Fail-safe cache partition fallback to guarantee 100% crashless execution
        try {
            val outputDir = File(context.cacheDir, "CamScannerPro")
            outputDir.mkdirs()

            val mainJpgFile = File(outputDir, "$baseFileName.jpg")
            FileOutputStream(mainJpgFile).use { out ->
                bitmaps[0].compress(Bitmap.CompressFormat.JPEG, 95, out)
            }

            val pdfFile = File(outputDir, "$baseFileName.pdf")
            val pdfDocument = PdfDocument()
            for (i in bitmaps.indices) {
                val bitmap = bitmaps[i]
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, i + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
            }

            FileOutputStream(pdfFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            Pair(pdfFile, mainJpgFile)
        } catch (ex: Exception) {
            ex.printStackTrace()
            null
        }
    }
}

// Read and parse all files currently available in output directory
fun getScannedFiles(context: Context): List<ScannedFile> {
    val list = mutableListOf<ScannedFile>()
    try {
        var dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
        if (!dir.exists()) {
            dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
        }

        if (dir.exists()) {
            val files = dir.listFiles()
            if (files != null) {
                val sorted = files.filter { it.isFile && (it.name.endsWith(".pdf") || it.name.endsWith(".jpg")) }
                    .sortedByDescending { it.lastModified() }
                
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                for (f in sorted) {
                    val kb = f.length() / 1024
                    val sizeStr = if (kb > 1024) String.format("%.1f MB", kb / 1024.0) else "$kb KB"
                    list.add(
                        ScannedFile(
                            file = f,
                            name = f.name,
                            dateString = sdf.format(Date(f.lastModified())),
                            sizeString = sizeStr,
                            isPdf = f.name.endsWith(".pdf")
                        )
                    )
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return list
}

// Securely shares file via implicit chooser granting read permissions
fun shareFile(context: Context, file: File, mimeType: String) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "බෙදාගන්න (Share Document)"))
    } catch (e: Exception) {
        Toast.makeText(context, "Error sharing file: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
}

// Securely opens file in system intent chooser with read URI flags
fun openFile(context: Context, file: File, mimeType: String) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "විවෘත කරන්න (Open Document)"))
    } catch (e: Exception) {
        Toast.makeText(context, "No app available to open this format", Toast.LENGTH_SHORT).show()
    }
}

// Utility to retrieve Activity context from Compose Context
private fun getComponentActivity(context: Context): Activity? {
    var ctx = context
    while (ctx is android.content.ContextWrapper) {
        if (ctx is Activity) {
            return ctx
        }
        ctx = ctx.baseContext
    }
    return null
}
