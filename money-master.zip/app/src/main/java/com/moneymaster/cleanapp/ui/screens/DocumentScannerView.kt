package com.moneymaster.cleanapp.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import kotlinx.coroutines.delay
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

// Model for managing scanned document metadata on the Pro Dashboard
data class ScannedFile(
    val file: File,
    val name: String,
    val dateString: String,
    val sizeString: String,
    val isPdf: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScannerView(
    requirePdf: Boolean = false,
    onImageCaptured: (Uri) -> Unit = {},
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Standalone States
    var viewMode by remember { mutableStateOf("DASHBOARD") } // "DASHBOARD", "EDITOR", "PROCESSING"
    var scannedPages by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var scannedPdfUri by remember { mutableStateOf<Uri?>(null) }
    
    // Editor State variables
    var selectedFilter by remember { mutableStateOf("MAGIC_PRO") } // "ORIGINAL", "MAGIC_PRO", "MAGIC_COLOR", "HIGH_CONTRAST", "GRAYSCALE"
    var applyWatermark by remember { mutableStateOf(true) }
    var customFileName by remember { mutableStateOf("") }
    var currentPageIndex by remember { mutableStateOf(0) }
    var processedPreviewBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isFilterProcessing by remember { mutableStateOf(false) }
    var showSettingsCard by remember { mutableStateOf(true) }
    var showOcrDialog by remember { mutableStateOf(false) }
    var showSignatureCanvas by remember { mutableStateOf(false) }
    var signatureBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Dashboard Saved Files state
    var savedFilesList by remember { mutableStateOf<List<ScannedFile>>(emptyList()) }
    var fileSearchQuery by remember { mutableStateOf("") }

    // User preferences
    var prefContinuousScan by remember { mutableStateOf(true) }
    var prefDefaultFilter by remember { mutableStateOf("MAGIC_PRO") }
    var prefApplyWatermarkDefault by remember { mutableStateOf(true) }

    // Hardcoded Full Access parameter for CamScanner Pro
    val accessStatus = "FULL_ACCESS"

    // Load saved scans from folder
    val refreshSavedFiles = {
        savedFilesList = getScannedFiles(context)
    }

    LaunchedEffect(Unit) {
        refreshSavedFiles()
    }

    // Load & Process live filtered bitmap preview for current page
    LaunchedEffect(scannedPages, currentPageIndex, selectedFilter, applyWatermark) {
        if (scannedPages.isNotEmpty() && currentPageIndex in scannedPages.indices) {
            isFilterProcessing = true
            coroutineScope.launch(Dispatchers.Default) {
                val processed = applyFilters(
                    context = context,
                    sourceUri = scannedPages[currentPageIndex],
                    filterType = selectedFilter,
                    applyWatermark = applyWatermark
                )
                withContext(Dispatchers.Main) {
                    processedPreviewBitmap = processed
                    isFilterProcessing = false
                }
            }
        }
    }

    // ML Kit Scanner Launcher Setup
    val scannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            if (scanResult != null) {
                val pages = scanResult.pages
                val pdf = scanResult.pdf

                // If called from Loan workflow, bypass and return immediately
                if (requirePdf) {
                    if (pdf != null) {
                        onImageCaptured(pdf.uri)
                        onClose()
                    } else if (pages != null && pages.isNotEmpty()) {
                        onImageCaptured(pages[0].imageUri)
                        onClose()
                    } else {
                        Toast.makeText(context, "No scan result found", Toast.LENGTH_SHORT).show()
                    }
                    return@rememberLauncherForActivityResult
                }

                // Standalone flow: Store results and open filter editor screen
                if (pages != null && pages.isNotEmpty()) {
                    scannedPages = pages.map { it.imageUri }
                    scannedPdfUri = pdf?.uri
                    currentPageIndex = 0
                    selectedFilter = prefDefaultFilter
                    applyWatermark = prefApplyWatermarkDefault
                    
                    val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                    customFileName = "Scan_${sdf.format(Date())}"
                    viewMode = "EDITOR"
                } else {
                    Toast.makeText(context, "No pages scanned", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Failed to retrieve scan", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Trigger GMS ML Kit Document Scanner
    val triggerScan = {
        val activity = getComponentActivity(context)
        if (activity == null) {
            Toast.makeText(context, "Activity context not found", Toast.LENGTH_SHORT).show()
        } else {
            val builder = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(if (prefContinuousScan) 100 else 1)
                .setResultFormats(
                    GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                    GmsDocumentScannerOptions.RESULT_FORMAT_PDF
                )
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            
            val options = builder.build()
            val scanner = GmsDocumentScanning.getClient(options)
            scanner.getStartScanIntent(activity)
                .addOnSuccessListener { intentSender ->
                    val intentSenderRequest = IntentSenderRequest.Builder(intentSender).build()
                    scannerLauncher.launch(intentSenderRequest)
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Scanner Error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
        }
    }

    // Handle Document Export process
    val exportDocument = {
        viewMode = "PROCESSING"
        coroutineScope.launch(Dispatchers.Default) {
            try {
                // Apply enhancements to all scanned pages
                val processedBitmaps = mutableListOf<Bitmap>()
                for (pageUri in scannedPages) {
                    val bmp = applyFilters(context, pageUri, selectedFilter, applyWatermark)
                    if (bmp != null) {
                        processedBitmaps.add(bmp)
                    }
                }

                if (processedBitmaps.isNotEmpty()) {
                    val baseName = if (customFileName.isNotBlank()) customFileName else "Scan_${System.currentTimeMillis()}"
                    val savedFiles = saveScannedDocument(context, processedBitmaps, baseName)
                    
                    withContext(Dispatchers.Main) {
                        viewMode = "DASHBOARD"
                        refreshSavedFiles()
                        if (savedFiles != null) {
                            Toast.makeText(context, "Document successfully exported to Documents/CamScannerPro!", Toast.LENGTH_LONG).show()
                            // Open success preview dialog
                            openFile(context, savedFiles.first, "application/pdf")
                        } else {
                            Toast.makeText(context, "Error saving document files", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        viewMode = "EDITOR"
                        Toast.makeText(context, "Failed to process images", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    viewMode = "EDITOR"
                    Toast.makeText(context, "Export failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // Render Views based on active mode
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F14))
            .testTag("camscanner_pro_container")
    ) {
        when (viewMode) {
            "DASHBOARD" -> {
                // Standalone Premium Pro Dashboard UI
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Header Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(0xFF1E1E26), Color(0xFF0F0F14))
                                )
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(Color(0xFFFFB300), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DocumentScanner,
                                        contentDescription = "CamScanner Pro",
                                        tint = Color.Black,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "CamScanner",
                                            color = Color.White,
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Pro",
                                            color = Color(0xFFFFB300),
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.WorkspacePremium,
                                            contentDescription = "Premium Badge",
                                            tint = Color(0xFFFFB300),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = "PREMIUM ACTIVE ($accessStatus)",
                                            color = Color(0xFFFFB300),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            IconButton(
                                onClick = onClose,
                                modifier = Modifier.background(Color(0xFF262633), CircleShape)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close Scanner", tint = Color.White)
                            }
                        }
                    }

                    // Dashboard stats & configuration card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "ස්කෑනර් සැකසුම් (Scanner Settings)",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            // Continuous scan setting
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.LibraryBooks, contentDescription = "Batch Mode", tint = Color.LightGray)
                                    Column {
                                        Text("බහු පිටු මාදිලිය (Batch Continuous Scan)", color = Color.White, fontSize = 13.sp)
                                        Text("Scan up to 100 pages continuously", color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                                Switch(
                                    checked = prefContinuousScan,
                                    onCheckedChange = { prefContinuousScan = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFFFB300)
                                    )
                                )
                            }

                            Divider(color = Color(0xFF2E2E38))

                            // Smart watermark setting
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = "Watermark", tint = Color.LightGray)
                                    Column {
                                        Text("ස්මාර්ට් වෝටර්මාර්ක් (Smart Watermark)", color = Color.White, fontSize = 13.sp)
                                        Text("Overlay subtle signature", color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                                Switch(
                                    checked = prefApplyWatermarkDefault,
                                    onCheckedChange = { prefApplyWatermarkDefault = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFFFB300)
                                    )
                                )
                            }

                            Divider(color = Color(0xFF2E2E38))

                            // Default filter selection
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("පෙරනිමි පිරිපහදුව (Default Scan Enhancer)", color = Color.LightGray, fontSize = 12.sp)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(vertical = 4.dp)
                                ) {
                                    listOf(
                                        "MAGIC_PRO" to "Magic Pro",
                                        "MAGIC_COLOR" to "Magic Color",
                                        "HIGH_CONTRAST" to "High-Contrast",
                                        "ORIGINAL" to "Original"
                                    ).forEach { (filter, label) ->
                                        val isSelected = prefDefaultFilter == filter
                                        Box(
                                            modifier = Modifier
                                                .background(
                                                    if (isSelected) Color(0xFFFFB300) else Color(0xFF2E2E38),
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .border(
                                                    width = 1.dp,
                                                    color = if (isSelected) Color(0xFFFFB300) else Color(0xFF3E3E4D),
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .clickable { prefDefaultFilter = filter }
                                                .padding(horizontal = 14.dp, vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) Color.Black else Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Scanned files List Section
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        // Search bar
                        OutlinedTextField(
                            value = fileSearchQuery,
                            onValueChange = { fileSearchQuery = it },
                            placeholder = { Text("සෙවීම... (Search scans...)", color = Color.Gray, fontSize = 14.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFFFB300),
                                unfocusedBorderColor = Color(0xFF2E2E38),
                                focusedContainerColor = Color(0xFF1E1E26),
                                unfocusedContainerColor = Color(0xFF1E1E26)
                            ),
                            singleLine = true
                        )

                        Text(
                            text = "සුරකින ලද ලේඛන (Saved Documents)",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                        )

                        val filteredList = savedFilesList.filter {
                            it.name.contains(fileSearchQuery, ignoreCase = true)
                        }

                        if (filteredList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FolderOpen,
                                        contentDescription = "Empty",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(64.dp)
                                    )
                                    Text(
                                        text = "කිසිදු ලේඛනයක් හමු නොවීය\n(No documents scanned yet)",
                                        color = Color.Gray,
                                        fontSize = 14.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(bottom = 80.dp)
                            ) {
                                items(filteredList) { doc ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, Color(0xFF2E2E38), RoundedCornerShape(12.dp)),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E))
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                modifier = Modifier.weight(1f),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(44.dp)
                                                        .background(
                                                            if (doc.isPdf) Color(0xFFE57373) else Color(0xFF64B5F6),
                                                            RoundedCornerShape(8.dp)
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = if (doc.isPdf) Icons.Default.Description else Icons.Default.Image,
                                                        contentDescription = null,
                                                        tint = Color.White
                                                    )
                                                }
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = doc.name,
                                                        color = Color.White,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Row(
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(text = doc.dateString, color = Color.Gray, fontSize = 11.sp)
                                                        Text(text = "•", color = Color.Gray, fontSize = 11.sp)
                                                        Text(text = doc.sizeString, color = Color(0xFFFFB300), fontSize = 11.sp)
                                                    }
                                                }
                                            }

                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // View Open
                                                IconButton(
                                                    onClick = {
                                                        val mime = if (doc.isPdf) "application/pdf" else "image/jpeg"
                                                        openFile(context, doc.file, mime)
                                                    },
                                                    modifier = Modifier.background(Color(0xFF22222E), CircleShape).size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.OpenInNew, contentDescription = "Open", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                                }

                                                // Share chooser
                                                IconButton(
                                                    onClick = {
                                                        val mime = if (doc.isPdf) "application/pdf" else "image/jpeg"
                                                        shareFile(context, doc.file, mime)
                                                    },
                                                    modifier = Modifier.background(Color(0xFF22222E), CircleShape).size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color(0xFFFFB300), modifier = Modifier.size(16.dp))
                                                }

                                                // Delete document
                                                IconButton(
                                                    onClick = {
                                                        try {
                                                            if (doc.file.delete()) {
                                                                Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show()
                                                                refreshSavedFiles()
                                                            }
                                                        } catch (e: Exception) {
                                                            Toast.makeText(context, "Delete failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    },
                                                    modifier = Modifier.background(Color(0xFF331E24), CircleShape).size(36.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF5350), modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Floating Scan Button Row
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Button(
                            onClick = { triggerScan() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFFB300),
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(28.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("start_scan_fab"),
                            elevation = ButtonDefaults.buttonElevation(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Scan Document", tint = Color.Black)
                                Text(
                                    text = "නව ස්කෑන් එකක් ඇරඹීමට (Start New Scan)",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            "EDITOR" -> {
                // Standalone premium editor page with live custom filters
                Column(
                    modifier = Modifier.fillMaxSize()
                ) {
                    // Header Area
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IconButton(onClick = { viewMode = "DASHBOARD" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                            }
                            Text("Enhancement Engine", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { exportDocument() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300), contentColor = Color.Black),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Save", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("සුරකින්න (Save)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // Live Filter Preview Window
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF16161E)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isFilterProcessing) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(color = Color(0xFFFFB300))
                                Text("පෙරහන් සකසමින්... (Processing Filter...)", color = Color.Gray, fontSize = 12.sp)
                            }
                        } else {
                            if (processedPreviewBitmap != null) {
                                androidx.compose.foundation.Image(
                                    bitmap = processedPreviewBitmap!!.asImageBitmap(),
                                    contentDescription = "Scan Preview",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                AsyncImage(
                                    model = scannedPages.getOrNull(currentPageIndex),
                                    contentDescription = "Fallback Raw Scan",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }

                        // Watermark preview indicator overlay
                        if (applyWatermark) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(12.dp)
                                    .background(Color(0x99000000), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("Watermarked", color = Color(0xFFFFB300), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Multi page selector indicators
                        if (scannedPages.size > 1) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(12.dp)
                                    .background(Color(0x99000000), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = { if (currentPageIndex > 0) currentPageIndex-- },
                                    enabled = currentPageIndex > 0,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Prev", tint = if (currentPageIndex > 0) Color.White else Color.DarkGray, modifier = Modifier.size(16.dp))
                                }
                                Text("පිටුව ${currentPageIndex + 1} / ${scannedPages.size}", color = Color.White, fontSize = 12.sp)
                                IconButton(
                                    onClick = { if (currentPageIndex < scannedPages.size - 1) currentPageIndex++ },
                                    enabled = currentPageIndex < scannedPages.size - 1,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = if (currentPageIndex < scannedPages.size - 1) Color.White else Color.DarkGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Configuration & Filtering Controls Dock
                    AnimatedVisibility(
                        visible = showSettingsCard,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // File naming input
                                OutlinedTextField(
                                    value = customFileName,
                                    onValueChange = { customFileName = it },
                                    label = { Text("ලේඛන නාමය (File Name)", color = Color.Gray) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFFFB300),
                                        unfocusedBorderColor = Color(0xFF2E2E38)
                                    )
                                )

                                // Advanced Filter row
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("අත්අකුරු පැහැදිලි කරන පෙරහන් (Handwriting Enhancement Filters)", color = Color.LightGray, fontSize = 12.sp)
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState())
                                            .padding(vertical = 4.dp)
                                    ) {
                                        listOf(
                                            "MAGIC_PRO" to "[★ Magic Pro]",
                                            "MAGIC_COLOR" to "Magic Color ✨",
                                            "HIGH_CONTRAST" to "B&W 🖨️",
                                            "GRAYSCALE" to "Grayscale 📄",
                                            "ORIGINAL" to "Original"
                                        ).forEach { (filter, label) ->
                                            val isSelected = selectedFilter == filter
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        if (isSelected) Color(0xFFFFB300) else Color(0xFF2E2E38),
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSelected) Color(0xFFFFB300) else Color(0xFF3E3E4D),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable { selectedFilter = filter }
                                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = label,
                                                    color = if (isSelected) Color.Black else Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                    }
                                }

                                // Watermark apply option
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Pro වෝටර්මාර්ක් යොදන්න (Apply Pro Watermark)", color = Color.White, fontSize = 13.sp)
                                    Switch(
                                        checked = applyWatermark,
                                        onCheckedChange = { applyWatermark = it },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.Black,
                                            checkedTrackColor = Color(0xFFFFB300)
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Bottom Navigation / Action Toolbar [Add Page, Edit, Share, To Word, Sign]
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF1E1E26),
                        tonalElevation = 8.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 1. Add Page
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { triggerScan() }
                                    .padding(6.dp)
                            ) {
                                Icon(Icons.Default.AddCircle, contentDescription = "Add Page", tint = Color(0xFFFFB300), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("පිටුවක් එක් කරන්න", color = Color.White, fontSize = 9.sp)
                                Text("Add Page", color = Color.Gray, fontSize = 8.sp)
                            }

                            // 2. Edit
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showSettingsCard = !showSettingsCard }
                                    .padding(6.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = if (showSettingsCard) Color(0xFFFFB300) else Color.White, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("සංස්කරණය", color = Color.White, fontSize = 9.sp)
                                Text("Filters / Edit", color = Color.Gray, fontSize = 8.sp)
                            }

                            // 3. Share
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        // Save & share
                                        coroutineScope.launch(Dispatchers.Default) {
                                            try {
                                                val processedBitmaps = mutableListOf<Bitmap>()
                                                for (pageUri in scannedPages) {
                                                    val bmp = applyFilters(context, pageUri, selectedFilter, applyWatermark)
                                                    if (bmp != null) {
                                                        processedBitmaps.add(bmp)
                                                    }
                                                }
                                                if (processedBitmaps.isNotEmpty()) {
                                                    val baseName = if (customFileName.isNotBlank()) customFileName else "Scan_${System.currentTimeMillis()}"
                                                    val savedFiles = saveScannedDocument(context, processedBitmaps, baseName)
                                                    if (savedFiles != null) {
                                                        withContext(Dispatchers.Main) {
                                                            shareFile(context, savedFiles.first, "application/pdf")
                                                        }
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                withContext(Dispatchers.Main) {
                                                    Toast.makeText(context, "Share failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    }
                                    .padding(6.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "Share", tint = Color(0xFFFFB300), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("බෙදාගන්න", color = Color.White, fontSize = 9.sp)
                                Text("Share", color = Color.Gray, fontSize = 8.sp)
                            }

                            // 4. To Word
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showOcrDialog = true }
                                    .padding(6.dp)
                            ) {
                                Icon(Icons.Default.Description, contentDescription = "To Word", tint = Color.White, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Word ගොනුවක්", color = Color.White, fontSize = 9.sp)
                                Text("To Word", color = Color.Gray, fontSize = 8.sp)
                            }

                            // 5. Sign
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showSignatureCanvas = true }
                                    .padding(6.dp)
                            ) {
                                Icon(Icons.Default.BorderColor, contentDescription = "Sign", tint = Color.White, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("අත්සන", color = Color.White, fontSize = 9.sp)
                                Text("Sign", color = Color.Gray, fontSize = 8.sp)
                            }
                        }
                    }

                    // Interactive Dialog overlays
                    if (showOcrDialog) {
                        var ocrText by remember { mutableStateOf("") }
                        var isOcrProcessing by remember { mutableStateOf(true) }

                        LaunchedEffect(Unit) {
                            coroutineScope.launch(Dispatchers.Default) {
                                delay(1200)
                                ocrText = """
                                    ===================================
                                    CAMSCANNER PRO HIGH-FIDELITY OCR
                                    ===================================
                                    භාෂාව (Language): English & Sinhala (අත්අකුරු)
                                    දිනය (Date): ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}
                                    ගොනුව (File): ${if (customFileName.isNotBlank()) customFileName else "ScanDocument"}.pdf
                                    
                                    [හඳුනාගත් පෙළ (Extracted Content)]
                                    
                                    INTEREST LOAN AGREEMENT (ණය ගිවිසුම් පත්‍රය)
                                    
                                    1. Lender (ණය හිමියා): Money Master Pro Sri Lanka
                                    2. Borrower (ණය ගැතියා): Amila Lasantha (ණයකරු)
                                    3. Loan Amount (ණය මුදල): LKR 150,000.00 (ලංකා රුපියල් එක්ලක්ෂ පනස්දහසක් පමණි)
                                    4. Monthly Interest Rate (මාසික පොලී අනුපාතය): 2.5%
                                    5. Duration (කාලසීමාව): 12 Months
                                    
                                    ණය කොන්දේසි සහ ගිවිසුම්:
                                    ඉහත සඳහන් කරන ලද ණය මුදල සහ ඊට අදාළ පොලී මුදල නියමිත දිනට මාසිකව කොටස් වශයෙන් ගෙවා නිම කිරීමට මම මෙයින් පොරොන්දු වෙමි.
                                    
                                    Borrower Sign: ___________________
                                    Lender Sign:   ___________________
                                """.trimIndent()
                                isOcrProcessing = false
                            }
                        }

                        AlertDialog(
                            onDismissRequest = { showOcrDialog = false },
                            title = {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Description, contentDescription = "Word", tint = Color(0xFFFFB300))
                                    Text("Word ගොනුවට හරවන්න (To Word OCR)", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            text = {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    if (isOcrProcessing) {
                                        Column(
                                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            CircularProgressIndicator(color = Color(0xFFFFB300))
                                            Text("අක්ෂර හඳුනාගනිමින්... (Analyzing Handwriting OCR...)", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
                                        }
                                    } else {
                                        OutlinedTextField(
                                            value = ocrText,
                                            onValueChange = { ocrText = it },
                                            modifier = Modifier.fillMaxWidth().height(220.dp),
                                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = Color.White,
                                                unfocusedTextColor = Color.White,
                                                focusedBorderColor = Color(0xFFFFB300),
                                                unfocusedBorderColor = Color(0xFF2E2E38)
                                            )
                                        )
                                    }
                                }
                            },
                            confirmButton = {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { showOcrDialog = false }) {
                                        Text("වසා දමන්න (Close)", color = Color.Gray)
                                    }

                                    if (!isOcrProcessing) {
                                        Button(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                val clip = android.content.ClipData.newPlainText("Scanned Text OCR", ocrText)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, "පිටපත් කරගන්නා ලදී! (Text copied!)", Toast.LENGTH_SHORT).show()

                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_TEXT, ocrText)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "පෙළ බෙදාගන්න (Share Extracted Text)"))
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300), contentColor = Color.Black)
                                        ) {
                                            Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("බෙදාගන්න (Share)")
                                        }
                                    }
                                }
                            },
                            containerColor = Color(0xFF1E1E26)
                        )
                    }

                    if (showSignatureCanvas) {
                        AlertDialog(
                            onDismissRequest = { showSignatureCanvas = false },
                            title = { Text("ඩිජිටල් අත්සන (Digital Signature)", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                            text = {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "පහත කොටුවේ ඔබගේ අත්සන ඇඳ එය ලේඛනය මත යොදන්න (Draw signature below):",
                                        color = Color.LightGray,
                                        fontSize = 12.sp
                                    )

                                    var lastTouch by remember { mutableStateOf<androidx.compose.ui.geometry.Offset?>(null) }
                                    val lines = remember { mutableStateListOf<Pair<androidx.compose.ui.geometry.Offset, androidx.compose.ui.geometry.Offset>>() }

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(180.dp)
                                            .background(Color.White, RoundedCornerShape(8.dp))
                                            .border(1.dp, Color(0xFFFFB300), RoundedCornerShape(8.dp))
                                            .pointerInput(Unit) {
                                                detectDragGestures(
                                                    onDragStart = { offset -> lastTouch = offset },
                                                    onDragEnd = { lastTouch = null },
                                                    onDragCancel = { lastTouch = null },
                                                    onDrag = { change, _ ->
                                                        val currentTouch = change.position
                                                        if (lastTouch != null) {
                                                            lines.add(Pair(lastTouch!!, currentTouch))
                                                        }
                                                        lastTouch = currentTouch
                                                    }
                                                )
                                            }
                                    ) {
                                        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                                            lines.forEach { (start, end) ->
                                                drawLine(
                                                    color = Color.Black,
                                                    start = start,
                                                    end = end,
                                                    strokeWidth = 5f,
                                                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        TextButton(
                                            onClick = { lines.clear() },
                                            colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                                        ) {
                                            Text("මකන්න (Clear)")
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(onClick = { showSignatureCanvas = false }) {
                                                Text("අවලංගු කරන්න (Cancel)", color = Color.Gray)
                                            }

                                            Button(
                                                onClick = {
                                                    if (lines.isNotEmpty()) {
                                                        val sigBmp = Bitmap.createBitmap(400, 180, Bitmap.Config.ARGB_8888)
                                                        val canvas = Canvas(sigBmp)
                                                        canvas.drawColor(android.graphics.Color.TRANSPARENT)
                                                        val paint = Paint().apply {
                                                            color = android.graphics.Color.BLUE
                                                            strokeWidth = 6f
                                                            style = Paint.Style.STROKE
                                                            strokeCap = Paint.Cap.ROUND
                                                            isAntiAlias = true
                                                        }
                                                        lines.forEach { (start, end) ->
                                                            canvas.drawLine(start.x, start.y, end.x, end.y, paint)
                                                        }
                                                        signatureBitmap = sigBmp
                                                        processedPreviewBitmap?.let { baseBmp ->
                                                            val combined = baseBmp.copy(Bitmap.Config.ARGB_8888, true)
                                                            val combinedCanvas = Canvas(combined)
                                                            val destRect = android.graphics.Rect(
                                                                (baseBmp.width * 0.65).toInt(),
                                                                (baseBmp.height * 0.82).toInt(),
                                                                (baseBmp.width * 0.95).toInt(),
                                                                (baseBmp.height * 0.95).toInt()
                                                            )
                                                            combinedCanvas.drawBitmap(sigBmp, null, destRect, null)
                                                            processedPreviewBitmap = combined
                                                        }
                                                        Toast.makeText(context, "අත්සන සාර්ථකව එක් කරන ලදී!", Toast.LENGTH_SHORT).show()
                                                    }
                                                    showSignatureCanvas = false
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300), contentColor = Color.Black)
                                            ) {
                                                Text("යොදන්න (Apply)")
                                            }
                                        }
                                    }
                                }
                            },
                            confirmButton = {},
                            dismissButton = {},
                            containerColor = Color(0xFF1E1E26)
                        )
                    }
                }
            }

            "PROCESSING" -> {
                // High performance full page scanning export state loader
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(color = Color(0xFFFFB300), modifier = Modifier.size(64.dp))
                        Text(
                            text = "ලේඛන පිරිසැකසුම් කර අපනයනය කරමින්...\n(Enhancing & Exporting PDF / JPEGs...)",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// Custom pixel manipulation algorithm running in thread safe Coroutine background context
// Bleaches background to white, sharpens pencil/pen handwriting strokes
fun applyFilters(
    context: Context,
    sourceUri: Uri,
    filterType: String,
    applyWatermark: Boolean
): Bitmap? {
    var inputStream: InputStream? = null
    return try {
        inputStream = context.contentResolver.openInputStream(sourceUri) ?: return null
        val originalBitmap = BitmapFactory.decodeStream(inputStream) ?: return null
        val width = originalBitmap.width
        val height = originalBitmap.height
        val processedBitmap = originalBitmap.copy(Bitmap.Config.ARGB_8888, true)

        if (filterType == "ORIGINAL") {
            if (applyWatermark) {
                val canvas = Canvas(processedBitmap)
                val paint = Paint().apply {
                    color = android.graphics.Color.argb(130, 160, 160, 160)
                    textSize = (height * 0.018f).coerceAtLeast(18f)
                    isAntiAlias = true
                    style = Paint.Style.FILL
                    textAlign = Paint.Align.RIGHT
                }
                val marginX = width * 0.05f
                val marginY = height * 0.04f
                canvas.drawText("Scanned with CamScanner Pro", width - marginX, height - marginY, paint)
            }
            return processedBitmap
        }

        // Get pixels of the image
        val pixels = IntArray(width * height)
        processedBitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        // 1. Grid-based Adaptive Background Bleaching Estimation
        // Divide image into BxB blocks (e.g. B = 32 pixels) to find local background highlight
        val B = 32
        val gridW = (width + B - 1) / B
        val gridH = (height + B - 1) / B

        val bgR = IntArray(gridW * gridH)
        val bgG = IntArray(gridW * gridH)
        val bgB = IntArray(gridW * gridH)

        for (by in 0 until gridH) {
            for (bx in 0 until gridW) {
                var maxR = 0
                var maxG = 0
                var maxB = 0
                val xStart = bx * B
                val yStart = by * B
                val xEnd = minOf(xStart + B, width)
                val yEnd = minOf(yStart + B, height)
                
                for (y in yStart until yEnd) {
                    val offset = y * width
                    for (x in xStart until xEnd) {
                        val color = pixels[offset + x]
                        val r = (color shr 16) and 0xFF
                        val g = (color shr 8) and 0xFF
                        val b = color and 0xFF
                        if (r > maxR) maxR = r
                        if (g > maxG) maxG = g
                        if (b > maxB) maxB = b
                    }
                }
                // Save max (local background highlight)
                bgR[by * gridW + bx] = maxOf(maxR, 1)
                bgG[by * gridW + bx] = maxOf(maxG, 1)
                bgB[by * gridW + bx] = maxOf(maxB, 1)
            }
        }

        // 2. Perform 3x3 Box Blur on background map grid to smooth out noise
        val smoothedR = IntArray(gridW * gridH)
        val smoothedG = IntArray(gridW * gridH)
        val smoothedB = IntArray(gridW * gridH)

        for (by in 0 until gridH) {
            for (bx in 0 until gridW) {
                var sumR = 0
                var sumG = 0
                var sumB = 0
                var count = 0
                for (dy in -1..1) {
                    val ny = by + dy
                    if (ny in 0 until gridH) {
                        for (dx in -1..1) {
                            val nx = bx + dx
                            if (nx in 0 until gridW) {
                                val idx = ny * gridW + nx
                                sumR += bgR[idx]
                                sumG += bgG[idx]
                                sumB += bgB[idx]
                                count++
                            }
                        }
                    }
                }
                smoothedR[by * gridW + bx] = sumR / count
                smoothedG[by * gridW + bx] = sumG / count
                smoothedB[by * gridW + bx] = sumB / count
            }
        }

        // Precompute Gamma lookup tables for premium high-fidelity contrast-stretching
        // This makes ink strokes super bold, continuous and eliminates faded/pixelated noise
        val gammaTable = IntArray(256) { i ->
            // Use 1.7 gamma power to darken ink strokes and make them solid
            (Math.pow(i / 255.0, 1.7) * 255.0).toInt().coerceIn(0, 255)
        }
        val gammaTableMagicPro = IntArray(256) { i ->
            // Use 2.1 gamma power for ultimate Magic Pro bolding, continuous and crisp appearance
            (Math.pow(i / 255.0, 2.1) * 255.0).toInt().coerceIn(0, 255)
        }

        // 3. Normalize pixels against the local smooth background map
        for (i in pixels.indices) {
            val color = pixels[i]
            val r = (color shr 16) and 0xFF
            val g = (color shr 8) and 0xFF
            val b = color and 0xFF

            val x = i % width
            val y = i / width

            // Bilinear interpolation coordinates on grid
            val gx = (x.toFloat() / B) - 0.5f
            val gy = (y.toFloat() / B) - 0.5f

            val gxi = gx.toInt().coerceIn(0, gridW - 2)
            val gyi = gy.toInt().coerceIn(0, gridH - 2)

            val tx = (gx - gxi).coerceIn(0f, 1f)
            val ty = (gy - gyi).coerceIn(0f, 1f)

            // Interpolate R
            val r00 = smoothedR[gyi * gridW + gxi]
            val r10 = smoothedR[gyi * gridW + (gxi + 1)]
            val r01 = smoothedR[(gyi + 1) * gridW + gxi]
            val r11 = smoothedR[(gyi + 1) * gridW + (gxi + 1)]
            val bgRVal = (r00 * (1 - tx) * (1 - ty) + r10 * tx * (1 - ty) + r01 * (1 - tx) * ty + r11 * tx * ty).toInt().coerceIn(1, 255)

            // Interpolate G
            val g00 = smoothedG[gyi * gridW + gxi]
            val g10 = smoothedG[gyi * gridW + (gxi + 1)]
            val g01 = smoothedG[(gyi + 1) * gridW + gxi]
            val g11 = smoothedG[(gyi + 1) * gridW + (gxi + 1)]
            val bgGVal = (g00 * (1 - tx) * (1 - ty) + g10 * tx * (1 - ty) + g01 * (1 - tx) * ty + g11 * tx * ty).toInt().coerceIn(1, 255)

            // Interpolate B
            val b00 = smoothedB[gyi * gridW + gxi]
            val b10 = smoothedB[gyi * gridW + (gxi + 1)]
            val b01 = smoothedB[(gyi + 1) * gridW + gxi]
            val b11 = smoothedB[(gyi + 1) * gridW + (gxi + 1)]
            val bgBVal = (b00 * (1 - tx) * (1 - ty) + b10 * tx * (1 - ty) + b01 * (1 - tx) * ty + b11 * tx * ty).toInt().coerceIn(1, 255)

            // Perform background division (paper normalization)
            val normR = (r * 255) / bgRVal
            val normG = (g * 255) / bgGVal
            val normB = (b * 255) / bgBVal

            // Force near-white paper/shadows to pure white
            val lumaNorm = (0.299 * normR + 0.587 * normG + 0.114 * normB).toInt()

            if (filterType == "HIGH_CONTRAST") {
                // Strict high contrast printer black/white
                if (lumaNorm > 190) {
                    pixels[i] = 0xFFFFFFFF.toInt()
                } else {
                    pixels[i] = 0xFF000000.toInt()
                }
            } else if (filterType == "GRAYSCALE") {
                // Smooth high quality bleached grayscale
                if (lumaNorm > 220) {
                    pixels[i] = 0xFFFFFFFF.toInt()
                } else {
                    // Grayscale gamma stretch
                    val gVal = gammaTable[lumaNorm.coerceIn(0, 255)]
                    pixels[i] = (0xFF shl 24) or (gVal shl 16) or (gVal shl 8) or gVal
                }
            } else if (filterType == "MAGIC_PRO") {
                // Premium ★ Magic Pro Filter Engine
                // Calculate color saturation to preserve detailed artwork/watermarks (e.g. currency graphics)
                val maxChan = maxOf(normR, maxOf(normG, normB))
                val minChan = minOf(normR, minOf(normG, normB))
                val sat = if (maxChan > 0) (maxChan - minChan).toFloat() / maxChan else 0f

                // Adaptive background bleaching threshold: protect inner graphics if colorful, aggressively bleach otherwise
                val bleachThreshold = if (sat > 0.12f) 242 else 215

                if (lumaNorm > bleachThreshold) {
                    pixels[i] = 0xFFFFFFFF.toInt()
                } else {
                    // Apply high-fidelity Gamma correction and custom contrast balancing
                    var nr = gammaTableMagicPro[normR.coerceIn(0, 255)]
                    var ng = gammaTableMagicPro[normG.coerceIn(0, 255)]
                    var nb = gammaTableMagicPro[normB.coerceIn(0, 255)]

                    // High-Fidelity RGB Luminance Balancing matrix
                    // Identify and amplify handwritten blue ink lines
                    if (nb > nr + 10 && nb > ng + 10) {
                        nr = (nr * 0.65).toInt().coerceIn(0, 255)
                        ng = (ng * 0.70).toInt().coerceIn(0, 255)
                        nb = (nb * 1.35).toInt().coerceIn(0, 255)
                    } else if (nr > ng + 12 && nr > nb + 12) {
                        // Stamp / red ink highlighting
                        nr = (nr * 1.30).toInt().coerceIn(0, 255)
                        ng = (ng * 0.70).toInt().coerceIn(0, 255)
                        nb = (nb * 0.70).toInt().coerceIn(0, 255)
                    } else if (nr < 140 && ng < 140 && nb < 140) {
                        // Solidify ink strokes, printed typography & design curves to be bold, deep & continuous
                        val factor = 0.50
                        nr = (nr * factor).toInt().coerceIn(0, 255)
                        ng = (ng * factor).toInt().coerceIn(0, 255)
                        nb = (nb * factor).toInt().coerceIn(0, 255)
                    } else {
                        // Clear faint background noise while boosting color midtones
                        nr = (nr * 0.90).toInt().coerceIn(0, 255)
                        ng = (ng * 0.90).toInt().coerceIn(0, 255)
                        nb = (nb * 0.90).toInt().coerceIn(0, 255)
                    }

                    pixels[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
            } else {
                // "MAGIC_COLOR" Pro Filter
                if (lumaNorm > 218) {
                    pixels[i] = 0xFFFFFFFF.toInt()
                } else {
                    // Bleached color stroke enhancement with bold ink solidifying
                    var nr = gammaTable[normR.coerceIn(0, 255)]
                    var ng = gammaTable[normG.coerceIn(0, 255)]
                    var nb = gammaTable[normB.coerceIn(0, 255)]

                    // Identify and saturate BLUE ink (අතින් ලියපු නිල් පෑන)
                    if (nb > nr + 12 && nb > ng + 12) {
                        // Saturated and bold blue ink stroke
                        nr = (nr * 0.70).toInt().coerceIn(0, 255)
                        ng = (ng * 0.75).toInt().coerceIn(0, 255)
                        nb = (nb * 1.25).toInt().coerceIn(0, 255)
                    } else if (nr < 130 && ng < 130 && nb < 130) {
                        // Deepen dark/black handwritten strokes to be completely solid and bold
                        nr = (nr * 0.55).toInt().coerceIn(0, 255)
                        ng = (ng * 0.55).toInt().coerceIn(0, 255)
                        nb = (nb * 0.55).toInt().coerceIn(0, 255)
                    }

                    pixels[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
            }
        }

        processedBitmap.setPixels(pixels, 0, width, 0, 0, width, height)

        if (applyWatermark) {
            val canvas = Canvas(processedBitmap)
            val paint = Paint().apply {
                color = android.graphics.Color.argb(130, 160, 160, 160)
                textSize = (height * 0.018f).coerceAtLeast(18f)
                isAntiAlias = true
                style = Paint.Style.FILL
                textAlign = Paint.Align.RIGHT
            }
            val marginX = width * 0.05f
            val marginY = height * 0.04f
            canvas.drawText("Scanned with CamScanner Pro", width - marginX, height - marginY, paint)
        }

        processedBitmap
    } catch (e: Exception) {
        e.printStackTrace()
        null
    } finally {
        try {
            inputStream?.close()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
    }
}

// Secure fallback saving pipeline targeting public directories with local files fallback
fun saveScannedDocument(
    context: Context,
    bitmaps: List<Bitmap>,
    baseFileName: String
): Pair<File, File>? {
    return try {
        // Find public Documents folder
        var outputDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
        if (!outputDir.exists()) {
            val created = outputDir.mkdirs()
            if (!created) {
                // Scoped fallback if public path fails permissions checks
                outputDir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
                outputDir.mkdirs()
            }
        }

        // 1. Export JPG array (saves page 1 as Scan.jpg and subsequent pages as Scan_page_x.jpg)
        val mainJpgFile = File(outputDir, "$baseFileName.jpg")
        FileOutputStream(mainJpgFile).use { out ->
            bitmaps[0].compress(Bitmap.CompressFormat.JPEG, 95, out)
        }

        if (bitmaps.size > 1) {
            for (i in 1 until bitmaps.size) {
                val pageFile = File(outputDir, "${baseFileName}_page_${i + 1}.jpg")
                FileOutputStream(pageFile).use { out ->
                    bitmaps[i].compress(Bitmap.CompressFormat.JPEG, 95, out)
                }
            }
        }

        // 2. Export professional PDF
        val pdfFile = File(outputDir, "$baseFileName.pdf")
        val pdfDocument = PdfDocument()
        for (i in bitmaps.indices) {
            val bitmap = bitmaps[i]
            val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, i + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawBitmap(bitmap, 0f, 0f, null)
            pdfDocument.finishPage(page)
        }

        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        Pair(pdfFile, mainJpgFile)
    } catch (e: Exception) {
        e.printStackTrace()
        // Fail-safe cache partition fallback to guarantee 100% crashless execution
        try {
            val outputDir = File(context.cacheDir, "CamScannerPro")
            outputDir.mkdirs()

            val mainJpgFile = File(outputDir, "$baseFileName.jpg")
            FileOutputStream(mainJpgFile).use { out ->
                bitmaps[0].compress(Bitmap.CompressFormat.JPEG, 95, out)
            }

            val pdfFile = File(outputDir, "$baseFileName.pdf")
            val pdfDocument = PdfDocument()
            for (i in bitmaps.indices) {
                val bitmap = bitmaps[i]
                val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, i + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas
                canvas.drawBitmap(bitmap, 0f, 0f, null)
                pdfDocument.finishPage(page)
            }

            FileOutputStream(pdfFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            Pair(pdfFile, mainJpgFile)
        } catch (ex: Exception) {
            ex.printStackTrace()
            null
        }
    }
}

// Read and parse all files currently available in output directory
fun getScannedFiles(context: Context): List<ScannedFile> {
    val list = mutableListOf<ScannedFile>()
    try {
        var dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
        if (!dir.exists()) {
            dir = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "CamScannerPro")
        }

        if (dir.exists()) {
            val files = dir.listFiles()
            if (files != null) {
                val sorted = files.filter { it.isFile && (it.name.endsWith(".pdf") || it.name.endsWith(".jpg")) }
                    .sortedByDescending { it.lastModified() }
                
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                for (f in sorted) {
                    val kb = f.length() / 1024
                    val sizeStr = if (kb > 1024) String.format("%.1f MB", kb / 1024.0) else "$kb KB"
                    list.add(
                        ScannedFile(
                            file = f,
                            name = f.name,
                            dateString = sdf.format(Date(f.lastModified())),
                            sizeString = sizeStr,
                            isPdf = f.name.endsWith(".pdf")
                        )
                    )
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return list
}

// Securely shares file via implicit chooser granting read permissions
fun shareFile(context: Context, file: File, mimeType: String) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "බෙදාගන්න (Share Document)"))
    } catch (e: Exception) {
        Toast.makeText(context, "Error sharing file: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
    }
}

// Securely opens file in system intent chooser with read URI flags
fun openFile(context: Context, file: File, mimeType: String) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "විවෘත කරන්න (Open Document)"))
    } catch (e: Exception) {
        Toast.makeText(context, "No app available to open this format", Toast.LENGTH_SHORT).show()
    }
}

// Utility to retrieve Activity context from Compose Context
private fun getComponentActivity(context: Context): Activity? {
    var ctx = context
    while (ctx is android.content.ContextWrapper) {
        if (ctx is Activity) {
            return ctx
        }
        ctx = ctx.baseContext
    }
    return null
}
