package com.moneymaster.cleanapp.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.net.Uri
import android.util.Log
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@Composable
fun DocumentScannerView(
    onImageCaptured: (Uri) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }

    if (!hasCameraPermission) {
        // Request camera permission inline if not granted
        val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            contract = androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { granted ->
            hasCameraPermission = granted
        }

        LaunchedEffect(Unit) {
            permissionLauncher.launch(android.Manifest.permission.CAMERA)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Color(0xFFFFB300))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Camera permission is required...", color = Color.White)
            }
        }
        return
    }

    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }
    var camera: Camera? by remember { mutableStateOf(null) }
    var isFlashOn by remember { mutableStateOf(false) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("document_scanner_screen")
    ) {
        // Camera Preview
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = androidx.camera.core.Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    imageCapture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build()

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                    try {
                        cameraProvider.unbindAll()
                        camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageCapture
                        )
                    } catch (e: Exception) {
                        Log.e("DocumentScanner", "Use case binding failed", e)
                    }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Glowing Dotted Edge-detection Alignment Overlay
        ComposeCanvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Calculate card alignment guide (e.g., center with 80% width)
            val rectWidth = canvasWidth * 0.85f
            val rectHeight = rectWidth * 0.63f // standard document ratio
            val left = (canvasWidth - rectWidth) / 2f
            val top = (canvasHeight - rectHeight) / 2.3f

            // Draw darkening scrim outside document target area
            drawRect(
                color = Color.Black.copy(alpha = 0.5f),
                size = size
            )

            // Punch holes in scrim inside document rect
            drawRoundRect(
                color = Color.Transparent,
                topLeft = Offset(left, top),
                size = Size(rectWidth, rectHeight),
                cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
                blendMode = androidx.compose.ui.graphics.BlendMode.Clear
            )

            // Draw glowing scan guide rectangle border
            drawRoundRect(
                color = Color(0xFFFFB300),
                topLeft = Offset(left, top),
                size = Size(rectWidth, rectHeight),
                cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
                style = Stroke(width = 3.dp.toPx()),
            )

            // Draw decorative corners overlay (CamScanner style)
            val cornerLen = 30.dp.toPx()
            val thick = 5.dp.toPx()
            val greenAccent = Color(0xFF00E676)

            // Top-left corner
            drawRect(greenAccent, Offset(left - 2, top - 2), Size(cornerLen, thick))
            drawRect(greenAccent, Offset(left - 2, top - 2), Size(thick, cornerLen))

            // Top-right corner
            drawRect(greenAccent, Offset(left + rectWidth - cornerLen + 2, top - 2), Size(cornerLen, thick))
            drawRect(greenAccent, Offset(left + rectWidth - thick + 2, top - 2), Size(thick, cornerLen))

            // Bottom-left corner
            drawRect(greenAccent, Offset(left - 2, top + rectHeight - thick + 2), Size(cornerLen, thick))
            drawRect(greenAccent, Offset(left - 2, top + rectHeight - cornerLen + 2), Size(thick, cornerLen))

            // Bottom-right corner
            drawRect(greenAccent, Offset(left + rectWidth - cornerLen + 2, top + rectHeight - thick + 2), Size(cornerLen, thick))
            drawRect(greenAccent, Offset(left + rectWidth - thick + 2, top + rectHeight - cornerLen + 2), Size(thick, cornerLen))
        }

        // Overlay Title Instructions
        Text(
            text = "ලියවිල්ල කොටුව තුළට සමපාත කරන්න\n(Align document inside the frame)",
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 40.dp)
                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        // Flashlight Button Overlay
        IconButton(
            onClick = {
                val currentCam = camera
                if (currentCam != null && currentCam.cameraInfo.hasFlashUnit()) {
                    isFlashOn = !isFlashOn
                    currentCam.cameraControl.enableTorch(isFlashOn)
                }
            },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 40.dp, end = 20.dp)
                .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                .testTag("flashlight_toggle")
        ) {
            Icon(
                imageVector = if (isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                contentDescription = "Flash Toggle",
                tint = if (isFlashOn) Color(0xFFFFB300) else Color.White
            )
        }

        // Bottom Controls Layout
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 48.dp, start = 24.dp, end = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Close / Cancel Button
            Button(
                onClick = onClose,
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                Spacer(modifier = Modifier.width(6.dp))
                Text("පසුපසට (Back)", fontSize = 12.sp)
            }

            // Capture Shutter Button
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .clickable {
                        val capture = imageCapture ?: return@clickable
                        val file = File(context.cacheDir, "temp_scan_${System.currentTimeMillis()}.jpg")
                        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

                        capture.takePicture(
                            outputOptions,
                            ContextCompat.getMainExecutor(context),
                            object : ImageCapture.OnImageSavedCallback {
                                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                    cameraExecutor.execute {
                                        try {
                                            // 1. Decode original captured photo
                                            val originalBitmap = BitmapFactory.decodeFile(file.absolutePath)
                                            if (originalBitmap != null) {
                                                // 2. Perform Hardware-Accelerated High-Contrast Processing
                                                val processedBitmap = applyHighContrastFilters(originalBitmap)
                                                
                                                // 3. Save processed high-contrast bitmap back to file
                                                FileOutputStream(file).use { out ->
                                                    processedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                                                }
                                                processedBitmap.recycle()
                                                originalBitmap.recycle()
                                            }

                                            // 4. Return processed Uri on UI thread
                                            ContextCompat.getMainExecutor(context).execute {
                                                onImageCaptured(Uri.fromFile(file))
                                            }
                                        } catch (e: Exception) {
                                            Log.e("DocumentScanner", "Processing failed", e)
                                        }
                                    }
                                }

                                override fun onError(exc: ImageCaptureException) {
                                    Log.e("DocumentScanner", "Photo capture failed: ${exc.message}", exc)
                                }
                            }
                        )
                    }
                    .padding(4.dp)
                    .border(3.dp, Color(0xFFFFB300), CircleShape)
                    .testTag("scanner_capture_button")
            )

            // Hidden placeholder to balance Row
            Spacer(modifier = Modifier.width(60.dp))
        }
    }
}

/**
 * Natively performs extremely fast high-contrast filter processing using Android's
 * hardware-accelerated ColorMatrix logic to maximize text readability (CamScanner effect).
 */
private fun applyHighContrastFilters(src: Bitmap): Bitmap {
    val dest = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(dest)
    val paint = Paint()

    val saturationMatrix = ColorMatrix().apply { setSaturation(0.0f) } // grayscale conversion
    val contrastValue = 2.0f
    val translateValue = -128f * contrastValue + 128f
    val contrastMatrixArray = floatArrayOf(
        contrastValue, 0f, 0f, 0f, translateValue,
        0f, contrastValue, 0f, 0f, translateValue,
        0f, 0f, contrastValue, 0f, translateValue,
        0f, 0f, 0f, 1f, 0f
    )
    val contrastMatrix = ColorMatrix(contrastMatrixArray)

    // Concatenate matrices: saturation first, then contrast
    val finalMatrix = ColorMatrix().apply {
        set(saturationMatrix)
        postConcat(contrastMatrix)
    }

    paint.colorFilter = ColorMatrixColorFilter(finalMatrix)
    canvas.drawBitmap(src, 0f, 0f, paint)
    return dest
}
