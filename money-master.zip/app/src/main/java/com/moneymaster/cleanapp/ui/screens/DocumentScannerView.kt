package com.moneymaster.cleanapp.ui.screens

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult

@Composable
fun DocumentScannerView(
    requirePdf: Boolean = false,
    onImageCaptured: (Uri) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var isScanningTriggered by remember { mutableStateOf(false) }

    val scannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val scanResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)
            if (scanResult != null) {
                if (requirePdf && scanResult.pdf != null) {
                    onImageCaptured(scanResult.pdf!!.uri)
                } else if (scanResult.pages != null && scanResult.pages!!.isNotEmpty()) {
                    onImageCaptured(scanResult.pages!![0].imageUri)
                } else {
                    Toast.makeText(context, "No scanned content found", Toast.LENGTH_SHORT).show()
                    onClose()
                }
            } else {
                Toast.makeText(context, "Failed to retrieve scan results", Toast.LENGTH_SHORT).show()
                onClose()
            }
        } else {
            // Cancelled or failed
            onClose()
        }
    }

    val triggerScan = {
        val activity = getComponentActivity(context)
        if (activity == null) {
            Toast.makeText(context, "Activity context not found", Toast.LENGTH_SHORT).show()
            onClose()
        } else {
            val options = GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(100)
                .setResultFormats(
                    GmsDocumentScannerOptions.RESULT_FORMAT_JPEG,
                    GmsDocumentScannerOptions.RESULT_FORMAT_PDF
                )
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()

            val scanner = GmsDocumentScanning.getClient(options)
            scanner.getStartScanIntent(activity)
                .addOnSuccessListener { intentSender ->
                    val intentSenderRequest = IntentSenderRequest.Builder(intentSender).build()
                    scannerLauncher.launch(intentSenderRequest)
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Error starting scanner: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                    onClose()
                }
        }
    }

    LaunchedEffect(Unit) {
        if (!isScanningTriggered) {
            isScanningTriggered = true
            triggerScan()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            .testTag("document_scanner_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            CircularProgressIndicator(color = Color(0xFFFFB300))
            
            Text(
                text = "ලියකියවිලි ස්කෑනරය සූදානම් කරමින්...\n(Preparing ML Kit Document Scanner...)",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { triggerScan() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300), contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Scan")
                Spacer(modifier = Modifier.width(8.dp))
                Text("නැවත උත්සාහ කරන්න (Retry Scan)", fontWeight = FontWeight.Bold)
            }

            TextButton(onClick = onClose) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.Gray)
                Spacer(modifier = Modifier.width(6.dp))
                Text("පසුපසට (Go Back)", color = Color.Gray)
            }
        }
    }
}

private fun getComponentActivity(context: Context): Activity? {
    var ctx = context
    while (ctx is android.content.ContextWrapper) {
        if (ctx is Activity) {
            return ctx
        }
        ctx = ctx.baseContext
    }
    return null
}
