const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');

admin.initializeApp({
  projectId: 'school-app-a3c7c',
});

const db = getFirestore();

async function run() {
  console.log('Running v2 query...');
  const collections = await db.listCollections();
  console.log('Collections:', collections.map(c => c.id));
}

run().catch(console.error);
