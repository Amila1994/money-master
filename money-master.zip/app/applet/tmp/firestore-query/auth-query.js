const admin = require('firebase-admin');

admin.initializeApp({
  projectId: 'school-app-a3c7c',
});

async function run() {
  console.log('Admin keys:', Object.keys(admin));
  try {
    const { getAuth } = require('firebase-admin/auth');
    const auth = getAuth();
    const userRecord = await auth.getUserByEmail('amilalasantha940703@gmail.com');
    console.log('Successfully fetched user data:', JSON.stringify(userRecord, null, 2));
  } catch (error) {
    console.error('Error fetching user:', error.message);
  }
}

run().catch(console.error);
