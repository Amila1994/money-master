const http = require('https');

const apiKey = 'AIzaSyCefA1J1zN6ePNzafqnNOfr-hNvCeA2NyI';
const projectId = 'school-app-a3c7c';
const email = 'amilalasantha940703@gmail.com';
const emailShort = 'amilalasantha940703';
const collections = ['users', 'members', 'money_master', 'ads', 'streaks', 'payments', 'packages', 'customers', 'schools'];

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  console.log('Querying Firestore REST API...');
  for (const col of collections) {
    for (const id of [email, emailShort]) {
      const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/${col}/${encodeURIComponent(id)}?key=${apiKey}`;
      try {
        const res = await fetchUrl(url);
        if (res.status === 200) {
          console.log(`[${col}] doc(${id}):`, JSON.stringify(res.body, null, 2));
        } else if (res.status !== 404) {
          console.log(`[${col}] doc(${id}) - Status: ${res.status}`, JSON.stringify(res.body));
        }
      } catch (e) {
        console.error(`Error fetching ${col}/${id}:`, e.message);
      }
    }
  }
}

run();
