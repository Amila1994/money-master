const http = require('https');

const apiKey = 'AIzaSyCefA1J1zN6ePNzafqnNOfr-hNvCeA2NyI';
const projectId = 'school-app-a3c7c';
const collections = ['users', 'money_master', 'ads', 'streaks', 'payments', 'packages', 'customers'];

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  console.log('Querying Firestore all documents...');
  for (const col of collections) {
    const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/(default)/documents/${col}?key=${apiKey}`;
    try {
      const res = await fetchUrl(url);
      if (res.status === 200) {
        console.log(`[${col}] documents:`, JSON.stringify(res.body, null, 2));
      } else {
        console.log(`[${col}] Status: ${res.status}`, JSON.stringify(res.body));
      }
    } catch (e) {
      console.error(`Error fetching ${col}:`, e.message);
    }
  }
}

run();
