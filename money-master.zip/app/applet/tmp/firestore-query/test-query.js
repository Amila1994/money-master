const admin = require('firebase-admin');
const { getFirestore } = require('firebase-admin/firestore');

admin.initializeApp({
  projectId: 'school-app-a3c7c',
});

const db = getFirestore();

async function run() {
  console.log('Querying Firestore collections...');
  const collections = await db.listCollections();
  console.log('Collections:', collections.map(c => c.id));
  
  const email = 'amilalasantha940703@gmail.com';
  const emailShort = 'amilalasantha940703';
  const cols = ['users', 'members', 'money_master', 'ads', 'streaks', 'payments', 'packages', 'customers', 'schools'];
  
  for (const col of cols) {
    try {
      const snap1 = await db.collection(col).doc(email).get();
      if (snap1.exists) {
        console.log(`[${col}] doc(${email}):`, snap1.data());
      }
      const snap2 = await db.collection(col).doc(emailShort).get();
      if (snap2.exists) {
        console.log(`[${col}] doc(${emailShort}):`, snap2.data());
      }
    } catch (e) {
      console.error(`Error querying ${col}:`, e.message);
    }
  }
}

run().catch(console.error);
