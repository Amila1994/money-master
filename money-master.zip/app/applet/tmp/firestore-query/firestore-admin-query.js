const admin = require('firebase-admin');

admin.initializeApp({
  projectId: 'school-app-a3c7c',
});

const db = admin.firestore();

async function run() {
  console.log('Running firestore admin query...');
  
  // List collections
  const collections = await db.listCollections();
  console.log('Collections:', collections.map(c => c.id));
  
  // Let's query amilalasantha940703@gmail.com and amilalasantha940703 in common collections
  const email = 'amilalasantha940703@gmail.com';
  const emailShort = 'amilalasantha940703';
  const cols = ['users', 'members', 'money_master', 'ads', 'streaks', 'payments', 'packages', 'customers', 'schools'];
  
  for (const col of cols) {
    try {
      const snap1 = await db.collection(col).doc(email).get();
      if (snap1.exists) {
        console.log(`[${col}] doc(${email}):`, snap1.data());
      }
      const snap2 = await db.collection(col).doc(emailShort).get();
      if (snap2.exists) {
        console.log(`[${col}] doc(${emailShort}):`, snap2.data());
      }
      
      const query1 = await db.collection(col).where('email', '==', email).get();
      if (!query1.empty) {
        query1.forEach(doc => {
          console.log(`[${col}] query(email==${email}) doc(${doc.id}):`, doc.data());
        });
      }
      
      const query2 = await db.collection(col).where('email', '==', emailShort).get();
      if (!query2.empty) {
        query2.forEach(doc => {
          console.log(`[${col}] query(email==${emailShort}) doc(${doc.id}):`, doc.data());
        });
      }
    } catch (e) {
      console.error(`Error querying ${col}:`, e.message);
    }
  }
}

run().catch(console.error);
