const { Firestore } = require('@google-cloud/firestore');

async function run() {
  const db = new Firestore({
    projectId: 'school-app-a3c7c',
  });

  console.log('Listing top-level collections...');
  const collections = await db.listCollections();
  for (const col of collections) {
    console.log(`Collection: ${col.id}`);
  }

  // Check schools collection
  console.log('Checking "schools" collection...');
  try {
    const schoolsRef = db.collection('schools');
    const schoolsSnap = await schoolsRef.limit(10).get();
    schoolsSnap.forEach(doc => {
      console.log(`School Document ID: ${doc.id}, data:`, doc.data());
    });
  } catch (err) {
    console.error('Error reading schools:', err);
  }

  // Check if there is a money master or user specific collection
  const userEmail = 'amilalasantha940703@gmail.com';
  console.log(`Searching for email ${userEmail} in all collections...`);
  // Let's check some common collections
  const commonCollections = ['users', 'members', 'money_master', 'ads', 'streaks', 'payments', 'packages', 'customers'];
  for (const colName of commonCollections) {
    try {
      const colRef = db.collection(colName);
      const docRef = colRef.doc(userEmail);
      const docSnap = await docRef.get();
      if (docSnap.exists) {
        console.log(`FOUND in ${colName}:`, docSnap.data());
      } else {
        // also try query where email == userEmail
        const qSnap = await colRef.where('email', '==', userEmail).get();
        if (!qSnap.empty) {
          qSnap.forEach(doc => {
            console.log(`FOUND via query in ${colName} (ID: ${doc.id}):`, doc.data());
          });
        }
      }
    } catch (err) {
      console.error(`Error querying ${colName}:`, err.message);
    }
  }
}

run().catch(console.error);
