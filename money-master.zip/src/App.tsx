import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { AuthModal } from './components/AuthModal';
import { PinLockModal } from './components/PinLockModal';
import { StudentList } from './components/StudentList';
import { ExamActivity } from './components/ExamActivity';
import { AttendanceActivity } from './components/AttendanceActivity';
import { TeacherAttendanceActivity } from './components/TeacherAttendanceActivity';
import { TimetableActivity } from './components/TimetableActivity';
import { AdditionsActivity } from './components/AdditionsActivity';
import { SettingsActivity } from './components/SettingsActivity';
import { LiveStatusDashboard } from './components/LiveStatusDashboard';
import {
  Users, GraduationCap, CalendarCheck, Clock, Bell, Settings, LayoutDashboard,
  TrendingUp, Award, CheckCircle2, ChevronRight, UserCheck, Key, Share2
} from 'lucide-react';
import { t } from './utils/i18n';

const MainAppContent: React.FC = () => {
  const { activeTab, setActiveTab, settingsSubTab, setSettingsSubTab, students, attendanceRecords, examRecords, settings } = useApp();
  const [isLiveModalOpen, setIsLiveModalOpen] = useState(true);

  // Dashboard Stats
  const totalStudents = students.length;
  const presentToday = students.filter(s => s.isPresent).length;
  const attendanceRate = totalStudents > 0 ? Math.round((presentToday / totalStudents) * 100) : 0;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative">
      <Header />
      <AuthModal />
      <PinLockModal />
      <LiveStatusDashboard isOpen={isLiveModalOpen} onClose={() => setIsLiveModalOpen(false)} />

      {/* Main Navigation Bar */}
      <nav className="bg-slate-900/90 border-b border-slate-800 sticky top-0 sm:top-[65px] z-20 backdrop-blur-md px-2 sm:px-4 py-2 w-full max-w-full overflow-x-hidden">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 overflow-x-auto no-scrollbar scroll-smooth w-full pb-1">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'dashboard' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>{t('dashboard', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('students')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'students' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <Users className="w-4 h-4" />
            <span>{t('students', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('exams')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'exams' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>{t('exams', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'attendance' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <CalendarCheck className="w-4 h-4" />
            <span>{t('attendance', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('teacher_attendance')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'teacher_attendance' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <UserCheck className="w-4 h-4" />
            <span>{t('teacher_attendance', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('timetable')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'timetable' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <Clock className="w-4 h-4" />
            <span>{t('timetable', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('notes')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'notes' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <Bell className="w-4 h-4" />
            <span>{t('notes', settings.language)}</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'settings' && settingsSubTab !== 'handover' ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'}`}
          >
            <Settings className="w-4 h-4" />
            <span>{t('settings', settings.language)}</span>
          </button>

          <button
            onClick={() => { setActiveTab('settings'); setSettingsSubTab('handover'); }}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap shrink-0 ${activeTab === 'settings' && settingsSubTab === 'handover' ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20' : 'text-emerald-400 hover:text-emerald-300 hover:bg-slate-800/60 border border-emerald-500/30 bg-emerald-500/10'}`}
          >
            <Share2 className="w-4 h-4" />
            <span>{settings.language === 'si' ? '📥 පන්ති Handover' : '📥 Class Handover'}</span>
          </button>
        </div>
      </nav>

      {/* Main Body */}
      <main className="flex-1 max-w-full overflow-x-hidden overflow-y-auto p-3 sm:p-6 w-full mx-auto space-y-6">
        {activeTab === 'dashboard' && (
          <div className="space-y-6 max-w-7xl mx-auto">
            {/* Hero Welcome Card */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950 border border-slate-800 p-4 sm:p-6 rounded-2xl shadow-xl relative overflow-hidden flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="relative z-10 max-w-xl">
                <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-3 py-1 rounded-full inline-block mb-2 sm:mb-3">
                  🏫 {t('school_hub', settings.language)} • {t('dashboard', settings.language)}
                </span>
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-100 tracking-tight">
                  {t('school_hub', settings.language)}
                </h2>
                <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                  {t('student_directory_desc', settings.language)}
                </p>
              </div>

              <div className="shrink-0 relative z-10 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => { setActiveTab('settings'); setSettingsSubTab('handover'); }}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-3.5 py-2.5 rounded-xl text-xs shadow-lg shadow-emerald-500/20 flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  <span>📥 {settings.language === 'si' ? 'පන්ති Handover' : 'Class Handover'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsLiveModalOpen(true)}
                  className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition group cursor-pointer border border-cyan-400/30"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-950 animate-ping"></span>
                  <span>⚡ {settings.language === 'si' ? 'සජීවී Live පුවරුව බලන්න' : 'View Live Status Modal'}</span>
                </button>
              </div>
            </div>

            {/* Core Summary Cards Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              <div
                onClick={() => setActiveTab('students')}
                className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 p-4 sm:p-5 rounded-2xl shadow-xl cursor-pointer transition group"
              >
                <div className="flex items-center justify-between mb-2 sm:mb-3">
                  <div className="w-8 sm:w-10 h-8 sm:h-10 bg-cyan-500/10 border border-cyan-500/30 rounded-xl flex items-center justify-center text-cyan-400">
                    <Users className="w-4 sm:w-5 h-4 sm:h-5" />
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 transition" />
                </div>
                <p className="text-[10px] sm:text-xs text-slate-400 font-semibold uppercase">{t('total_students', settings.language)}</p>
                <p className="text-xl sm:text-2xl font-extrabold text-slate-100 mt-1">{totalStudents}</p>
                <p className="text-[10px] sm:text-[11px] text-cyan-400 mt-1 sm:mt-2 font-medium truncate">{t('student_roster', settings.language)}</p>
              </div>

              <div
                onClick={() => setActiveTab('attendance')}
                className="bg-slate-900 border border-slate-800 hover:border-emerald-500/50 p-4 sm:p-5 rounded-2xl shadow-xl cursor-pointer transition group"
              >
                <div className="flex items-center justify-between mb-2 sm:mb-3">
                  <div className="w-8 sm:w-10 h-8 sm:h-10 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-center text-emerald-400">
                    <CalendarCheck className="w-4 sm:w-5 h-4 sm:h-5" />
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-emerald-400 transition" />
                </div>
                <p className="text-[10px] sm:text-xs text-slate-400 font-semibold uppercase">{t('attendance_today', settings.language)}</p>
                <p className="text-xl sm:text-2xl font-extrabold text-slate-100 mt-1">{attendanceRate}%</p>
                <p className="text-[10px] sm:text-[11px] text-emerald-400 mt-1 sm:mt-2 font-medium truncate">{presentToday} / {totalStudents} {t('present', settings.language)}</p>
              </div>

              <div
                onClick={() => setActiveTab('exams')}
                className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-4 sm:p-5 rounded-2xl shadow-xl cursor-pointer transition group"
              >
                <div className="flex items-center justify-between mb-2 sm:mb-3">
                  <div className="w-8 sm:w-10 h-8 sm:h-10 bg-blue-500/10 border border-blue-500/30 rounded-xl flex items-center justify-center text-blue-400">
                    <GraduationCap className="w-4 sm:w-5 h-4 sm:h-5" />
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-blue-400 transition" />
                </div>
                <p className="text-[10px] sm:text-xs text-slate-400 font-semibold uppercase">{t('term_exams', settings.language)}</p>
                <p className="text-xl sm:text-2xl font-extrabold text-slate-100 mt-1">{examRecords.length}</p>
                <p className="text-[10px] sm:text-[11px] text-blue-400 mt-1 sm:mt-2 font-medium truncate">{t('exams_ranks', settings.language)}</p>
              </div>

              <div
                onClick={() => setActiveTab('timetable')}
                className="bg-slate-900 border border-slate-800 hover:border-purple-500/50 p-4 sm:p-5 rounded-2xl shadow-xl cursor-pointer transition group"
              >
                <div className="flex items-center justify-between mb-2 sm:mb-3">
                  <div className="w-8 sm:w-10 h-8 sm:h-10 bg-purple-500/10 border border-purple-500/30 rounded-xl flex items-center justify-center text-purple-400">
                    <Clock className="w-4 sm:w-5 h-4 sm:h-5" />
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-purple-400 transition" />
                </div>
                <p className="text-[10px] sm:text-xs text-slate-400 font-semibold uppercase">{t('timetable', settings.language)}</p>
                <p className="text-xl sm:text-2xl font-extrabold text-slate-100 mt-1">Mon - Fri</p>
                <p className="text-[10px] sm:text-[11px] text-purple-400 mt-1 sm:mt-2 font-medium truncate">{t('class_timetable', settings.language)}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'students' && <div className="max-w-7xl mx-auto"><StudentList /></div>}
        {activeTab === 'exams' && <div className="max-w-7xl mx-auto"><ExamActivity /></div>}
        {activeTab === 'attendance' && <div className="max-w-7xl mx-auto"><AttendanceActivity /></div>}
        {activeTab === 'teacher_attendance' && <div className="max-w-7xl mx-auto"><TeacherAttendanceActivity /></div>}
        {activeTab === 'timetable' && <div className="max-w-7xl mx-auto"><TimetableActivity /></div>}
        {activeTab === 'notes' && <div className="max-w-7xl mx-auto"><AdditionsActivity /></div>}
        {activeTab === 'settings' && <div className="max-w-7xl mx-auto"><SettingsActivity /></div>}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-4 px-6 text-center text-xs text-slate-500 mt-auto">
        Classroom Hub v1.0 • Built for Teachers & Students • Live Web Preview Pane
      </footer>
    </div>
  );
};

export function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}

export default App;
