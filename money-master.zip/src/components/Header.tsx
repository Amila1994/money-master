import React from 'react';
import { useApp } from '../context/AppContext';
import { Cloud, CheckCircle2, RefreshCw, Lock, LogIn, Globe } from 'lucide-react';
import { t } from '../utils/i18n';

export const Header: React.FC = () => {
  const { session, setIsAuthModalOpen, settings, isSyncing, lastSyncTime, triggerDriveSync, setIsPinLocked } = useApp();

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-30 px-3 sm:px-4 py-2.5 sm:py-3 shadow-lg w-full max-w-full overflow-x-hidden">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 sm:gap-3">
        {/* Left Branding */}
        <div className="flex items-center space-x-2.5 sm:space-x-3 min-w-0">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-white font-bold text-lg sm:text-xl shadow-md shadow-cyan-500/20 shrink-0">
            🏫
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-base sm:text-lg font-bold text-slate-100 leading-tight tracking-tight flex items-center gap-1.5 sm:gap-2 truncate">
              <span className="truncate">{t('school_hub', settings.language)}</span>
              <span className="text-[10px] sm:text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded-full font-medium shrink-0">
                v1.0 • Live Drive Auto-Sync
              </span>
            </h1>
            <p className="text-[11px] sm:text-xs text-slate-400 truncate">{session.schoolName} • {session.displayName}</p>
          </div>
        </div>

        {/* Sync Header & Quick Actions */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Google Drive 1s Realtime Auto-Sync Widget */}
          <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl px-2.5 sm:px-3 py-1.5 text-xs text-slate-300">
            {isSyncing ? (
              <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin shrink-0" />
            ) : (
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            )}
            <div className="flex flex-col">
              <span className="text-[9px] sm:text-[10px] text-slate-400 font-medium leading-none flex items-center gap-1">
                <span>{t('drive_auto_sync_1s', settings.language)}</span>
              </span>
              <span className="text-slate-200 font-semibold text-[10px] sm:text-[11px] leading-tight truncate max-w-[120px] sm:max-w-none">
                {isSyncing ? t('purging_syncing', settings.language) : `${t('synced_at', settings.language)} ${lastSyncTime}`}
              </span>
            </div>
            <button
              onClick={() => triggerDriveSync()}
              disabled={isSyncing}
              className="ml-0.5 p-1 hover:bg-slate-800 rounded-lg transition text-cyan-400 disabled:opacity-50"
              title="Force Sync & Purge Old Revisions"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Country & Language Indicator */}
          <div className="flex items-center gap-1.5 bg-slate-800/80 border border-slate-700/60 rounded-xl px-2.5 py-1.5 text-xs text-slate-300">
            <span className="text-sm">{settings.countryFlag || '🇱🇰'}</span>
            <span className="font-medium text-slate-200 text-xs uppercase">
              {settings.language}
            </span>
          </div>

          {/* Security Lock Toggle */}
          {settings.pinLockEnabled && (
            <button
              onClick={() => setIsPinLocked(true)}
              className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-semibold transition"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{t('lock_app', settings.language)}</span>
            </button>
          )}

          {/* Account Login / Profile */}
          <button
            onClick={() => setIsAuthModalOpen(true)}
            className="flex items-center gap-1.5 sm:gap-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-medium text-slate-200 transition"
          >
            {session.isLoggedIn ? (
              <>
                <img src={session.photoUrl} alt="Avatar" className="w-4 h-4 sm:w-5 sm:h-5 rounded-full object-cover border border-cyan-400" />
                <span className="truncate max-w-[80px] sm:max-w-[100px]">{session.displayName}</span>
              </>
            ) : (
              <>
                <LogIn className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t('google_sign_in', settings.language)}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
