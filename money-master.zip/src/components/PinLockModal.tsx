import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Lock,
  KeyRound,
  AlertCircle,
  CheckCircle2,
  Mail,
  Send,
  RefreshCw,
  ShieldCheck,
  ArrowLeft,
  Key,
  Sparkles
} from 'lucide-react';

export const PinLockModal: React.FC = () => {
  const { isPinLocked, setIsPinLocked, verifyPin, settings, updateSettings, session } = useApp();
  
  // View states: 'ENTER_PIN' | 'ENTER_OTP' | 'CREATE_NEW_PIN' | 'SECURITY_QUESTION'
  const [view, setView] = useState<'ENTER_PIN' | 'ENTER_OTP' | 'CREATE_NEW_PIN' | 'SECURITY_QUESTION'>('ENTER_PIN');
  
  const [pinInput, setPinInput] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  
  // OTP Reset states
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);
  const [otpInput, setOtpInput] = useState('');
  const [isSendingOtp, setIsSendingOtp] = useState(false);
  const [otpSentNotification, setOtpSentNotification] = useState<string | null>(null);

  // New PIN creation states
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');

  // Security question state (fallback)
  const [answerInput, setAnswerInput] = useState('');

  if (!isPinLocked) return null;

  // Auto-detected registered Google email from session context
  const registeredEmail = session?.email || 'amila940703@gmail.com';
  const lang = settings.language || 'si';

  // 1. Handle normal PIN Unlock
  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyPin(pinInput)) {
      setErrorMsg('');
      setIsPinLocked(false);
      setPinInput('');
    } else {
      setErrorMsg(lang === 'si' ? 'අවලංගු PIN අංකයකි. නැවත උත්සාහ කරන්න.' : 'Incorrect Security PIN. Please try again.');
      setPinInput('');
    }
  };

  // 2. Generate and send 6-Digit OTP via registered email
  const handleSendEmailOtp = () => {
    setIsSendingOtp(true);
    setErrorMsg('');
    
    // Generate random 6-digit OTP code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(code);

    setTimeout(() => {
      setIsSendingOtp(false);
      setView('ENTER_OTP');
      setOtpSentNotification(`OTP Verification code sent to ${registeredEmail}`);
    }, 800);
  };

  // 3. Verify OTP Code
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (otpInput.trim() === generatedOtp) {
      setSuccessMsg(lang === 'si' ? 'OTP අංකය සාර්ථකයි! නව PIN අංකයක් සාදන්න.' : 'OTP Verified successfully! Create your new PIN.');
      setTimeout(() => {
        setSuccessMsg('');
        setView('CREATE_NEW_PIN');
      }, 1000);
    } else {
      setErrorMsg(lang === 'si' ? 'අවලංගු OTP අංකයකි. පරීක්ෂා කර නැවත ඇතුළත් කරන්න.' : 'Invalid OTP code. Please check your email and try again.');
    }
  };

  // 4. Save New PIN and Unlock App
  const handleSaveNewPin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      setErrorMsg(lang === 'si' ? 'PIN අංකය ඉලක්කම් 4 කින් සමන්විත විය යුතුය.' : 'PIN must be exactly 4 numeric digits.');
      return;
    }

    if (newPin !== confirmPin) {
      setErrorMsg(lang === 'si' ? 'නව PIN අංක ගැළපෙන්නේ නැත.' : 'New PINs do not match.');
      return;
    }

    // Update settings in context & LocalStorage
    updateSettings({ securityPin: newPin });
    setSuccessMsg(lang === 'si' ? 'නව PIN අංකය සාර්ථකව සුරකින ලදී! Unlock වෙමින්...' : 'New PIN saved successfully! Unlocking app...');

    setTimeout(() => {
      setIsPinLocked(false);
      setView('ENTER_PIN');
      setPinInput('');
      setNewPin('');
      setConfirmPin('');
      setOtpInput('');
      setGeneratedOtp(null);
      setSuccessMsg('');
    }, 1200);
  };

  // 5. Fallback Security Question
  const handleVerifyAnswer = (e: React.FormEvent) => {
    e.preventDefault();
    if (answerInput.trim().toLowerCase() === settings.securityAnswer.trim().toLowerCase()) {
      setSuccessMsg(lang === 'si' ? 'පිළිතුර නිවැරදියි! Unlocking...' : 'Answer Verified! Unlocking...');
      setTimeout(() => {
        setIsPinLocked(false);
        setView('ENTER_PIN');
        setSuccessMsg('');
      }, 1200);
    } else {
      setErrorMsg(lang === 'si' ? 'ආරක්‍ෂිත ප්‍රශ්නයට පිළිතුර වැරදියි.' : 'Incorrect answer to security question.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl text-center relative overflow-hidden space-y-4">
        
        {/* Top Header Lock Icon */}
        <div className="w-14 h-14 sm:w-16 sm:h-16 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-center mx-auto text-amber-400 shadow-lg shadow-amber-500/10">
          <Lock className="w-7 h-7 sm:w-8 sm:h-8" />
        </div>

        <div>
          <h2 className="text-lg sm:text-xl font-extrabold text-slate-100">
            {lang === 'si' ? 'යෙදුම් ආරක්ෂණ පුවරුව' : 'App Security Lock'}
          </h2>
          
          {/* Linked Registered Google Email Display */}
          <div className="mt-2 inline-flex items-center gap-1.5 bg-slate-950 border border-slate-800 px-3 py-1 rounded-full text-xs text-slate-300 font-medium max-w-full truncate">
            <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-slate-400">{lang === 'si' ? 'සම්බන්ධිත ගිණුම:' : 'Linked Account:'}</span>
            <strong className="text-slate-200 truncate font-mono">{registeredEmail}</strong>
          </div>
        </div>

        {/* Global Notifications / Messages */}
        {errorMsg && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 animate-in slide-in-from-top-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 animate-in slide-in-from-top-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* VIEW 1: ENTER PIN */}
        {view === 'ENTER_PIN' && (
          <form onSubmit={handleUnlock} className="space-y-4 pt-1">
            <div>
              <label className="block text-xs text-slate-400 font-medium mb-1.5">
                {lang === 'si' ? 'අංක 4 න් යුත් PIN අංකය ඇතුළත් කරන්න' : 'Enter 4-Digit Security PIN'}
              </label>
              <input
                type="password"
                maxLength={4}
                value={pinInput}
                onChange={e => setPinInput(e.target.value)}
                placeholder="• • • •"
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-2xl px-4 py-3 text-center text-3xl font-mono tracking-[0.8em] text-slate-100 outline-none transition shadow-inner"
                autoFocus
              />
            </div>

            <button
              type="submit"
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-3 rounded-xl transition text-sm flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-amber-500/20"
            >
              <KeyRound className="w-4 h-4" />
              <span>{lang === 'si' ? 'යෙදුම Unlock කරන්න' : 'Unlock App'}</span>
            </button>

            {/* Email OTP Reset Action Button */}
            <div className="pt-2 border-t border-slate-800/80 space-y-2">
              <button
                type="button"
                onClick={handleSendEmailOtp}
                disabled={isSendingOtp}
                className="w-full bg-slate-800/90 hover:bg-slate-700/90 text-amber-400 hover:text-amber-300 border border-slate-700/60 font-semibold py-2.5 rounded-xl transition text-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSendingOtp ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                    <span>{lang === 'si' ? 'OTP කේතය යවමින්...' : 'Sending OTP to Email...'}</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5 text-amber-400" />
                    <span>{lang === 'si' ? 'ලියාපදිංචි Email එක හරහා PIN අංකය Reset කරන්න' : 'Reset PIN via Registered Email'}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => { setView('SECURITY_QUESTION'); setErrorMsg(''); }}
                className="text-[11px] text-slate-400 hover:text-slate-200 underline transition"
              >
                {lang === 'si' ? 'ආරක්‍ෂිත ප්‍රශ්නය මගින් PIN එක ලබාගන්න' : 'Use Security Question instead'}
              </button>
            </div>
          </form>
        )}

        {/* VIEW 2: ENTER OTP (Received via Email) */}
        {view === 'ENTER_OTP' && (
          <form onSubmit={handleVerifyOtp} className="space-y-4 pt-1 text-left">
            <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-300 font-bold">
                <span className="flex items-center gap-1.5 text-amber-400">
                  <Mail className="w-4 h-4" />
                  <span>{lang === 'si' ? 'Email OTP තහවුරු කිරීම' : 'Email OTP Verification'}</span>
                </span>
                <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded-full font-mono font-bold">
                  6-Digits
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {otpSentNotification || `A 6-digit verification OTP code was dispatched to ${registeredEmail}`}
              </p>
            </div>

            {/* Simulated Live OTP Dispatch Toast Box for instant user convenience */}
            {generatedOtp && (
              <div className="bg-amber-500/10 border border-amber-500/30 p-2.5 rounded-xl flex items-center justify-between text-xs">
                <span className="text-amber-300 font-medium flex items-center gap-1 text-[11px]">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>[Simulated Mail Inbox]:</span>
                </span>
                <span className="font-mono font-extrabold text-amber-300 bg-amber-950/80 border border-amber-500/40 px-2 py-0.5 rounded text-xs tracking-wider">
                  OTP Code: {generatedOtp}
                </span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {lang === 'si' ? 'ලැබුණු 6-Digit OTP කේතය ඇතුළත් කරන්න:' : 'Enter Received 6-Digit OTP:'}
              </label>
              <input
                type="text"
                maxLength={6}
                value={otpInput}
                onChange={e => setOtpInput(e.target.value)}
                placeholder="1 2 3 4 5 6"
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-4 py-2.5 text-center text-2xl font-mono tracking-[0.4em] text-amber-300 outline-none transition"
                autoFocus
                required
              />
            </div>

            <div className="flex items-center gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => { setView('ENTER_PIN'); setErrorMsg(''); }}
                className="w-1/3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{lang === 'si' ? 'ආපසු' : 'Back'}</span>
              </button>

              <button
                type="submit"
                className="w-2/3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-500/20"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{lang === 'si' ? 'OTP තහවුරු කරන්න' : 'Verify OTP Code'}</span>
              </button>
            </div>
          </form>
        )}

        {/* VIEW 3: CREATE NEW 4-DIGIT PIN */}
        {view === 'CREATE_NEW_PIN' && (
          <form onSubmit={handleSaveNewPin} className="space-y-3.5 pt-1 text-left">
            <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl">
              <h3 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                <Key className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'si' ? 'නව PIN අංකයක් සකසන්න' : 'Create New 4-Digit PIN'}</span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {lang === 'si' ? 'ඉදිරි යෙදුම් භාවිතය සඳහා නව PIN අංකය යොදන්න' : 'Set your new 4-digit code to unlock the app'}
              </p>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {lang === 'si' ? 'නව PIN අංකය (New PIN)' : 'New 4-Digit PIN'}
              </label>
              <input
                type="password"
                maxLength={4}
                value={newPin}
                onChange={e => setNewPin(e.target.value)}
                placeholder="• • • •"
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-center text-2xl font-mono tracking-[0.5em] text-slate-100 outline-none"
                autoFocus
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {lang === 'si' ? 'නව PIN අංකය තහවුරු කරන්න (Confirm PIN)' : 'Confirm New PIN'}
              </label>
              <input
                type="password"
                maxLength={4}
                value={confirmPin}
                onChange={e => setConfirmPin(e.target.value)}
                placeholder="• • • •"
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3 py-2 text-center text-2xl font-mono tracking-[0.5em] text-slate-100 outline-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2.5 rounded-xl transition text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{lang === 'si' ? 'නව PIN එක සුරකිමින් Unlock කරන්න' : 'Save PIN & Unlock App'}</span>
            </button>
          </form>
        )}

        {/* VIEW 4: FALLBACK SECURITY QUESTION */}
        {view === 'SECURITY_QUESTION' && (
          <form onSubmit={handleVerifyAnswer} className="space-y-4 pt-1 text-left">
            <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl">
              <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                {lang === 'si' ? 'ආරක්‍ෂිත ප්‍රශ්නය' : 'Security Question'}
              </span>
              <p className="text-xs text-amber-300 font-medium mt-0.5">{settings.securityQuestion}</p>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {lang === 'si' ? 'ඔබගේ පිළිතුර:' : 'Your Security Answer:'}
              </label>
              <input
                type="text"
                value={answerInput}
                onChange={e => setAnswerInput(e.target.value)}
                placeholder={lang === 'si' ? 'පිළිතුර ඇතුළත් කරන්න...' : 'Enter answer...'}
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-500 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none"
                required
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => { setView('ENTER_PIN'); setErrorMsg(''); }}
                className="w-1/2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium py-2.5 rounded-xl text-xs cursor-pointer"
              >
                {lang === 'si' ? 'ආපසු' : 'Back'}
              </button>
              <button
                type="submit"
                className="w-1/2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs cursor-pointer"
              >
                {lang === 'si' ? 'තහවුරු කර Unlock කරන්න' : 'Verify & Unlock'}
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};

