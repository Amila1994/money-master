import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { TeacherAttendanceRecord, TeacherAttendanceStatus } from '../types';
import {
  UserCheck,
  Calendar,
  Clock,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  XCircle,
  Briefcase,
  FileText,
  PieChart,
  X,
  Award,
  FileSpreadsheet,
  HeartPulse,
  Sparkles,
  Check,
  ShieldCheck,
  TrendingUp
} from 'lucide-react';
import { t } from '../utils/i18n';

export const TeacherAttendanceActivity: React.FC = () => {
  const {
    session,
    teacherAttendanceRecords,
    markTeacherAttendance,
    updateTeacherAttendance,
    deleteTeacherAttendance,
    settings
  } = useApp();

  const lang = settings.language || 'si';
  const todayStr = new Date().toISOString().split('T')[0];
  const teacherName = session.displayName || 'Sarath Gunawardena';

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<TeacherAttendanceRecord | null>(null);

  // Form Fields (For Add or Edit)
  const [formTeacherName, setFormTeacherName] = useState(teacherName);
  const [selectedDate, setSelectedDate] = useState(todayStr);
  const [status, setStatus] = useState<TeacherAttendanceStatus>('PRESENT');
  const [timeIn, setTimeIn] = useState('07:25 AM');
  const [timeOut, setTimeOut] = useState('01:30 PM');
  const [notes, setNotes] = useState('');

  // Relief Periods Covered Counter (with local storage persistence)
  const [reliefCoveredCount, setReliefCoveredCount] = useState<number>(() => {
    const saved = localStorage.getItem('ch_relief_count');
    return saved ? parseInt(saved, 10) : 8;
  });

  useEffect(() => {
    localStorage.setItem('ch_relief_count', reliefCoveredCount.toString());
  }, [reliefCoveredCount]);

  // Filter records for current logged-in teacher
  const myRecords = teacherAttendanceRecords.filter(r => r.teacherName === teacherName || !r.teacherName);
  
  // Stats Calculations
  const totalSchoolDays = Math.max(myRecords.length, 20); // standard benchmark 20 days
  const daysPresent = myRecords.filter(r => r.status === 'PRESENT' || r.status === 'ON_DUTY' || r.status === 'PAPER_MARKING').length;
  const daysAbsent = myRecords.filter(r => r.status === 'ABSENT').length;
  const daysLeave = myRecords.filter(r => r.status === 'LEAVE' || r.status === 'SICK_LEAVE' || r.status === 'HALF_DAY').length;
  const attendancePercentage = totalSchoolDays > 0 ? Math.round((daysPresent / totalSchoolDays) * 100) : 100;

  // Leave Tracker Calculations
  // Total entitlement benchmark: 21 Casual, 24 Sick, 10 Duty
  const totalCasualQuota = 21;
  const totalSickQuota = 24;

  const casualLeavesTaken = myRecords.filter(r => r.status === 'ABSENT' || r.status === 'LEAVE').length;
  const sickLeavesTaken = myRecords.filter(r => r.status === 'SICK_LEAVE').length;
  const dutyLeavesTaken = myRecords.filter(r => r.status === 'ON_DUTY' || r.status === 'PAPER_MARKING').length;

  const casualLeavesRemaining = Math.max(0, totalCasualQuota - casualLeavesTaken);
  const sickLeavesRemaining = Math.max(0, totalSickQuota - sickLeavesTaken);
  
  const totalQuota = totalCasualQuota + totalSickQuota; // 45 Days Total
  const totalTaken = casualLeavesTaken + sickLeavesTaken;
  const totalRemaining = Math.max(0, totalQuota - totalTaken);
  const leaveRemainingPercentage = Math.round((totalRemaining / totalQuota) * 100);

  // Quick Duty Remarks Pills
  const quickDutyPills = [
    { labelEn: 'Term Exam Paper Marking', labelSi: 'වාර විභාග ප්‍රශ්න පත්‍ර ඇගයීම' },
    { labelEn: 'Grade 10 Class Teacher Duty', labelSi: '10 ශ්‍රේණියේ පන්ති භාර රාජකාරිය' },
    { labelEn: 'Zonal Meeting / Seminar', labelSi: 'කලාපීය රැස්වීම / සම්මන්ත්‍රණය' },
    { labelEn: 'Sports Festival Duty', labelSi: 'ක්‍රීඩා උත්සව රාජකාරිය' },
    { labelEn: 'Science Lab Supervision', labelSi: 'විද්‍යාගාර නිරීක්ෂණය' },
    { labelEn: 'A/L Evaluation Duty', labelSi: 'උසස් පෙළ ඇගයීම් රාජකාරිය' }
  ];

  const handleOpenAdd = () => {
    setEditingRecord(null);
    setFormTeacherName(teacherName);
    setSelectedDate(todayStr);
    setStatus('PRESENT');
    setTimeIn('07:25 AM');
    setTimeOut('01:30 PM');
    setNotes('');
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (rec: TeacherAttendanceRecord) => {
    setEditingRecord(rec);
    setFormTeacherName(rec.teacherName || teacherName);
    setSelectedDate(rec.date);
    setStatus(rec.status);
    setTimeIn(rec.timeIn || '07:25 AM');
    setTimeOut(rec.timeOut || '01:30 PM');
    setNotes(rec.notes || '');
    setIsAddModalOpen(true);
  };

  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRecord) {
      updateTeacherAttendance(editingRecord.id, {
        teacherName: formTeacherName,
        date: selectedDate,
        status,
        timeIn,
        timeOut,
        notes
      });
    } else {
      markTeacherAttendance(formTeacherName, selectedDate, status, timeIn, timeOut, notes);
    }
    setIsAddModalOpen(false);
    setEditingRecord(null);
    setNotes('');
  };

  const getStatusBadge = (st: TeacherAttendanceStatus) => {
    switch (st) {
      case 'PRESENT':
        return (
          <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{lang === 'si' ? 'පැමිණ ඇත (Present)' : 'Present'}</span>
          </span>
        );
      case 'PAPER_MARKING':
        return (
          <span className="bg-purple-500/10 text-purple-300 border border-purple-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <FileSpreadsheet className="w-3.5 h-3.5 text-purple-400" />
            <span>{lang === 'si' ? 'ප්‍රශ්න පත්‍ර ඇගයීම' : 'Exam Paper Marking'}</span>
          </span>
        );
      case 'ON_DUTY':
        return (
          <span className="bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <Briefcase className="w-3.5 h-3.5" />
            <span>{lang === 'si' ? 'රාජකාරි සඳහා පිටත්ව (On Duty)' : 'On Duty / Seminar'}</span>
          </span>
        );
      case 'HALF_DAY':
        return (
          <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <Clock className="w-3.5 h-3.5" />
            <span>{lang === 'si' ? 'අර්ධ නිවාඩු (Half Day)' : 'Half Day Leave'}</span>
          </span>
        );
      case 'SICK_LEAVE':
        return (
          <span className="bg-rose-500/10 text-rose-300 border border-rose-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
            <span>{lang === 'si' ? 'ගිලන් නිවාඩු (Sick Leave)' : 'Sick Leave'}</span>
          </span>
        );
      case 'CASUAL_LEAVE':
        return (
          <span className="bg-amber-500/10 text-amber-300 border border-amber-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'si' ? 'පෞද්ගලික නිවාඩු (Casual Leave)' : 'Casual Leave'}</span>
          </span>
        );
      case 'ABSENT':
        return (
          <span className="bg-red-500/10 text-red-400 border border-red-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <XCircle className="w-3.5 h-3.5" />
            <span>{lang === 'si' ? 'පැමිණ නැත (Absent)' : 'Absent'}</span>
          </span>
        );
      case 'LEAVE':
      default:
        return (
          <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 shadow-sm">
            <FileText className="w-3.5 h-3.5" />
            <span>{lang === 'si' ? 'නිවාඩු (Leave)' : 'Approved Leave'}</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header Banner & Quick Action */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950 border border-slate-800 p-4 sm:p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-center text-emerald-400 shrink-0 shadow-lg shadow-emerald-500/10">
            <UserCheck className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-100 flex items-center gap-2">
              <span>{t('teacher_attendance', lang)}</span>
              <span className="text-[10px] sm:text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
                Official Teacher Log & Leave Tracker
              </span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'si'
                ? 'ගුරුවරයාගේ පැමිණීම, නිවාඩු ට්‍රැකර්, ප්‍රශ්න පත්‍ර ඇගයීම් සහ ආදේශක පන්ති වාර්තා'
                : 'Manage attendance records, leave balance quota, exam paper marking duties & relief substitution'}
            </p>
          </div>
        </div>

        <button
          onClick={handleOpenAdd}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition self-start md:self-auto border border-emerald-400/30 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{lang === 'si' ? 'පැමිණීම / නිවාඩු සටහන් කරන්න' : 'Mark / Log Attendance'}</span>
        </button>
      </div>

      {/* TOP SUMMARY STATS GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Benchmark */}
        <div className="bg-slate-900 border border-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] sm:text-xs font-bold uppercase">{t('total_school_days', lang)}</span>
            <Calendar className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-xl sm:text-2xl font-extrabold text-slate-100">{totalSchoolDays} {lang === 'si' ? 'දින' : 'Days'}</p>
          <p className="text-[10px] sm:text-[11px] text-cyan-400 font-medium">{lang === 'si' ? 'වාරයේ දින ගණන' : 'Term Benchmark'}</p>
        </div>

        {/* Days Present */}
        <div className="bg-slate-900 border border-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] sm:text-xs font-bold uppercase">{t('days_present', lang)}</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl sm:text-2xl font-extrabold text-emerald-400">{daysPresent} {lang === 'si' ? 'දින' : 'Days'}</p>
          <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium">
            {lang === 'si' ? 'රාජකාරි හා ඇගයීම් ඇතුළත්ව' : 'Includes On-Duty & Marking'}
          </p>
        </div>

        {/* Days Absent / Leave */}
        <div className="bg-slate-900 border border-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] sm:text-xs font-bold uppercase">{t('days_absent', lang)}</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-xl sm:text-2xl font-extrabold text-rose-400">{daysAbsent + daysLeave} {lang === 'si' ? 'දින' : 'Days'}</p>
          <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium">
            {daysLeave} {lang === 'si' ? 'අනුමත නිවාඩු' : 'Approved Leaves'}
          </p>
        </div>

        {/* Attendance Percentage */}
        <div className="bg-slate-900 border border-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-xl space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] sm:text-xs font-bold uppercase">{t('attendance_percentage', lang)}</span>
            <PieChart className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl sm:text-2xl font-extrabold text-amber-400">{attendancePercentage}%</p>
          <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden">
            <div className="bg-amber-400 h-1.5 rounded-full" style={{ width: `${attendancePercentage}%` }}></div>
          </div>
        </div>
      </div>

      {/* COMPREHENSIVE TEACHER LEAVE TRACKER & EXTRA FEATURES */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* LEAVE TRACKER DASHBOARD CARD (Left 2 Columns) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">
                  {lang === 'si' ? 'ගුරු නිවාඩු ට්‍රැකර් (Leave Tracker)' : 'Teacher Leave Balance Tracker'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {lang === 'si' ? 'වසරේ ගන්නා ලද සහ ඉතිරි නිවාඩු ශේෂය' : 'Annual entitlement vs used leave breakdown'}
                </p>
              </div>
            </div>

            <span className="text-xs bg-purple-500/10 text-purple-300 border border-purple-500/20 px-3 py-1 rounded-full font-bold">
              {totalRemaining} / {totalQuota} {lang === 'si' ? 'ඉතිරි දින' : 'Days Remaining'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Casual Leaves */}
            <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'si' ? 'පෞද්ගලික නිවාඩු (Casual)' : 'Casual Leaves'}</span>
                <span className="text-[9px] text-cyan-400 font-mono font-bold">{casualLeavesRemaining} {lang === 'si' ? 'ඉතිරියි' : 'Left'}</span>
              </div>
              <p className="text-lg font-extrabold text-cyan-300">
                {casualLeavesTaken} <span className="text-xs text-slate-500 font-normal">/ {totalCasualQuota}</span>
              </p>
              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-cyan-400 h-1.5 rounded-full"
                  style={{ width: `${Math.min(100, (casualLeavesTaken / totalCasualQuota) * 100)}%` }}
                ></div>
              </div>
            </div>

            {/* Sick Leaves */}
            <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'si' ? 'ගිලන් නිවාඩු (Sick/Rest)' : 'Sick Leaves'}</span>
                <span className="text-[9px] text-rose-400 font-mono font-bold">{sickLeavesRemaining} {lang === 'si' ? 'ඉතිරියි' : 'Left'}</span>
              </div>
              <p className="text-lg font-extrabold text-rose-300">
                {sickLeavesTaken} <span className="text-xs text-slate-500 font-normal">/ {totalSickQuota}</span>
              </p>
              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-rose-400 h-1.5 rounded-full"
                  style={{ width: `${Math.min(100, (sickLeavesTaken / totalSickQuota) * 100)}%` }}
                ></div>
              </div>
            </div>

            {/* Duty & Exam Marking Leaves */}
            <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-bold uppercase">{lang === 'si' ? 'රාජකාරි නිවාඩු (Duty)' : 'Duty & Seminars'}</span>
                <span className="text-[9px] text-purple-400 font-mono font-bold">{dutyLeavesTaken} {lang === 'si' ? 'ලබාගෙන ඇත' : 'Days'}</span>
              </div>
              <p className="text-lg font-extrabold text-purple-300">
                {dutyLeavesTaken} <span className="text-xs text-slate-500 font-normal">{lang === 'si' ? 'දින' : 'Days'}</span>
              </p>
              <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-purple-400 h-1.5 rounded-full"
                  style={{ width: `${Math.min(100, (dutyLeavesTaken / 15) * 100)}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Overall Remaining Leave Progress Ring Bar */}
          <div className="bg-slate-950/60 border border-slate-800 p-3 rounded-xl flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <p className="text-xs font-bold text-slate-200">
                {lang === 'si' ? 'මුළු නිවාඩු ශේෂ ප්‍රතිශතය' : 'Total Remaining Leave Quota'}
              </p>
              <p className="text-[11px] text-slate-400">
                {lang === 'si' ? `ලබාගත් මුළු නිවාඩු: දින ${totalTaken}යි` : `Total leaves taken this year: ${totalTaken} days`}
              </p>
            </div>
            
            <div className="flex items-center gap-2 shrink-0">
              <div className="w-24 bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-800 p-0.5">
                <div
                  className="bg-gradient-to-r from-emerald-400 to-cyan-400 h-full rounded-full transition-all duration-500"
                  style={{ width: `${leaveRemainingPercentage}%` }}
                ></div>
              </div>
              <span className="font-mono text-xs font-extrabold text-emerald-400">{leaveRemainingPercentage}%</span>
            </div>
          </div>
        </div>

        {/* EXTRA TEACHER FEATURE: SUBSTITUTION / RELIEF TRACKER */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col justify-between space-y-3">
          <div className="space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-100">
                    {lang === 'si' ? 'ආදේශක පන්ති ට්‍රැකර්' : 'Relief Covered Tracker'}
                  </h3>
                  <p className="text-[10px] text-slate-400">Substitution periods covered</p>
                </div>
              </div>

              <span className="text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20 px-2 py-0.5 rounded-full font-bold">
                This Month
              </span>
            </div>

            <div className="text-center py-2 bg-slate-950/80 border border-slate-800 rounded-xl space-y-1">
              <p className="text-xs text-slate-400 font-semibold">{lang === 'si' ? 'ආවරණය කළ ආදේශක කාලච්ඡේද' : 'Relief Periods Covered'}</p>
              <p className="text-3xl font-extrabold text-amber-400 font-mono">{reliefCoveredCount} <span className="text-xs font-sans text-slate-400">Periods</span></p>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => setReliefCoveredCount(prev => Math.max(0, prev - 1))}
              className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold py-1.5 rounded-xl text-xs transition border border-slate-700/60"
            >
              - 1 Period
            </button>
            <button
              type="button"
              onClick={() => setReliefCoveredCount(prev => prev + 1)}
              className="flex-1 bg-amber-600 hover:bg-amber-500 text-slate-950 font-extrabold py-1.5 rounded-xl text-xs transition border border-amber-400/30 shadow-md shadow-amber-500/10"
            >
              + 1 Period
            </button>
          </div>
        </div>

      </div>

      {/* ATTENDANCE LOG RECORDS TABLE */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-100">
              {lang === 'si' ? 'ගුරු පැමිණීමේ හා නිවාඩු ලේඛන වාර්තා' : 'Attendance Log & Duty Records for'} {teacherName}
            </h3>
          </div>
          <span className="text-xs text-slate-400 bg-slate-950 px-2.5 py-1 rounded-full border border-slate-800">
            {myRecords.length} {lang === 'si' ? 'සටහන් logged' : 'records logged'}
          </span>
        </div>

        <div className="overflow-x-auto w-full">
          <table className="w-full text-xs text-left text-slate-300">
            <thead className="bg-slate-950 text-slate-400 font-semibold border-b border-slate-800 uppercase text-[10px]">
              <tr>
                <th className="p-3">{lang === 'si' ? 'දිනය' : 'Date'}</th>
                <th className="p-3">{lang === 'si' ? 'ගුරුවරයා' : 'Teacher'}</th>
                <th className="p-3">{lang === 'si' ? 'තත්ත්වය' : 'Status'}</th>
                <th className="p-3">{lang === 'si' ? 'පැමිණි වේලාව' : 'Time In'}</th>
                <th className="p-3">{lang === 'si' ? 'පිටවූ වේලාව' : 'Time Out'}</th>
                <th className="p-3">{lang === 'si' ? 'රාජකාරි / විස්තර' : 'Duty / Remarks'}</th>
                <th className="p-3 text-right">{lang === 'si' ? 'ක්‍රියාමාර්ග' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {myRecords.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-6 text-center text-slate-500">
                    {lang === 'si'
                      ? 'තවමත් පැමිණීම් සටහන් කර නොමැත. ඉහත "පැමිණීම / නිවාඩු සටහන් කරන්න" බොත්තම ඔබන්න!'
                      : 'No teacher attendance records logged yet. Click "Mark / Log Attendance" above!'}
                  </td>
                </tr>
              ) : (
                myRecords.map(rec => (
                  <tr key={rec.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3 font-semibold text-slate-200 whitespace-nowrap">{rec.date}</td>
                    <td className="p-3 text-slate-100 font-medium whitespace-nowrap">{rec.teacherName}</td>
                    <td className="p-3 whitespace-nowrap">
                      {getStatusBadge(rec.status)}
                    </td>
                    <td className="p-3 text-slate-300 font-mono whitespace-nowrap">{rec.timeIn || '--:--'}</td>
                    <td className="p-3 text-slate-300 font-mono whitespace-nowrap">{rec.timeOut || '--:--'}</td>
                    <td className="p-3 text-slate-300 max-w-[220px] truncate">{rec.notes || 'Normal School Duty'}</td>
                    <td className="p-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(rec)}
                          className="p-1.5 text-cyan-400 hover:text-cyan-200 hover:bg-cyan-500/10 rounded-lg transition border border-cyan-500/20"
                          title={lang === 'si' ? 'සංස්කරණය' : 'Edit Record'}
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteTeacherAttendance(rec.id)}
                          className="p-1.5 text-rose-400 hover:text-rose-200 hover:bg-rose-500/10 rounded-lg transition border border-rose-500/20"
                          title={lang === 'si' ? 'මකන්න' : 'Delete Record'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MARK / EDIT ATTENDANCE MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-3xl p-5 sm:p-6 shadow-2xl relative my-auto">
            
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-800 transition"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-100">
                {editingRecord
                  ? (lang === 'si' ? 'පැමිණීමේ සටහන සංස්කරණය' : 'Edit Attendance Record')
                  : t('mark_teacher_attendance', lang)}
              </h3>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              {lang === 'si' ? 'තත්ත්වය, වේලාවන් සහ රාජකාරි විස්තර ඇතුළත් කරන්න' : 'Update status, check-in times & duty remarks'}
            </p>

            <form onSubmit={handleSaveSubmit} className="space-y-3.5 text-xs">
              
              {/* Teacher Name */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {lang === 'si' ? 'ගුරුවරයාගේ නම' : 'Teacher Name'}
                </label>
                <input
                  type="text"
                  required
                  value={formTeacherName}
                  onChange={e => setFormTeacherName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Date */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {lang === 'si' ? 'දිනය' : 'Date'}
                </label>
                <input
                  type="date"
                  required
                  value={selectedDate}
                  onChange={e => setSelectedDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Enhanced Attendance Status Selection */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {lang === 'si' ? 'පැමිණීමේ / නිවාඩු තත්ත්වය' : 'Attendance / Leave Status'}
                </label>
                <select
                  value={status}
                  onChange={e => setStatus(e.target.value as TeacherAttendanceStatus)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-emerald-500 text-xs"
                >
                  <option value="PRESENT">✅ PRESENT ({lang === 'si' ? 'පැමිණ ඇත - Full Day' : 'Full Day Present'})</option>
                  <option value="PAPER_MARKING">📝 PAPER_MARKING ({lang === 'si' ? 'ප්‍රශ්න පත්‍ර ඇගයීම් රාජකාරි' : 'Exam Paper Marking'})</option>
                  <option value="ON_DUTY">💼 ON_DUTY ({lang === 'si' ? 'රාජකාරි සඳහා පිටත්ව ගොස් ඇත' : 'On Duty / Seminar'})</option>
                  <option value="HALF_DAY">🕒 HALF_DAY ({lang === 'si' ? 'අර්ධ නිවාඩු' : 'Half Day'})</option>
                  <option value="CASUAL_LEAVE">🌴 CASUAL_LEAVE ({lang === 'si' ? 'පෞද්ගලික නිවාඩු' : 'Casual Leave'})</option>
                  <option value="SICK_LEAVE">🏥 SICK_LEAVE ({lang === 'si' ? 'ගිලන් නිවාඩු' : 'Sick Leave'})</option>
                  <option value="ABSENT">❌ ABSENT ({lang === 'si' ? 'පැමිණ නැත' : 'Absent'})</option>
                </select>
              </div>

              {/* Time In & Time Out */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {lang === 'si' ? 'පැමිණි වේලාව (Time In)' : 'Time In'}
                  </label>
                  <input
                    type="text"
                    value={timeIn}
                    onChange={e => setTimeIn(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                    placeholder="07:25 AM"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    {lang === 'si' ? 'පිටවූ වේලාව (Time Out)' : 'Time Out'}
                  </label>
                  <input
                    type="text"
                    value={timeOut}
                    onChange={e => setTimeOut(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-mono focus:outline-none focus:border-emerald-500"
                    placeholder="01:30 PM"
                  />
                </div>
              </div>

              {/* Remarks / Duty Input with Quick Shortcut Pills */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  {lang === 'si' ? 'රාජකාරි / සටහන් (Duty / Remarks)' : 'Duty Remarks'}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-emerald-500"
                  placeholder={lang === 'si' ? 'උදා: 10-A පන්ති භාර රාජකාරිය' : 'e.g. Grade 10-A Class Teacher Duty'}
                />

                {/* Quick Duty Shortcut Pills */}
                <div className="mt-2 space-y-1">
                  <span className="text-[10px] text-slate-400 font-semibold block">
                    ⚡ {lang === 'si' ? 'ඉක්මන් රාජකාරි සටහන් (Quick Duty Remarks):' : 'Quick Remarks Shortcuts:'}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {quickDutyPills.map((pill, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setNotes(lang === 'si' ? pill.labelSi : pill.labelEn)}
                        className="text-[9px] bg-slate-800 hover:bg-emerald-500/20 hover:text-emerald-300 text-slate-300 border border-slate-700 hover:border-emerald-500/30 px-2 py-1 rounded-lg transition"
                      >
                        + {lang === 'si' ? pill.labelSi : pill.labelEn}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Submit / Cancel Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl transition"
                >
                  {lang === 'si' ? 'අවලංගු කරන්න' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-5 py-2 rounded-xl transition shadow-lg shadow-emerald-500/20 border border-emerald-400/30"
                >
                  {editingRecord
                    ? (lang === 'si' ? 'වෙනස්කම් සුරකින්න' : 'Update Record')
                    : (lang === 'si' ? 'සටහන සුරකින්න' : 'Save Record')}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}
    </div>
  );
};
