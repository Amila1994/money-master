import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AttendanceStatus } from '../types';
import {
  CalendarCheck, Calendar, CheckCircle, XCircle, Clock, AlertCircle, Save, FileText, Check, Users
} from 'lucide-react';

export const AttendanceActivity: React.FC = () => {
  const { students, attendanceRecords, markAttendance, getAttendanceForDate, settings } = useApp();

  const [selectedDate, setSelectedDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );

  const dailyAttendanceMap = getAttendanceForDate(selectedDate);

  // Stats calculation
  const totalStudents = students.length;
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let excusedCount = 0;

  students.forEach(s => {
    const status = dailyAttendanceMap[s.id] || (s.isPresent ? 'PRESENT' : 'ABSENT');
    if (status === 'PRESENT') presentCount++;
    else if (status === 'ABSENT') absentCount++;
    else if (status === 'LATE') lateCount++;
    else if (status === 'EXCUSED') excusedCount++;
  });

  const attendancePercentage = totalStudents > 0
    ? Math.round(((presentCount + lateCount) / totalStudents) * 100)
    : 0;

  const handleStatusChange = (studentId: string, studentName: string, status: AttendanceStatus) => {
    markAttendance(studentId, studentName, selectedDate, status);
  };

  const handleMarkAllPresent = () => {
    students.forEach(s => {
      markAttendance(s.id, s.name, selectedDate, 'PRESENT');
    });
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-center text-emerald-400">
            <CalendarCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">
              {settings.language === 'si' ? 'පැමිණීම සටහන් කිරීම' : 'Daily Attendance Manager'}
            </h2>
            <p className="text-xs text-slate-400">Mark student presence, generate monthly registers & instant summary</p>
          </div>
        </div>

        {/* Date Selector */}
        <div className="flex items-center gap-3 bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs">
          <Calendar className="w-4 h-4 text-emerald-400" />
          <span className="text-slate-400 font-semibold">Select Date:</span>
          <input
            type="date"
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
            className="bg-transparent text-slate-100 font-bold outline-none cursor-pointer"
          />
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Class Attendance Rate</span>
          <p className="text-2xl font-extrabold text-emerald-400 mt-1">{attendancePercentage}%</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Present Count</span>
          <p className="text-2xl font-extrabold text-slate-100 mt-1">{presentCount}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Absent Count</span>
          <p className="text-2xl font-extrabold text-rose-400 mt-1">{absentCount}</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Late / Excused</span>
          <p className="text-2xl font-extrabold text-amber-400 mt-1">{lateCount + excusedCount}</p>
        </div>
      </div>

      {/* Control Bar & Quick Mark All */}
      <div className="flex items-center justify-between bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <span className="text-xs text-slate-300 font-medium">Marking for {selectedDate}</span>
        <button
          onClick={handleMarkAllPresent}
          className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center gap-1.5 transition"
        >
          <Check className="w-3.5 h-3.5" />
          <span>Mark All Present</span>
        </button>
      </div>

      {/* Attendance Table */}
      <div className="w-full overflow-x-auto max-w-full bg-slate-900 border border-slate-800 rounded-2xl shadow-xl">
        <table className="w-full text-left text-xs text-slate-300 min-w-[540px]">
          <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
            <tr>
              <th className="px-3 sm:px-4 py-3">Roll No</th>
              <th className="px-3 sm:px-4 py-3">Student Name</th>
              <th className="px-3 sm:px-4 py-3">Grade</th>
              <th className="px-3 sm:px-4 py-3 text-center">Status Control</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {students.map(student => {
              const currentStatus: AttendanceStatus = dailyAttendanceMap[student.id] || (student.isPresent ? 'PRESENT' : 'ABSENT');

              return (
                <tr key={student.id} className="hover:bg-slate-800/50 transition">
                  <td className="px-3 sm:px-4 py-3 font-bold text-cyan-400">#{student.rollNo}</td>
                  <td className="px-3 sm:px-4 py-3 font-bold text-slate-100">{student.name}</td>
                  <td className="px-3 sm:px-4 py-3 text-slate-400">{student.grade}</td>
                  <td className="px-3 sm:px-4 py-3">
                    <div className="flex items-center justify-center gap-1 sm:gap-1.5">
                      <button
                        onClick={() => handleStatusChange(student.id, student.name, 'PRESENT')}
                        className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${currentStatus === 'PRESENT' ? 'bg-emerald-500 text-slate-950 shadow-md' : 'bg-slate-950 text-slate-400 hover:bg-slate-800'}`}
                      >
                        <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>Present</span>
                      </button>

                      <button
                        onClick={() => handleStatusChange(student.id, student.name, 'ABSENT')}
                        className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${currentStatus === 'ABSENT' ? 'bg-rose-500 text-slate-950 shadow-md' : 'bg-slate-950 text-slate-400 hover:bg-slate-800'}`}
                      >
                        <XCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>Absent</span>
                      </button>

                      <button
                        onClick={() => handleStatusChange(student.id, student.name, 'LATE')}
                        className={`px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${currentStatus === 'LATE' ? 'bg-amber-500 text-slate-950 shadow-md' : 'bg-slate-950 text-slate-400 hover:bg-slate-800'}`}
                      >
                        <Clock className="w-3.5 h-3.5 shrink-0" />
                        <span>Late</span>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
