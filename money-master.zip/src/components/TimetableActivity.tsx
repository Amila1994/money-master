import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { TimetablePeriod } from '../types';
import { Clock, Plus, Trash2, BookOpen, MapPin, User, X, AlertCircle, Coffee, ArrowRight, Calendar, Sparkles } from 'lucide-react';
import { t } from '../utils/i18n';

const DAYS: ('Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday')[] = [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'
];

export const TimetableActivity: React.FC = () => {
  const { timetable, addTimetableEntry, deleteTimetableEntry, subjects, settings, session } = useApp();

  const [timetableType, setTimetableType] = useState<'CLASS' | 'TEACHER'>('CLASS');
  const [activeDay, setActiveDay] = useState<'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday'>('Monday');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Live Timer State
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Form State
  const [formData, setFormData] = useState<Omit<TimetablePeriod, 'id'>>({
    type: 'CLASS',
    day: 'Monday',
    startTime: '08:00',
    endTime: '08:40',
    subject: subjects[0] || 'Mathematics',
    teacher: session.displayName || 'Sarath Gunawardena',
    classroom: 'Room 10-A',
    isFreePeriod: false,
    isRelief: false,
    reliefTeacher: '',
    reliefNotes: ''
  });

  const activePeriods = timetable
    .filter(t => t.day === activeDay && (t.type || 'CLASS') === timetableType)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  // Determine current active period for Live Status Bar
  const currentDayName = DAYS[currentTime.getDay() - 1] || 'Monday';
  const nowHours = currentTime.getHours();
  const nowMins = currentTime.getMinutes();
  const nowSecs = currentTime.getSeconds();
  const nowInMins = nowHours * 60 + nowMins;

  const todayPeriods = timetable
    .filter(t => t.day === currentDayName && (t.type || 'CLASS') === timetableType)
    .sort((a, b) => a.startTime.localeCompare(b.startTime));

  let activeLivePeriod: TimetablePeriod | null = null;
  let nextLivePeriod: TimetablePeriod | null = null;
  let countdownSecondsStr = '';

  for (let i = 0; i < todayPeriods.length; i++) {
    const p = todayPeriods[i];
    const [sH, sM] = p.startTime.split(':').map(Number);
    const [eH, eM] = p.endTime.split(':').map(Number);
    const startMins = sH * 60 + sM;
    const endMins = eH * 60 + eM;

    if (nowInMins >= startMins && nowInMins < endMins) {
      activeLivePeriod = p;
      nextLivePeriod = todayPeriods[i + 1] || null;

      const remainingSecs = (endMins * 60) - (nowInMins * 60 + nowSecs);
      const remMins = Math.floor(remainingSecs / 60);
      const remSecs = remainingSecs % 60;
      countdownSecondsStr = `${remMins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
      break;
    } else if (nowInMins < startMins && !nextLivePeriod) {
      nextLivePeriod = p;
    }
  }

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    addTimetableEntry({
      ...formData,
      type: timetableType,
      day: activeDay
    });
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-500/10 border border-purple-500/30 rounded-2xl flex items-center justify-center text-purple-400 shrink-0">
            <Clock className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
              <span>{t('class_timetable', settings.language)}</span>
              <span className="text-xs bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2.5 py-0.5 rounded-full font-semibold">
                Live
              </span>
            </h2>
            <p className="text-xs text-slate-400">Class & Teacher Schedules with Live School Status Widget</p>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setTimetableType('CLASS')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              timetableType === 'CLASS'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>{t('class_timetable', settings.language)}</span>
          </button>
          <button
            onClick={() => setTimetableType('TEACHER')}
            className={`px-3 sm:px-4 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              timetableType === 'TEACHER'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>{t('teacher_timetable', settings.language)}</span>
          </button>
        </div>
      </div>

      {/* LIVE CLASS STATUS WIDGET / BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-purple-500/30 rounded-2xl p-4 sm:p-5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between gap-3 mb-3 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
            </span>
            <span>{t('live_status_bar', settings.language)} • {currentDayName} ({currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })})</span>
          </div>
          <span className="text-[11px] text-purple-300 font-semibold bg-purple-500/10 border border-purple-500/20 px-2.5 py-1 rounded-full">
            {timetableType === 'CLASS' ? 'Viewing Class Schedule' : 'Viewing Teacher Schedule'}
          </span>
        </div>

        {activeLivePeriod ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {/* Active Period */}
            <div className="bg-slate-950/80 border border-purple-500/40 rounded-xl p-3.5 relative">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-purple-400 font-bold uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>{t('active_period', settings.language)} ({activeLivePeriod.startTime} - {activeLivePeriod.endTime})</span>
                </span>
                {activeLivePeriod.isFreePeriod && (
                  <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] px-2 py-0.5 rounded-full font-bold">
                    {t('free_period', settings.language)}
                  </span>
                )}
                {activeLivePeriod.isRelief && (
                  <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] px-2 py-0.5 rounded-full font-bold">
                    {t('relief_class', settings.language)}
                  </span>
                )}
              </div>
              <p className="text-base font-bold text-slate-100">{activeLivePeriod.subject}</p>
              <p className="text-slate-300 font-medium">{activeLivePeriod.teacher}</p>
              <p className="text-slate-400 text-[11px] mt-0.5">Location: {activeLivePeriod.classroom}</p>
            </div>

            {/* Live Countdown */}
            <div className="bg-slate-950/80 border border-cyan-500/40 rounded-xl p-3.5 flex flex-col justify-center items-center text-center">
              <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider mb-1 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{t('time_remaining', settings.language)}</span>
              </span>
              <span className="text-2xl sm:text-3xl font-extrabold text-cyan-400 font-mono tracking-tight">
                {countdownSecondsStr}
              </span>
              <span className="text-[10px] text-slate-400 mt-1">Countdown until period ends</span>
            </div>

            {/* Next Period */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mb-1">
                {t('next_period', settings.language)}
              </span>
              {nextLivePeriod ? (
                <>
                  <p className="text-sm font-bold text-slate-200">{nextLivePeriod.subject} ({nextLivePeriod.startTime})</p>
                  <p className="text-slate-400 text-[11px]">{nextLivePeriod.teacher} • {nextLivePeriod.classroom}</p>
                  {nextLivePeriod.isFreePeriod && (
                    <span className="mt-1 inline-block text-[10px] text-amber-400 font-semibold">★ Free Period Upcoming</span>
                  )}
                </>
              ) : (
                <p className="text-slate-400 italic">No further periods scheduled for today</p>
              )}
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3 text-xs text-slate-300 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <Coffee className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Outside active school period or break interval. Next scheduled period:</span>
            </div>
            {nextLivePeriod ? (
              <span className="font-bold text-purple-300">{nextLivePeriod.subject} ({nextLivePeriod.startTime})</span>
            ) : (
              <span className="text-slate-400 italic">School hours finished</span>
            )}
          </div>
        )}
      </div>

      {/* Day Tabs & Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 text-xs overflow-x-auto no-scrollbar scroll-smooth flex-1">
          {DAYS.map(day => (
            <button
              key={day}
              onClick={() => setActiveDay(day)}
              className={`px-4 py-2 rounded-xl font-bold transition whitespace-nowrap shrink-0 ${
                activeDay === day ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {day}
            </button>
          ))}
        </div>

        <button
          onClick={() => {
            setFormData(prev => ({ ...prev, day: activeDay, type: timetableType }));
            setIsAddModalOpen(true);
          }}
          className="bg-purple-600 hover:bg-purple-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-500/20 transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add {timetableType === 'CLASS' ? 'Class' : 'Teacher'} Period</span>
        </button>
      </div>

      {/* Timetable List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {activePeriods.length === 0 ? (
          <div className="col-span-full bg-slate-900 border border-slate-800 p-8 rounded-2xl text-center text-slate-400 text-xs">
            No periods scheduled for {activeDay} ({timetableType === 'CLASS' ? 'Class' : 'Teacher'} Timetable). Click "Add Period" to create one!
          </div>
        ) : (
          activePeriods.map(period => (
            <div
              key={period.id}
              className={`bg-slate-900 border ${
                period.isRelief
                  ? 'border-rose-500/40 bg-rose-950/10'
                  : period.isFreePeriod
                  ? 'border-amber-500/40 bg-amber-950/10'
                  : 'border-slate-800'
              } p-4 sm:p-5 rounded-2xl shadow-xl flex flex-col justify-between relative`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="bg-purple-500/10 text-purple-300 border border-purple-500/30 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{period.startTime} - {period.endTime}</span>
                  </span>

                  <button
                    onClick={() => deleteTimetableEntry(period.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
                    title="Delete Entry"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-base sm:text-lg font-bold text-slate-100">{period.subject}</h3>
                  {period.isFreePeriod && (
                    <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] px-2 py-0.5 rounded-full font-bold">
                      {t('free_period', settings.language)}
                    </span>
                  )}
                  {period.isRelief && (
                    <span className="bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] px-2 py-0.5 rounded-full font-bold">
                      {t('relief_class', settings.language)}
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-300 flex items-center gap-1.5 mb-1">
                  <User className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                  <span>{period.teacher}</span>
                </p>
                <p className="text-xs text-slate-400 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>{period.classroom}</span>
                </p>

                {period.isRelief && (
                  <div className="mt-3 bg-rose-500/10 border border-rose-500/20 p-2 rounded-xl text-[11px] text-rose-300">
                    <p className="font-semibold">Relief Notes: {period.reliefNotes || 'Covering teacher duty'}</p>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal: Add Timetable Entry */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-slate-100 mb-1">
              Add {timetableType === 'CLASS' ? 'Class' : 'Teacher'} Timetable Period
            </h3>
            <p className="text-xs text-slate-400 mb-4">Set subject, timings, teacher, free period or relief status</p>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Day of Week</label>
                <select
                  value={formData.day}
                  onChange={e => setFormData({ ...formData, day: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                >
                  {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Start Time</label>
                  <input
                    type="time"
                    value={formData.startTime}
                    onChange={e => setFormData({ ...formData, startTime: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">End Time</label>
                  <input
                    type="time"
                    value={formData.endTime}
                    onChange={e => setFormData({ ...formData, endTime: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Subject Name</label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={e => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  placeholder="e.g. Mathematics, Free Period"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Teacher Name</label>
                <input
                  type="text"
                  required
                  value={formData.teacher}
                  onChange={e => setFormData({ ...formData, teacher: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Classroom / Location</label>
                <input
                  type="text"
                  value={formData.classroom}
                  onChange={e => setFormData({ ...formData, classroom: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-between border-t border-slate-800 pt-3">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isFreePeriod || false}
                    onChange={e => setFormData({ ...formData, isFreePeriod: e.target.checked })}
                    className="rounded text-purple-600 focus:ring-purple-500 bg-slate-950 border-slate-700"
                  />
                  <span>Mark as Free Period (හිස් කාලච්ඡේදය)</span>
                </label>
              </div>

              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isRelief || false}
                    onChange={e => setFormData({ ...formData, isRelief: e.target.checked })}
                    className="rounded text-rose-600 focus:ring-rose-500 bg-slate-950 border-slate-700"
                  />
                  <span>Mark as Relief Class (සහන කාලච්ඡේදය)</span>
                </label>
              </div>

              {formData.isRelief && (
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Relief Notes / Covered Teacher</label>
                  <input
                    type="text"
                    value={formData.reliefNotes || ''}
                    onChange={e => setFormData({ ...formData, reliefNotes: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                    placeholder="e.g. Covering for Mrs. Perera"
                  />
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-slate-800 text-slate-300 px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-500 text-white font-bold px-5 py-2 rounded-xl"
                >
                  Save Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
