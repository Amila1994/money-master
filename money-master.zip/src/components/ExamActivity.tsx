import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid
} from 'recharts';
import {
  GraduationCap, Award, Calculator, TrendingUp, BookOpen, Plus, Trash2, CheckCircle2, Save, FileSpreadsheet, Layers
} from 'lucide-react';

export const ExamActivity: React.FC = () => {
  const { students, subjects, addSubject, deleteSubject, examTerm, setExamTerm, examRecords, saveStudentMarks, settings } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'entry' | 'analytics' | 'config'>('entry');
  const [selectedSubject, setSelectedSubject] = useState<string>(subjects[0] || 'Mathematics');

  // Input marks state for Fast Mark Entry
  const [inputMarks, setInputMarks] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    students.forEach(s => {
      const rec = examRecords.find(r => r.studentId === s.id && r.examTerm === examTerm);
      if (rec && rec.subjectMarks[selectedSubject] !== undefined) {
        initial[s.id] = rec.subjectMarks[selectedSubject];
      } else {
        initial[s.id] = 75;
      }
    });
    return initial;
  });

  const handleMarkChange = (studentId: string, mark: number) => {
    setInputMarks(prev => ({ ...prev, [studentId]: Math.min(100, Math.max(0, mark)) }));
  };

  const handleSaveMarks = () => {
    students.forEach(student => {
      const existingRec = examRecords.find(r => r.studentId === student.id && r.examTerm === examTerm);
      const currentMarks = existingRec ? { ...existingRec.subjectMarks } : {};
      currentMarks[selectedSubject] = inputMarks[student.id] || 0;

      saveStudentMarks(
        student.id,
        student.name,
        student.rollNo,
        examTerm,
        currentMarks
      );
    });
    alert(`Marks for ${selectedSubject} (${examTerm}) successfully saved!`);
  };

  // Analytics Data Processing
  const termRecords = examRecords.filter(r => r.examTerm === examTerm);

  const gradeCountData = [
    { name: 'A+ (90-100)', value: termRecords.filter(r => r.average >= 90).length, color: '#10B981' },
    { name: 'A (75-89)', value: termRecords.filter(r => r.average >= 75 && r.average < 90).length, color: '#3B82F6' },
    { name: 'B (65-74)', value: termRecords.filter(r => r.average >= 65 && r.average < 75).length, color: '#06B6D4' },
    { name: 'C (55-64)', value: termRecords.filter(r => r.average >= 55 && r.average < 65).length, color: '#F59E0B' },
    { name: 'S/F (<55)', value: termRecords.filter(r => r.average < 55).length, color: '#EF4444' }
  ];

  const studentPerformanceBarData = termRecords.map(r => ({
    name: r.studentName,
    Average: r.average,
    Total: r.totalMarks
  }));

  const subjectAverageData = subjects.map(subj => {
    let sum = 0;
    let count = 0;
    termRecords.forEach(r => {
      if (r.subjectMarks[subj] !== undefined) {
        sum += r.subjectMarks[subj];
        count++;
      }
    });
    return {
      subject: subj,
      Average: count > 0 ? Math.round(sum / count) : 0
    };
  });

  const [newSubjectName, setNewSubjectName] = useState('');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-500/10 border border-blue-500/30 rounded-2xl flex items-center justify-center text-blue-400">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              {settings.language === 'si' ? 'විභාග සහ ලකුණු පුවරුව' : 'Exams & Marks Analytics'}
            </h2>
            <p className="text-xs text-slate-400">Fast term mark entry, automated grades & rank trajectory charts</p>
          </div>
        </div>

        {/* Term Exam Selector */}
        <div className="flex items-center gap-2 bg-slate-950 border border-slate-800 px-3 py-2 rounded-xl text-xs">
          <span className="text-slate-400 font-semibold">Active Term:</span>
          <select
            value={examTerm}
            onChange={e => setExamTerm(e.target.value)}
            className="bg-transparent text-cyan-400 font-bold outline-none cursor-pointer"
          >
            <option value="1st Term 2026" className="bg-slate-900">1st Term 2026</option>
            <option value="2nd Term 2026" className="bg-slate-900">2nd Term 2026</option>
            <option value="3rd Term 2026" className="bg-slate-900">3rd Term 2026</option>
          </select>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 text-xs overflow-x-auto no-scrollbar scroll-smooth w-full">
        <button
          onClick={() => setActiveSubTab('entry')}
          className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap shrink-0 ${activeSubTab === 'entry' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Fast Mark Entry</span>
        </button>
        <button
          onClick={() => setActiveSubTab('analytics')}
          className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap shrink-0 ${activeSubTab === 'analytics' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Results Analytics & Charts</span>
        </button>
        <button
          onClick={() => setActiveSubTab('config')}
          className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap shrink-0 ${activeSubTab === 'config' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
        >
          <Layers className="w-4 h-4" />
          <span>Subjects Config</span>
        </button>
      </div>

      {/* Sub-tab 1: Fast Mark Entry */}
      {activeSubTab === 'entry' && (
        <div className="space-y-4 w-full max-w-full overflow-x-hidden">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-900 p-3.5 sm:p-4 rounded-2xl border border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2.5 sm:gap-3">
              <span className="text-xs font-semibold text-slate-400 shrink-0">Select Subject:</span>
              <div className="flex flex-wrap gap-1.5">
                {subjects.map(subj => (
                  <button
                    key={subj}
                    onClick={() => setSelectedSubject(subj)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${selectedSubject === subj ? 'bg-cyan-500 text-slate-950' : 'bg-slate-950 text-slate-300 hover:bg-slate-800'}`}
                  >
                    {subj}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleSaveMarks}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 sm:px-5 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition self-start sm:self-auto shrink-0"
            >
              <Save className="w-4 h-4" />
              <span>Save Marks</span>
            </button>
          </div>

          <div className="w-full overflow-x-auto max-w-full bg-slate-900 border border-slate-800 rounded-2xl shadow-xl">
            <table className="w-full text-left text-xs text-slate-300 min-w-[580px]">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3">Roll No</th>
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">Grade</th>
                  <th className="px-4 py-3">Subject Mark (Out of 100)</th>
                  <th className="px-4 py-3">Auto Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {students.map(student => {
                  const mark = inputMarks[student.id] ?? 75;
                  let gradeBadge = 'F';
                  let badgeColor = 'text-rose-400 border-rose-500/30 bg-rose-500/10';
                  if (mark >= 90) { gradeBadge = 'A+'; badgeColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10'; }
                  else if (mark >= 75) { gradeBadge = 'A'; badgeColor = 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10'; }
                  else if (mark >= 65) { gradeBadge = 'B'; badgeColor = 'text-blue-400 border-blue-500/30 bg-blue-500/10'; }
                  else if (mark >= 55) { gradeBadge = 'C'; badgeColor = 'text-amber-400 border-amber-500/30 bg-amber-500/10'; }
                  else if (mark >= 35) { gradeBadge = 'S'; badgeColor = 'text-slate-400 border-slate-500/30 bg-slate-500/10'; }

                  return (
                    <tr key={student.id} className="hover:bg-slate-800/50 transition">
                      <td className="px-4 py-3 font-bold text-cyan-400">#{student.rollNo}</td>
                      <td className="px-4 py-3 font-bold text-slate-100">{student.name}</td>
                      <td className="px-4 py-3 text-slate-400">{student.grade}</td>
                      <td className="px-4 py-3">
                        <input
                          type="number"
                          min={0}
                          max={100}
                          value={mark}
                          onChange={e => handleMarkChange(student.id, parseInt(e.target.value) || 0)}
                          className="w-20 sm:w-24 bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl px-3 py-1.5 text-slate-100 font-bold text-center outline-none"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs font-bold px-2.5 py-1 rounded-full border ${badgeColor}`}>
                          {gradeBadge} ({mark}%)
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-tab 2: Results & Analytics */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Grade Distribution Chart */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <h3 className="font-bold text-slate-100 text-sm mb-1 flex items-center gap-2">
                <Award className="w-4 h-4 text-cyan-400" />
                <span>Grade Distribution ({examTerm})</span>
              </h3>
              <p className="text-xs text-slate-400 mb-4">Breakdown of student averages by letter grade</p>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={gradeCountData}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {gradeCountData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#f8fafc' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Subject Average Comparisons */}
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <h3 className="font-bold text-slate-100 text-sm mb-1 flex items-center gap-2">
                <Calculator className="w-4 h-4 text-blue-400" />
                <span>Subject Class Averages</span>
              </h3>
              <p className="text-xs text-slate-400 mb-4">Overall percentage average per subject</p>

              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={subjectAverageData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="subject" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} domain={[0, 100]} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#f8fafc' }} />
                    <Bar dataKey="Average" fill="#38bdf8" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Top Performers Leaderboard */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
            <h3 className="font-bold text-slate-100 text-sm mb-4 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Term Leaderboard & Rank Trajectory</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {termRecords.sort((a, b) => a.rank - b.rank).slice(0, 3).map(rec => (
                <div key={rec.studentId} className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400 text-base">
                    #{rec.rank}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-100 text-sm">{rec.studentName}</h4>
                    <p className="text-xs text-slate-400">Total: {rec.totalMarks} | Avg: {rec.average}% ({rec.grade})</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab 3: Subjects Configuration */}
      {activeSubTab === 'config' && (
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl space-y-4">
          <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span>Manage Curriculum Subjects</span>
          </h3>
          <p className="text-xs text-slate-400">Add or remove subjects tracked in mark sheets</p>

          <div className="flex gap-2 max-w-md">
            <input
              type="text"
              value={newSubjectName}
              onChange={e => setNewSubjectName(e.target.value)}
              placeholder="e.g. Health Science..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 outline-none"
            />
            <button
              onClick={() => {
                if (newSubjectName.trim()) {
                  addSubject(newSubjectName.trim());
                  setNewSubjectName('');
                }
              }}
              className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              <span>Add</span>
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-2">
            {subjects.map(subj => (
              <div key={subj} className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs text-slate-200 flex items-center gap-2">
                <span>{subj}</span>
                <button
                  onClick={() => deleteSubject(subj)}
                  className="text-slate-400 hover:text-rose-400 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
