import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ClassNote } from '../types';
import { Plus, Bell, BookOpen, Calendar, FileText, Trash2, X } from 'lucide-react';

export const AdditionsActivity: React.FC = () => {
  const { classNotes, addClassNote, deleteClassNote, session, settings } = useApp();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [filterType, setFilterType] = useState<string>('ALL');

  const [formData, setFormData] = useState<{
    title: string;
    content: string;
    type: 'ANNOUNCEMENT' | 'HOMEWORK' | 'ASSIGNMENT' | 'EXAM_NOTICE' | 'GENERAL_NOTE';
    author: string;
  }>({
    title: '',
    content: '',
    type: 'ANNOUNCEMENT',
    author: session.displayName || 'Teacher'
  });

  const filteredNotes = classNotes.filter(n => filterType === 'ALL' || n.type === filterType);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.content) return;
    addClassNote(formData);
    setIsAddModalOpen(false);
    setFormData({
      title: '',
      content: '',
      type: 'ANNOUNCEMENT',
      author: session.displayName || 'Teacher'
    });
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-center justify-center text-amber-400">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">
              {settings.language === 'si' ? 'විශේෂ සටහන් සහ නිවේදන' : 'Announcements & Homework'}
            </h2>
            <p className="text-xs text-slate-400">Post homework tasks, school announcements & class notes</p>
          </div>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 transition self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Announcement / Note</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 sm:gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 text-xs overflow-x-auto no-scrollbar scroll-smooth w-full">
        {['ALL', 'ANNOUNCEMENT', 'HOMEWORK', 'ASSIGNMENT', 'EXAM_NOTICE', 'GENERAL_NOTE'].map(type => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-3 sm:px-4 py-2 rounded-xl font-bold transition whitespace-nowrap shrink-0 ${filterType === type ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-slate-200'}`}
          >
            {type}
          </button>
        ))}
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredNotes.map(note => {
          let badgeColor = 'bg-amber-500/10 text-amber-400 border-amber-500/30';
          if (note.type === 'HOMEWORK') badgeColor = 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30';
          if (note.type === 'ASSIGNMENT') badgeColor = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
          if (note.type === 'EXAM_NOTICE') badgeColor = 'bg-purple-500/10 text-purple-400 border-purple-500/30';
          if (note.type === 'GENERAL_NOTE') badgeColor = 'bg-slate-700/40 text-slate-300 border-slate-600';

          return (
            <div key={note.id} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${badgeColor}`}>
                    {note.type}
                  </span>
                  <span className="text-[10px] text-slate-500">{note.date}</span>
                </div>

                <h3 className="text-base font-bold text-slate-100 mb-2">{note.title}</h3>
                <p className="text-xs text-slate-300 leading-relaxed mb-4">{note.content}</p>
              </div>

              <div className="flex items-center justify-between border-t border-slate-800 pt-3">
                <span className="text-[10px] text-slate-500">By {note.author}</span>
                <button
                  onClick={() => deleteClassNote(note.id)}
                  className="p-1 text-slate-500 hover:text-rose-400 rounded-lg hover:bg-slate-800 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Add Note */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-slate-100 mb-4">
              {settings.language === 'si' ? 'නව නිවේදනයක් / සටහනක් එක් කරන්න' : 'Create Announcement or Homework'}
            </h3>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  {settings.language === 'si' ? 'වර්ගය (Type)' : 'Type'}
                </label>
                <select
                  value={formData.type}
                  onChange={e => setFormData({ ...formData, type: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 font-bold focus:outline-none focus:border-amber-500"
                >
                  <option value="ANNOUNCEMENT">📢 ANNOUNCEMENT ({settings.language === 'si' ? 'දැනුම්දීම' : 'Announcement'})</option>
                  <option value="HOMEWORK">📚 HOMEWORK ({settings.language === 'si' ? 'ගෙදර වැඩ' : 'Homework'})</option>
                  <option value="ASSIGNMENT">📝 ASSIGNMENT ({settings.language === 'si' ? 'ඇගයීම්' : 'Assignment'})</option>
                  <option value="EXAM_NOTICE">🔔 EXAM_NOTICE ({settings.language === 'si' ? 'විභාග පණිවුඩ' : 'Exam Notice'})</option>
                  <option value="GENERAL_NOTE">📌 GENERAL_NOTE ({settings.language === 'si' ? 'සාමාන්‍ය සටහන' : 'General Note'})</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Title *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Details & Content *</label>
                <textarea
                  rows={4}
                  required
                  value={formData.content}
                  onChange={e => setFormData({ ...formData, content: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-slate-800 text-slate-300 px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2 rounded-xl"
                >
                  Post Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
