import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Student } from '../types';
import {
  Users, UserPlus, Search, Filter, Phone, Mail, MapPin, Calendar, BookOpen,
  Eye, Edit3, Trash2, History, X, Check, Award, ShieldAlert, ChevronRight, Plus
} from 'lucide-react';
import { t } from '../utils/i18n';

export const StudentList: React.FC = () => {
  const { students, addStudent, updateStudent, deleteStudent, settings, grades, addGrade } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [viewingStudent, setViewingStudent] = useState<Student | null>(null);
  const [historyStudent, setHistoryStudent] = useState<Student | null>(null);

  // New Grade Inline State
  const [showAddGradeBox, setShowAddGradeBox] = useState(false);
  const [newGradeInput, setNewGradeInput] = useState('');

  // Form State
  const [formData, setFormData] = useState<Partial<Student>>({
    name: '',
    nameWithInitials: '',
    rollNo: '',
    grade: grades[0] || 'Grade 10-A',
    marks: 75,
    isPresent: true,
    dob: '2010-01-01',
    gender: 'Male',
    ethnicity: 'Sinhalese',
    religion: 'Buddhism',
    medium: 'Sinhala',
    permAddress: '',
    fatherName: '',
    fatherNic: '',
    fatherPhone: '',
    motherName: '',
    motherNic: '',
    motherPhone: '',
    guardianName: '',
    emergencyPhone: ''
  });

  const filteredStudents = students.filter(s => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.rollNo.includes(searchQuery) ||
      (s.nameWithInitials && s.nameWithInitials.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
    return matchesSearch && matchesGrade;
  });

  const handleOpenAdd = () => {
    setEditingStudent(null);
    setFormData({
      name: '',
      nameWithInitials: '',
      rollNo: `100${students.length + 1}`,
      grade: 'Grade 10-A',
      marks: 75,
      isPresent: true,
      dob: '2010-01-01',
      gender: 'Male',
      ethnicity: 'Sinhalese',
      religion: 'Buddhism',
      medium: 'Sinhala',
      permAddress: '',
      fatherName: '',
      fatherNic: '',
      fatherPhone: '',
      motherName: '',
      motherNic: '',
      motherPhone: '',
      guardianName: '',
      emergencyPhone: ''
    });
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({ ...student });
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.rollNo) return;

    if (editingStudent) {
      updateStudent(editingStudent.id, formData);
    } else {
      addStudent(formData as Omit<Student, 'id'>);
    }
    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-cyan-500/10 border border-cyan-500/30 rounded-2xl flex items-center justify-center text-cyan-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              {settings.language === 'si' ? 'සිසුන් කළමනාකරණය' : 'Student Directory'}
              <span className="text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded-full font-medium">
                {students.length} Total
              </span>
            </h2>
            <p className="text-xs text-slate-400">View, add, edit, and track student profiles & year records</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleOpenAdd}
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition"
          >
            <UserPlus className="w-4 h-4" />
            <span>{settings.language === 'si' ? 'නව සිසුවෙකු එකතු කරන්න' : 'Add New Student'}</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={settings.language === 'si' ? 'නම හෝ අංකයෙන් සොයන්න...' : 'Search by name or Roll No...'}
            className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-700 px-3 py-1.5 rounded-xl text-xs text-slate-300">
            <Filter className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={selectedGrade}
              onChange={e => setSelectedGrade(e.target.value)}
              className="bg-transparent text-slate-200 font-medium outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900">All Grades</option>
              <option value="Grade 10-A" className="bg-slate-900">Grade 10-A</option>
              <option value="Grade 10-B" className="bg-slate-900">Grade 10-B</option>
              <option value="Grade 11-A" className="bg-slate-900">Grade 11-A</option>
            </select>
          </div>

          <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl p-1 text-xs">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1 rounded-lg transition ${viewMode === 'grid' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'}`}
            >
              Grid
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1 rounded-lg transition ${viewMode === 'list' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'}`}
            >
              List
            </button>
          </div>
        </div>
      </div>

      {/* Grid or List View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {filteredStudents.map(student => (
            <div
              key={student.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 sm:p-5 rounded-2xl shadow-lg transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-slate-800 to-slate-700 border border-slate-600 flex items-center justify-center text-base sm:text-lg font-bold text-cyan-400 shrink-0">
                      {student.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-bold text-slate-100 text-sm sm:text-base leading-snug group-hover:text-cyan-400 transition truncate">
                        {student.name}
                      </h3>
                      <p className="text-[11px] sm:text-xs text-slate-400 truncate">{student.nameWithInitials || student.name}</p>
                    </div>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${student.isPresent ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-rose-500/10 text-rose-400 border-rose-500/30'}`}>
                    {student.isPresent ? 'Present' : 'Absent'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/60 p-2.5 sm:p-3 rounded-xl border border-slate-800 mb-3 sm:mb-4">
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 font-semibold block uppercase">Roll / Index</span>
                    <span className="font-bold text-slate-200">#{student.rollNo}</span>
                  </div>
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 font-semibold block uppercase">Class / Grade</span>
                    <span className="font-bold text-cyan-400 truncate block">{student.grade}</span>
                  </div>
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 font-semibold block uppercase">Medium</span>
                    <span className="text-slate-300 truncate block">{student.medium || 'Sinhala'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] sm:text-[10px] text-slate-500 font-semibold block uppercase">Grade Rank</span>
                    <span className="text-amber-400 font-bold truncate block">{student.marks}% ({student.marks >= 75 ? 'A' : student.marks >= 65 ? 'B' : student.marks >= 55 ? 'C' : 'S'})</span>
                  </div>
                </div>

                {student.fatherPhone && (
                  <p className="text-[11px] sm:text-xs text-slate-400 flex items-center gap-1.5 mb-2 truncate">
                    <Phone className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span className="truncate">Father: {student.fatherPhone}</span>
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between border-t border-slate-800/80 pt-3 mt-2">
                <button
                  onClick={() => setViewingStudent(student)}
                  className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Details</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setHistoryStudent(student)}
                    className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded-lg transition"
                    title="Year History Log"
                  >
                    <History className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleOpenEdit(student)}
                    className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-slate-800 rounded-lg transition"
                    title="Edit Student"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => { if (confirm(`Delete student ${student.name}?`)) deleteStudent(student.id); }}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                    title="Delete Student"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List View */
        <div className="w-full overflow-x-auto max-w-full bg-slate-900 border border-slate-800 rounded-2xl shadow-xl">
          <table className="w-full text-left text-xs text-slate-300 min-w-[640px]">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="px-4 py-3">Roll No</th>
                <th className="px-4 py-3">Student Name</th>
                <th className="px-4 py-3">Grade</th>
                <th className="px-4 py-3">Gender / DOB</th>
                <th className="px-4 py-3">Parent Contact</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredStudents.map(student => (
                <tr key={student.id} className="hover:bg-slate-800/50 transition">
                  <td className="px-4 py-3 font-bold text-cyan-400">#{student.rollNo}</td>
                  <td className="px-4 py-3">
                    <p className="font-bold text-slate-100">{student.name}</p>
                    <p className="text-[11px] text-slate-400">{student.nameWithInitials}</p>
                  </td>
                  <td className="px-4 py-3">{student.grade}</td>
                  <td className="px-4 py-3">{student.gender || 'N/A'} • {student.dob || 'N/A'}</td>
                  <td className="px-4 py-3">{student.fatherPhone || student.motherPhone || 'N/A'}</td>
                  <td className="px-4 py-3 text-right space-x-2">
                    <button onClick={() => setViewingStudent(student)} className="text-cyan-400 hover:underline font-semibold">View</button>
                    <button onClick={() => handleOpenEdit(student)} className="text-blue-400 hover:underline font-semibold">Edit</button>
                    <button onClick={() => { if (confirm(`Delete ${student.name}?`)) deleteStudent(student.id); }} className="text-rose-400 hover:underline font-semibold">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal: Add/Edit Student */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl p-4 sm:p-6 shadow-2xl relative my-auto">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base sm:text-lg font-bold text-slate-100 mb-1">
              {editingStudent ? 'Edit Student Record' : 'Add New Student Record'}
            </h3>
            <p className="text-xs text-slate-400 mb-4 sm:mb-6">Enter official student details, parents information & emergency contacts</p>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Index / Roll Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.rollNo || ''}
                    onChange={e => setFormData({ ...formData, rollNo: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name || ''}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Name with Initials</label>
                  <input
                    type="text"
                    value={formData.nameWithInitials || ''}
                    onChange={e => setFormData({ ...formData, nameWithInitials: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-300 font-medium">Class / Grade *</label>
                    <button
                      type="button"
                      onClick={() => setShowAddGradeBox(!showAddGradeBox)}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-semibold"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add New Grade</span>
                    </button>
                  </div>

                  {showAddGradeBox ? (
                    <div className="flex items-center gap-1.5 mb-2">
                      <input
                        type="text"
                        placeholder="e.g. Grade 9-C"
                        value={newGradeInput}
                        onChange={e => setNewGradeInput(e.target.value)}
                        className="flex-1 bg-slate-950 border border-cyan-500/50 rounded-xl px-2.5 py-1.5 text-xs text-slate-100"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (newGradeInput.trim()) {
                            addGrade(newGradeInput.trim());
                            setFormData({ ...formData, grade: newGradeInput.trim() });
                            setNewGradeInput('');
                            setShowAddGradeBox(false);
                          }
                        }}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1.5 rounded-xl text-xs font-semibold"
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowAddGradeBox(false)}
                        className="bg-slate-800 text-slate-400 hover:text-slate-200 px-2 py-1.5 rounded-xl text-xs"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : null}

                  <select
                    value={formData.grade || (grades[0] || 'Grade 10-A')}
                    onChange={e => setFormData({ ...formData, grade: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  >
                    {grades.map(g => (
                      <option key={g} value={g}>{g}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={formData.dob || ''}
                    onChange={e => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Gender</label>
                  <select
                    value={formData.gender || 'Male'}
                    onChange={e => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Ethnicity & Religion</label>
                  <input
                    type="text"
                    value={`${formData.ethnicity || 'Sinhalese'}, ${formData.religion || 'Buddhism'}`}
                    onChange={e => {
                      const parts = e.target.value.split(',');
                      setFormData({ ...formData, ethnicity: parts[0]?.trim(), religion: parts[1]?.trim() });
                    }}
                    placeholder="e.g. Sinhalese, Buddhism"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Medium of Instruction</label>
                  <select
                    value={formData.medium || 'Sinhala'}
                    onChange={e => setFormData({ ...formData, medium: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="Sinhala">Sinhala</option>
                    <option value="English">English</option>
                    <option value="Tamil">Tamil</option>
                  </select>
                </div>
              </div>

              <hr className="border-slate-800 my-3" />
              <h4 className="text-xs font-bold text-cyan-400 uppercase">Parents & Guardian Information</h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Father's Name & Phone</label>
                  <input
                    type="text"
                    value={formData.fatherName || ''}
                    onChange={e => setFormData({ ...formData, fatherName: e.target.value })}
                    placeholder="Father Name"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 mb-2"
                  />
                  <input
                    type="text"
                    value={formData.fatherPhone || ''}
                    onChange={e => setFormData({ ...formData, fatherPhone: e.target.value })}
                    placeholder="Father Phone Number"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Mother's Name & Phone</label>
                  <input
                    type="text"
                    value={formData.motherName || ''}
                    onChange={e => setFormData({ ...formData, motherName: e.target.value })}
                    placeholder="Mother Name"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100 mb-2"
                  />
                  <input
                    type="text"
                    value={formData.motherPhone || ''}
                    onChange={e => setFormData({ ...formData, motherPhone: e.target.value })}
                    placeholder="Mother Phone Number"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1 text-xs">Permanent Residential Address</label>
                <textarea
                  rows={2}
                  value={formData.permAddress || ''}
                  onChange={e => setFormData({ ...formData, permAddress: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 px-5 py-2 rounded-xl text-xs font-bold"
                >
                  {editingStudent ? 'Update Record' : 'Save Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: View Student Profile */}
      {viewingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl p-4 sm:p-6 shadow-2xl relative">
            <button
              onClick={() => setViewingStudent(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 sm:gap-4 mb-4 border-b border-slate-800 pb-4 min-w-0">
              <div className="w-12 sm:w-16 h-12 sm:h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 flex items-center justify-center text-xl sm:text-2xl font-bold text-white shadow-lg shrink-0">
                {viewingStudent.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-bold text-slate-100 truncate">{viewingStudent.name}</h3>
                <p className="text-xs text-slate-400 truncate">{viewingStudent.nameWithInitials}</p>
                <span className="inline-block mt-1 bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full truncate">
                  Roll #{viewingStudent.rollNo} • {viewingStudent.grade}
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <p className="text-slate-400 font-medium">Personal Details:</p>
                <p className="text-slate-200 mt-1">
                  DOB: {viewingStudent.dob || 'N/A'} | Gender: {viewingStudent.gender || 'N/A'} | Medium: {viewingStudent.medium || 'Sinhala'}
                </p>
                <p className="text-slate-200 mt-1">Address: {viewingStudent.permAddress || 'No address provided'}</p>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <p className="text-slate-400 font-medium">Parents & Contact:</p>
                <p className="text-slate-200 mt-1">Father: {viewingStudent.fatherName || 'N/A'} ({viewingStudent.fatherPhone || 'No phone'})</p>
                <p className="text-slate-200 mt-1">Mother: {viewingStudent.motherName || 'N/A'} ({viewingStudent.motherPhone || 'No phone'})</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Year History Log */}
      {historyStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
            <button
              onClick={() => setHistoryStudent(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <History className="w-6 h-6 text-amber-400" />
              <div>
                <h3 className="font-bold text-slate-100 text-base">{historyStudent.name}'s History Log</h3>
                <p className="text-xs text-slate-400">Academic & Conduct Trajectory</p>
              </div>
            </div>

            <div className="space-y-3 text-xs max-h-72 overflow-y-auto pr-1">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-amber-400 font-bold uppercase">2026 Academic Year</span>
                <p className="text-slate-200 font-semibold mt-0.5">Enrolled in {historyStudent.grade}</p>
                <p className="text-slate-400 text-[11px] mt-1">Attendance: 92% | Term Rank: #2 in Class</p>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] text-slate-400 font-bold uppercase">2025 Academic Year</span>
                <p className="text-slate-200 font-semibold mt-0.5">Passed Grade 9-A with Distinction</p>
                <p className="text-slate-400 text-[11px] mt-1">Promoted by Class Teacher Sarath Kumara</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
