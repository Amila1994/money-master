import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Clock,
  UserCheck,
  Calendar,
  BookOpen,
  Timer,
  ArrowRight,
  School,
  X,
  User
} from 'lucide-react';
import { t } from '../utils/i18n';

export interface LiveStatusDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveStatusDashboard: React.FC<LiveStatusDashboardProps> = ({ isOpen, onClose }) => {
  const { timetable, session, settings } = useApp();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isOpen) return null;

  const lang = settings.language || 'si';

  // Day & Time Calculations
  const dayNames: ('Sunday' | 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday')[] = [
    'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
  ];
  const currentDay = dayNames[now.getDay()];
  const isWeekend = currentDay === 'Saturday' || currentDay === 'Sunday';

  const hours = now.getHours();
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();
  const currentTotalSec = hours * 3600 + minutes * 60 + seconds;

  // Default Daily Schedule Periods
  const defaultSchedule = [
    { period: 1, name: 'Period 1', start: '08:00', end: '08:40', startSec: 8 * 3600, endSec: 8 * 3600 + 40 * 60 },
    { period: 2, name: 'Period 2', start: '08:40', end: '09:20', startSec: 8 * 3600 + 40 * 60, endSec: 9 * 3600 + 20 * 60 },
    { period: 3, name: 'Period 3', start: '09:20', end: '10:00', startSec: 9 * 3600 + 20 * 60, endSec: 10 * 3600 },
    { period: 4, name: 'Period 4', start: '10:00', end: '10:40', startSec: 10 * 3600, endSec: 10 * 3600 + 40 * 60 },
    { period: 5, name: 'Interval / Break', start: '10:40', end: '11:00', startSec: 10 * 3600 + 40 * 60, endSec: 11 * 3600, isBreak: true },
    { period: 6, name: 'Period 5', start: '11:00', end: '11:40', startSec: 11 * 3600, endSec: 11 * 3600 + 40 * 60 },
    { period: 7, name: 'Period 6', start: '11:40', end: '12:20', startSec: 11 * 3600 + 40 * 60, endSec: 12 * 3600 + 20 * 60 },
    { period: 8, name: 'Period 7', start: '12:20', end: '13:00', startSec: 12 * 3600 + 20 * 60, endSec: 13 * 3600 },
    { period: 9, name: 'Period 8', start: '13:00', end: '13:30', startSec: 13 * 3600, endSec: 13 * 3600 + 30 * 60 }
  ];

  // Match active period from user's timetable or default schedule
  const todayTeacherPeriods = timetable.filter(t => t.type === 'TEACHER' && (t.day === currentDay || isWeekend));
  const todayClassPeriods = timetable.filter(t => (t.type === 'CLASS' || !t.type) && (t.day === currentDay || isWeekend));

  // Determine current active period slot
  let activeSlot = defaultSchedule.find(s => currentTotalSec >= s.startSec && currentTotalSec < s.endSec);
  let isOutsideSchoolHours = !activeSlot || isWeekend;

  // For demo & preview outside school hours: simulate active slot as Period 1
  const effectiveSlot = activeSlot || defaultSchedule[0];
  const totalSlotSec = effectiveSlot.endSec - effectiveSlot.startSec;
  const elapsedSec = isOutsideSchoolHours
    ? (currentTotalSec % totalSlotSec)
    : (currentTotalSec - effectiveSlot.startSec);
  const remainingSec = Math.max(0, totalSlotSec - elapsedSec);

  const remMins = Math.floor(remainingSec / 60);
  const remSecs = remainingSec % 60;
  const countdownStr = `${remMins.toString().padStart(2, '0')}:${remSecs.toString().padStart(2, '0')}`;
  const progressPercent = Math.min(100, Math.max(0, Math.round((elapsedSec / totalSlotSec) * 100)));

  // Teacher Schedule info for effective period
  const teacherCurrentPeriod = todayTeacherPeriods.find(p => p.startTime === effectiveSlot.start) || {
    subject: 'Mathematics',
    classroom: 'Grade 10-A',
    teacher: session.displayName || 'Sarath Gunawardena',
    isFreePeriod: false,
    isRelief: false
  };

  const nextSlotIndex = defaultSchedule.findIndex(s => s.start === effectiveSlot.start) + 1;
  const nextSlot = defaultSchedule[nextSlotIndex] || defaultSchedule[0];

  const teacherNextPeriod = todayTeacherPeriods.find(p => p.startTime === nextSlot.start) || {
    subject: 'Science',
    classroom: 'Grade 11-B',
    teacher: session.displayName || 'Sarath Gunawardena'
  };

  // Class Schedule info for effective period
  const classCurrentPeriod = todayClassPeriods.find(p => p.startTime === effectiveSlot.start) || {
    subject: 'Mathematics',
    teacher: session.displayName || 'Sarath Gunawardena',
    classroom: 'Grade 10-A'
  };

  const classNextPeriod = todayClassPeriods.find(p => p.startTime === nextSlot.start) || {
    subject: 'Science',
    teacher: 'Mrs. Nimali Perera',
    classroom: 'Grade 10-A'
  };

  // Determine Teacher Status
  let teacherBadgeLabel = lang === 'si' ? 'උගන්වමින් පවතී' : 'Currently Teaching';
  let teacherBadgeStyle = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30 shadow-emerald-500/10';
  let statusDotColor = 'bg-emerald-400';

  if (isOutsideSchoolHours) {
    teacherBadgeLabel = lang === 'si' ? 'පන්ති වේලාවෙන් බැහැරයි' : 'Outside School Hours';
    teacherBadgeStyle = 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30 shadow-cyan-500/10';
    statusDotColor = 'bg-cyan-400';
  } else if (effectiveSlot.isBreak) {
    teacherBadgeLabel = lang === 'si' ? 'විවේක කාලය (Break)' : 'Interval / Break';
    teacherBadgeStyle = 'bg-amber-500/10 text-amber-400 border-amber-500/30 shadow-amber-500/10';
    statusDotColor = 'bg-amber-400';
  } else if (teacherCurrentPeriod.isFreePeriod) {
    teacherBadgeLabel = lang === 'si' ? 'නිදහස් කාලච්ඡේදය' : 'Free Period / Off';
    teacherBadgeStyle = 'bg-blue-500/10 text-blue-400 border-blue-500/30 shadow-blue-500/10';
    statusDotColor = 'bg-blue-400';
  } else if (teacherCurrentPeriod.isRelief) {
    teacherBadgeLabel = lang === 'si' ? 'ආදේශක පන්තිය' : 'Covering Relief';
    teacherBadgeStyle = 'bg-purple-500/10 text-purple-400 border-purple-500/30 shadow-purple-500/10';
    statusDotColor = 'bg-purple-400';
  }

  // Format Date & Time strings
  const formattedDate = now.toLocaleDateString(lang === 'si' ? 'si-LK' : 'en-US', {
    weekday: 'long',
    month: 'short',
    day: 'numeric'
  });

  const formattedTime = now.toLocaleTimeString(lang === 'si' ? 'si-LK' : 'en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl max-w-2xl w-full p-4 sm:p-6 relative overflow-hidden space-y-4 my-auto max-h-[92vh] flex flex-col">
        
        {/* Modal Top Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse shrink-0"></span>
            <h2 className="text-sm sm:text-base font-extrabold text-slate-100 truncate">
              ⚡ {lang === 'si' ? 'සජීවී පන්ති සහ ගුරු Live පුවරුව' : 'Live Status & Timetable Board'}
            </h2>
            <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-0.5 rounded-full font-bold hidden sm:inline-block shrink-0">
              Live Real-Time
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition border border-slate-700/60 flex items-center gap-1.5 text-xs font-semibold shrink-0 cursor-pointer"
            title={lang === 'si' ? 'වහන්න' : 'Close'}
          >
            <span className="hidden sm:inline">{lang === 'si' ? 'වහන්න' : 'Close'}</span>
            <X className="w-4 h-4 text-slate-300" />
          </button>
        </div>

        {/* Modal Body: Single-Column Stacked Vertical Layout */}
        <div className="overflow-y-auto pr-0.5 flex-1 space-y-4">
          
          {/* SECTION 1 (TOP CARD): Teacher Live Status (ගුරුවරයාගේ Live තත්ත්වය) */}
          <div className="bg-slate-950/90 border border-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-lg space-y-3">
            
            {/* Header & Status Badge */}
            <div className="flex items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 sm:w-8 sm:h-8 bg-cyan-500/10 border border-cyan-500/30 rounded-xl flex items-center justify-center text-cyan-400 shrink-0">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-100 truncate">
                    👨‍🏫 {lang === 'si' ? 'ගුරුවරයාගේ Live තත්ත්වය' : 'Teacher Live Status'}
                  </h3>
                  <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium truncate">
                    {session.displayName || 'Sarath Gunawardena'}
                  </p>
                </div>
              </div>

              {/* Status Badge */}
              <div className={`px-2.5 py-1 rounded-full border text-[10px] sm:text-[11px] font-bold flex items-center gap-1.5 shadow-md shrink-0 ${teacherBadgeStyle}`}>
                <span className={`w-2 h-2 rounded-full animate-pulse ${statusDotColor}`}></span>
                <span className="truncate">{teacherBadgeLabel}</span>
              </div>
            </div>

            {/* Current Date, Day & Live Clock */}
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-200 font-bold min-w-0 truncate">
                <Calendar className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="truncate">{formattedDate}</span>
              </div>
              <div className="flex items-center gap-1.5 text-xs font-mono font-extrabold text-cyan-300 bg-cyan-950/60 border border-cyan-500/30 px-2.5 py-1 rounded-lg shrink-0">
                <Clock className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                <span>{formattedTime}</span>
              </div>
            </div>

            {/* Current & Next Period Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              
              {/* Current Period Card */}
              <div className="bg-slate-900/80 border border-cyan-500/20 p-3 rounded-xl space-y-1">
                <div className="flex items-center justify-between text-[10px] sm:text-[11px]">
                  <span className="font-extrabold text-cyan-400 uppercase tracking-wider flex items-center gap-1 truncate">
                    <BookOpen className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{effectiveSlot.name} ({effectiveSlot.start} - {effectiveSlot.end})</span>
                  </span>
                  <span className="text-[9px] bg-cyan-500/10 text-cyan-300 px-1.5 py-0.5 rounded font-mono font-bold shrink-0">
                    NOW
                  </span>
                </div>
                <div className="space-y-0.5 pt-0.5">
                  <p className="text-sm font-extrabold text-slate-100 truncate">
                    {teacherCurrentPeriod.subject}
                  </p>
                  <p className="text-xs text-slate-300 font-medium flex items-center gap-1 truncate">
                    <School className="w-3 h-3 text-slate-400 shrink-0" />
                    <span>{lang === 'si' ? 'පන්තිය' : 'Class'}: <strong className="text-cyan-300">{teacherCurrentPeriod.classroom}</strong></span>
                  </p>
                </div>
              </div>

              {/* Next Period Card */}
              <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-xl space-y-1">
                <div className="flex items-center justify-between text-[10px] sm:text-[11px]">
                  <span className="font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1 truncate">
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>{nextSlot.name} ({nextSlot.start})</span>
                  </span>
                  <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono font-bold shrink-0">
                    NEXT
                  </span>
                </div>
                <div className="space-y-0.5 pt-0.5">
                  <p className="text-sm font-extrabold text-slate-200 truncate">
                    {teacherNextPeriod.subject}
                  </p>
                  <p className="text-xs text-slate-400 font-medium flex items-center gap-1 truncate">
                    <School className="w-3 h-3 text-slate-500 shrink-0" />
                    <span>{lang === 'si' ? 'පන්තිය' : 'Class'}: <strong className="text-slate-300">{teacherNextPeriod.classroom}</strong></span>
                  </p>
                </div>
              </div>

            </div>

            {/* Live Countdown Timer Bar */}
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-bold flex items-center gap-1.5 truncate">
                  <Timer className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow shrink-0" />
                  <span>{lang === 'si' ? 'ගුරු කාලච්ඡේද අවසානය' : 'Teacher Period Timer'}</span>
                </span>
                <span className="font-mono font-extrabold text-cyan-300 bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 rounded text-xs shrink-0">
                  {countdownStr} {lang === 'si' ? 'ඉතිරියි' : 'remaining'}
                </span>
              </div>

              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800 p-0.5">
                <div
                  className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full transition-all duration-1000 ease-linear shadow-sm shadow-cyan-500/30"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                <span>{effectiveSlot.start}</span>
                <span>{progressPercent}% {lang === 'si' ? 'සම්පූර්ණයි' : 'completed'}</span>
                <span>{effectiveSlot.end}</span>
              </div>
            </div>

          </div>

          {/* SECTION 2 (BOTTOM CARD): Class Live Timetable Section (පංතියේ Live කාලසටහන) */}
          <div className="bg-slate-950/90 border border-slate-800 p-3.5 sm:p-4 rounded-2xl shadow-lg space-y-3">
            
            {/* Header Title */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-7 h-7 sm:w-8 sm:h-8 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-center text-emerald-400 shrink-0">
                  <School className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h3 className="text-xs sm:text-sm font-extrabold text-slate-100 truncate">
                    🏫 {lang === 'si' ? 'පංතියේ Live කාලසටහන' : 'Class Live Timetable'}
                  </h3>
                  <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium truncate">
                    Grade 10-A Classroom Timetable
                  </p>
                </div>
              </div>

              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full shrink-0">
                {formattedDate}
              </span>
            </div>

            {/* Current & Next Subject Period Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              
              {/* Current Class Subject & Teacher */}
              <div className="bg-slate-900/80 border border-emerald-500/20 p-3 rounded-xl space-y-1">
                <div className="flex items-center justify-between text-[10px] sm:text-[11px]">
                  <span className="font-extrabold text-emerald-400 uppercase tracking-wider flex items-center gap-1 truncate">
                    <BookOpen className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{effectiveSlot.name} ({effectiveSlot.start} - {effectiveSlot.end})</span>
                  </span>
                  <span className="text-[9px] bg-emerald-500/10 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold shrink-0">
                    CURRENT
                  </span>
                </div>
                <div className="space-y-0.5 pt-0.5">
                  <p className="text-sm font-extrabold text-slate-100 truncate">
                    {classCurrentPeriod.subject}
                  </p>
                  <p className="text-xs text-slate-300 font-medium flex items-center gap-1 truncate">
                    <User className="w-3 h-3 text-slate-400 shrink-0" />
                    <span>{lang === 'si' ? 'ගුරුවරයා' : 'Teacher'}: <strong className="text-emerald-300">{classCurrentPeriod.teacher}</strong></span>
                  </p>
                </div>
              </div>

              {/* Next Class Subject & Teacher */}
              <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-xl space-y-1">
                <div className="flex items-center justify-between text-[10px] sm:text-[11px]">
                  <span className="font-extrabold text-slate-400 uppercase tracking-wider flex items-center gap-1 truncate">
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                    <span>{nextSlot.name} ({nextSlot.start})</span>
                  </span>
                  <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono font-bold shrink-0">
                    NEXT
                  </span>
                </div>
                <div className="space-y-0.5 pt-0.5">
                  <p className="text-sm font-extrabold text-slate-200 truncate">
                    {classNextPeriod.subject}
                  </p>
                  <p className="text-xs text-slate-400 font-medium flex items-center gap-1 truncate">
                    <User className="w-3 h-3 text-slate-500 shrink-0" />
                    <span>{lang === 'si' ? 'ගුරුවරයා' : 'Teacher'}: <strong className="text-slate-300">{classNextPeriod.teacher}</strong></span>
                  </p>
                </div>
              </div>

            </div>

            {/* Live Countdown Timer Bar for Class */}
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-bold flex items-center gap-1.5 truncate">
                  <Timer className="w-3.5 h-3.5 text-emerald-400 animate-spin-slow shrink-0" />
                  <span>{lang === 'si' ? 'පංති කාලච්ඡේද අවසානය' : 'Class Period Timer'}</span>
                </span>
                <span className="font-mono font-extrabold text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded text-xs shrink-0">
                  {countdownStr} {lang === 'si' ? 'ඉතිරියි' : 'remaining'}
                </span>
              </div>

              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800 p-0.5">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-full rounded-full transition-all duration-1000 ease-linear shadow-sm shadow-emerald-500/30"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-500 font-medium">
                <span>{effectiveSlot.start}</span>
                <span>{progressPercent}% {lang === 'si' ? 'ගත වී ඇත' : 'elapsed'}</span>
                <span>{effectiveSlot.end}</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
