import React from 'react';
import { useApp } from '../context/AppContext';
import { X, CheckCircle2, Shield, LogOut, UserCheck, Sparkles } from 'lucide-react';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, session, setSession } = useApp();

  if (!isAuthModalOpen) return null;

  const handleGoogleLogin = () => {
    setSession({
      isLoggedIn: true,
      email: 'teacher.class10a@school.lk',
      displayName: 'Sarath Gunawardena',
      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      role: 'TEACHER',
      schoolName: 'Royal College, Colombo'
    });
    setIsAuthModalOpen(false);
  };

  const handleLogout = () => {
    setSession({
      isLoggedIn: false,
      email: '',
      displayName: 'Guest User',
      photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=250',
      role: 'STUDENT',
      schoolName: 'Classroom Hub'
    });
    setIsAuthModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl p-6 shadow-2xl relative">
        <button
          onClick={() => setIsAuthModalOpen(false)}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-gradient-to-tr from-cyan-600 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg shadow-cyan-500/20 text-2xl">
            🎓
          </div>
          <h2 className="text-xl font-bold text-slate-100">Classroom Hub Account</h2>
          <p className="text-xs text-slate-400 mt-1">Google Workspace & Cloud Sync Authentication</p>
        </div>

        {session.isLoggedIn ? (
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <img src={session.photoUrl} alt="User" className="w-12 h-12 rounded-full border-2 border-cyan-500" />
              <div>
                <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                  {session.displayName}
                  <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                </h3>
                <p className="text-xs text-slate-400">{session.email}</p>
                <span className="inline-block mt-1 text-[10px] bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full font-semibold">
                  {session.role} • {session.schoolName}
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-3 mb-6">
            <button
              onClick={handleGoogleLogin}
              className="w-full bg-white hover:bg-slate-100 text-slate-900 font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-3 shadow-md transition text-sm"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Sign in with Google</span>
            </button>
            <p className="text-[11px] text-center text-slate-500">
              Syncs students, marks, attendance & timetable automatically with Google Drive.
            </p>
          </div>
        )}

        {session.isLoggedIn ? (
          <button
            onClick={handleLogout}
            className="w-full bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-semibold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 transition text-xs"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out of Account</span>
          </button>
        ) : null}
      </div>
    </div>
  );
};
