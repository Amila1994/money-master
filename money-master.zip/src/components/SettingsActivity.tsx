import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Globe,
  Lock,
  Cloud,
  CheckCircle2,
  Save,
  Search,
  RefreshCw,
  Share2,
  Send,
  Download,
  Settings,
  Info,
  QrCode,
  Copy,
  Check,
  Inbox,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { COUNTRIES_LIST, CountryInfo } from '../data/countries';
import { t } from '../utils/i18n';
import {
  prepareClassHandoverData,
  exportAndShareClassData,
  downloadHandoverJsonFile,
  importClassDataToNewTeacher,
  getHandoverInvitesForEmail,
  HandoverInvite
} from '../utils/driveHandover';
import { QrCodeSvg } from '../utils/qrCode';

export const SettingsActivity: React.FC = () => {
  const {
    settings,
    updateSettings,
    isSyncing,
    triggerDriveSync,
    lastSyncTime,
    session,
    students,
    attendanceRecords,
    teacherAttendanceRecords,
    examRecords,
    timetable,
    classNotes,
    settingsSubTab,
    setSettingsSubTab,
    importClassDataset,
    setActiveTab
  } = useApp();

  const [countrySearch, setCountrySearch] = useState('');
  const [selectedCountryName, setSelectedCountryName] = useState(settings.country || 'Sri Lanka');
  const [lang, setLang] = useState<string>(settings.language || 'si');
  const [pinEnabled, setPinEnabled] = useState(settings.pinLockEnabled);
  const [pin, setPin] = useState(settings.securityPin);
  const [question, setQuestion] = useState(settings.securityQuestion);
  const [answer, setAnswer] = useState(settings.securityAnswer);
  const [autoBackupDrive, setAutoBackupDrive] = useState(settings.autoBackupDrive ?? true);
  const [autoPurgeOldBackups, setAutoPurgeOldBackups] = useState(settings.autoPurgeOldBackups ?? true);

  const [savedSuccess, setSavedSuccess] = useState(false);

  // Class Data Handover state (Teacher A -> Teacher B)
  const [recipientEmail, setRecipientEmail] = useState('');
  const [handoverClassName, setHandoverClassName] = useState('Grade 10-A');
  const [isExportingHandover, setIsExportingHandover] = useState(false);
  const [createdInvite, setCreatedInvite] = useState<HandoverInvite | null>(null);
  const [handoverStatusMsg, setHandoverStatusMsg] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Teacher B Import & Discovery state
  const [teacherBEmail, setTeacherBEmail] = useState(session.email || 'teacherB@gmail.com');
  const [discoveredInvites, setDiscoveredInvites] = useState<HandoverInvite[]>([]);
  const [isSearchingInvites, setIsSearchingInvites] = useState(false);
  const [importCodeInput, setImportCodeInput] = useState('');
  const [isImportingClass, setIsImportingClass] = useState(false);
  const [importStatusMsg, setImportStatusMsg] = useState<string | null>(null);

  // Auto discover invites on mount for Teacher B
  useEffect(() => {
    if (session.email) {
      const found = getHandoverInvitesForEmail(session.email);
      setDiscoveredInvites(found);
    }
  }, [session.email]);

  const handleHandoverShare = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientEmail || !recipientEmail.includes('@')) {
      setHandoverStatusMsg(lang === 'si' ? 'කරුණාකර නිවැරදි Email ලිපිනයක් ඇතුළත් කරන්න.' : 'Please enter a valid recipient email address.');
      return;
    }

    setIsExportingHandover(true);
    setHandoverStatusMsg(null);

    const payload = prepareClassHandoverData(
      handoverClassName,
      session.email || 'teacherA@school.lk',
      recipientEmail,
      {
        students,
        attendanceRecords,
        teacherAttendanceRecords,
        examRecords,
        timetable,
        classNotes
      }
    );

    const result = await exportAndShareClassData(payload, recipientEmail);
    setIsExportingHandover(false);
    if (result.success) {
      setCreatedInvite(result.invite);
      setHandoverStatusMsg(result.message);
    }
  };

  const handleSearchInvites = async () => {
    setIsSearchingInvites(true);
    setImportStatusMsg(null);
    await new Promise(r => setTimeout(r, 600));
    const found = getHandoverInvitesForEmail(teacherBEmail);
    setDiscoveredInvites(found);
    setIsSearchingInvites(false);
  };

  const handleOneClickImport = async (invite: HandoverInvite) => {
    setIsImportingClass(true);
    setImportStatusMsg(null);

    try {
      const result = await importClassDataToNewTeacher(invite.payload, teacherBEmail);
      importClassDataset(invite.payload);
      setIsImportingClass(false);
      setImportStatusMsg(
        lang === 'si'
          ? `🎉 "${invite.className}" පන්තියේ සියලු දත්ත සාර්ථකව Import විය! (ශිෂ්‍යයන් ${invite.payload.students.length} දෙනෙකු පන්තියට එකතු විය)`
          : `🎉 Class "${invite.className}" successfully imported with ${invite.payload.students.length} student records!`
      );
    } catch (err: any) {
      setIsImportingClass(false);
      setImportStatusMsg(err?.message || 'Error importing shared class file.');
    }
  };

  const handleManualCodeImport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!importCodeInput.trim()) {
      setImportStatusMsg(lang === 'si' ? 'කරුණාකර Invite Code එක ඇතුළත් කරන්න.' : 'Please enter the Invite Code.');
      return;
    }

    setIsImportingClass(true);
    setImportStatusMsg(null);

    try {
      const result = await importClassDataToNewTeacher(importCodeInput, teacherBEmail);
      importClassDataset(result.importedData);
      setIsImportingClass(false);
      setImportStatusMsg(
        lang === 'si'
          ? `🎉 පන්ති දත්ත සාර්ථකව Import විය!`
          : `🎉 Class dataset imported successfully via code!`
      );
    } catch (err: any) {
      setIsImportingClass(false);
      setImportStatusMsg(err?.message || 'Error importing shared class file.');
    }
  };

  const copyShareLink = () => {
    if (createdInvite?.shareUrl) {
      navigator.clipboard.writeText(createdInvite.shareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const filteredCountries = COUNTRIES_LIST.filter((c: CountryInfo) =>
    c.name.toLowerCase().includes(countrySearch.toLowerCase()) ||
    c.code.toLowerCase().includes(countrySearch.toLowerCase())
  );

  const selectedCountryObj = COUNTRIES_LIST.find((c: CountryInfo) => c.name === selectedCountryName) || COUNTRIES_LIST[0];

  const handleCountrySelect = (cName: string) => {
    setSelectedCountryName(cName);
    const found = COUNTRIES_LIST.find((c: CountryInfo) => c.name === cName);
    if (found) {
      const officialLangs = found.languages.map(l => l.code);
      const defaultLang = officialLangs[0] || 'en';
      setLang(defaultLang);
      updateSettings({
        country: found.name,
        countryCode: found.code,
        countryFlag: found.flag,
        officialLanguages: officialLangs,
        language: defaultLang
      });
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const officialLangs = selectedCountryObj.languages.map(l => l.code);
    updateSettings({
      country: selectedCountryObj.name,
      countryCode: selectedCountryObj.code,
      countryFlag: selectedCountryObj.flag,
      officialLanguages: officialLangs,
      language: lang,
      pinLockEnabled: pinEnabled,
      securityPin: pin,
      securityQuestion: question,
      securityAnswer: answer,
      autoBackupDrive,
      autoPurgeOldBackups
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Settings Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl shadow-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-cyan-500/10 border border-cyan-500/30 rounded-2xl flex items-center justify-center text-cyan-400 shrink-0">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-100">
              {t('settings', lang)} & {t('security', lang)}
            </h2>
            <p className="text-xs text-slate-400">
              {lang === 'si' ? 'යෙදුම් සැකසුම්, Google Drive Sync සහ පන්ති Handover පාලනය කරන්න' : 'Manage app preferences, Google Drive auto-sync & teacher class handover'}
            </p>
          </div>
        </div>

        {savedSuccess && (
          <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>Saved!</span>
          </span>
        )}
      </div>

      {/* 3 Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 overflow-x-auto no-scrollbar scroll-smooth">
        <button
          type="button"
          onClick={() => setSettingsSubTab('general')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
            settingsSubTab === 'general'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
          }`}
        >
          <Globe className="w-4 h-4" />
          <span>⚙️ {lang === 'si' ? 'සාමාන්‍ය සැකසුම්' : 'General Settings'}</span>
        </button>

        <button
          type="button"
          onClick={() => setSettingsSubTab('drive')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
            settingsSubTab === 'drive'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70'
          }`}
        >
          <Cloud className="w-4 h-4" />
          <span>☁️ {lang === 'si' ? 'Google Drive Sync' : 'Google Drive Sync'}</span>
        </button>

        <button
          type="button"
          onClick={() => setSettingsSubTab('handover')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
            settingsSubTab === 'handover'
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
              : 'text-emerald-400 hover:text-emerald-300 hover:bg-slate-800/70'
          }`}
        >
          <Share2 className="w-4 h-4" />
          <span>📥 {lang === 'si' ? 'පන්ති දත්ත Handover' : 'Class Data Handover'}</span>
        </button>
      </div>

      {/* TAB 1: GENERAL SETTINGS */}
      {settingsSubTab === 'general' && (
        <form onSubmit={handleSaveSettings} className="space-y-5 animate-in fade-in duration-200">
          {/* Country Selector & Dynamic i18n */}
          <div className="bg-slate-900 border border-slate-800 p-5 sm:p-6 rounded-2xl shadow-xl space-y-4">
            <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2 border-b border-slate-800 pb-3">
              <Globe className="w-4 h-4 text-cyan-400" />
              <span>🌐 {t('select_country', lang)}</span>
            </h3>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Search & Choose Official Country
              </label>
              <div className="relative mb-3">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search country name... (e.g. Sri Lanka, India, United Kingdom)"
                  value={countrySearch}
                  onChange={e => setCountrySearch(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1 bg-slate-950 rounded-xl border border-slate-800">
                {filteredCountries.map((c: CountryInfo) => (
                  <button
                    key={c.code}
                    type="button"
                    onClick={() => handleCountrySelect(c.name)}
                    className={`p-2.5 rounded-lg border text-left text-xs transition flex items-center gap-2 cursor-pointer ${
                      selectedCountryName === c.name
                        ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold'
                        : 'bg-slate-900 border-slate-800/80 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span className="text-base">{c.flag}</span>
                    <span className="truncate">{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Dynamic Language Options for Selected Country */}
            <div className="pt-2">
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                {t('select_interface_lang', lang)} {selectedCountryObj.flag} {selectedCountryObj.name}
              </label>

              <div className="flex flex-wrap items-center gap-2">
                {selectedCountryObj.languages.map(l => (
                  <button
                    key={l.code}
                    type="button"
                    onClick={() => {
                      setLang(l.code);
                      updateSettings({ language: l.code });
                    }}
                    className={`px-4 py-2 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                      lang === l.code
                        ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-md'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span>{selectedCountryObj.flag}</span>
                    <span>{l.nativeName} ({l.name})</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* PIN Lock Security Settings */}
          <div className="bg-slate-900 border border-slate-800 p-5 sm:p-6 rounded-2xl shadow-xl space-y-4">
            <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2 border-b border-slate-800 pb-3">
              <Lock className="w-4 h-4 text-amber-400" />
              <span>🔐 {t('security_pin_lock', lang)}</span>
            </h3>

            <div className="flex items-center justify-between bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <div>
                <p className="text-xs font-bold text-slate-200">{t('enable_pin_lock', lang)}</p>
                <p className="text-[11px] text-slate-400">{t('pin_lock_desc', lang)}</p>
              </div>
              <input
                type="checkbox"
                checked={pinEnabled}
                onChange={e => setPinEnabled(e.target.checked)}
                className="w-5 h-5 accent-amber-500 rounded cursor-pointer"
              />
            </div>

            {pinEnabled && (
              <div className="space-y-3 pt-2 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">{t('set_pin', lang)}</label>
                  <input
                    type="password"
                    maxLength={4}
                    value={pin}
                    onChange={e => setPin(e.target.value)}
                    className="w-full sm:w-48 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-center text-lg font-mono text-slate-100 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">{t('security_question', lang)}</label>
                  <input
                    type="text"
                    value={question}
                    onChange={e => setQuestion(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">{t('security_answer', lang)}</label>
                  <input
                    type="text"
                    value={answer}
                    onChange={e => setAnswer(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>
            )}
          </div>

          {/* App Info & System Metadata */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl space-y-3">
            <h3 className="font-bold text-slate-100 text-xs flex items-center gap-1.5 text-slate-300">
              <Info className="w-4 h-4 text-cyan-400" />
              <span>📱 {lang === 'si' ? 'යෙදුම් පද්ධති තොරතුරු (App Package Info)' : 'System Package Information'}</span>
            </h3>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Package Name:</span>
                <span className="font-mono text-slate-200">{settings.packageName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">SHA-1 Certificate:</span>
                <span className="font-mono text-slate-200 truncate max-w-[220px] sm:max-w-none">{settings.sha1Fingerprint}</span>
              </div>
            </div>
          </div>

          {/* Save Button */}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold py-3.5 rounded-xl text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/20 transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{t('save_settings', lang)}</span>
          </button>
        </form>
      )}

      {/* TAB 2: GOOGLE DRIVE SYNC */}
      {settingsSubTab === 'drive' && (
        <form onSubmit={handleSaveSettings} className="space-y-5 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 p-5 sm:p-6 rounded-2xl shadow-xl space-y-4">
            <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2 border-b border-slate-800 pb-3">
              <Cloud className="w-4 h-4 text-cyan-400" />
              <span>☁️ {t('drive_sync_settings', lang)}</span>
            </h3>

            <div className="space-y-3">
              <div className="flex items-center justify-between bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <div>
                  <p className="text-xs font-bold text-slate-200">{t('drive_auto_sync_1s', lang)}</p>
                  <p className="text-[11px] text-slate-400">{t('auto_sync_desc', lang)}</p>
                </div>
                <input
                  type="checkbox"
                  checked={autoBackupDrive}
                  onChange={e => setAutoBackupDrive(e.target.checked)}
                  className="w-5 h-5 accent-cyan-500 rounded cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <div>
                  <p className="text-xs font-bold text-slate-200">{t('auto_purge_desc', lang)}</p>
                  <p className="text-[11px] text-slate-400">{t('auto_purge_desc', lang)}</p>
                </div>
                <input
                  type="checkbox"
                  checked={autoPurgeOldBackups}
                  onChange={e => setAutoPurgeOldBackups(e.target.checked)}
                  className="w-5 h-5 accent-cyan-500 rounded cursor-pointer"
                />
              </div>

              {/* Live Status & Force Sync Button */}
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">{t('sync_status', lang)}:</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>1s Realtime Active ({lastSyncTime})</span>
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => triggerDriveSync()}
                  disabled={isSyncing}
                  className="w-full bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? t('purging_syncing', lang) : t('force_sync_now', lang)}</span>
                </button>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold py-3.5 rounded-xl text-sm flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/20 transition cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{lang === 'si' ? 'Drive Sync සැකසුම් සුරකින්න' : 'Save Drive Preferences'}</span>
          </button>
        </form>
      )}

      {/* TAB 3: STREAMLINED CLASS DATA HANDOVER */}
      {settingsSubTab === 'handover' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* TEACHER A: SHARE & QR HANDOVER GENERATOR */}
          <div className="bg-slate-900 border border-slate-800 p-5 sm:p-6 rounded-2xl shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <Share2 className="w-4.5 h-4.5 text-emerald-400" />
                <span>📤 {lang === 'si' ? 'A ගුරුවරයා: 1-Click QR Handover එකක් සාදන්න' : 'Teacher A: Generate 1-Click QR & Email Invite'}</span>
              </h3>
              <span className="text-[11px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2.5 py-1 rounded-full font-bold">
                Auto-Sync Ready
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {lang === 'si'
                ? 'B ගුරුවරයාගේ Email ලිපිනය ඇතුළත් කරන්න. B ගුරුවරයාට auto email invitation link එකක් යැවෙන අතර QR Code එකක් visual ලෙස display වේ. File ID පිටපත් කිරීමට අවශ්‍ය නැත.'
                : 'Enter Teacher B’s Email address. An automatic 1-click invitation link and QR Code will be generated instantly.'}
            </p>

            <form onSubmit={handleHandoverShare} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    {lang === 'si' ? 'පන්තිය / Grade:' : 'Class / Grade Name:'}
                  </label>
                  <input
                    type="text"
                    value={handoverClassName}
                    onChange={e => setHandoverClassName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-slate-100 font-bold outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    {lang === 'si' ? 'ලබාගන්නා B ගුරුවරයාගේ Email:' : 'Recipient Teacher B Email:'}
                  </label>
                  <input
                    type="email"
                    placeholder="teacherB@gmail.com"
                    value={recipientEmail}
                    onChange={e => setRecipientEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono outline-none"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="submit"
                  disabled={isExportingHandover}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-5 py-3 rounded-xl text-xs flex items-center gap-2 transition cursor-pointer disabled:opacity-50 shadow-lg shadow-emerald-500/20"
                >
                  {isExportingHandover ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>{lang === 'si' ? 'QR Code & Invite සකසමින්...' : 'Creating QR Invite...'}</span>
                    </>
                  ) : (
                    <>
                      <QrCode className="w-4 h-4" />
                      <span>{lang === 'si' ? 'QR Code & 1-Click Link සාදන්න' : 'Generate QR Code & Invite Link'}</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const payload = prepareClassHandoverData(
                      handoverClassName,
                      session.email || 'teacherA@school.lk',
                      recipientEmail || 'teacherB@school.lk',
                      { students, attendanceRecords, teacherAttendanceRecords, examRecords, timetable, classNotes }
                    );
                    downloadHandoverJsonFile(payload);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 px-4 py-3 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-400" />
                  <span>{lang === 'si' ? 'Local JSON Backup' : 'Local Backup File'}</span>
                </button>
              </div>
            </form>

            {/* Visual QR Code Display Card when created */}
            {createdInvite && (
              <div className="mt-4 p-5 bg-slate-950 border border-emerald-500/40 rounded-2xl space-y-4 animate-in fade-in">
                <div className="flex flex-col sm:flex-row items-center gap-5">
                  <div className="shrink-0">
                    <QrCodeSvg value={createdInvite.shareUrl} size={150} />
                  </div>

                  <div className="space-y-2 text-xs text-slate-300 text-center sm:text-left">
                    <div className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-full font-bold text-[11px] border border-emerald-500/30">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{lang === 'si' ? '1-Click Invite සූදානම්' : '1-Click Invite Ready'}</span>
                    </div>

                    <h4 className="font-extrabold text-slate-100 text-sm">{createdInvite.className}</h4>

                    <p className="text-slate-400">
                      Invite Code: <span className="font-mono text-cyan-400 font-bold">{createdInvite.inviteCode}</span>
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Recipient: <span className="font-mono text-slate-200">{createdInvite.recipientEmail}</span>
                    </p>

                    <div className="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-2">
                      <button
                        type="button"
                        onClick={copyShareLink}
                        className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-lg text-[11px] font-bold flex items-center gap-1.5 transition cursor-pointer"
                      >
                        {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
                        <span>{copiedLink ? (lang === 'si' ? 'පිටපත් විය!' : 'Copied!') : (lang === 'si' ? 'Link එක Copy කරන්න' : 'Copy 1-Click Link')}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {handoverStatusMsg && (
                  <div className="text-[11px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 p-2.5 rounded-xl flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{handoverStatusMsg}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* TEACHER B: AUTO-DISCOVERY & 1-CLICK IMPORT */}
          <div className="bg-slate-900 border border-slate-800 p-5 sm:p-6 rounded-2xl shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-slate-100 text-sm flex items-center gap-2">
                <Inbox className="w-4.5 h-4.5 text-cyan-400" />
                <span>📥 {lang === 'si' ? 'B ගුරුවරයා: Auto-Discover & 1-Click Import' : 'Teacher B: Check Invites & 1-Click Auto Import'}</span>
              </h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {lang === 'si'
                ? 'ඔබට ලැබී ඇති පන්ති Handover Invites ස්වයංක්‍රීයව සොයාගෙන තනි Click එකකින් මුළු පන්තියම ඔබේ ඇප් එකට Import කරගන්න.'
                : 'Automatically search for class handover invitations sent to your email and import the complete dataset with a single click.'}
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-3 text-xs">
              <div className="w-full sm:flex-1">
                <label className="block font-semibold text-slate-400 mb-1">Your Google Teacher Email:</label>
                <input
                  type="email"
                  value={teacherBEmail}
                  onChange={e => setTeacherBEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-slate-100 font-mono"
                />
              </div>

              <div className="w-full sm:w-auto self-end">
                <button
                  type="button"
                  onClick={handleSearchInvites}
                  disabled={isSearchingInvites}
                  className="w-full sm:w-auto bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSearchingInvites ? 'animate-spin' : ''}`} />
                  <span>{lang === 'si' ? 'Invites පරීක්ෂා කරන්න' : 'Check for Handover Invites'}</span>
                </button>
              </div>
            </div>

            {/* Discovered Invites List */}
            <div className="space-y-3 pt-2">
              {discoveredInvites.length === 0 ? (
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center text-xs text-slate-400">
                  {lang === 'si' ? 'තවමත් Handover Invites හමුවී නැත. "Invites පරීක්ෂා කරන්න" ක්ලික් කරන්න.' : 'No active handover invites found yet. Click "Check for Handover Invites".'}
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-xs font-bold text-slate-300">
                    {lang === 'si' ? `ලැබුණු Invites (${discoveredInvites.length}):` : `Found Pending Invites (${discoveredInvites.length}):`}
                  </p>

                  {discoveredInvites.map(inv => (
                    <div
                      key={inv.id}
                      className="bg-slate-950 border border-slate-800 hover:border-cyan-500/50 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition shadow-md"
                    >
                      <div className="space-y-1 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-100 text-sm">{inv.className}</span>
                          <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-md font-mono text-[10px] font-bold">
                            {inv.inviteCode}
                          </span>
                        </div>
                        <p className="text-slate-400">
                          From Teacher A: <span className="text-slate-200 font-mono">{inv.senderEmail}</span>
                        </p>
                        <p className="text-[11px] text-slate-500">
                          Students count: <span className="text-emerald-400 font-bold">{inv.payload.students.length}</span> | Date: {new Date(inv.createdAt).toLocaleDateString()}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleOneClickImport(inv)}
                        disabled={isImportingClass}
                        className="w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition cursor-pointer disabled:opacity-50 shrink-0"
                      >
                        {isImportingClass ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Importing...</span>
                          </>
                        ) : (
                          <>
                            <Download className="w-3.5 h-3.5" />
                            <span>{lang === 'si' ? '⚡ 1-Click Import Class' : '⚡ 1-Click Import Class'}</span>
                          </>
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Manual Invite Code Entry Option */}
            <div className="mt-4 pt-4 border-t border-slate-800">
              <form onSubmit={handleManualCodeImport} className="flex flex-col sm:flex-row items-center gap-2 text-xs">
                <span className="text-slate-400 shrink-0">{lang === 'si' ? 'හෝ Invite Code එකෙන්:' : 'Or Enter Invite Code:'}</span>
                <input
                  type="text"
                  placeholder="e.g. HO-982314"
                  value={importCodeInput}
                  onChange={e => setImportCodeInput(e.target.value)}
                  className="w-full sm:flex-1 bg-slate-950 border border-slate-700 focus:border-cyan-500 rounded-xl px-3 py-2 text-slate-100 font-mono"
                />

                <button
                  type="submit"
                  disabled={isImportingClass}
                  className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 px-4 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50 shrink-0"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>Import via Code</span>
                </button>
              </form>
            </div>

            {importStatusMsg && (
              <div className="bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 p-3.5 rounded-xl text-xs flex items-center gap-2.5 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                <span className="leading-relaxed font-medium">{importStatusMsg}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsActivity;
