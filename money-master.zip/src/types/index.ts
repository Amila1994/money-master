export interface Student {
  id: string;
  name: string;
  nameWithInitials: string;
  rollNo: string;
  grade: string;
  marks: number;
  isPresent: boolean;
  
  // Detailed attributes
  dob?: string;
  gender?: string;
  placeOfBirth?: string;
  ethnicity?: string;
  religion?: string;
  birthCertNo?: string;
  medium?: string;
  permAddress?: string;
  
  // Parents & Guardian
  fatherName?: string;
  fatherNic?: string;
  fatherPhone?: string;
  motherName?: string;
  motherNic?: string;
  motherPhone?: string;
  guardianName?: string;
  emergencyName?: string;
  emergencyRelation?: string;
  emergencyPhone?: string;
}

export type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'EXCUSED';

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  remarks?: string;
}

export interface ExamSubjectMark {
  subjectName: string;
  marks: number;
  maxMarks: number;
  grade: string;
}

export interface StudentExamRecord {
  studentId: string;
  studentName: string;
  rollNo: string;
  examTerm: string; // e.g. "1st Term 2026", "Mid-Year 2026", "Final Term 2026"
  subjectMarks: Record<string, number>; // subjectName -> mark
  totalMarks: number;
  average: number;
  rank: number;
  grade: string;
}

export interface TimetablePeriod {
  id: string;
  type: 'CLASS' | 'TEACHER'; // Class Timetable or Teacher Timetable
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
  startTime: string; // e.g. "08:00"
  endTime: string;   // e.g. "08:40"
  subject: string;
  teacher: string;
  classroom: string;
  isFreePeriod?: boolean;
  isRelief?: boolean;
  reliefTeacher?: string;
  reliefNotes?: string;
}

export type TeacherAttendanceStatus = 'PRESENT' | 'ABSENT' | 'HALF_DAY' | 'ON_DUTY' | 'LEAVE' | 'PAPER_MARKING' | 'SICK_LEAVE' | 'CASUAL_LEAVE';

export interface TeacherAttendanceRecord {
  id: string;
  teacherName: string;
  date: string; // YYYY-MM-DD
  status: TeacherAttendanceStatus;
  timeIn?: string;
  timeOut?: string;
  notes?: string;
}

export interface ClassNote {
  id: string;
  title: string;
  content: string;
  type: 'ANNOUNCEMENT' | 'HOMEWORK' | 'ASSIGNMENT' | 'EXAM_NOTICE' | 'GENERAL_NOTE' | 'EVENT' | 'NOTE';
  date: string;
  author: string;
}

export interface UserSession {
  isLoggedIn: boolean;
  email: string;
  displayName: string;
  photoUrl: string;
  role: 'TEACHER' | 'STUDENT' | 'ADMIN';
  schoolName: string;
}

export interface AppSettings {
  language: string; // 'si', 'en', 'ta', 'es', 'hi', 'ja', 'de', 'fr', etc.
  country: string;  // e.g. 'Sri Lanka', 'United States', 'India'
  countryCode: string; // e.g. 'LK', 'US', 'IN'
  countryFlag: string; // e.g. '🇱🇰', '🇺🇸', '🇮🇳'
  officialLanguages: string[]; // list of official languages for the chosen country
  pinLockEnabled: boolean;
  securityPin: string;
  securityQuestion: string;
  securityAnswer: string;
  autoBackupDrive: boolean;
  realtimeSyncIntervalSec: number; // 1 second real-time sync
  autoPurgeOldBackups: boolean; // Purge old revisions on drive
  themeMode: 'dark' | 'light';
  lastDriveSync: string;
  packageName?: string;
  sha1Fingerprint?: string;
}
