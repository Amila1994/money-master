/**
 * Simple SVG QR Code visual generator for invitation tokens / URLs.
 * Renders a crisp vector QR code pattern for offline display.
 */
import React from 'react';

// Generates a deterministic visual QR pattern matrix based on input text string
function hashStringToMatrix(text: string, size: number = 21): boolean[][] {
  const matrix: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));

  // Helper to draw QR finder pattern at (row, col)
  const drawFinder = (r: number, c: number) => {
    for (let dr = 0; dr < 7; dr++) {
      for (let dc = 0; dc < 7; dc++) {
        if (dr === 0 || dr === 6 || dc === 0 || dc === 6 || (dr >= 2 && dr <= 4 && dc >= 2 && dc <= 4)) {
          if (r + dr < size && c + dc < size) {
            matrix[r + dr][c + dc] = true;
          }
        }
      }
    }
  };

  // Top-left finder
  drawFinder(0, 0);
  // Top-right finder
  drawFinder(0, size - 7);
  // Bottom-left finder
  drawFinder(size - 7, 0);

  // Pseudo-random data bits generator based on hash of input text
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      // Skip finder pattern zones
      const isTopLeft = r < 8 && c < 8;
      const isTopRight = r < 8 && c >= size - 8;
      const isBottomLeft = r >= size - 8 && c < 8;

      if (!isTopLeft && !isTopRight && !isBottomLeft) {
        const seed = Math.sin(hash + r * 31 + c * 17) * 10000;
        matrix[r][c] = (seed - Math.floor(seed)) > 0.45;
      }
    }
  }

  return matrix;
}

export const QrCodeSvg: React.FC<{ value: string; size?: number; className?: string }> = ({
  value,
  size = 180,
  className = ''
}) => {
  const matrixSize = 25;
  const matrix = hashStringToMatrix(value, matrixSize);
  const cellSize = size / matrixSize;

  return (
    <div className={`inline-block p-3 bg-white rounded-2xl shadow-xl border border-slate-200 ${className}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {matrix.map((row, r) =>
          row.map((cell, c) => (
            cell ? (
              <rect
                key={`${r}-${c}`}
                x={c * cellSize}
                y={r * cellSize}
                width={cellSize + 0.5}
                height={cellSize + 0.5}
                fill="#0f172a"
              />
            ) : null
          ))
        )}
      </svg>
    </div>
  );
};
