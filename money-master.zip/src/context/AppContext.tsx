import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  Student,
  AttendanceRecord,
  StudentExamRecord,
  TimetablePeriod,
  ClassNote,
  UserSession,
  AppSettings,
  AttendanceStatus,
  TeacherAttendanceRecord,
  TeacherAttendanceStatus
} from '../types';

interface AppContextType {
  // Navigation
  activeTab: string;
  setActiveTab: (tab: string) => void;
  settingsSubTab: 'general' | 'drive' | 'handover';
  setSettingsSubTab: (subTab: 'general' | 'drive' | 'handover') => void;

  // Session & Auth
  session: UserSession;
  setSession: React.Dispatch<React.SetStateAction<UserSession>>;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;

  // PIN Security
  isPinLocked: boolean;
  setIsPinLocked: (locked: boolean) => void;
  verifyPin: (pin: string) => boolean;

  // Settings
  settings: AppSettings;
  updateSettings: (newSettings: Partial<AppSettings>) => void;

  // Google Drive Sync
  isSyncing: boolean;
  lastSyncTime: string;
  triggerDriveSync: () => Promise<void>;

  // Grades Management
  grades: string[];
  addGrade: (grade: string) => void;
  deleteGrade: (grade: string) => void;

  // Students
  students: Student[];
  addStudent: (student: Omit<Student, 'id'>) => void;
  updateStudent: (id: string, updated: Partial<Student>) => void;
  deleteStudent: (id: string) => void;

  // Subjects
  subjects: string[];
  addSubject: (subject: string) => void;
  deleteSubject: (subject: string) => void;

  // Student Attendance
  attendanceRecords: AttendanceRecord[];
  markAttendance: (studentId: string, studentName: string, date: string, status: AttendanceStatus, remarks?: string) => void;
  getAttendanceForDate: (date: string) => Record<string, AttendanceStatus>;

  // Teacher Attendance
  teacherAttendanceRecords: TeacherAttendanceRecord[];
  markTeacherAttendance: (teacherName: string, date: string, status: TeacherAttendanceStatus, timeIn?: string, timeOut?: string, notes?: string) => void;
  updateTeacherAttendance: (id: string, updated: Partial<TeacherAttendanceRecord>) => void;
  deleteTeacherAttendance: (id: string) => void;

  // Exams & Marks
  examTerm: string;
  setExamTerm: (term: string) => void;
  examRecords: StudentExamRecord[];
  saveStudentMarks: (studentId: string, studentName: string, rollNo: string, term: string, subjectMarks: Record<string, number>) => void;

  // Timetable
  timetable: TimetablePeriod[];
  addTimetableEntry: (entry: Omit<TimetablePeriod, 'id'>) => void;
  deleteTimetableEntry: (id: string) => void;

  // Notes & Additions
  classNotes: ClassNote[];
  addClassNote: (note: Omit<ClassNote, 'id' | 'date'>) => void;
  deleteClassNote: (id: string) => void;

  // Class Dataset Handover Import
  importClassDataset: (payload: any) => void;
}

const initialStudents: Student[] = [
  {
    id: 's1',
    name: 'Kasun Perera',
    nameWithInitials: 'K. A. Kasun Perera',
    rollNo: '1001',
    grade: 'Grade 10-A',
    marks: 88,
    isPresent: true,
    dob: '2010-05-14',
    gender: 'Male',
    ethnicity: 'Sinhalese',
    religion: 'Buddhism',
    permAddress: 'No 45, Temple Road, Colombo 07',
    fatherName: 'Sunil Perera',
    fatherNic: '782341234V',
    fatherPhone: '+94 77 123 4567',
    motherName: 'Sita Perera',
    motherNic: '805671234V',
    motherPhone: '+94 71 987 6543',
    medium: 'Sinhala'
  },
  {
    id: 's2',
    name: 'Nuwan Silva',
    nameWithInitials: 'M. Nuwan Silva',
    rollNo: '1002',
    grade: 'Grade 10-A',
    marks: 76,
    isPresent: true,
    dob: '2010-08-22',
    gender: 'Male',
    ethnicity: 'Sinhalese',
    religion: 'Buddhism',
    permAddress: '12/A, Galle Road, Panadura',
    fatherName: 'Anura Silva',
    fatherNic: '751239876V',
    fatherPhone: '+94 70 333 4444',
    motherName: 'Malini Silva',
    motherNic: '798887776V',
    motherPhone: '+94 77 222 1111',
    medium: 'English'
  },
  {
    id: 's3',
    name: 'Amali Fernando',
    nameWithInitials: 'W. Amali Fernando',
    rollNo: '1003',
    grade: 'Grade 10-A',
    marks: 94,
    isPresent: true,
    dob: '2010-02-10',
    gender: 'Female',
    ethnicity: 'Sinhalese',
    religion: 'Catholic',
    permAddress: '88, Main Street, Negombo',
    fatherName: 'Joseph Fernando',
    fatherNic: '723456789V',
    fatherPhone: '+94 76 555 6666',
    motherName: 'Mary Fernando',
    motherNic: '768901234V',
    motherPhone: '+94 71 444 3333',
    medium: 'English'
  },
  {
    id: 's4',
    name: 'Chamara Bandara',
    nameWithInitials: 'H. M. Chamara Bandara',
    rollNo: '1004',
    grade: 'Grade 10-A',
    marks: 62,
    isPresent: false,
    dob: '2010-11-05',
    gender: 'Male',
    ethnicity: 'Sinhalese',
    religion: 'Buddhism',
    permAddress: 'Kandy Road, Kurunegala',
    fatherName: 'Dhammika Bandara',
    fatherNic: '734561239V',
    fatherPhone: '+94 78 888 9999',
    motherName: 'Kanthi Bandara',
    motherNic: '771234567V',
    motherPhone: '+94 75 111 2222',
    medium: 'Sinhala'
  },
  {
    id: 's5',
    name: 'Dilini Jayasinghe',
    nameWithInitials: 'S. Dilini Jayasinghe',
    rollNo: '1005',
    grade: 'Grade 10-A',
    marks: 81,
    isPresent: true,
    dob: '2010-04-30',
    gender: 'Female',
    ethnicity: 'Sinhalese',
    religion: 'Buddhism',
    permAddress: '54/2, Station Road, Maharagama',
    fatherName: 'Gamini Jayasinghe',
    fatherNic: '719998887V',
    fatherPhone: '+94 72 666 7777',
    motherName: 'Champa Jayasinghe',
    motherNic: '745554443V',
    motherPhone: '+94 77 999 0000',
    medium: 'Sinhala'
  }
];

const initialSubjects = ['Mathematics', 'Science', 'Sinhala', 'English', 'History', 'ICT'];

const initialGrades = ['Grade 10-A', 'Grade 10-B', 'Grade 11-A', 'Grade 11-B', 'Grade 12-A', 'Grade 13-A'];

const initialTeacherAttendance: TeacherAttendanceRecord[] = [
  {
    id: 'ta_1',
    teacherName: 'Sarath Gunawardena',
    date: '2026-07-28',
    status: 'PRESENT',
    timeIn: '07:25 AM',
    timeOut: '01:30 PM',
    notes: 'Grade 10-A Class Teacher Duty'
  },
  {
    id: 'ta_2',
    teacherName: 'Sarath Gunawardena',
    date: '2026-07-27',
    status: 'PRESENT',
    timeIn: '07:28 AM',
    timeOut: '01:35 PM',
    notes: 'On Time'
  },
  {
    id: 'ta_3',
    teacherName: 'Sarath Gunawardena',
    date: '2026-07-24',
    status: 'ON_DUTY',
    timeIn: '08:00 AM',
    timeOut: '02:00 PM',
    notes: 'Zonal Education Seminar'
  }
];

const initialTimetable: TimetablePeriod[] = [
  { id: 't1', type: 'CLASS', day: 'Monday', startTime: '08:00', endTime: '08:40', subject: 'Mathematics', teacher: 'Sarath Gunawardena', classroom: 'Room 10-A' },
  { id: 't2', type: 'CLASS', day: 'Monday', startTime: '08:40', endTime: '09:20', subject: 'Science', teacher: 'Mrs. Nimali Perera', classroom: 'Science Lab 2' },
  { id: 't3', type: 'CLASS', day: 'Monday', startTime: '09:20', endTime: '10:00', subject: 'English', teacher: 'Ms. Rachel Diaz', classroom: 'Room 10-A', isRelief: true, reliefTeacher: 'Mr. Bandara', reliefNotes: 'Covering for Ms. Diaz' },
  { id: 't4', type: 'CLASS', day: 'Tuesday', startTime: '08:00', endTime: '08:40', subject: 'ICT', teacher: 'Mr. Bandara', classroom: 'Computer Lab' },
  { id: 't5', type: 'CLASS', day: 'Tuesday', startTime: '08:40', endTime: '09:20', subject: 'History', teacher: 'Mrs. Jayawardena', classroom: 'Room 10-A' },
  { id: 't6', type: 'CLASS', day: 'Wednesday', startTime: '08:00', endTime: '08:40', subject: 'Sinhala', teacher: 'Mr. Wickramasinghe', classroom: 'Room 10-A' },
  { id: 't7', type: 'CLASS', day: 'Thursday', startTime: '08:00', endTime: '08:40', subject: 'Mathematics', teacher: 'Sarath Gunawardena', classroom: 'Room 10-A' },
  { id: 't8', type: 'CLASS', day: 'Friday', startTime: '08:00', endTime: '08:40', subject: 'Science', teacher: 'Mrs. Nimali Perera', classroom: 'Science Lab 2' },
  
  // Teacher Timetable
  { id: 'tt1', type: 'TEACHER', day: 'Monday', startTime: '08:00', endTime: '08:40', subject: 'Mathematics', teacher: 'Sarath Gunawardena', classroom: 'Grade 10-A' },
  { id: 'tt2', type: 'TEACHER', day: 'Monday', startTime: '08:40', endTime: '09:20', subject: 'Free Period', teacher: 'Sarath Gunawardena', classroom: 'Staff Room', isFreePeriod: true },
  { id: 'tt3', type: 'TEACHER', day: 'Monday', startTime: '09:20', endTime: '10:00', subject: 'Mathematics', teacher: 'Sarath Gunawardena', classroom: 'Grade 11-B' },
  { id: 'tt4', type: 'TEACHER', day: 'Tuesday', startTime: '08:00', endTime: '08:40', subject: 'Relief - Science', teacher: 'Sarath Gunawardena', classroom: 'Grade 9-A', isRelief: true, reliefNotes: 'Covering for Mrs. Perera' },
  { id: 'tt5', type: 'TEACHER', day: 'Wednesday', startTime: '08:00', endTime: '08:40', subject: 'Free Period', teacher: 'Sarath Gunawardena', classroom: 'Staff Room', isFreePeriod: true },
  { id: 'tt6', type: 'TEACHER', day: 'Thursday', startTime: '08:00', endTime: '08:40', subject: 'Mathematics', teacher: 'Sarath Gunawardena', classroom: 'Grade 10-A' },
  { id: 'tt7', type: 'TEACHER', day: 'Friday', startTime: '08:00', endTime: '08:40', subject: 'Mathematics', teacher: 'Sarath Gunawardena', classroom: 'Grade 11-B' }
];

const initialNotes: ClassNote[] = [
  {
    id: 'n1',
    title: 'Grade 10 Mid-Term Mathematics Assignment',
    content: 'Complete Algebra exercises on Page 142-145 in the textbook. Submission deadline is Thursday morning.',
    type: 'HOMEWORK',
    date: '2026-07-28',
    author: 'Sarath Kumara (Maths Teacher)'
  },
  {
    id: 'n2',
    title: 'Parent-Teacher Meeting Scheduled',
    content: 'Term 2 Progress Review Meeting will be held on Friday at 1:30 PM in the Main Auditorium.',
    type: 'ANNOUNCEMENT',
    date: '2026-07-25',
    author: 'Principal Office'
  },
  {
    id: 'n3',
    title: 'Science Exhibition Prep',
    content: 'Students interested in entering the Inter-School Science Fair must submit project proposals by next Monday.',
    type: 'EVENT',
    date: '2026-07-20',
    author: 'Science Club Coordinator'
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [settingsSubTab, setSettingsSubTab] = useState<'general' | 'drive' | 'handover'>('general');

  const [session, setSession] = useState<UserSession>(() => {
    const saved = localStorage.getItem('ch_session');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      isLoggedIn: true,
      email: 'teacher.class10a@school.lk',
      displayName: 'Sarath Gunawardena',
      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      role: 'TEACHER',
      schoolName: 'Royal College, Colombo'
    };
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('ch_settings');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      language: 'si',
      country: 'Sri Lanka',
      countryCode: 'LK',
      countryFlag: '🇱🇰',
      officialLanguages: ['si', 'en', 'ta'],
      pinLockEnabled: false,
      securityPin: '1234',
      securityQuestion: 'What is your school name?',
      securityAnswer: 'Royal College',
      autoBackupDrive: true,
      realtimeSyncIntervalSec: 1,
      autoPurgeOldBackups: true,
      themeMode: 'dark',
      lastDriveSync: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      packageName: 'com.classroomhub.teacher',
      sha1Fingerprint: 'A1:B2:C3:D4:E5:F6:78:90:12:34:56:78:90:AB:CD:EF:12:34:56:78'
    };
  });

  const [isPinLocked, setIsPinLocked] = useState<boolean>(() => settings.pinLockEnabled);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>(settings.lastDriveSync);

  // Grades list
  const [grades, setGrades] = useState<string[]>(() => {
    const saved = localStorage.getItem('ch_grades');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return initialGrades;
  });

  // Core collections with localStorage backing
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('ch_students');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return initialStudents;
  });

  const [subjects, setSubjects] = useState<string[]>(() => {
    const saved = localStorage.getItem('ch_subjects');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return initialSubjects;
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('ch_attendance');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    // Default today's records
    const today = new Date().toISOString().split('T')[0];
    return initialStudents.map(s => ({
      id: `att_${s.id}_${today}`,
      studentId: s.id,
      studentName: s.name,
      date: today,
      status: s.isPresent ? 'PRESENT' : 'ABSENT'
    }));
  });

  const [teacherAttendanceRecords, setTeacherAttendanceRecords] = useState<TeacherAttendanceRecord[]>(() => {
    const saved = localStorage.getItem('ch_teacher_attendance');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return initialTeacherAttendance;
  });

  const [examTerm, setExamTerm] = useState<string>('2nd Term 2026');

  const [examRecords, setExamRecords] = useState<StudentExamRecord[]>(() => {
    const saved = localStorage.getItem('ch_exams');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      {
        studentId: 's1',
        studentName: 'Kasun Perera',
        rollNo: '1001',
        examTerm: '2nd Term 2026',
        subjectMarks: { Mathematics: 88, Science: 85, Sinhala: 90, English: 82, History: 89, ICT: 94 },
        totalMarks: 528,
        average: 88,
        rank: 2,
        grade: 'A'
      },
      {
        studentId: 's3',
        studentName: 'Amali Fernando',
        rollNo: '1003',
        examTerm: '2nd Term 2026',
        subjectMarks: { Mathematics: 96, Science: 94, Sinhala: 92, English: 98, History: 90, ICT: 96 },
        totalMarks: 566,
        average: 94.3,
        rank: 1,
        grade: 'A+'
      },
      {
        studentId: 's5',
        studentName: 'Dilini Jayasinghe',
        rollNo: '1005',
        examTerm: '2nd Term 2026',
        subjectMarks: { Mathematics: 78, Science: 82, Sinhala: 85, English: 80, History: 84, ICT: 77 },
        totalMarks: 486,
        average: 81,
        rank: 3,
        grade: 'A'
      }
    ];
  });

  const [timetable, setTimetable] = useState<TimetablePeriod[]>(() => {
    const saved = localStorage.getItem('ch_timetable');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return initialTimetable;
  });

  const [classNotes, setClassNotes] = useState<ClassNote[]>(() => {
    const saved = localStorage.getItem('ch_notes');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return initialNotes;
  });

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('ch_session', JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    localStorage.setItem('ch_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('ch_grades', JSON.stringify(grades));
  }, [grades]);

  useEffect(() => {
    localStorage.setItem('ch_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('ch_subjects', JSON.stringify(subjects));
  }, [subjects]);

  useEffect(() => {
    localStorage.setItem('ch_attendance', JSON.stringify(attendanceRecords));
  }, [attendanceRecords]);

  useEffect(() => {
    localStorage.setItem('ch_teacher_attendance', JSON.stringify(teacherAttendanceRecords));
  }, [teacherAttendanceRecords]);

  useEffect(() => {
    localStorage.setItem('ch_exams', JSON.stringify(examRecords));
  }, [examRecords]);

  useEffect(() => {
    localStorage.setItem('ch_timetable', JSON.stringify(timetable));
  }, [timetable]);

  useEffect(() => {
    localStorage.setItem('ch_notes', JSON.stringify(classNotes));
  }, [classNotes]);

  // Real-time Background Drive Sync Engine (1-Second Interval + Old Revisions Purge)
  useEffect(() => {
    if (!settings.autoBackupDrive) return;

    const interval = setInterval(() => {
      // Create lightweight snapshot payload
      const payload = {
        timestamp: new Date().toISOString(),
        studentsCount: students.length,
        attendanceCount: attendanceRecords.length,
        teacherAttendanceCount: teacherAttendanceRecords.length,
        examsCount: examRecords.length,
        timetableCount: timetable.length,
        session: session.displayName,
        school: session.schoolName
      };

      // 1. Purge/Overwrite old revision keys
      if (settings.autoPurgeOldBackups) {
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith('ch_gdrive_backup_rev_')) {
            localStorage.removeItem(key);
          }
        }
      }

      // 2. Save strictly single latest backup state
      localStorage.setItem('ch_gdrive_latest_backup', JSON.stringify(payload));

      const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastSyncTime(now);
    }, (settings.realtimeSyncIntervalSec || 1) * 1000);

    return () => clearInterval(interval);
  }, [settings.autoBackupDrive, settings.realtimeSyncIntervalSec, settings.autoPurgeOldBackups, students, attendanceRecords, teacherAttendanceRecords, examRecords, timetable, session]);

  // Methods
  const updateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  const verifyPin = (pin: string) => {
    return pin === settings.securityPin;
  };

  const triggerDriveSync = async () => {
    setIsSyncing(true);
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Purge old backup revisions on Google Drive simulation
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('ch_gdrive_backup_rev_')) {
        localStorage.removeItem(key);
      }
    }
    localStorage.setItem('ch_gdrive_latest_backup', JSON.stringify({
      manualSyncAt: new Date().toISOString(),
      status: 'SUCCESS_LATEST_STATE_OVERWRITTEN'
    }));

    const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setLastSyncTime(now);
    updateSettings({ lastDriveSync: now });
    setIsSyncing(false);
  };

  const addGrade = (grade: string) => {
    const trimmed = grade.trim();
    if (trimmed && !grades.includes(trimmed)) {
      setGrades(prev => [...prev, trimmed]);
    }
  };

  const deleteGrade = (grade: string) => {
    setGrades(prev => prev.filter(g => g !== grade));
  };

  const addStudent = (studentData: Omit<Student, 'id'>) => {
    const id = 's_' + Date.now();
    const newStudent: Student = { ...studentData, id };
    setStudents(prev => [...prev, newStudent]);
  };

  const updateStudent = (id: string, updated: Partial<Student>) => {
    setStudents(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
  };

  const deleteStudent = (id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
  };

  const addSubject = (subject: string) => {
    if (!subjects.includes(subject)) {
      setSubjects(prev => [...prev, subject]);
    }
  };

  const deleteSubject = (subject: string) => {
    setSubjects(prev => prev.filter(s => s !== subject));
  };

  const markAttendance = (studentId: string, studentName: string, date: string, status: AttendanceStatus, remarks?: string) => {
    setAttendanceRecords(prev => {
      const existingIndex = prev.findIndex(r => r.studentId === studentId && r.date === date);
      if (existingIndex >= 0) {
        const copy = [...prev];
        copy[existingIndex] = { ...copy[existingIndex], status, remarks };
        return copy;
      } else {
        return [...prev, {
          id: `att_${studentId}_${date}`,
          studentId,
          studentName,
          date,
          status,
          remarks
        }];
      }
    });

    const today = new Date().toISOString().split('T')[0];
    if (date === today) {
      setStudents(prev => prev.map(s => s.id === studentId ? { ...s, isPresent: status === 'PRESENT' } : s));
    }
  };

  const markTeacherAttendance = (
    teacherName: string,
    date: string,
    status: TeacherAttendanceStatus,
    timeIn?: string,
    timeOut?: string,
    notes?: string
  ) => {
    setTeacherAttendanceRecords(prev => {
      const existingIndex = prev.findIndex(r => r.teacherName === teacherName && r.date === date);
      if (existingIndex >= 0) {
        const copy = [...prev];
        copy[existingIndex] = { ...copy[existingIndex], status, timeIn, timeOut, notes };
        return copy;
      } else {
        return [
          ...prev,
          {
            id: `ta_${Date.now()}`,
            teacherName,
            date,
            status,
            timeIn: timeIn || '07:30 AM',
            timeOut: timeOut || '01:30 PM',
            notes
          }
        ];
      }
    });
  };

  const updateTeacherAttendance = (id: string, updated: Partial<TeacherAttendanceRecord>) => {
    setTeacherAttendanceRecords(prev => prev.map(r => r.id === id ? { ...r, ...updated } : r));
  };

  const deleteTeacherAttendance = (id: string) => {
    setTeacherAttendanceRecords(prev => prev.filter(r => r.id !== id));
  };

  const getAttendanceForDate = (date: string) => {
    const map: Record<string, AttendanceStatus> = {};
    attendanceRecords.filter(r => r.date === date).forEach(r => {
      map[r.studentId] = r.status;
    });
    return map;
  };

  const saveStudentMarks = (
    studentId: string,
    studentName: string,
    rollNo: string,
    term: string,
    subjectMarks: Record<string, number>
  ) => {
    const marksList = Object.values(subjectMarks);
    const totalMarks = marksList.reduce((a, b) => a + b, 0);
    const average = marksList.length > 0 ? parseFloat((totalMarks / marksList.length).toFixed(1)) : 0;
    
    let grade = 'F';
    if (average >= 90) grade = 'A+';
    else if (average >= 75) grade = 'A';
    else if (average >= 65) grade = 'B';
    else if (average >= 55) grade = 'C';
    else if (average >= 35) grade = 'S';

    setExamRecords(prev => {
      const existing = prev.filter(r => !(r.studentId === studentId && r.examTerm === term));
      const updatedList = [
        ...existing,
        {
          studentId,
          studentName,
          rollNo,
          examTerm: term,
          subjectMarks,
          totalMarks,
          average,
          rank: 0,
          grade
        }
      ];

      const termRecords = updatedList.filter(r => r.examTerm === term).sort((a, b) => b.totalMarks - a.totalMarks);
      termRecords.forEach((rec, idx) => { rec.rank = idx + 1; });

      return updatedList;
    });
  };

  const addTimetableEntry = (entry: Omit<TimetablePeriod, 'id'>) => {
    const id = 't_' + Date.now();
    setTimetable(prev => [...prev, { ...entry, id }]);
  };

  const deleteTimetableEntry = (id: string) => {
    setTimetable(prev => prev.filter(t => t.id !== id));
  };

  const addClassNote = (note: Omit<ClassNote, 'id' | 'date'>) => {
    const id = 'n_' + Date.now();
    const date = new Date().toISOString().split('T')[0];
    setClassNotes(prev => [{ ...note, id, date }, ...prev]);
  };

  const deleteClassNote = (id: string) => {
    setClassNotes(prev => prev.filter(n => n.id !== id));
  };

  const importClassDataset = (payload: any) => {
    if (payload.students && Array.isArray(payload.students) && payload.students.length > 0) {
      setStudents(payload.students);
    }
    if (payload.attendanceHistory && Array.isArray(payload.attendanceHistory)) {
      setAttendanceRecords(payload.attendanceHistory);
    }
    if (payload.teacherAttendance && Array.isArray(payload.teacherAttendance)) {
      setTeacherAttendanceRecords(payload.teacherAttendance);
    }
    if (payload.marksHistory && Array.isArray(payload.marksHistory)) {
      setExamRecords(payload.marksHistory);
    }
    if (payload.timetable && Array.isArray(payload.timetable)) {
      setTimetable(payload.timetable);
    }
    if (payload.notes && Array.isArray(payload.notes)) {
      setClassNotes(payload.notes);
    }
    setTimeout(() => {
      triggerDriveSync();
    }, 500);
  };

  return (
    <AppContext.Provider value={{
      activeTab,
      setActiveTab,
      settingsSubTab,
      setSettingsSubTab,
      session,
      setSession,
      isAuthModalOpen,
      setIsAuthModalOpen,
      isPinLocked,
      setIsPinLocked,
      verifyPin,
      settings,
      updateSettings,
      isSyncing,
      lastSyncTime,
      triggerDriveSync,
      grades,
      addGrade,
      deleteGrade,
      students,
      addStudent,
      updateStudent,
      deleteStudent,
      subjects,
      addSubject,
      deleteSubject,
      attendanceRecords,
      markAttendance,
      getAttendanceForDate,
      teacherAttendanceRecords,
      markTeacherAttendance,
      updateTeacherAttendance,
      deleteTeacherAttendance,
      examTerm,
      setExamTerm,
      examRecords,
      saveStudentMarks,
      timetable,
      addTimetableEntry,
      deleteTimetableEntry,
      classNotes,
      addClassNote,
      deleteClassNote,
      importClassDataset
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
