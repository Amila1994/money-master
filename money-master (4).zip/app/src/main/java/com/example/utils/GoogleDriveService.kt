package com.example.utils

import android.content.Context

object GoogleDriveService {
    fun getAccessToken(context: Context): String? {
        return null
    }

    fun uploadBackup(context: Context, onResult: (Boolean, String) -> Unit) {
        onResult(false, "Google Drive Backup is currently disabled as the auth/billing module is removed.")
    }

    fun restoreBackup(context: Context, onResult: (Boolean, String) -> Unit) {
        onResult(false, "Google Drive Restore is currently disabled as the auth/billing module is removed.")
    }
}
