package com.aistudio.classroomhub.app;

public class ChatMessage {
    private String messageId;
    private String senderUid;
    private String receiverUid;
    private String messageText;
    private long timestamp;
    private String senderSchoolName;

    // Advanced Chat Features
    private String messageType = "TEXT"; // "TEXT", "IMAGE", "FILE"
    private String mediaUrl = "";
    private String fileName = "";
    private boolean seen = false;
    private long seenAt = 0L;
    private boolean deleted = false;

    public ChatMessage() {
        // Default constructor required for Firestore
    }

    public ChatMessage(String senderUid, String receiverUid, String messageText, long timestamp, String senderSchoolName) {
        this.senderUid = senderUid;
        this.receiverUid = receiverUid;
        this.messageText = messageText;
        this.timestamp = timestamp;
        this.senderSchoolName = senderSchoolName;
        this.messageType = "TEXT";
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getSenderUid() {
        return senderUid;
    }

    public void setSenderUid(String senderUid) {
        this.senderUid = senderUid;
    }

    public String getReceiverUid() {
        return receiverUid;
    }

    public void setReceiverUid(String receiverUid) {
        this.receiverUid = receiverUid;
    }

    public String getMessageText() {
        return messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getSenderSchoolName() {
        return senderSchoolName;
    }

    public void setSenderSchoolName(String senderSchoolName) {
        this.senderSchoolName = senderSchoolName;
    }

    public String getMessageType() {
        return messageType != null ? messageType : "TEXT";
    }

    public void setMessageType(String messageType) {
        this.messageType = messageType;
    }

    public String getMediaUrl() {
        return mediaUrl != null ? mediaUrl : "";
    }

    public void setMediaUrl(String mediaUrl) {
        this.mediaUrl = mediaUrl;
    }

    public String getFileName() {
        return fileName != null ? fileName : "";
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public boolean isSeen() {
        return seen;
    }

    public void setSeen(boolean seen) {
        this.seen = seen;
    }

    public long getSeenAt() {
        return seenAt;
    }

    public void setSeenAt(long seenAt) {
        this.seenAt = seenAt;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
}
