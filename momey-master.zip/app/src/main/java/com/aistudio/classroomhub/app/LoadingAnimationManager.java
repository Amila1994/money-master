package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;

public class LoadingAnimationManager {
    public static final String PREF_NAME = "app_loader_prefs";
    public static final String KEY_ANIMATION_STYLE = "loading_animation_style";

    public enum LoaderStyle {
        CIRCULAR_SPINNER("Circular Spinner", "කැරකෙන චක්‍රය"),
        PULSE_DOTS("Pulse Dots", "ස්පන්දන බිංදු"),
        WAVE_BARS("Wave Bars", "තරංග තීරු"),
        BOUNCING_BALLS("Bouncing Balls", "උඩ පනින බෝල"),
        SKELETON_SHIMMER("Skeleton Shimmer", "සැකිලි ශිමර්"),
        CUBE_FLIP("Cube Flip", "කැරකෙන කැටය"),
        DUAL_RING("Dual Ring", "ද්විත්ව වළලු"),
        RIPPLE_EFFECT("Ripple Effect", "දිය රළ සටහන"),
        ORBITING_PLANETS("Orbiting Planets", "පරිභ්‍රමණය වන ග්‍රහලෝක"),
        HOURGLASS_FLIP("Hourglass Flip", "පැය වීදුරුව"),
        RADAR_PULSE("Radar Pulse", "රේඩාර් ස්කෑනරය"),
        FADING_CIRCLES("Fading Circles", "මැකී යන වළලු"),
        ROTATING_SQUARE("Rotating Square", "කැරකෙන සමචතුරස්‍රය"),
        ARC_SPINNER("Arc Spinner", "චාප කැරකැවුම"),
        BREATHING_GLOW("Breathing Glow", "ආශ්වාස ආලෝකය"),
        MORPHING_TRIANGLE("Morphing Triangle", "හැඩය වෙනස්වන ත්‍රිකෝණය"),
        CLOCK_SWEEP("Clock Sweep", "ඔරලෝසු භ්‍රමණය"),
        MATRIX_RAIN_DOTS("Matrix Rain Dots", "මැට්‍රික්ස් වර්ෂාව"),
        STAIRCASE_STEPS("Staircase Steps", "පඩිපෙළ රටාව"),
        HEXAGON_PULSE("Hexagon Pulse", "ෂඩස්‍ර ස්පන්දනය");

        private final String englishName;
        private final String sinhalaName;

        LoaderStyle(String englishName, String sinhalaName) {
            this.englishName = englishName;
            this.sinhalaName = sinhalaName;
        }

        public String getEnglishName() {
            return englishName;
        }

        public String getSinhalaName() {
            return sinhalaName;
        }

        public String getDisplayName(Context context) {
            String lang = AppSecurityManager.getSelectedLanguageCode(context);
            if ("si".equals(lang)) {
                return sinhalaName + " (" + englishName + ")";
            }
            return englishName;
        }
    }

    public static LoaderStyle getSelectedStyle(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        int ordinal = prefs.getInt(KEY_ANIMATION_STYLE, 0);
        LoaderStyle[] values = LoaderStyle.values();
        if (ordinal >= 0 && ordinal < values.length) {
            return values[ordinal];
        }
        return LoaderStyle.CIRCULAR_SPINNER;
    }

    public static void setSelectedStyle(Context context, LoaderStyle style) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putInt(KEY_ANIMATION_STYLE, style.ordinal()).apply();
    }
}
