package com.aistudio.classroomhub.app.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "app_backups")
public class BackupEntity {

    @PrimaryKey
    public int id = 1; // Single row to store current database state

    public String jsonContent;
    public long updatedAt;
    public boolean isSynced;

    public BackupEntity(int id, String jsonContent, long updatedAt, boolean isSynced) {
        this.id = id;
        this.jsonContent = jsonContent;
        this.updatedAt = updatedAt;
        this.isSynced = isSynced;
    }
}
