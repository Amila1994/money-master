package com.aistudio.classroomhub.app;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

public class SyncScheduler {

    private static final String ONE_TIME_SYNC_WORK_NAME = "classroom_one_time_sync";
    private static final String PERIODIC_SYNC_WORK_NAME = "classroom_daily_periodic_sync";

    /**
     * Triggers immediate local save (Offline-First) and enqueues a silent cloud sync via WorkManager.
     */
    public static void triggerBackgroundSync(Context context) {
        if (context == null) return;

        // 1. Save data locally to Room & file cache immediately
        DataBackupManager.saveLocalState(context);

        // 2. Enqueue background cloud sync when internet is connected
        try {
            Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

            OneTimeWorkRequest syncRequest = new OneTimeWorkRequest.Builder(AutoSyncWorker.class)
                    .setConstraints(constraints)
                    .build();

            WorkManager.getInstance(context.getApplicationContext())
                    .enqueueUniqueWork(ONE_TIME_SYNC_WORK_NAME, ExistingWorkPolicy.REPLACE, syncRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Schedules a daily background sync job.
     */
    public static void scheduleDailyPeriodicSync(Context context) {
        if (context == null) return;

        try {
            Constraints constraints = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();

            PeriodicWorkRequest periodicRequest = new PeriodicWorkRequest.Builder(
                    AutoSyncWorker.class, 24, TimeUnit.HOURS)
                    .setConstraints(constraints)
                    .build();

            WorkManager.getInstance(context.getApplicationContext())
                    .enqueueUniquePeriodicWork(PERIODIC_SYNC_WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, periodicRequest);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
