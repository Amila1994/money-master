package com.aistudio.classroomhub.app.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface BackupDao {

    @Query("SELECT * FROM app_backups WHERE id = 1 LIMIT 1")
    BackupEntity getBackup();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOrUpdateBackup(BackupEntity backup);

    @Query("UPDATE app_backups SET isSynced = :isSynced WHERE id = 1")
    void setSyncStatus(boolean isSynced);

    @Query("DELETE FROM app_backups")
    void clearAll();
}
