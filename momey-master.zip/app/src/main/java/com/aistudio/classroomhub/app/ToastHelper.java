package com.aistudio.classroomhub.app;

import android.content.Context;
import android.widget.Toast;

public class ToastHelper {

    private static Toast currentToast;

    public static synchronized void showToast(Context context, String message, int duration) {
        if (context == null) return;
        try {
            if (currentToast != null) {
                currentToast.cancel();
            }
            currentToast = Toast.makeText(context.getApplicationContext(), message, duration);
            currentToast.show();
        } catch (Exception e) {
            // Fallback safety
        }
    }

    public static void showShort(Context context, String message) {
        showToast(context, message, Toast.LENGTH_SHORT);
    }

    public static void showLong(Context context, String message) {
        showToast(context, message, Toast.LENGTH_LONG);
    }
}
