package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Environment;
import android.text.TextPaint;
import android.util.Log;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class LetterPdfExporter {

    private static final String TAG = "LetterPdfExporter";
    private static final int MARGIN = 45;       // Left & Right margin

    public static File exportLetterToPdf(Context context, String title, String content, boolean includeSchoolHeader) {
        return exportLetterToPdf(context, title, content, includeSchoolHeader, "A4", "PORTRAIT");
    }

    public static File exportLetterToPdf(Context context, String title, String content, boolean includeSchoolHeader, String pageSizeStr, String orientationStr) {
        try {
            int baseWidth = 595;
            int baseHeight = 842;

            if ("A3".equalsIgnoreCase(pageSizeStr)) {
                baseWidth = 842;
                baseHeight = 1191;
            } else if ("LETTER".equalsIgnoreCase(pageSizeStr)) {
                baseWidth = 612;
                baseHeight = 792;
            } else if ("LEGAL".equalsIgnoreCase(pageSizeStr)) {
                baseWidth = 612;
                baseHeight = 1008;
            } else { // A4
                baseWidth = 595;
                baseHeight = 842;
            }

            int pageWidth = "LANDSCAPE".equalsIgnoreCase(orientationStr) ? baseHeight : baseWidth;
            int pageHeight = "LANDSCAPE".equalsIgnoreCase(orientationStr) ? baseWidth : baseHeight;

            PdfDocument pdfDocument = new PdfDocument();
            Paint paint = new Paint();
            TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);

            int pageNum = 1;
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create();
            PdfDocument.Page page = pdfDocument.startPage(pageInfo);
            Canvas canvas = page.getCanvas();

            int currentY = 40;

            // 1. Optional School Header Banner
            if (includeSchoolHeader) {
                currentY = drawOfficialSchoolHeader(context, canvas, paint, textPaint, pageWidth);
            } else {
                currentY = 50;
            }

            // 2. Wrap text content lines
            textPaint.setColor(Color.parseColor("#1E293B"));
            textPaint.setTextSize(11);
            textPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));

            int maxTextWidth = pageWidth - (MARGIN * 2);
            List<String> wrappedLines = wrapText(content, textPaint, maxTextWidth);

            int lineHeight = 18;
            int footerSpace = 60;

            for (String line : wrappedLines) {
                if (currentY + lineHeight > pageHeight - footerSpace) {
                    // Draw Page Footer
                    drawFooter(canvas, textPaint, pageNum, pageWidth, pageHeight);
                    pdfDocument.finishPage(page);

                    // New Page
                    pageNum++;
                    pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create();
                    page = pdfDocument.startPage(pageInfo);
                    canvas = page.getCanvas();
                    currentY = 50;
                }

                // Check if line is bold header or subject line
                if (line.startsWith("Subject:") || line.startsWith("विषය:") || line.startsWith("මාතෘකාව:") || line.toUpperCase().contains("APPLICATION FOR") || line.contains("RECOMMENDATION")) {
                    textPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
                    textPaint.setTextSize(12);
                    textPaint.setColor(Color.parseColor("#0F172A"));
                } else {
                    textPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
                    textPaint.setTextSize(11);
                    textPaint.setColor(Color.parseColor("#1E293B"));
                }

                canvas.drawText(line, MARGIN, currentY, textPaint);
                currentY += lineHeight;
            }

            // Draw Footer on last page
            drawFooter(canvas, textPaint, pageNum, pageWidth, pageHeight);
            pdfDocument.finishPage(page);

            // Save PDF File
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String sanitizedTitle = title.replaceAll("[^a-zA-Z0-9\\-_]", "_");
            String fileName = "Letter_" + sanitizedTitle + "_" + timeStamp + ".pdf";

            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (downloadsDir != null && !downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            File pdfFile = new File(downloadsDir, fileName);
            FileOutputStream fos = new FileOutputStream(pdfFile);
            pdfDocument.writeTo(fos);
            pdfDocument.close();
            fos.close();

            Log.d(TAG, "PDF Exported successfully to: " + pdfFile.getAbsolutePath());
            return pdfFile;

        } catch (Exception e) {
            Log.e(TAG, "Error exporting letter PDF", e);
            return null;
        }
    }

    private static int drawOfficialSchoolHeader(Context context, Canvas canvas, Paint paint, TextPaint textPaint, int pageWidth) {
        SharedPreferences prefs = context.getSharedPreferences("school_header_prefs", Context.MODE_PRIVATE);
        String schoolName = prefs.getString("school_name", "මධ්‍ය මහා විද්‍යාලය - කොළඹ");
        String schoolAddress = prefs.getString("school_address", "නො. 123, ගාලු පාර, කොළඹ 03 | දුරකථන: 011-2345678");
        String logoPath = prefs.getString("school_logo_path", "");

        // Top Navy Header Bar
        paint.setColor(Color.parseColor("#1E293B"));
        canvas.drawRect(0, 0, pageWidth, 70, paint);

        // Draw School Crest Logo
        Bitmap logoBitmap = null;
        if (logoPath != null && !logoPath.isEmpty()) {
            File imgFile = new File(logoPath);
            if (imgFile.exists()) {
                logoBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
            }
        }

        if (logoBitmap != null) {
            Bitmap scaledLogo = Bitmap.createScaledBitmap(logoBitmap, 48, 48, true);
            canvas.drawBitmap(scaledLogo, 20, 11, paint);
        } else {
            // Emblem Circle Badge
            paint.setColor(Color.parseColor("#38BDF8"));
            canvas.drawCircle(44, 35, 22, paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(44, 35, 18, paint);

            textPaint.setColor(Color.parseColor("#1E293B"));
            textPaint.setTextSize(14);
            textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            canvas.drawText("🎓", 36, 40, textPaint);
        }

        // School Title & Address
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(14);
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        canvas.drawText(schoolName, 80, 30, textPaint);

        textPaint.setTextSize(9);
        textPaint.setTypeface(Typeface.DEFAULT);
        textPaint.setColor(Color.parseColor("#CBD5E1"));
        canvas.drawText(schoolAddress, 80, 50, textPaint);

        // Gold Divider Line
        paint.setColor(Color.parseColor("#F59E0B"));
        canvas.drawRect(0, 70, pageWidth, 74, paint);

        return 100; // Return Y start position for document content
    }

    private static void drawFooter(Canvas canvas, TextPaint textPaint, int pageNum, int pageWidth, int pageHeight) {
        textPaint.setColor(Color.parseColor("#94A3B8"));
        textPaint.setTextSize(9);
        textPaint.setTypeface(Typeface.DEFAULT);

        String footerText = "ClassroomHub Official School Letter | Page " + pageNum;
        canvas.drawText(footerText, MARGIN, pageHeight - 25, textPaint);

        // Draw thin footer line
        Paint linePaint = new Paint();
        linePaint.setColor(Color.parseColor("#E2E8F0"));
        linePaint.setStrokeWidth(1);
        canvas.drawLine(MARGIN, pageHeight - 40, pageWidth - MARGIN, pageHeight - 40, linePaint);
    }

    private static List<String> wrapText(String text, TextPaint paint, int maxWidth) {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) return result;

        String[] paragraphs = text.split("\n");
        for (String paragraph : paragraphs) {
            if (paragraph.trim().isEmpty()) {
                result.add(""); // Empty line break
                continue;
            }

            String[] words = paragraph.split(" ");
            StringBuilder line = new StringBuilder();

            for (String word : words) {
                String testLine = line.length() == 0 ? word : line + " " + word;
                float measureWidth = paint.measureText(testLine);

                if (measureWidth <= maxWidth) {
                    line.append(line.length() == 0 ? "" : " ").append(word);
                } else {
                    if (line.length() > 0) {
                        result.add(line.toString());
                        line = new StringBuilder(word);
                    } else {
                        result.add(word);
                    }
                }
            }
            if (line.length() > 0) {
                result.add(line.toString());
            }
        }
        return result;
    }

    public static void openFile(Context context, File file, String mimeType) {
        if (file == null || !file.exists()) {
            ToastHelper.showShort(context, "File not found");
            return;
        }

        try {
            Uri uri = FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mimeType);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            context.startActivity(Intent.createChooser(intent, "Open file with..."));
        } catch (Exception e) {
            ToastHelper.showLong(context, "No app found to open this file type. Saved in Downloads.");
        }
    }
}
