package com.aistudio.classroomhub.app;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class DocxGenerator {

    private static final String TAG = "DocxGenerator";

    /**
     * Converts raw letter text into a valid Microsoft Word (.docx) file.
     *
     * @param context Application context
     * @param title Document title or template name
     * @param content Plain or formatted text content
     * @return Generated File object, or null if failed
     */
    public static File createDocxFile(Context context, String title, String content) {
        return createDocxFile(context, title, content, "A4", "PORTRAIT");
    }

    public static File createDocxFile(Context context, String title, String content, String pageSize, String orientation) {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String sanitizedTitle = title.replaceAll("[^a-zA-Z0-9\\-_]", "_");
            String fileName = "Letter_" + sanitizedTitle + "_" + timeStamp + ".docx";

            File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (downloadsDir != null && !downloadsDir.exists()) {
                downloadsDir.mkdirs();
            }

            File docxFile = new File(downloadsDir, fileName);
            if (docxFile.exists()) {
                docxFile.delete();
            }

            FileOutputStream fos = new FileOutputStream(docxFile);
            ZipOutputStream zos = new ZipOutputStream(fos);

            // 1. Add [Content_Types].xml
            addZipEntry(zos, "[Content_Types].xml", getContentTypesXml());

            // 2. Add _rels/.rels
            addZipEntry(zos, "_rels/.rels", getRelsXml());

            // 3. Add word/document.xml
            addZipEntry(zos, "word/document.xml", getDocumentXml(content, pageSize, orientation));

            zos.close();
            fos.close();

            Log.d(TAG, "DOCX generated successfully at: " + docxFile.getAbsolutePath());
            return docxFile;

        } catch (Exception e) {
            Log.e(TAG, "Error generating DOCX file", e);
            return null;
        }
    }

    private static void addZipEntry(ZipOutputStream zos, String entryName, String xmlContent) throws Exception {
        ZipEntry entry = new ZipEntry(entryName);
        zos.putNextEntry(entry);
        byte[] bytes = xmlContent.getBytes(StandardCharsets.UTF_8);
        zos.write(bytes, 0, bytes.length);
        zos.closeEntry();
    }

    private static String getContentTypesXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">\n" +
                "  <Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>\n" +
                "  <Default Extension=\"xml\" ContentType=\"application/xml\"/>\n" +
                "  <Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>\n" +
                "</Types>";
    }

    private static String getRelsXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">\n" +
                "  <Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>\n" +
                "</Relationships>";
    }

    private static String getDocumentXml(String rawText, String pageSizeStr, String orientationStr) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n");
        sb.append("<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">\n");
        sb.append("  <w:body>\n");

        if (rawText != null) {
            String[] lines = rawText.split("\n");
            for (String line : lines) {
                String escapedLine = escapeXml(line);
                sb.append("    <w:p>\n");
                sb.append("      <w:pPr>\n");
                sb.append("        <w:spacing w:line=\"280\" w:lineRule=\"auto\" w:before=\"80\" w:after=\"80\"/>\n");
                sb.append("      </w:pPr>\n");
                sb.append("      <w:r>\n");
                sb.append("        <w:rPr>\n");
                sb.append("          <w:rFonts w:ascii=\"Arial\" w:hAnsi=\"Arial\" w:cs=\"Arial\"/>\n");
                sb.append("          <w:sz w:val=\"22\"/>\n"); // 11pt font size
                sb.append("        </w:rPr>\n");
                sb.append("        <w:t xml:space=\"preserve\">").append(escapedLine).append("</w:t>\n");
                sb.append("      </w:r>\n");
                sb.append("    </w:p>\n");
            }
        }

        int widthTwips = 11906;  // A4
        int heightTwips = 16838;

        if ("A3".equalsIgnoreCase(pageSizeStr)) {
            widthTwips = 16838;
            heightTwips = 23811;
        } else if ("LETTER".equalsIgnoreCase(pageSizeStr)) {
            widthTwips = 12240;
            heightTwips = 15840;
        } else if ("LEGAL".equalsIgnoreCase(pageSizeStr)) {
            widthTwips = 12240;
            heightTwips = 20160;
        }

        boolean isLandscape = "LANDSCAPE".equalsIgnoreCase(orientationStr);
        int finalW = isLandscape ? heightTwips : widthTwips;
        int finalH = isLandscape ? widthTwips : heightTwips;

        sb.append("    <w:sectPr>\n");
        if (isLandscape) {
            sb.append("      <w:pgSz w:w=\"").append(finalW).append("\" w:h=\"").append(finalH).append("\" w:orient=\"landscape\"/>\n");
        } else {
            sb.append("      <w:pgSz w:w=\"").append(finalW).append("\" w:h=\"").append(finalH).append("\"/>\n");
        }
        sb.append("      <w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\"/>\n");
        sb.append("    </w:sectPr>\n");
        sb.append("  </w:body>\n");
        sb.append("</w:document>");

        return sb.toString();
    }

    private static String escapeXml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }
}
