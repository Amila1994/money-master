package com.aistudio.classroomhub.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;

public class AppLoadingView extends View {

    private Paint paint;
    private Paint fillPaint;
    private Paint glowPaint;
    private ValueAnimator animator;
    private float progress = 0f;

    private LoadingAnimationManager.LoaderStyle overrideStyle = null;

    public AppLoadingView(Context context) {
        super(context);
        init();
    }

    public AppLoadingView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AppLoadingView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(Color.parseColor("#38BDF8")); // Primary Sky Blue
        paint.setStrokeWidth(dpToPx(4));

        fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setColor(Color.parseColor("#38BDF8"));

        glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        glowPaint.setStyle(Paint.Style.FILL);
        glowPaint.setColor(Color.parseColor("#3338BDF8"));

        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1200);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            progress = (float) animation.getAnimatedValue();
            invalidate();
        });
    }

    public void setLoaderStyle(LoadingAnimationManager.LoaderStyle style) {
        this.overrideStyle = style;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (animator != null && !animator.isRunning()) {
            animator.start();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) {
            animator.cancel();
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int defaultSize = dpToPx(56);
        int width = resolveSize(defaultSize, widthMeasureSpec);
        int height = resolveSize(defaultSize, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        LoadingAnimationManager.LoaderStyle style = overrideStyle != null
                ? overrideStyle
                : LoadingAnimationManager.getSelectedStyle(getContext());

        int width = getWidth();
        int height = getHeight();
        float cx = width / 2f;
        float cy = height / 2f;
        float size = Math.min(width, height) * 0.8f;
        float radius = size / 2f;

        if (radius <= 0) return;

        switch (style) {
            case CIRCULAR_SPINNER:
                drawCircularSpinner(canvas, cx, cy, radius);
                break;
            case PULSE_DOTS:
                drawPulseDots(canvas, cx, cy, size);
                break;
            case WAVE_BARS:
                drawWaveBars(canvas, cx, cy, size);
                break;
            case BOUNCING_BALLS:
                drawBouncingBalls(canvas, cx, cy, size);
                break;
            case SKELETON_SHIMMER:
                drawSkeletonShimmer(canvas, cx, cy, size);
                break;
            case CUBE_FLIP:
                drawCubeFlip(canvas, cx, cy, size);
                break;
            case DUAL_RING:
                drawDualRing(canvas, cx, cy, radius);
                break;
            case RIPPLE_EFFECT:
                drawRippleEffect(canvas, cx, cy, radius);
                break;
            case ORBITING_PLANETS:
                drawOrbitingPlanets(canvas, cx, cy, radius);
                break;
            case HOURGLASS_FLIP:
                drawHourglassFlip(canvas, cx, cy, size);
                break;
            case RADAR_PULSE:
                drawRadarPulse(canvas, cx, cy, radius);
                break;
            case FADING_CIRCLES:
                drawFadingCircles(canvas, cx, cy, radius);
                break;
            case ROTATING_SQUARE:
                drawRotatingSquare(canvas, cx, cy, size);
                break;
            case ARC_SPINNER:
                drawArcSpinner(canvas, cx, cy, radius);
                break;
            case BREATHING_GLOW:
                drawBreathingGlow(canvas, cx, cy, radius);
                break;
            case MORPHING_TRIANGLE:
                drawMorphingTriangle(canvas, cx, cy, radius);
                break;
            case CLOCK_SWEEP:
                drawClockSweep(canvas, cx, cy, radius);
                break;
            case MATRIX_RAIN_DOTS:
                drawMatrixRainDots(canvas, cx, cy, size);
                break;
            case STAIRCASE_STEPS:
                drawStaircaseSteps(canvas, cx, cy, size);
                break;
            case HEXAGON_PULSE:
                drawHexagonPulse(canvas, cx, cy, radius);
                break;
        }
    }

    // 1. Circular Spinner
    private void drawCircularSpinner(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(4));
        paint.setColor(Color.parseColor("#38BDF8"));

        float startAngle = progress * 360f;
        float sweepAngle = 90f + (float) Math.sin(progress * Math.PI * 2) * 60f;

        RectF rect = new RectF(cx - radius + 4, cy - radius + 4, cx + radius - 4, cy + radius - 4);
        canvas.drawArc(rect, startAngle, sweepAngle, false, paint);
    }

    // 2. Pulse Dots
    private void drawPulseDots(Canvas canvas, float cx, float cy, float size) {
        int numDots = 3;
        float dotSpacing = size / 3f;
        float startX = cx - (dotSpacing * (numDots - 1) / 2f);

        for (int i = 0; i < numDots; i++) {
            float phase = (progress + i * 0.25f) % 1.0f;
            float scale = 0.4f + 0.6f * (float) Math.sin(phase * Math.PI);
            float r = dpToPx(5) * scale;

            fillPaint.setColor(Color.parseColor("#38BDF8"));
            fillPaint.setAlpha((int) (100 + 155 * scale));
            canvas.drawCircle(startX + i * dotSpacing, cy, r, fillPaint);
        }
    }

    // 3. Wave Bars
    private void drawWaveBars(Canvas canvas, float cx, float cy, float size) {
        int numBars = 5;
        float barWidth = dpToPx(4);
        float spacing = dpToPx(4);
        float totalWidth = numBars * barWidth + (numBars - 1) * spacing;
        float startX = cx - totalWidth / 2f;
        float maxBarHeight = size * 0.7f;

        fillPaint.setColor(Color.parseColor("#38BDF8"));
        fillPaint.setAlpha(255);

        for (int i = 0; i < numBars; i++) {
            float phase = (progress + i * 0.15f) % 1.0f;
            float h = dpToPx(8) + maxBarHeight * (float) Math.sin(phase * Math.PI);
            float left = startX + i * (barWidth + spacing);
            RectF barRect = new RectF(left, cy - h / 2f, left + barWidth, cy + h / 2f);
            canvas.drawRoundRect(barRect, barWidth / 2f, barWidth / 2f, fillPaint);
        }
    }

    // 4. Bouncing Balls
    private void drawBouncingBalls(Canvas canvas, float cx, float cy, float size) {
        int numBalls = 3;
        float spacing = size / 3.2f;
        float startX = cx - (spacing * (numBalls - 1) / 2f);
        float maxJump = size * 0.35f;

        fillPaint.setColor(Color.parseColor("#38BDF8"));

        for (int i = 0; i < numBalls; i++) {
            float phase = (progress + i * 0.2f) % 1.0f;
            float jumpY = (float) Math.abs(Math.sin(phase * Math.PI)) * maxJump;
            canvas.drawCircle(startX + i * spacing, cy - jumpY + maxJump / 2f, dpToPx(5), fillPaint);
        }
    }

    // 5. Skeleton Shimmer
    private void drawSkeletonShimmer(Canvas canvas, float cx, float cy, float size) {
        float rectWidth = size * 0.9f;
        float rectHeight = dpToPx(12);
        RectF rect = new RectF(cx - rectWidth / 2f, cy - rectHeight / 2f, cx + rectWidth / 2f, cy + rectHeight / 2f);

        fillPaint.setColor(Color.parseColor("#1E293B"));
        canvas.drawRoundRect(rect, dpToPx(6), dpToPx(6), fillPaint);

        float shimmerX = rect.left + (rectWidth + dpToPx(40)) * progress - dpToPx(20);
        LinearGradient gradient = new LinearGradient(
                shimmerX - dpToPx(20), cy, shimmerX + dpToPx(20), cy,
                new int[]{Color.TRANSPARENT, Color.parseColor("#38BDF8"), Color.TRANSPARENT},
                null, Shader.TileMode.CLAMP
        );

        Paint shimmerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        shimmerPaint.setShader(gradient);
        canvas.drawRoundRect(rect, dpToPx(6), dpToPx(6), shimmerPaint);
    }

    // 6. Cube Flip
    private void drawCubeFlip(Canvas canvas, float cx, float cy, float size) {
        canvas.save();
        canvas.translate(cx, cy);
        float angle = progress * 360f;
        canvas.rotate(angle);

        float scale = 0.6f + 0.4f * (float) Math.abs(Math.cos(progress * Math.PI * 2));
        canvas.scale(scale, scale);

        float side = size * 0.45f;
        RectF cubeRect = new RectF(-side / 2f, -side / 2f, side / 2f, side / 2f);

        fillPaint.setColor(Color.parseColor("#38BDF8"));
        fillPaint.setAlpha(220);
        canvas.drawRoundRect(cubeRect, dpToPx(6), dpToPx(6), fillPaint);

        canvas.restore();
    }

    // 7. Dual Ring
    private void drawDualRing(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(3));

        // Outer Ring
        paint.setColor(Color.parseColor("#38BDF8"));
        RectF outerRect = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawArc(outerRect, progress * 360f, 120f, false, paint);

        // Inner Ring
        paint.setColor(Color.parseColor("#818CF8"));
        float innerR = radius * 0.65f;
        RectF innerRect = new RectF(cx - innerR, cy - innerR, cx + innerR, cy + innerR);
        canvas.drawArc(innerRect, -progress * 360f * 1.5f, 140f, false, paint);
    }

    // 8. Ripple Effect
    private void drawRippleEffect(Canvas canvas, float cx, float cy, float radius) {
        int numRipples = 3;
        for (int i = 0; i < numRipples; i++) {
            float phase = (progress + i * 0.33f) % 1.0f;
            float r = radius * phase;
            int alpha = (int) (255 * (1.0f - phase));

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dpToPx(2.5f));
            paint.setColor(Color.parseColor("#38BDF8"));
            paint.setAlpha(alpha);
            canvas.drawCircle(cx, cy, r, paint);
        }
    }

    // 9. Orbiting Planets
    private void drawOrbitingPlanets(Canvas canvas, float cx, float cy, float radius) {
        // Sun
        fillPaint.setColor(Color.parseColor("#F59E0B"));
        fillPaint.setAlpha(255);
        canvas.drawCircle(cx, cy, dpToPx(6), fillPaint);

        // Orbit 1
        float r1 = radius * 0.5f;
        float angle1 = progress * (float) Math.PI * 2f;
        float p1x = cx + (float) Math.cos(angle1) * r1;
        float p1y = cy + (float) Math.sin(angle1) * r1;
        fillPaint.setColor(Color.parseColor("#38BDF8"));
        canvas.drawCircle(p1x, p1y, dpToPx(4), fillPaint);

        // Orbit 2
        float r2 = radius * 0.85f;
        float angle2 = -progress * (float) Math.PI * 3f;
        float p2x = cx + (float) Math.cos(angle2) * r2;
        float p2y = cy + (float) Math.sin(angle2) * r2;
        fillPaint.setColor(Color.parseColor("#EC4899"));
        canvas.drawCircle(p2x, p2y, dpToPx(3.5f), fillPaint);
    }

    // 10. Hourglass Flip
    private void drawHourglassFlip(Canvas canvas, float cx, float cy, float size) {
        canvas.save();
        canvas.translate(cx, cy);

        float rotation = (float) Math.floor(progress * 2) * 180f;
        canvas.rotate(rotation);

        float h = size * 0.4f;
        float w = size * 0.35f;

        Path path = new Path();
        path.moveTo(-w, -h);
        path.lineTo(w, -h);
        path.lineTo(-w, h);
        path.lineTo(w, h);
        path.close();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(3));
        paint.setColor(Color.parseColor("#38BDF8"));
        canvas.drawPath(path, paint);

        // Sand dot
        fillPaint.setColor(Color.parseColor("#F59E0B"));
        float sandY = -h / 2f + progress * h;
        canvas.drawCircle(0, sandY, dpToPx(2.5f), fillPaint);

        canvas.restore();
    }

    // 11. Radar Pulse
    private void drawRadarPulse(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(1.5f));
        paint.setColor(Color.parseColor("#334155"));
        canvas.drawCircle(cx, cy, radius, paint);
        canvas.drawCircle(cx, cy, radius * 0.5f, paint);

        float angle = progress * (float) Math.PI * 2f;
        float endX = cx + (float) Math.cos(angle) * radius;
        float endY = cy + (float) Math.sin(angle) * radius;

        paint.setColor(Color.parseColor("#10B981"));
        paint.setStrokeWidth(dpToPx(2.5f));
        canvas.drawLine(cx, cy, endX, endY, paint);

        fillPaint.setColor(Color.parseColor("#10B981"));
        fillPaint.setAlpha(180);
        canvas.drawCircle(endX, endY, dpToPx(3), fillPaint);
    }

    // 12. Fading Circles
    private void drawFadingCircles(Canvas canvas, float cx, float cy, float radius) {
        int count = 8;
        for (int i = 0; i < count; i++) {
            float angle = (i / (float) count) * (float) Math.PI * 2f;
            float px = cx + (float) Math.cos(angle) * (radius * 0.75f);
            float py = cy + (float) Math.sin(angle) * (radius * 0.75f);

            float diff = (progress - (i / (float) count) + 1.0f) % 1.0f;
            int alpha = (int) (255 * (1.0f - diff));

            fillPaint.setColor(Color.parseColor("#38BDF8"));
            fillPaint.setAlpha(Math.max(30, alpha));
            canvas.drawCircle(px, py, dpToPx(3.5f), fillPaint);
        }
    }

    // 13. Rotating Square
    private void drawRotatingSquare(Canvas canvas, float cx, float cy, float size) {
        canvas.save();
        canvas.translate(cx, cy);
        canvas.rotate(progress * 360f);

        float side = size * 0.5f;
        RectF square = new RectF(-side / 2f, -side / 2f, side / 2f, side / 2f);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(3.5f));
        paint.setColor(Color.parseColor("#38BDF8"));
        canvas.drawRoundRect(square, dpToPx(8), dpToPx(8), paint);

        canvas.restore();
    }

    // 14. Arc Spinner
    private void drawArcSpinner(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(4));
        paint.setColor(Color.parseColor("#38BDF8"));

        RectF rect = new RectF(cx - radius + 4, cy - radius + 4, cx + radius - 4, cy + radius - 4);
        float angle = progress * 360f;
        canvas.drawArc(rect, angle, 80f, false, paint);
        canvas.drawArc(rect, angle + 180f, 80f, false, paint);
    }

    // 15. Breathing Glow
    private void drawBreathingGlow(Canvas canvas, float cx, float cy, float radius) {
        float scale = 0.4f + 0.6f * (float) Math.sin(progress * Math.PI);
        float currentR = radius * scale;

        glowPaint.setColor(Color.parseColor("#3338BDF8"));
        canvas.drawCircle(cx, cy, currentR * 1.3f, glowPaint);

        fillPaint.setColor(Color.parseColor("#38BDF8"));
        fillPaint.setAlpha((int) (150 + 105 * scale));
        canvas.drawCircle(cx, cy, currentR, fillPaint);
    }

    // 16. Morphing Triangle
    private void drawMorphingTriangle(Canvas canvas, float cx, float cy, float radius) {
        canvas.save();
        canvas.translate(cx, cy);
        canvas.rotate(progress * 360f);

        Path path = new Path();
        int points = 3;
        float r = radius * 0.75f;
        for (int i = 0; i < points; i++) {
            float angle = (i / (float) points) * (float) Math.PI * 2f - (float) Math.PI / 2f;
            float px = (float) Math.cos(angle) * r;
            float py = (float) Math.sin(angle) * r;
            if (i == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(3.5f));
        paint.setColor(Color.parseColor("#F472B6"));
        canvas.drawPath(path, paint);

        canvas.restore();
    }

    // 17. Clock Sweep
    private void drawClockSweep(Canvas canvas, float cx, float cy, float radius) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(2.5f));
        paint.setColor(Color.parseColor("#38BDF8"));
        canvas.drawCircle(cx, cy, radius, paint);

        // Hour hand
        float hourAngle = progress * (float) Math.PI * 2f;
        canvas.drawLine(cx, cy, cx + (float) Math.cos(hourAngle) * (radius * 0.45f), cy + (float) Math.sin(hourAngle) * (radius * 0.45f), paint);

        // Minute hand
        float minAngle = progress * (float) Math.PI * 8f;
        paint.setStrokeWidth(dpToPx(1.8f));
        canvas.drawLine(cx, cy, cx + (float) Math.cos(minAngle) * (radius * 0.75f), cy + (float) Math.sin(minAngle) * (radius * 0.75f), paint);
    }

    // 18. Matrix Rain Dots
    private void drawMatrixRainDots(Canvas canvas, float cx, float cy, float size) {
        int cols = 4;
        float colSpacing = size / 4f;
        float startX = cx - (colSpacing * (cols - 1) / 2f);

        for (int c = 0; c < cols; c++) {
            float colProgress = (progress + c * 0.22f) % 1.0f;
            float py = cy - size / 2f + colProgress * size;

            fillPaint.setColor(Color.parseColor("#10B981"));
            fillPaint.setAlpha((int) (255 * (1.0f - colProgress)));
            canvas.drawCircle(startX + c * colSpacing, py, dpToPx(3.5f), fillPaint);
        }
    }

    // 19. Staircase Steps
    private void drawStaircaseSteps(Canvas canvas, float cx, float cy, float size) {
        int steps = 4;
        float stepWidth = size / 5f;
        float stepHeight = size / 5f;
        float startX = cx - (stepWidth * steps) / 2f;
        float startY = cy + (stepHeight * steps) / 2f;

        for (int i = 0; i < steps; i++) {
            float activeIndex = (progress * steps);
            boolean isActive = Math.abs(i - activeIndex) < 1.0f;

            float x = startX + i * stepWidth;
            float y = startY - (i + 1) * stepHeight;

            fillPaint.setColor(isActive ? Color.parseColor("#38BDF8") : Color.parseColor("#334155"));
            canvas.drawRect(x, y, x + stepWidth - 2, y + stepHeight - 2, fillPaint);
        }
    }

    // 20. Hexagon Pulse
    private void drawHexagonPulse(Canvas canvas, float cx, float cy, float radius) {
        canvas.save();
        canvas.translate(cx, cy);

        float pulseScale = 0.8f + 0.2f * (float) Math.sin(progress * Math.PI * 2);
        canvas.scale(pulseScale, pulseScale);

        Path path = new Path();
        int sides = 6;
        for (int i = 0; i < sides; i++) {
            float angle = (i / (float) sides) * (float) Math.PI * 2f;
            float px = (float) Math.cos(angle) * (radius * 0.8f);
            float py = (float) Math.sin(angle) * (radius * 0.8f);
            if (i == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dpToPx(3));
        paint.setColor(Color.parseColor("#A855F7"));
        canvas.drawPath(path, paint);

        canvas.restore();
    }

    private int dpToPx(float dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
