package com.aistudio.classroomhub.app

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ReminderRecord(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val note: String,
    val dueDate: String,
    val time: String,
    val priority: String = "Normal"
)

object ReminderRepository {
    private val reminders = mutableStateListOf<ReminderRecord>(
        ReminderRecord(
            id = "rem_1",
            title = "පන්ති තක්සේරු ලකුණු සටහන",
            note = "Grade 10 term exam mark entry due tomorrow",
            dueDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            time = "10:30 AM",
            priority = "High"
        )
    )

    fun add(reminder: ReminderRecord) {
        reminders.add(0, reminder)
    }

    fun update(reminder: ReminderRecord) {
        val idx = reminders.indexOfFirst { it.id == reminder.id }
        if (idx != -1) {
            reminders[idx] = reminder
        }
    }

    fun delete(id: String) {
        reminders.removeAll { it.id == id }
    }

    fun getAll(): List<ReminderRecord> = reminders
}

@Composable
fun ReminderModalContent(
    onDismissRequest: () -> Unit
) {
    var isAddingNew by remember { mutableStateOf(false) }
    var editingReminder by remember { mutableStateOf<ReminderRecord?>(null) }

    var titleText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var dueDateText by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var timeText by remember { mutableStateOf("09:00 AM") }

    fun resetForm() {
        titleText = ""
        noteText = ""
        dueDateText = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        timeText = "09:00 AM"
        editingReminder = null
        isAddingNew = false
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "මතක් කිරීම් (Reminders)",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                if (isAddingNew || editingReminder != null) {
                    // Form Layout
                    Text(
                        text = if (editingReminder != null) "සංස්කරණය කරන්න (Edit Reminder)" else "නව මතක් කිරීමක් එක් කරන්න (Add Reminder)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = titleText,
                        onValueChange = { titleText = it },
                        label = { Text("මතක් කිරීමේ මාතෘකාව (Title)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("සටහන / විස්තරය (Note)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = dueDateText,
                            onValueChange = { dueDateText = it },
                            label = { Text("දිනය (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = timeText,
                            onValueChange = { timeText = it },
                            label = { Text("වේලාව (Time)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { resetForm() }) {
                            Text("අවලංගු කරන්න")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (titleText.trim().isEmpty()) return@Button
                                if (editingReminder != null) {
                                    ReminderRepository.update(
                                        editingReminder!!.copy(
                                            title = titleText.trim(),
                                            note = noteText.trim(),
                                            dueDate = dueDateText.trim(),
                                            time = timeText.trim()
                                        )
                                    )
                                } else {
                                    ReminderRepository.add(
                                        ReminderRecord(
                                            title = titleText.trim(),
                                            note = noteText.trim(),
                                            dueDate = dueDateText.trim(),
                                            time = timeText.trim()
                                        )
                                    )
                                }
                                resetForm()
                            },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("සුරකින්න (Save)")
                        }
                    }
                } else {
                    // List Layout
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "වත්මන් මතක් කිරීම් (${ReminderRepository.getAll().size})",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Button(
                            onClick = { isAddingNew = true },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("නව මතක් කිරීමක්")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val allReminders = ReminderRepository.getAll()
                    if (allReminders.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "තවම මතක් කිරීම් කිසිවක් නැත.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.heightIn(max = 300.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(allReminders, key = { it.id }) { reminder ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    tonalElevation = 2.dp
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .padding(12.dp)
                                            .fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = reminder.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            if (reminder.note.isNotEmpty()) {
                                                Text(
                                                    text = reminder.note,
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Text(
                                                text = "📅 ${reminder.dueDate} | ⏰ ${reminder.time}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Row {
                                            IconButton(onClick = {
                                                editingReminder = reminder
                                                titleText = reminder.title
                                                noteText = reminder.note
                                                dueDateText = reminder.dueDate
                                                timeText = reminder.time
                                            }) {
                                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color(0xFF38BDF8))
                                            }
                                            IconButton(onClick = {
                                                ReminderRepository.delete(reminder.id)
                                            }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun showReminderModal(context: Context) {
    val composeView = ComposeView(context)
    val dialog = AlertDialog.Builder(context)
        .setView(composeView)
        .create()

    dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

    composeView.setContent {
        ReminderModalContent(
            onDismissRequest = { dialog.dismiss() }
        )
    }

    dialog.show()
}
