package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ClassTimetableRepository {

    private static final List<ClassTimetableEntry> entries = new ArrayList<>();

    static {
        initSampleClassTimetableData();
    }

    private static void initSampleClassTimetableData() {
        // Start with an empty user-configured class timetable.
    }

    public static List<ClassTimetableEntry> getEntries() {
        return entries;
    }

    public static List<ClassTimetableEntry> getEntriesForDay(String day) {
        List<ClassTimetableEntry> result = new ArrayList<>();
        for (ClassTimetableEntry e : entries) {
            if (e.getDay().equalsIgnoreCase(day)) {
                result.add(e);
            }
        }
        return result;
    }

    public static void addEntry(ClassTimetableEntry entry) {
        entries.add(entry);
    }

    public static void removeEntry(String id) {
        for (int i = 0; i < entries.size(); i++) {
            if (entries.get(i).getId().equals(id)) {
                entries.remove(i);
                break;
            }
        }
    }

    public static void clear() {
        entries.clear();
    }
}
