package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LetterCloudManager {

    private static final String TAG = "LetterCloudManager";
    private static final String PREF_NAME = "letter_cloud_local_cache";
    private static final String KEY_SAVED_LETTERS = "key_saved_letters";
    private static final String KEY_CUSTOM_TEMPLATES = "key_custom_templates";

    public interface FirestoreCallback<T> {
        void onSuccess(T result);
        void onError(Exception e);
    }

    public static String getUserId(Context context) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null && user.getUid() != null && !user.getUid().isEmpty()) {
            return user.getUid();
        }
        if (context != null) {
            String permanentUid = UserRoleManager.getPermanentUid(context);
            if (permanentUid != null && !permanentUid.isEmpty() && !"GUEST-USER-88".equals(permanentUid)) {
                return permanentUid;
            }
        }
        return "default_local_user";
    }

    public static String getUserId() {
        return getUserId(null);
    }

    // =========================================================================
    // SAVED LETTERS (users/{userId}/savedLetters/{letterId})
    // =========================================================================

    public static void saveLetterToCloud(Context context, LetterTemplate letter, FirestoreCallback<Boolean> callback) {
        letter.setSavedDocument(true);
        letter.setCustomTemplate(false);
        letter.setCategory("My Saved Documents");
        letter.setUserId(getUserId(context));
        letter.setLastUpdated(System.currentTimeMillis());

        if (letter.getId() == null || letter.getId().isEmpty()) {
            letter.setId("doc_" + System.currentTimeMillis());
        }

        // 1. Local Cache Save
        saveLetterToLocalCache(context, letter, KEY_SAVED_LETTERS);

        // 2. Firestore Sync
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String path = "users/" + getUserId(context) + "/savedLetters";
            Map<String, Object> map = templateToMap(letter);

            db.collection(path).document(letter.getId())
                    .set(map)
                    .addOnSuccessListener(aVoid -> {
                        Log.d(TAG, "Saved letter synced to Firestore: " + letter.getId());
                        if (callback != null) callback.onSuccess(true);
                    })
                    .addOnFailureListener(e -> {
                        Log.w(TAG, "Firestore letter sync failed, stored locally", e);
                        if (callback != null) callback.onSuccess(true); // Success locally
                    });
        } catch (Exception e) {
            Log.e(TAG, "Firebase unavailable", e);
            if (callback != null) callback.onSuccess(true);
        }
    }

    public static void loadSavedLetters(Context context, FirestoreCallback<List<LetterTemplate>> callback) {
        List<LetterTemplate> localList = getLettersFromLocalCache(context, KEY_SAVED_LETTERS);

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String path = "users/" + getUserId(context) + "/savedLetters";

            db.collection(path).get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        List<LetterTemplate> cloudList = new ArrayList<>();
                        for (DocumentSnapshot doc : queryDocumentSnapshots) {
                            LetterTemplate t = mapToTemplate(doc.getData());
                            if (t != null) {
                                t.setSavedDocument(true);
                                cloudList.add(t);
                            }
                        }
                        if (!cloudList.isEmpty()) {
                            saveListToLocalCache(context, cloudList, KEY_SAVED_LETTERS);
                            if (callback != null) callback.onSuccess(cloudList);
                        } else {
                            if (callback != null) callback.onSuccess(localList);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.w(TAG, "Error fetching saved letters from cloud", e);
                        if (callback != null) callback.onSuccess(localList);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Firebase unavailable", e);
            if (callback != null) callback.onSuccess(localList);
        }
    }

    // =========================================================================
    // CUSTOM TEMPLATES (users/{userId}/customTemplates/{templateId})
    // =========================================================================

    public static void saveCustomTemplateToCloud(Context context, LetterTemplate template, FirestoreCallback<Boolean> callback) {
        template.setCustomTemplate(true);
        template.setSavedDocument(false);
        template.setCategory("My Custom Templates");
        template.setUserId(getUserId(context));
        template.setLastUpdated(System.currentTimeMillis());

        if (template.getId() == null || template.getId().isEmpty()) {
            template.setId("tmpl_" + System.currentTimeMillis());
        }

        // 1. Local Cache Save
        saveLetterToLocalCache(context, template, KEY_CUSTOM_TEMPLATES);

        // 2. Firestore Sync
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String path = "users/" + getUserId(context) + "/customTemplates";

            Map<String, Object> map = templateToMap(template);

            db.collection(path).document(template.getId())
                    .set(map)
                    .addOnSuccessListener(aVoid -> {
                        Log.d(TAG, "Custom template synced to Firestore: " + template.getId());
                        if (callback != null) callback.onSuccess(true);
                    })
                    .addOnFailureListener(e -> {
                        Log.w(TAG, "Firestore template sync failed, stored locally", e);
                        if (callback != null) callback.onSuccess(true);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Firebase unavailable", e);
            if (callback != null) callback.onSuccess(true);
        }
    }

    public static void loadCustomTemplates(Context context, FirestoreCallback<List<LetterTemplate>> callback) {
        List<LetterTemplate> localList = getLettersFromLocalCache(context, KEY_CUSTOM_TEMPLATES);

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String path = "users/" + getUserId(context) + "/customTemplates";

            db.collection(path).get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        List<LetterTemplate> cloudList = new ArrayList<>();
                        for (DocumentSnapshot doc : queryDocumentSnapshots) {
                            LetterTemplate t = mapToTemplate(doc.getData());
                            if (t != null) {
                                t.setCustomTemplate(true);
                                cloudList.add(t);
                            }
                        }
                        if (!cloudList.isEmpty()) {
                            saveListToLocalCache(context, cloudList, KEY_CUSTOM_TEMPLATES);
                            if (callback != null) callback.onSuccess(cloudList);
                        } else {
                            if (callback != null) callback.onSuccess(localList);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.w(TAG, "Error fetching custom templates from cloud", e);
                        if (callback != null) callback.onSuccess(localList);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Firebase unavailable", e);
            if (callback != null) callback.onSuccess(localList);
        }
    }

    // =========================================================================
    // DELETE OPERATIONS
    // =========================================================================

    public static void deleteDocument(Context context, LetterTemplate template, FirestoreCallback<Boolean> callback) {
        if (template == null || template.getId() == null) return;

        String key = template.isCustomTemplate() ? KEY_CUSTOM_TEMPLATES : KEY_SAVED_LETTERS;
        deleteFromLocalCache(context, template.getId(), key);

        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            String subColl = template.isCustomTemplate() ? "customTemplates" : "savedLetters";
            String path = "users/" + getUserId(context) + "/" + subColl;

            db.collection(path).document(template.getId())
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        if (callback != null) callback.onSuccess(true);
                    })
                    .addOnFailureListener(e -> {
                        if (callback != null) callback.onSuccess(true);
                    });
        } catch (Exception e) {
            if (callback != null) callback.onSuccess(true);
        }
    }

    // =========================================================================
    // HELPER METHODS (LOCAL & MAP MAPPING)
    // =========================================================================

    private static Map<String, Object> templateToMap(LetterTemplate t) {
        Map<String, Object> map = new HashMap<>();
        map.put("id", t.getId());
        map.put("title", t.getTitle() != null ? t.getTitle() : "");
        map.put("category", t.getCategory() != null ? t.getCategory() : "");
        map.put("subCategory", t.getSubCategory() != null ? t.getSubCategory() : "");
        map.put("description", t.getDescription() != null ? t.getDescription() : "");
        map.put("content", t.getContent() != null ? t.getContent() : "");
        map.put("pageSize", t.getPageSize() != null ? t.getPageSize() : "A4");
        map.put("orientation", t.getOrientation() != null ? t.getOrientation() : "PORTRAIT");
        map.put("isCustomTemplate", t.isCustomTemplate());
        map.put("isSavedDocument", t.isSavedDocument());
        map.put("lastUpdated", t.getLastUpdated());
        map.put("userId", t.getUserId() != null ? t.getUserId() : getUserId());
        return map;
    }

    private static LetterTemplate mapToTemplate(Map<String, Object> map) {
        if (map == null) return null;
        LetterTemplate t = new LetterTemplate();
        t.setId((String) map.get("id"));
        t.setTitle((String) map.get("title"));
        t.setCategory((String) map.get("category"));
        t.setSubCategory((String) map.get("subCategory"));
        t.setDescription((String) map.get("description"));
        t.setContent((String) map.get("content"));
        t.setPageSize(map.get("pageSize") != null ? (String) map.get("pageSize") : "A4");
        t.setOrientation(map.get("orientation") != null ? (String) map.get("orientation") : "PORTRAIT");
        t.setCustomTemplate(Boolean.TRUE.equals(map.get("isCustomTemplate")));
        t.setSavedDocument(Boolean.TRUE.equals(map.get("isSavedDocument")));
        if (map.get("lastUpdated") instanceof Long) {
            t.setLastUpdated((Long) map.get("lastUpdated"));
        }
        t.setUserId((String) map.get("userId"));
        return t;
    }

    private static void saveLetterToLocalCache(Context context, LetterTemplate letter, String cacheKey) {
        List<LetterTemplate> list = getLettersFromLocalCache(context, cacheKey);
        // Remove existing item with same ID if any
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equalsIgnoreCase(letter.getId())) {
                list.remove(i);
                break;
            }
        }
        list.add(0, letter); // Add at top
        saveListToLocalCache(context, list, cacheKey);
    }

    private static void deleteFromLocalCache(Context context, String id, String cacheKey) {
        List<LetterTemplate> list = getLettersFromLocalCache(context, cacheKey);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equalsIgnoreCase(id)) {
                list.remove(i);
                break;
            }
        }
        saveListToLocalCache(context, list, cacheKey);
    }

    private static List<LetterTemplate> getLettersFromLocalCache(Context context, String cacheKey) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(cacheKey, "");
        if (json == null || json.isEmpty()) return new ArrayList<>();

        try {
            Gson gson = new Gson();
            Type type = new TypeToken<List<LetterTemplate>>() {}.getType();
            List<LetterTemplate> list = gson.fromJson(json, type);
            return list != null ? list : new ArrayList<>();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private static void saveListToLocalCache(Context context, List<LetterTemplate> list, String cacheKey) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = gson.toJson(list);
        prefs.edit().putString(cacheKey, json).apply();
    }
}
