package com.aistudio.classroomhub.app;

import android.app.TimePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class TimetableActivity extends AppCompatActivity {

    public static final String EXTRA_INITIAL_TAB = "extra_initial_tab";

    private ImageView btnBack, btnAddHeader;
    private View containerViewTimetable, containerClassTimetable;
    private ScrollView containerAddTimetable;

    private LinearLayout navTeacherTimetable, navAddTimetable, navClassTimetable;
    private ImageView iconTeacherNav, iconAddNav, iconClassNav;
    private TextView textTeacherNav, textAddNav, textClassNav;

    // View Timetable components
    private MaterialCardView cardLiveBanner;
    private ImageView imgLiveIndicator;
    private TextView tvLiveLabel, tvLiveCountdownPill, tvLiveTitle, tvLiveSubtitle;
    private TabLayout tabDays;
    private TextView tvDayHeader, tvEmptyDayMessage;
    private RecyclerView rvTimetableEntries;

    // View Class Timetable components
    private MaterialCardView cardClassLiveBanner;
    private ImageView imgClassLiveIndicator;
    private TextView tvClassLiveLabel, tvClassLiveCountdownPill, tvClassLiveTitle, tvClassLiveSubtitle;
    private TabLayout tabClassDays;
    private TextView tvClassDayHeader, tvClassEmptyDayMessage;
    private RecyclerView rvClassTimetableEntries;
    private String selectedClassDay = "සඳුදා";
    private ClassTimetableAdapter classTimetableAdapter;

    // Add Timetable components
    private TabLayout tabAddType;
    private View layoutRoleContainer, layoutClassContainer, layoutTeacherNameContainer;
    private Spinner spDay, spRole;
    private TextInputEditText etPeriodName, etSubject, etClass, etTeacherName, etRoom, etNotes;
    private Button btnSelectStartTime, btnSelectEndTime, btnSaveTimetable;
    private int lastActiveViewTab = 0; // 0 for Teacher, 2 for Class

    private int startHour = 7, startMinute = 50;
    private int endHour = 8, endMinute = 30;

    private String[] daysArray = {"සඳුදා", "අඟහරුවාදා", "බදාදා", "බ්‍රහස්පතින්දා", "සිකුරාදා"};
    private String[] rolesArray = {"ප්‍රධාන විෂය", "නියෝජන (Relief)", "නිදහස් (Free)"};

    private String selectedDay = "සඳුදා";
    private TimetableAdapter timetableAdapter;

    private Handler liveHandler = new Handler(Looper.getMainLooper());
    private Runnable liveRunnable = new Runnable() {
        @Override
        public void run() {
            updateLiveStatusBanner();
            updateClassLiveStatusBanner();
            if (timetableAdapter != null) {
                timetableAdapter.notifyDataSetChanged();
            }
            if (classTimetableAdapter != null) {
                classTimetableAdapter.notifyDataSetChanged();
            }
            liveHandler.postDelayed(this, 30000); // refresh every 30 seconds
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_timetable);

        initViews();
        setupDayTabs();
        setupClassDayTabs();
        setupFormSpinners();
        setupListeners();

        // Auto select current weekday tab
        autoSelectTodayTab();

        rvTimetableEntries.setLayoutManager(new LinearLayoutManager(this));
        rvClassTimetableEntries.setLayoutManager(new LinearLayoutManager(this));

        refreshDayTimetableList();
        refreshClassDayTimetableList();

        // Check if intent specified opening the Add tab directly
        if (getIntent().hasExtra(EXTRA_INITIAL_TAB) && "add".equalsIgnoreCase(getIntent().getStringExtra(EXTRA_INITIAL_TAB))) {
            switchNavTab(1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        liveHandler.post(liveRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        liveHandler.removeCallbacks(liveRunnable);
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        btnAddHeader = findViewById(R.id.btnAddHeader);

        containerViewTimetable = findViewById(R.id.containerViewTimetable);
        containerAddTimetable = findViewById(R.id.containerAddTimetable);
        containerClassTimetable = findViewById(R.id.containerClassTimetable);

        navTeacherTimetable = findViewById(R.id.navTeacherTimetable);
        navAddTimetable = findViewById(R.id.navAddTimetable);
        navClassTimetable = findViewById(R.id.navClassTimetable);

        iconTeacherNav = findViewById(R.id.iconTeacherNav);
        iconAddNav = findViewById(R.id.iconAddNav);
        iconClassNav = findViewById(R.id.iconClassNav);

        textTeacherNav = findViewById(R.id.textTeacherNav);
        textAddNav = findViewById(R.id.textAddNav);
        textClassNav = findViewById(R.id.textClassNav);

        cardLiveBanner = findViewById(R.id.cardLiveBanner);
        imgLiveIndicator = findViewById(R.id.imgLiveIndicator);
        tvLiveLabel = findViewById(R.id.tvLiveLabel);
        tvLiveCountdownPill = findViewById(R.id.tvLiveCountdownPill);
        tvLiveTitle = findViewById(R.id.tvLiveTitle);
        tvLiveSubtitle = findViewById(R.id.tvLiveSubtitle);

        tabDays = findViewById(R.id.tabDays);
        tvDayHeader = findViewById(R.id.tvDayHeader);
        tvEmptyDayMessage = findViewById(R.id.tvEmptyDayMessage);
        rvTimetableEntries = findViewById(R.id.rvTimetableEntries);

        // Class Timetable Views
        cardClassLiveBanner = findViewById(R.id.cardClassLiveBanner);
        imgClassLiveIndicator = findViewById(R.id.imgClassLiveIndicator);
        tvClassLiveLabel = findViewById(R.id.tvClassLiveLabel);
        tvClassLiveCountdownPill = findViewById(R.id.tvClassLiveCountdownPill);
        tvClassLiveTitle = findViewById(R.id.tvClassLiveTitle);
        tvClassLiveSubtitle = findViewById(R.id.tvClassLiveSubtitle);

        tabClassDays = findViewById(R.id.tabClassDays);
        tvClassDayHeader = findViewById(R.id.tvClassDayHeader);
        tvClassEmptyDayMessage = findViewById(R.id.tvClassEmptyDayMessage);
        rvClassTimetableEntries = findViewById(R.id.rvClassTimetableEntries);

        tabAddType = findViewById(R.id.tabAddType);
        layoutRoleContainer = findViewById(R.id.layoutRoleContainer);
        layoutClassContainer = findViewById(R.id.layoutClassContainer);
        layoutTeacherNameContainer = findViewById(R.id.layoutTeacherNameContainer);

        spDay = findViewById(R.id.spDay);
        spRole = findViewById(R.id.spRole);
        etPeriodName = findViewById(R.id.etPeriodName);
        etSubject = findViewById(R.id.etSubject);
        etClass = findViewById(R.id.etClass);
        etTeacherName = findViewById(R.id.etTeacherName);
        etRoom = findViewById(R.id.etRoom);
        etNotes = findViewById(R.id.etNotes);

        btnSelectStartTime = findViewById(R.id.btnSelectStartTime);
        btnSelectEndTime = findViewById(R.id.btnSelectEndTime);
        btnSaveTimetable = findViewById(R.id.btnSaveTimetable);
    }

    private void setupDayTabs() {
        tabDays.removeAllTabs();
        for (String day : daysArray) {
            tabDays.addTab(tabDays.newTab().setText(day));
        }

        tabDays.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab != null && tab.getText() != null) {
                    selectedDay = tab.getText().toString();
                    refreshDayTimetableList();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void setupClassDayTabs() {
        tabClassDays.removeAllTabs();
        for (String day : daysArray) {
            tabClassDays.addTab(tabClassDays.newTab().setText(day));
        }

        tabClassDays.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab != null && tab.getText() != null) {
                    selectedClassDay = tab.getText().toString();
                    refreshClassDayTimetableList();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void autoSelectTodayTab() {
        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int index = -1;
        switch (dayOfWeek) {
            case Calendar.MONDAY: index = 0; break;
            case Calendar.TUESDAY: index = 1; break;
            case Calendar.WEDNESDAY: index = 2; break;
            case Calendar.THURSDAY: index = 3; break;
            case Calendar.FRIDAY: index = 4; break;
        }

        if (index >= 0 && index < tabDays.getTabCount()) {
            TabLayout.Tab tab = tabDays.getTabAt(index);
            if (tab != null) {
                tab.select();
                selectedDay = daysArray[index];
            }
        }

        if (index >= 0 && index < tabClassDays.getTabCount()) {
            TabLayout.Tab tab = tabClassDays.getTabAt(index);
            if (tab != null) {
                tab.select();
                selectedClassDay = daysArray[index];
            }
        }
    }

    private void setupFormSpinners() {
        ArrayAdapter<String> dayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, daysArray);
        spDay.setAdapter(dayAdapter);

        ArrayAdapter<String> roleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, rolesArray);
        spRole.setAdapter(roleAdapter);
    }

    private void setupListeners() {
        if (btnBack != null) btnBack.setVisibility(View.GONE);
        if (btnAddHeader != null) btnAddHeader.setOnClickListener(v -> showAddMenuBottomSheet());

        navTeacherTimetable.setOnClickListener(v -> switchNavTab(0));
        navAddTimetable.setOnClickListener(v -> switchNavTab(1));
        navClassTimetable.setOnClickListener(v -> switchNavTab(2));

        if (tabAddType != null) {
            tabAddType.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    if (tab != null) {
                        updateAddFormFields(tab.getPosition());
                    }
                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {}

                @Override
                public void onTabReselected(TabLayout.Tab tab) {}
            });
        }

        btnSelectStartTime.setOnClickListener(v -> {
            TimePickerDialog dialog = new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                startHour = hourOfDay;
                startMinute = minute;
                btnSelectStartTime.setText(String.format(Locale.US, "ආරම්භය: %02d:%02d", startHour, startMinute));
            }, startHour, startMinute, true);
            dialog.show();
        });

        btnSelectEndTime.setOnClickListener(v -> {
            TimePickerDialog dialog = new TimePickerDialog(this, (view, hourOfDay, minute) -> {
                endHour = hourOfDay;
                endMinute = minute;
                btnSelectEndTime.setText(String.format(Locale.US, "අවසානය: %02d:%02d", endHour, endMinute));
            }, endHour, endMinute, true);
            dialog.show();
        });

        btnSaveTimetable.setOnClickListener(v -> saveNewTimetableEntry());
    }

    private void showAddMenuBottomSheet() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View view = getLayoutInflater().inflate(R.layout.bottom_sheet_add_timetable, null);
        bottomSheetDialog.setContentView(view);

        View itemAddTeacher = view.findViewById(R.id.itemAddTeacher);
        if (itemAddTeacher != null) {
            itemAddTeacher.setOnClickListener(v -> {
                bottomSheetDialog.dismiss();
                switchNavTab(1); // Teacher Form open කරන්න
            });
        }
        bottomSheetDialog.show();
    }

    private void updateAddFormFields(int typeIndex) {
        if (typeIndex == 0) {
            // Teacher Timetable mode
            layoutRoleContainer.setVisibility(View.VISIBLE);
            layoutClassContainer.setVisibility(View.VISIBLE);
            layoutTeacherNameContainer.setVisibility(View.GONE);
            btnSaveTimetable.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#0284C7")));
            btnSaveTimetable.setText("Save කර ගුරු කාලසටහනට එකතු කරන්න");
        } else {
            // Class Timetable mode
            layoutRoleContainer.setVisibility(View.GONE);
            layoutClassContainer.setVisibility(View.GONE);
            layoutTeacherNameContainer.setVisibility(View.VISIBLE);
            btnSaveTimetable.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#0D9488")));
            btnSaveTimetable.setText("Save කර පන්ති කාලසටහනට එකතු කරන්න");
        }
    }

    private void switchNavTab(int index) {
        containerViewTimetable.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        containerAddTimetable.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        containerClassTimetable.setVisibility(index == 2 ? View.VISIBLE : View.GONE);

        // Update colors
        int activeColor = Color.parseColor("#38BDF8");
        int inactiveColor = Color.parseColor("#94A3B8");

        iconTeacherNav.setColorFilter(index == 0 ? activeColor : inactiveColor);
        textTeacherNav.setTextColor(index == 0 ? activeColor : inactiveColor);

        iconAddNav.setColorFilter(index == 1 ? activeColor : inactiveColor);
        textAddNav.setTextColor(index == 1 ? activeColor : inactiveColor);

        iconClassNav.setColorFilter(index == 2 ? activeColor : inactiveColor);
        textClassNav.setTextColor(index == 2 ? activeColor : inactiveColor);

        if (index == 0) {
            lastActiveViewTab = 0;
            refreshDayTimetableList();
            updateLiveStatusBanner();
        } else if (index == 2) {
            lastActiveViewTab = 2;
            refreshClassDayTimetableList();
            updateClassLiveStatusBanner();
        } else if (index == 1 && tabAddType != null) {
            // Contextually pre-select the appropriate add tab
            int targetAddTab = (lastActiveViewTab == 2) ? 1 : 0;
            TabLayout.Tab tab = tabAddType.getTabAt(targetAddTab);
            if (tab != null) {
                tab.select();
            }
            updateAddFormFields(targetAddTab);
        }
    }

    private String getTodaySinhalaDay() {
        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        switch (dayOfWeek) {
            case Calendar.MONDAY: return "සඳුදා";
            case Calendar.TUESDAY: return "අඟහරුවාදා";
            case Calendar.WEDNESDAY: return "බදාදා";
            case Calendar.THURSDAY: return "බ්‍රහස්පතින්දා";
            case Calendar.FRIDAY: return "සිකුරාදා";
            default: return "සෙනසුරාදා / ඉරිදා";
        }
    }

    private TimetableEntry getCurrentActiveEntry() {
        String todaySinhala = getTodaySinhalaDay();
        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        List<TimetableEntry> todayEntries = TimetableRepository.getEntriesForDay(todaySinhala);
        for (TimetableEntry entry : todayEntries) {
            int start = entry.getStartMinutesOfDay();
            int end = entry.getEndMinutesOfDay();

            if (nowMinutes >= start && nowMinutes < end) {
                return entry;
            }
        }
        return null;
    }

    private void updateLiveStatusBanner() {
        TimetableEntry activeEntry = getCurrentActiveEntry();
        if (activeEntry != null) {
            cardLiveBanner.setStrokeColor(Color.parseColor("#0284C7"));
            imgLiveIndicator.setColorFilter(Color.parseColor("#EF4444"));
            tvLiveLabel.setText("දැනට පැවැත්වෙන කාලඡේදය");
            tvLiveLabel.setTextColor(Color.parseColor("#EF4444"));

            Calendar now = Calendar.getInstance();
            int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            int remaining = activeEntry.getEndMinutesOfDay() - nowMinutes;

            tvLiveCountdownPill.setText("තව මිනිත්තු " + remaining + " යි");
            tvLiveTitle.setText(activeEntry.getSubject() + " - " + activeEntry.getClassName());

            String sub = "කාලඡේදය: " + activeEntry.getPeriodName() + " (" + activeEntry.getFormattedTimeRange() + ") | භූමිකාව: " + activeEntry.getRole();
            tvLiveSubtitle.setText(sub);
        } else {
            cardLiveBanner.setStrokeColor(Color.parseColor("#334155"));
            imgLiveIndicator.setColorFilter(Color.parseColor("#F59E0B"));
            tvLiveLabel.setText("වත්මන් තත්වය");
            tvLiveLabel.setTextColor(Color.parseColor("#F59E0B"));

            tvLiveCountdownPill.setText("Off / Free");
            tvLiveTitle.setText("දැනට ඔබට පන්තියක් නොමැත");
            tvLiveSubtitle.setText("විවේක කාලඡේදයක් හෝ නිදහස් වේලාවක් (Free Period)");
        }
    }

    private void refreshDayTimetableList() {
        tvDayHeader.setText(selectedDay + " කාලසටහන");

        List<TimetableEntry> list = TimetableRepository.getEntriesForDay(selectedDay);
        if (list.isEmpty()) {
            tvEmptyDayMessage.setVisibility(View.VISIBLE);
            rvTimetableEntries.setVisibility(View.GONE);
        } else {
            tvEmptyDayMessage.setVisibility(View.GONE);
            rvTimetableEntries.setVisibility(View.VISIBLE);

            timetableAdapter = new TimetableAdapter(list);
            rvTimetableEntries.setAdapter(timetableAdapter);
        }
    }

    private void saveNewTimetableEntry() {
        int addType = (tabAddType != null) ? tabAddType.getSelectedTabPosition() : 0;

        String period = etPeriodName.getText() != null ? etPeriodName.getText().toString().trim() : "";
        String subject = etSubject.getText() != null ? etSubject.getText().toString().trim() : "";
        String room = etRoom.getText() != null ? etRoom.getText().toString().trim() : "";
        String notes = etNotes.getText() != null ? etNotes.getText().toString().trim() : "";
        String day = spDay.getSelectedItem() != null ? spDay.getSelectedItem().toString() : "සඳුදා";

        if (addType == 0) {
            // Teacher Timetable
            String className = etClass.getText() != null ? etClass.getText().toString().trim() : "";

            if (subject.isEmpty() || className.isEmpty()) {
                Toast.makeText(this, "කරුණාකර විෂය සහ පන්තිය ඇතුළත් කරන්න!", Toast.LENGTH_SHORT).show();
                return;
            }

            String role = spRole.getSelectedItem() != null ? spRole.getSelectedItem().toString() : "ප්‍රධාන විෂය";

            TimetableEntry entry = new TimetableEntry(
                    UUID.randomUUID().toString(),
                    day,
                    period.isEmpty() ? "කාලඡේදය" : period,
                    startHour, startMinute,
                    endHour, endMinute,
                    subject,
                    className,
                    room.isEmpty() ? "-" : room,
                    role,
                    notes
            );

            TimetableRepository.addEntry(entry);
            Toast.makeText(this, "ගුරු කාලසටහන සාර්ථකව එකතු කරන ලදී!", Toast.LENGTH_SHORT).show();

            // Clear input form
            etSubject.setText("");
            etClass.setText("");
            etNotes.setText("");

            // Switch to Teacher Timetable view
            switchNavTab(0);
        } else {
            // Class Timetable
            String teacherName = etTeacherName.getText() != null ? etTeacherName.getText().toString().trim() : "";

            if (subject.isEmpty() || teacherName.isEmpty()) {
                Toast.makeText(this, "කරුණාකර විෂය සහ ගුරුතුමා/තුමියගේ නම ඇතුළත් කරන්න!", Toast.LENGTH_SHORT).show();
                return;
            }

            ClassTimetableEntry entry = new ClassTimetableEntry(
                    UUID.randomUUID().toString(),
                    day,
                    period.isEmpty() ? "කාලඡේදය" : period,
                    startHour, startMinute,
                    endHour, endMinute,
                    subject,
                    teacherName,
                    room.isEmpty() ? "ප්‍රධාන පන්ති කාමරය" : room
            );

            ClassTimetableRepository.addEntry(entry);
            Toast.makeText(this, "පන්ති කාලසටහන සාර්ථකව එකතු කරන ලදී!", Toast.LENGTH_SHORT).show();

            // Clear input form
            etSubject.setText("");
            etTeacherName.setText("");
            etNotes.setText("");

            // Switch to Class Timetable view
            switchNavTab(2);
        }
    }

    // --- TIMETABLE ADAPTER ---
    private class TimetableAdapter extends RecyclerView.Adapter<TimetableAdapter.ViewHolder> {
        private List<TimetableEntry> list;

        public TimetableAdapter(List<TimetableEntry> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_timetable_entry, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            TimetableEntry item = list.get(position);

            holder.tvSubjectAndClass.setText(item.getSubject() + " (" + item.getClassName() + ")");
            holder.tvPeriodTimeAndRoom.setText(item.getPeriodName() + " (" + item.getFormattedTimeRange() + ") | " + item.getRoomNo());

            if (item.getNotes() != null && !item.getNotes().isEmpty()) {
                holder.tvNotes.setVisibility(View.VISIBLE);
                holder.tvNotes.setText("සටහන්: " + item.getNotes());
            } else {
                holder.tvNotes.setVisibility(View.GONE);
            }

            holder.tvRoleBadge.setText(item.getRole());

            // Role styling
            if (item.getRole().contains("නියෝජන")) {
                holder.tvRoleBadge.setTextColor(Color.parseColor("#FB923C"));
                holder.imgRoleIcon.setImageResource(android.R.drawable.ic_menu_rotate);
                holder.imgRoleIcon.setColorFilter(Color.parseColor("#FB923C"));
            } else if (item.getRole().contains("නිදහස්")) {
                holder.tvRoleBadge.setTextColor(Color.parseColor("#4ADE80"));
                holder.imgRoleIcon.setImageResource(android.R.drawable.ic_menu_view);
                holder.imgRoleIcon.setColorFilter(Color.parseColor("#4ADE80"));
            } else {
                holder.tvRoleBadge.setTextColor(Color.parseColor("#38BDF8"));
                holder.imgRoleIcon.setImageResource(android.R.drawable.ic_menu_agenda);
                holder.imgRoleIcon.setColorFilter(Color.parseColor("#38BDF8"));
            }

            // Highlight active entry
            TimetableEntry active = getCurrentActiveEntry();
            if (active != null && active.getId().equals(item.getId()) && item.getDay().equals(getTodaySinhalaDay())) {
                holder.cardTimetableItem.setStrokeColor(Color.parseColor("#0284C7"));
                holder.cardTimetableItem.setStrokeWidth(4);
            } else {
                holder.cardTimetableItem.setStrokeColor(Color.parseColor("#334155"));
                holder.cardTimetableItem.setStrokeWidth(2);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            MaterialCardView cardTimetableItem;
            ImageView imgRoleIcon;
            TextView tvSubjectAndClass, tvPeriodTimeAndRoom, tvNotes, tvRoleBadge;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                cardTimetableItem = itemView.findViewById(R.id.cardTimetableItem);
                imgRoleIcon = itemView.findViewById(R.id.imgRoleIcon);
                tvSubjectAndClass = itemView.findViewById(R.id.tvSubjectAndClass);
                tvPeriodTimeAndRoom = itemView.findViewById(R.id.tvPeriodTimeAndRoom);
                tvNotes = itemView.findViewById(R.id.tvNotes);
                tvRoleBadge = itemView.findViewById(R.id.tvRoleBadge);
            }
        }
    }

    // --- CLASS TIMETABLE METHODS & ADAPTER ---
    private ClassTimetableEntry getCurrentActiveClassEntry() {
        String todaySinhala = getTodaySinhalaDay();
        Calendar now = Calendar.getInstance();
        int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);

        List<ClassTimetableEntry> todayEntries = ClassTimetableRepository.getEntriesForDay(todaySinhala);
        for (ClassTimetableEntry entry : todayEntries) {
            int start = entry.getStartMinutesOfDay();
            int end = entry.getEndMinutesOfDay();

            if (nowMinutes >= start && nowMinutes < end) {
                return entry;
            }
        }
        return null;
    }

    private void updateClassLiveStatusBanner() {
        ClassTimetableEntry activeEntry = getCurrentActiveClassEntry();
        if (activeEntry != null) {
            cardClassLiveBanner.setStrokeColor(Color.parseColor("#0D9488"));
            imgClassLiveIndicator.setColorFilter(Color.parseColor("#14B8A6"));
            tvClassLiveLabel.setText("දැනට පන්තියේ පැවැත්වෙන කාලඡේදය");
            tvClassLiveLabel.setTextColor(Color.parseColor("#14B8A6"));

            Calendar now = Calendar.getInstance();
            int nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE);
            int remaining = activeEntry.getEndMinutesOfDay() - nowMinutes;

            tvClassLiveCountdownPill.setText("තව මිනිත්තු " + remaining + " යි");
            tvClassLiveTitle.setText(activeEntry.getSubject());

            String sub = "ගුරුතුමා/තුමිය: " + activeEntry.getTeacherName() + " | " + activeEntry.getPeriodName() + " (" + activeEntry.getFormattedTimeRange() + ") | " + activeEntry.getRoomNo();
            tvClassLiveSubtitle.setText(sub);
        } else {
            cardClassLiveBanner.setStrokeColor(Color.parseColor("#334155"));
            imgClassLiveIndicator.setColorFilter(Color.parseColor("#F59E0B"));
            tvClassLiveLabel.setText("වත්මන් පන්ති තත්වය");
            tvClassLiveLabel.setTextColor(Color.parseColor("#F59E0B"));

            tvClassLiveCountdownPill.setText("විවේක / Free");
            tvClassLiveTitle.setText("දැනට පන්තියේ කාලඡේදයක් නොමැත");
            tvClassLiveSubtitle.setText("විවේක කාලය හෝ නිදහස් කාලඡේදය");
        }
    }

    private void refreshClassDayTimetableList() {
        tvClassDayHeader.setText("පන්තියේ " + selectedClassDay + " කාලසටහන");

        List<ClassTimetableEntry> list = ClassTimetableRepository.getEntriesForDay(selectedClassDay);
        if (list.isEmpty()) {
            tvClassEmptyDayMessage.setVisibility(View.VISIBLE);
            rvClassTimetableEntries.setVisibility(View.GONE);
        } else {
            tvClassEmptyDayMessage.setVisibility(View.GONE);
            rvClassTimetableEntries.setVisibility(View.VISIBLE);

            classTimetableAdapter = new ClassTimetableAdapter(list);
            rvClassTimetableEntries.setAdapter(classTimetableAdapter);
        }
    }

    private class ClassTimetableAdapter extends RecyclerView.Adapter<ClassTimetableAdapter.ViewHolder> {
        private List<ClassTimetableEntry> list;

        public ClassTimetableAdapter(List<ClassTimetableEntry> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_class_timetable_entry, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ClassTimetableEntry item = list.get(position);

            holder.tvClassSubjectName.setText(item.getSubject());
            holder.tvClassTeacherName.setText("ගුරුතුමා/තුමිය: " + item.getTeacherName());
            holder.tvClassTimeAndRoom.setText("වේලාව: " + item.getFormattedTimeRange() + " | ස්ථානය: " + item.getRoomNo());
            holder.tvClassPeriodBadge.setText(item.getPeriodName());

            // Highlight active entry
            ClassTimetableEntry active = getCurrentActiveClassEntry();
            if (active != null && active.getId().equals(item.getId()) && item.getDay().equals(getTodaySinhalaDay())) {
                holder.cardClassTimetableItem.setStrokeColor(Color.parseColor("#0D9488"));
                holder.cardClassTimetableItem.setStrokeWidth(4);
            } else {
                holder.cardClassTimetableItem.setStrokeColor(Color.parseColor("#334155"));
                holder.cardClassTimetableItem.setStrokeWidth(2);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            MaterialCardView cardClassTimetableItem;
            ImageView imgSubjectIcon;
            TextView tvClassSubjectName, tvClassTeacherName, tvClassTimeAndRoom, tvClassPeriodBadge;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                cardClassTimetableItem = itemView.findViewById(R.id.cardClassTimetableItem);
                imgSubjectIcon = itemView.findViewById(R.id.imgSubjectIcon);
                tvClassSubjectName = itemView.findViewById(R.id.tvClassSubjectName);
                tvClassTeacherName = itemView.findViewById(R.id.tvClassTeacherName);
                tvClassTimeAndRoom = itemView.findViewById(R.id.tvClassTimeAndRoom);
                tvClassPeriodBadge = itemView.findViewById(R.id.tvClassPeriodBadge);
            }
        }
    }
}
