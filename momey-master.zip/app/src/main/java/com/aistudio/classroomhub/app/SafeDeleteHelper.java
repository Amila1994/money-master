package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class SafeDeleteHelper {

    public interface OnDeleteConfirmedListener {
        void onDeleteConfirmed();
    }

    public static void showSafeDeleteDialog(Context context, Student student, OnDeleteConfirmedListener listener) {
        if (student == null || context == null) return;

        String fullName = student.getName() != null ? student.getName().trim() : "Student";
        String[] parts = fullName.split("\\s+");
        String firstName = parts.length > 0 ? parts[0] : fullName;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_safe_delete, null);
        TextView tvPrompt = dialogView.findViewById(R.id.deleteConfirmPrompt);
        EditText etInput = dialogView.findViewById(R.id.deleteConfirmInput);
        Button confirmBtn = dialogView.findViewById(R.id.confirmDeleteBtn);

        if (tvPrompt != null) {
            tvPrompt.setText(fullName + " ශිෂ්‍යයාගේ තොරතුරු මකා දැමීමට පළමු නම (\"" + firstName + "\") පහත කොටුවේ Type කරන්න:");
        }

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle("මකා දැමීම තහවුරු කරන්න (Confirm Delete)")
                .setView(dialogView)
                .setNegativeButton("අවලංගු කරන්න (Cancel)", null)
                .create();

        if (confirmBtn != null && etInput != null) {
            confirmBtn.setEnabled(false);

            etInput.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    boolean matches = s.toString().trim().equalsIgnoreCase(firstName.trim());
                    confirmBtn.setEnabled(matches);
                    if (matches) {
                        confirmBtn.setBackgroundColor(0xFFDC2626);
                    } else {
                        confirmBtn.setBackgroundColor(0xFF64748B);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });

            confirmBtn.setOnClickListener(v -> {
                String input = etInput.getText().toString().trim();
                if (input.equalsIgnoreCase(firstName.trim())) {
                    dialog.dismiss();
                    if (listener != null) {
                        listener.onDeleteConfirmed();
                    }
                } else {
                    Toast.makeText(context, "නම නිවැරදි නැත! නැවත උත්සාහ කරන්න.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        dialog.show();
    }
}
