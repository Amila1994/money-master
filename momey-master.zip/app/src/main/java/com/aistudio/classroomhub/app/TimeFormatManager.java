package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimeFormatManager {
    public static final String PREF_NAME = "app_time_prefs";
    public static final String KEY_TIME_FORMAT = "time_format"; // "12" or "24"
    public static final String FORMAT_24 = "24";
    public static final String FORMAT_12 = "12";

    public static String getTimeFormat(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_TIME_FORMAT, FORMAT_24); // Default 24-Hour
    }

    public static void setTimeFormat(Context context, String format) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_TIME_FORMAT, format).apply();
    }

    public static boolean is24HourFormat(Context context) {
        return FORMAT_24.equals(getTimeFormat(context));
    }

    public static String getTimePattern(Context context) {
        return is24HourFormat(context) ? "HH:mm" : "hh:mm a";
    }

    public static String getDateTimePattern(Context context) {
        return is24HourFormat(context) ? "yyyy-MM-dd HH:mm" : "yyyy-MM-dd hh:mm a";
    }

    public static String formatTime(Context context, long timestamp) {
        if (timestamp <= 0) return "";
        SimpleDateFormat sdf = new SimpleDateFormat(getTimePattern(context), Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }

    public static String formatTime(Context context, int hourOfDay, int minute) {
        if (is24HourFormat(context)) {
            return String.format(Locale.US, "%02d:%02d", hourOfDay, minute);
        } else {
            int hour12 = hourOfDay % 12;
            if (hour12 == 0) hour12 = 12;
            String amPm = hourOfDay >= 12 ? "PM" : "AM";
            return String.format(Locale.US, "%02d:%02d %s", hour12, minute, amPm);
        }
    }

    public static String formatDateTime(Context context, long timestamp) {
        if (timestamp <= 0) return "";
        SimpleDateFormat sdf = new SimpleDateFormat(getDateTimePattern(context), Locale.getDefault());
        return sdf.format(new Date(timestamp));
    }
}
