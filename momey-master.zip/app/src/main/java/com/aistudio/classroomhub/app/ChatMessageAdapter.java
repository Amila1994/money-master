package com.aistudio.classroomhub.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatMessageAdapter extends RecyclerView.Adapter<ChatMessageAdapter.MessageViewHolder> {

    public interface OnMessageLongClickListener {
        void onMessageLongClick(ChatMessage message);
    }

    private final List<ChatMessage> messageList;
    private final String currentUserId;
    private OnMessageLongClickListener longClickListener;

    public ChatMessageAdapter(List<ChatMessage> messageList, String currentUserId) {
        this.messageList = messageList;
        this.currentUserId = currentUserId;
    }

    public void setOnMessageLongClickListener(OnMessageLongClickListener listener) {
        this.longClickListener = listener;
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat_message, parent, false);
        return new MessageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
        ChatMessage message = messageList.get(position);
        boolean isSent = message.getSenderUid() != null && message.getSenderUid().equals(currentUserId);

        Context context = holder.itemView.getContext();
        String formattedTime = TimeFormatManager.formatTime(context, message.getTimestamp());

        if (isSent) {
            holder.layoutSent.setVisibility(View.VISIBLE);
            holder.layoutReceived.setVisibility(View.GONE);

            if (message.isDeleted()) {
                holder.tvSentText.setText("🚫 පණිවුඩය ඉවත් කර ඇත (Message deleted)");
                holder.ivSentImage.setVisibility(View.GONE);
                holder.layoutSentFile.setVisibility(View.GONE);
            } else {
                holder.tvSentText.setText(message.getMessageText());
                bindMedia(holder.ivSentImage, holder.layoutSentFile, holder.tvSentFileName, message);
            }

            holder.tvSentTime.setText(formattedTime);

            // Read Receipt / Seen Status
            if (message.isSeen()) {
                holder.tvSentStatus.setText("Seen ✓✓");
                holder.tvSentStatus.setTextColor(android.graphics.Color.parseColor("#38BDF8"));
            } else {
                holder.tvSentStatus.setText("✓");
                holder.tvSentStatus.setTextColor(android.graphics.Color.parseColor("#BAE6FD"));
            }

            holder.cardSent.setOnLongClickListener(v -> {
                if (longClickListener != null && !message.isDeleted()) {
                    longClickListener.onMessageLongClick(message);
                    return true;
                }
                return false;
            });

        } else {
            holder.layoutSent.setVisibility(View.GONE);
            holder.layoutReceived.setVisibility(View.VISIBLE);

            if (message.isDeleted()) {
                holder.tvReceivedText.setText("🚫 පණිවුඩය ඉවත් කර ඇත (Message deleted)");
                holder.ivReceivedImage.setVisibility(View.GONE);
                holder.layoutReceivedFile.setVisibility(View.GONE);
            } else {
                holder.tvReceivedText.setText(message.getMessageText());
                bindMedia(holder.ivReceivedImage, holder.layoutReceivedFile, holder.tvReceivedFileName, message);
            }

            holder.tvReceivedTime.setText(formattedTime);

            if (message.getSenderSchoolName() != null && !message.getSenderSchoolName().isEmpty()) {
                holder.tvSenderName.setVisibility(View.VISIBLE);
                holder.tvSenderName.setText(message.getSenderSchoolName());
            } else {
                holder.tvSenderName.setVisibility(View.GONE);
            }

            holder.cardReceived.setOnLongClickListener(v -> {
                if (longClickListener != null && !message.isDeleted()) {
                    longClickListener.onMessageLongClick(message);
                    return true;
                }
                return false;
            });
        }
    }

    private void bindMedia(ImageView ivImage, LinearLayout layoutFile, TextView tvFileName, ChatMessage message) {
        String type = message.getMessageType();
        if ("IMAGE".equalsIgnoreCase(type) && !message.getMediaUrl().isEmpty()) {
            ivImage.setVisibility(View.VISIBLE);
            layoutFile.setVisibility(View.GONE);
            displayImageFromDataOrUrl(ivImage, message.getMediaUrl());
        } else if ("FILE".equalsIgnoreCase(type)) {
            ivImage.setVisibility(View.GONE);
            layoutFile.setVisibility(View.VISIBLE);
            tvFileName.setText(message.getFileName().isEmpty() ? "Attachment Document" : message.getFileName());
        } else {
            ivImage.setVisibility(View.GONE);
            layoutFile.setVisibility(View.GONE);
        }
    }

    private void displayImageFromDataOrUrl(ImageView ivImage, String mediaData) {
        try {
            if (mediaData.startsWith("data:image") || mediaData.length() > 200) {
                String cleanBase64 = mediaData.contains(",") ? mediaData.split(",")[1] : mediaData;
                byte[] decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
                if (bitmap != null) {
                    ivImage.setImageBitmap(bitmap);
                }
            }
        } catch (Exception e) {
            ivImage.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    static class MessageViewHolder extends RecyclerView.ViewHolder {
        LinearLayout layoutSent;
        LinearLayout layoutReceived;
        MaterialCardView cardSent;
        MaterialCardView cardReceived;

        ImageView ivSentImage;
        LinearLayout layoutSentFile;
        TextView tvSentFileName;
        TextView tvSentText;
        TextView tvSentTime;
        TextView tvSentStatus;

        TextView tvSenderName;
        ImageView ivReceivedImage;
        LinearLayout layoutReceivedFile;
        TextView tvReceivedFileName;
        TextView tvReceivedText;
        TextView tvReceivedTime;

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);
            layoutSent = itemView.findViewById(R.id.layoutSentMessage);
            layoutReceived = itemView.findViewById(R.id.layoutReceivedMessage);
            cardSent = itemView.findViewById(R.id.cardSent);
            cardReceived = itemView.findViewById(R.id.cardReceived);

            ivSentImage = itemView.findViewById(R.id.ivSentImage);
            layoutSentFile = itemView.findViewById(R.id.layoutSentFile);
            tvSentFileName = itemView.findViewById(R.id.tvSentFileName);
            tvSentText = itemView.findViewById(R.id.tvSentText);
            tvSentTime = itemView.findViewById(R.id.tvSentTime);
            tvSentStatus = itemView.findViewById(R.id.tvSentStatus);

            tvSenderName = itemView.findViewById(R.id.tvSenderName);
            ivReceivedImage = itemView.findViewById(R.id.ivReceivedImage);
            layoutReceivedFile = itemView.findViewById(R.id.layoutReceivedFile);
            tvReceivedFileName = itemView.findViewById(R.id.tvReceivedFileName);
            tvReceivedText = itemView.findViewById(R.id.tvReceivedText);
            tvReceivedTime = itemView.findViewById(R.id.tvReceivedTime);
        }
    }
}
