package com.aistudio.classroomhub.app;

import java.io.Serializable;

public class LetterTemplate implements Serializable {
    private String id;
    private String title;
    private String category;    // "Teacher & Staff", "School Admin & Student", "My Saved Documents", "My Custom Templates"
    private String subCategory; // e.g. "Casual Leave", "Transfers", "Leaving Certs", etc.
    private String description;
    private String content;
    private String pageSize = "A4";        // "A4", "A3", "Letter", "Legal"
    private String orientation = "PORTRAIT"; // "PORTRAIT", "LANDSCAPE"
    private boolean isCustomTemplate = false;
    private boolean isSavedDocument = false;
    private long lastUpdated = System.currentTimeMillis();
    private String userId = "";

    public LetterTemplate() {
    }

    public LetterTemplate(String id, String title, String category, String subCategory, String description, String content) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.subCategory = subCategory;
        this.description = description;
        this.content = content;
        this.pageSize = "A4";
        this.orientation = "PORTRAIT";
    }

    public LetterTemplate(String id, String title, String category, String subCategory, String description, String content, String pageSize, String orientation) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.subCategory = subCategory;
        this.description = description;
        this.content = content;
        this.pageSize = pageSize != null ? pageSize : "A4";
        this.orientation = orientation != null ? orientation : "PORTRAIT";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getPageSize() {
        return pageSize != null ? pageSize : "A4";
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    public String getOrientation() {
        return orientation != null ? orientation : "PORTRAIT";
    }

    public void setOrientation(String orientation) {
        this.orientation = orientation;
    }

    public boolean isCustomTemplate() {
        return isCustomTemplate;
    }

    public void setCustomTemplate(boolean customTemplate) {
        isCustomTemplate = customTemplate;
    }

    public boolean isSavedDocument() {
        return isSavedDocument;
    }

    public void setSavedDocument(boolean savedDocument) {
        isSavedDocument = savedDocument;
    }

    public long getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
