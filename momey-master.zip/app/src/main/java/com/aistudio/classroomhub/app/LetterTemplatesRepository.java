package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.List;

public class LetterTemplatesRepository {

    public static final String CAT_TEACHER = "Teacher & Staff";
    public static final String CAT_ADMIN_STUDENT = "School Admin & Student";

    public static List<LetterTemplate> getAllTemplates() {
        List<LetterTemplate> list = new ArrayList<>();
        list.addAll(getTeacherStaffTemplates());
        list.addAll(getSchoolAdminStudentTemplates());
        return list;
    }

    public static List<LetterTemplate> getTemplatesByCategory(String category) {
        List<LetterTemplate> result = new ArrayList<>();
        for (LetterTemplate template : getAllTemplates()) {
            if (template.getCategory().equalsIgnoreCase(category)) {
                result.add(template);
            }
        }
        return result;
    }

    // -------------------------------------------------------------------------
    // 50 TEACHER & STAFF LETTER TEMPLATES
    // -------------------------------------------------------------------------
    private static List<LetterTemplate> getTeacherStaffTemplates() {
        List<LetterTemplate> list = new ArrayList<>();

        // 1. Casual & Short Leave
        list.add(new LetterTemplate(
                "t_01",
                "Casual Leave Application (සාමාන්‍ය නිවාඩු ඉල්ලුම්පත)",
                CAT_TEACHER, "Casual & Short Leave",
                "Standard application for requesting 1 or 2 days casual leave for personal matters.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name],\n[School Address].\n\n" +
                "Through: Sectional Head / Vice Principal,\n\n" +
                "Subject: Application for Casual Leave\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I am writing to respectfully request casual leave for [Number of Days] day(s) on [Leave Date(s)] due to [Reason, e.g., urgent personal family commitment].\n\n" +
                "I have arranged for my teaching duties and class supervision during this period as follows:\n" +
                "1. Class [Grade/Class] - Period [Period No] covered by [Substitute Teacher Name]\n" +
                "2. Class [Grade/Class] - Period [Period No] covered by [Substitute Teacher Name]\n\n" +
                "I shall resume my normal duties on [Resumption Date]. Kindly approve my leave request.\n\n" +
                "Thanking you,\n\n" +
                "Yours faithfully,\n\n" +
                "______________________\n" +
                "[Teacher Name]\n" +
                "[Teacher Designation / Subject]\n" +
                "Service ID: [Teacher ID/Service No]"
        ));

        list.add(new LetterTemplate(
                "t_02",
                "Short Leave Request (කෙටි නිවාඩු ඉල්ලුම්පත)",
                CAT_TEACHER, "Casual & Short Leave",
                "Request permission for a short leave period (1-2 periods or hours during school time).",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Short Leave Permission\n\n" +
                "Respected Principal,\n\n" +
                "I request permission to take short leave today [Date] from [Start Time] to [End Time] in order to attend to an urgent [Reason, e.g., medical appointment / government office matter].\n\n" +
                "My assigned period ([Period Number]) for Class [Grade/Class] has been handed over to [Substitute Teacher Name].\n\n" +
                "Thank you for your understanding.\n\n" +
                "Yours obediently,\n\n" +
                "______________________\n" +
                "[Teacher Name]\n" +
                "Designation: [Teacher Designation]"
        ));

        list.add(new LetterTemplate(
                "t_03",
                "Duty Leave Request for Official Seminar (රාජකාරි නිවාඩු ඉල්ලුම්පත)",
                CAT_TEACHER, "Casual & Short Leave",
                "Request duty leave for attending Zonal Education Office training or workshop.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Duty Leave - [Seminar/Workshop Name]\n\n" +
                "Respected Sir/Madam,\n\n" +
                "As instructed by the Zonal Education Director per Letter Ref No: [Zonal Ref Letter No], I have been selected to attend the [Name of Training/Workshop] organized by the [Zonal/Provincial Education Department].\n\n" +
                "The program will be held at [Venue] on [Date(s)] from [Start Time] to [End Time].\n\n" +
                "I kindly request you to grant me Duty Leave for the specified day(s). The official invitation letter is attached herewith.\n\n" +
                "Thanking you,\n\n" +
                "Yours faithfully,\n\n" +
                "______________________\n" +
                "[Teacher Name]\n" +
                "[Subject / Grade Teacher]"
        ));

        list.add(new LetterTemplate(
                "t_04",
                "Half Day Leave Application (අර්ධ දින නිවාඩු ඉල්ලීම)",
                CAT_TEACHER, "Casual & Short Leave",
                "Request half day leave for morning or afternoon session.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Half Day Leave ([Morning / Afternoon] Session)\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I kindly request permission to take half day leave during the [Morning/Afternoon] session on [Date] due to [Reason].\n\n" +
                "I will be attending school until [Time] / I will arrive at school by [Time]. All class periods during my absence have been covered by arrangement.\n\n" +
                "Thanking you,\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_05",
                "Sick Leave Notification (අසනීප නිවාඩු දැනුම්දීම)",
                CAT_TEACHER, "Casual & Short Leave",
                "Formal notice informing the principal regarding sudden illness absence.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Notification of Absence Due to Illness\n\n" +
                "Respected Principal,\n\n" +
                "I regret to inform you that I am unable to report for duty today [Date] due to sudden illness ([Brief Illness Reason]).\n\n" +
                "I will report back to duty on [Expected Return Date]. I will submit the formal medical leave application along with the doctor's certificate upon my return.\n\n" +
                "Thanking you,\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_06",
                "Exam Duty Leave Request (විභාග නිරීක්ෂක රාජකාරි නිවාඩු)",
                CAT_TEACHER, "Casual & Short Leave",
                "Request duty leave for G.C.E. O/L or A/L examination supervision or evaluation.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Duty Leave Request for G.C.E. [O/L or A/L] Exam Duty\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I have been appointed as an [Invigilator / Supervisor / Marking Examiner] for the G.C.E. [O/L or A/L] Examination [Year] by the Department of Examinations, Sri Lanka (Appointment Letter No: [Appointment Ref No]).\n\n" +
                "The examination duty will take place at [Exam Center Name] from [Start Date] to [End Date].\n\n" +
                "I request you to grant me duty leave for the above period. A copy of the appointment letter is attached.\n\n" +
                "Thanking you,\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_07",
                "Marking Duty Leave Request (උත්තර පත්‍ර පරීක්ෂක රාජකාරි නිවාඩු)",
                CAT_TEACHER, "Casual & Short Leave",
                "Duty leave request for paper marking board evaluation.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Leave for G.C.E. [O/L or A/L] Paper Evaluation Board\n\n" +
                "Respected Sir,\n\n" +
                "I have been selected as an Assistant Examiner for the G.C.E. [O/L or A/L] paper evaluation panel for the subject [Subject Name] at [Evaluation Center].\n\n" +
                "Evaluation Period: From [Start Date] to [End Date].\n\n" +
                "Kindly grant me duty leave for this official national evaluation duty.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_08",
                "Paternity Leave Request (පීතෘත්ව නිවාඩු ඉල්ලුම්පත)",
                CAT_TEACHER, "Casual & Short Leave",
                "Application for paternity leave according to government regulations.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Paternity Leave\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I wish to inform you that my wife gave birth to a baby [boy/girl] on [Child Birth Date].\n\n" +
                "In accordance with Public Administration Establishments Code regulations, I request 3 working days of paternity leave from [Start Date] to [End Date].\n\n" +
                "Copy of the birth notification is attached herewith.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_09",
                "Maternity Extension Request (මාතෘත්ව නිවාඩු දීර්ඝ කිරීමේ ඉල්ලුම්පත)",
                CAT_TEACHER, "Casual & Short Leave",
                "Request for extended half-pay / no-pay maternity leave.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Through: Zonal Director of Education, [Zone Name].\n\n" +
                "Subject: Application for Extension of Maternity Leave ([Half Pay / No Pay])\n\n" +
                "Respected Sir,\n\n" +
                "My full-pay maternity leave of 84 working days expires on [Expiry Date]. In order to care for my newborn infant, I request an extension of maternity leave for [Number of Months] months on [Half Pay / No Pay] basis starting from [Start Date] to [End Date].\n\n" +
                "Medical certificate and child birth certificate copies are attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_10",
                "Emergency Family Leave Request (අත්‍යවශ්‍ය පවුලේ හදිසි නිවාඩු ඉල්ලීම)",
                CAT_TEACHER, "Casual & Short Leave",
                "Request for immediate leave due to family medical emergency.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Emergency Leave Due to Family Emergency\n\n" +
                "Respected Sir/Madam,\n\n" +
                "Due to an unforeseen medical emergency involving my [family member relation, e.g., parent/spouse/child], I am required to attend to them immediately.\n\n" +
                "Kindly grant me emergency leave for [Number of Days] days on [Date(s)]. I will ensure all missing teaching periods are duly covered upon my return.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        // 2. Medical & Special Leave
        list.add(new LetterTemplate(
                "t_11",
                "Medical Leave Application with Certificate (වෛද්‍ය නිවාඩු ඉල්ලුම්පත)",
                CAT_TEACHER, "Medical & Special Leave",
                "Formal application submitting government medical officer's sick note.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Medical Leave Application for [Number of Days] Days\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I was unable to report for duty from [Start Date] to [End Date] ([Total Days] days) due to [Illness/Medical condition].\n\n" +
                "I am attaching the official Medical Certificate issued by Government Medical Officer [Doctor's Name / Hospital Name], Registration No: [Reg No].\n\n" +
                "Kindly cover this absence under my entitled Medical Leave quota.\n\n" +
                "______________________\n" +
                "[Teacher Name]\n" +
                "Service No: [Teacher ID]"
        ));

        list.add(new LetterTemplate(
                "t_12",
                "Extended Medical Leave Request (දීර්ඝකාලීන වෛද්‍ය නිවාඩු)",
                CAT_TEACHER, "Medical & Special Leave",
                "Request for extended medical leave following surgery or major illness.",
                "[Date]\n\n" +
                "To: Zonal Director of Education,\n[Zonal Education Office],\nThrough: The Principal, [School Name].\n\n" +
                "Subject: Application for Extended Medical Leave\n\n" +
                "Respected Sir,\n\n" +
                "Following my major medical treatment/surgery for [Condition] at [Hospital Name], the Consultant Medical Specialist has advised me to undergo complete rest for [Period, e.g., 30 days] from [Start Date] to [End Date].\n\n" +
                "I request approval for extended medical leave. All relevant medical reports and specialist recommendations are attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_13",
                "Special Medical Board Leave (විශේෂ වෛද්‍ය මණ්ඩල නිවාඩු)",
                CAT_TEACHER, "Medical & Special Leave",
                "Submission to Zonal Director for Medical Board endorsement.",
                "[Date]\n\n" +
                "To: Zonal Education Director,\n[Zonal Office].\n\n" +
                "Subject: Application to Reference Medical Board for Medical Leave\n\n" +
                "Respected Sir/Madam,\n\n" +
                "Owing to continuous health complications ([Medical Condition]), I request to be referred to the Official Government Medical Board at [Hospital Name] for assessment and approval of continuous leave.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_14",
                "Quarantine / Infectious Disease Leave (නිරෝධායන නිවාඩු)",
                CAT_TEACHER, "Medical & Special Leave",
                "Special leave request for contagious illness under Public Health Officer directives.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Special Quarantine Leave\n\n" +
                "Respected Principal,\n\n" +
                "I have been diagnosed with an infectious disease ([Disease Name, e.g., Dengue / Chickenpox / COVID]) and advised by Public Health Inspector / Doctor to remain under strict isolation from [Start Date] to [End Date].\n\n" +
                "Attached is the diagnosis certificate and PHI recommendation note.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_15",
                "Accident Leave Application (අනතුරු නිවාඩු ඉල්ලුම්පත)",
                CAT_TEACHER, "Medical & Special Leave",
                "Special leave application for injury sustained on duty or road accident.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Accident Leave\n\n" +
                "Respected Sir,\n\n" +
                "I met with an unexpected road accident / injury on [Date of Accident] while traveling to school / duty.\n\n" +
                "Due to [Injury Details], I am hospitalized / confined to bed for [Days] days from [Start Date] to [End Date]. Kindly approve my accident leave.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_16",
                "Hospitalization Leave Request (රෝහල්ගතවීමේ නිවාඩු ඉල්ලීම)",
                CAT_TEACHER, "Medical & Special Leave",
                "Leave request for scheduled hospital admission and treatment.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Leave Due to Hospital Admission\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I am scheduled for hospital admission at [Hospital Name], Ward [Ward No] for [Medical Procedure/Treatment] starting from [Date].\n\n" +
                "I request medical leave for [Number of Days] days from [Start Date] to [End Date].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_17",
                "Convalescence Leave Request (පසු ප්‍රතිකාර වෛද්‍ය නිවාඩු)",
                CAT_TEACHER, "Medical & Special Leave",
                "Request for post-surgery recovery rest period.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Convalescence Recovery Leave\n\n" +
                "Respected Principal,\n\n" +
                "Post my discharge from [Hospital Name] on [Discharge Date], the Medical Specialist has recommended a mandatory [Number of Weeks] weeks convalescence period for post-surgical recovery.\n\n" +
                "Kindly grant me leave for the specified period.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_18",
                "Medical Board Fitness Submission (නැවත සේවයට වාර්තා කිරීම - වෛද්‍ය සහතිකය)",
                CAT_TEACHER, "Medical & Special Leave",
                "Covering letter resuming duties after long medical leave.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Resumption of Duty Post Medical Leave and Fitness Certificate Submission\n\n" +
                "Respected Sir,\n\n" +
                "I am pleased to inform you that I have recovered from my medical condition ([Illness]) and am resuming my full teaching duties today [Date].\n\n" +
                "I attach herewith the official Medical Fitness Certificate issued by [Doctor Name / Hospital].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_19",
                "Ante-natal Medical Leave Request (පූර්ව ප්‍රසව වෛද්‍ය නිවාඩු)",
                CAT_TEACHER, "Medical & Special Leave",
                "Pre-natal medical leave request before child birth.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Ante-natal Medical Leave\n\n" +
                "Respected Principal,\n\n" +
                "As advised by my Consultant Obstetrician due to pregnancy complications, I request ante-natal medical leave for [Days] days from [Start Date] to [End Date].\n\n" +
                "Specialist medical note is attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_20",
                "Surgical Medical Leave Request (ශල්‍යකර්ම වෛද්‍ය නිවාඩු)",
                CAT_TEACHER, "Medical & Special Leave",
                "Leave request for planned elective surgical procedure.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Surgical Medical Leave\n\n" +
                "Respected Sir,\n\n" +
                "I am undergoing a planned surgical procedure at [Hospital Name] on [Date]. I kindly request medical leave from [Start Date] to [End Date] as recommended by the surgeon.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        // 3. Transfers & Attachments
        list.add(new LetterTemplate(
                "t_21",
                "Annual Teacher Transfer Application (වාර්ෂික ගුරු මාරුවීම් ඉල්ලුම්පත)",
                CAT_TEACHER, "Transfers & Attachments",
                "Standard application for annual teacher transfer across zones/schools.",
                "[Date]\n\n" +
                "To: Zonal Education Director,\n[Zonal Education Office],\nThrough: The Principal, [School Name].\n\n" +
                "Subject: Application for Annual Teacher Transfer - [Year]\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I have completed [Number of Years] years of continuous service at [Current School Name] as a [Subject Name] teacher (Appointed Date: [Appointed Date]).\n\n" +
                "I respectfully apply for a transfer to one of the following preferred schools under the Annual Transfer scheme:\n" +
                "1. Preferred School 01: [School Name 1]\n" +
                "2. Preferred School 02: [School Name 2]\n" +
                "3. Preferred School 03: [School Name 3]\n\n" +
                "Reason for Transfer: [e.g., Distance from residence / Spouse employment / Family care].\n\n" +
                "Duly completed Annual Transfer Form and supporting documents are attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]\n" +
                "Service ID: [Teacher ID]"
        ));

        list.add(new LetterTemplate(
                "t_22",
                "Mutual Transfer Application (පරස්පර ගුරු මාරුවීම් ඉල්ලුම්පත)",
                CAT_TEACHER, "Transfers & Attachments",
                "Mutual transfer request between two agreed teachers.",
                "[Date]\n\n" +
                "To: Provincial Director of Education,\nThrough: Principals of [School A] & [School B].\n\n" +
                "Subject: Application for Mutual Transfer Between Teachers\n\n" +
                "Respected Sir,\n\n" +
                "We, the undersigned teachers teaching [Subject Name], hereby apply for a Mutual Transfer:\n\n" +
                "Teacher 01: [Teacher 01 Name], Service No: [ID 1], Current School: [School 01]\n" +
                "Teacher 02: [Teacher 02 Name], Service No: [ID 2], Current School: [School 02]\n\n" +
                "Both principals have consented to this exchange. Duly signed consent forms attached.\n\n" +
                "______________________              ______________________\n" +
                "[Teacher 01 Signature]             [Teacher 02 Signature]"
        ));

        list.add(new LetterTemplate(
                "t_23",
                "Medical Grounds Transfer Request (වෛද්‍ය හේතු මත ස්ථාන මාරුව)",
                CAT_TEACHER, "Transfers & Attachments",
                "Transfer request closer to home/hospital due to medical illness.",
                "[Date]\n\n" +
                "To: Zonal Education Director,\n[Zonal Office].\n\n" +
                "Subject: Request for Teacher Transfer on Humanitarian & Medical Grounds\n\n" +
                "Respected Sir/Madam,\n\n" +
                "I am currently serving at [Current School Name]. Due to my chronic medical condition ([Condition Name]), I am required to undergo weekly treatment at [Hospital Name].\n\n" +
                "The daily travel distance of [Distance in KM] km severely affects my health. I humbly request a transfer to a school near [Residence Town/Area].\n\n" +
                "Medical reports attached herewith.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_24",
                "Administrative Transfer Appeal (පාලන ස්ථාන මාරු අභියාචනය)",
                CAT_TEACHER, "Transfers & Attachments",
                "Appeal letter against unfair administrative transfer decision.",
                "[Date]\n\n" +
                "To: Secretary, Ministry of Education / Provincial Education Director.\n\n" +
                "Subject: Appeal Against Administrative Transfer Notice No: [Ref No]\n\n" +
                "Respected Sir,\n\n" +
                "I am writing to formally appeal against the recent transfer order assigning me to [New School Name] with effect from [Date].\n\n" +
                "I request a re-consideration on the following valid grounds: [Grounds, e.g., Mid-term examination responsibilities / Special Needs child care].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_25",
                "Temporary Attachment Request (තාවකාලික සේවයේ යෙදවීමේ ඉල්ලුම්පත)",
                CAT_TEACHER, "Transfers & Attachments",
                "Request temporary attachment to another school for a fixed duration.",
                "[Date]\n\n" +
                "To: Zonal Director of Education.\n\n" +
                "Subject: Application for Temporary Attachment to [Target School Name]\n\n" +
                "Respected Sir,\n\n" +
                "Due to [Reason, e.g., Pregnancy / Temporary relocation / Special care], I request a temporary attachment to [Target School Name] for a period of [6 Months / 1 Year] from [Start Date] to [End Date].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_26",
                "Release Letter Request for Transfer (මුදා හැරීමේ ලිපිය ඉල්ලීම)",
                CAT_TEACHER, "Transfers & Attachments",
                "Request principal to issue release letter post transfer order.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Official Release Letter Following Transfer Order\n\n" +
                "Respected Principal,\n\n" +
                "Pursuant to the Zonal Transfer Order Ref: [Transfer Order Ref No] dated [Date], I have been transferred to [New School Name].\n\n" +
                "I have completed handing over all class records, inventory items, and exam papers to [Relieving Teacher Name]. Kindly issue my official Release Letter.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_27",
                "Re-allocation Request for Subject Cadre (විෂය කාඩර් නැවත වෙන්කිරීම)",
                CAT_TEACHER, "Transfers & Attachments",
                "Request re-assignment to relevant subject specialization.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Re-allocation of Teaching Subjects\n\n" +
                "Respected Principal,\n\n" +
                "I hold a Bachelor's Degree / Trained Teacher Certificate in [Specialized Subject]. I request to be assigned to teach [Specialized Subject] for Grades [Grades] in the upcoming academic term.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_28",
                "Hardstation Service Transfer Request (දුෂ්කර සේවා මාරුවීම් ඉල්ලීම)",
                CAT_TEACHER, "Transfers & Attachments",
                "Transfer request after completing mandatory hardstation service period.",
                "[Date]\n\n" +
                "To: Zonal Education Director.\n\n" +
                "Subject: Transfer Application After Completing Difficult/Hardstation School Service\n\n" +
                "Respected Sir,\n\n" +
                "I have successfully completed [Number of Years] years of mandatory service in Difficult Area School [School Name] from [Start Date] to [End Date].\n\n" +
                "I request transfer to a favorable school in [Target Zone] as per Ministry circular guidelines.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        // 4. Salary, Agrahara & Loans
        list.add(new LetterTemplate(
                "t_29",
                "Agrahara Insurance Claim Application (අග්‍රහාර රක්ෂණ වන්දි ඉල්ලුම්පත)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Covering letter for Agrahara medical insurance reimbursement claim.",
                "[Date]\n\n" +
                "To: The Director, National Insurance Trust Fund (NITF),\nThrough: The Principal, [School Name].\n\n" +
                "Subject: Submission of Agrahara Medical Insurance Claim\n\n" +
                "Respected Sir,\n\n" +
                "I submit herewith my Agrahara Health Insurance Claim for medical treatment / surgery at [Hospital Name] from [Admit Date] to [Discharge Date].\n\n" +
                "Agrahara ID / Service No: [Agrahara No]\n" +
                "Total Hospital Bill Amount: LKR [Amount]\n\n" +
                "Enclosures: Duly certified claim form, original bills, discharge summary, and prescription copies.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_30",
                "Distress Loan Application (විපතේදී සහන ණය ඉල්ලුම්පත)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Application for government distress loan (10 months salary).",
                "[Date]\n\n" +
                "To: Zonal Education Director,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Application for Government Distress Loan\n\n" +
                "Respected Sir,\n\n" +
                "I request approval for a Government Distress Loan equivalent to 10 months basic salary for the purpose of [Reason, e.g., House repairs / Medical expenses / Education].\n\n" +
                "My present basic salary is LKR [Basic Salary Amount]. Duly completed loan form and pay slip attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_31",
                "Property Loan Recommendation Request (දේපල ණය නිරදේශය)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Recommendation request for housing / land property loan.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Recommendation Letter for Housing Property Loan\n\n" +
                "Respected Principal,\n\n" +
                "I am applying for a State Property / Housing Loan from [Bank Name, e.g., Bank of Ceylon / People's Bank].\n\n" +
                "Kindly issue the employer recommendation and salary deduction confirmation letter.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_32",
                "Salary Slip Request Letter (වැටුප් වාර්තා ඉල්ලුම්පත)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Request for official certified monthly pay slips.",
                "[Date]\n\n" +
                "To: Accounts Branch / Principal,\n[School Name].\n\n" +
                "Subject: Request for Certified Salary Slips ([Months/Year])\n\n" +
                "Respected Sir/Madam,\n\n" +
                "Please issue official certified copies of my salary slips for the months of [Month 1, Month 2, Month 3] for official bank verification purposes.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_33",
                "Salary Increment Restoration Request (වැටුප් වර්ධක යථා තත්ත්වයට පත්කිරීම)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Request for annual salary increment approval.",
                "[Date]\n\n" +
                "To: Zonal Education Director,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Application for Annual Salary Increment Approval ([Year])\n\n" +
                "Respected Sir,\n\n" +
                "My annual salary increment fell due on [Increment Due Date]. I have fulfilled all required service conditions, attendance quotas, and performance benchmarks.\n\n" +
                "Kindly grant approval to credit the annual increment.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_34",
                "Salary Anomaly Correction Request (වැටුප් විෂමතා සංශෝධන ඉල්ලීම)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Request to rectify salary scale discrepancy.",
                "[Date]\n\n" +
                "To: Zonal Accounts Branch,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Request to Rectify Salary Scale Anomaly\n\n" +
                "Respected Sir,\n\n" +
                "Upon comparing my salary step following promotion to Grade [I / II / III], I noticed a salary discrepancy in comparison with Public Administration Circular [Circular No].\n\n" +
                "Kindly audit my pay file and adjust the arrears.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_35",
                "Bank Loan Guarantee Request Letter (බැංකු ණය ඇපකර ඉල්ලීම)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Request principal's guarantee for bank personal loan.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Salary Deduction Authorization for Personal Loan\n\n" +
                "Respected Principal,\n\n" +
                "I am obtaining a personal loan from [Bank Name] for LKR [Amount]. Kindly approve the salary remittance authorization form required by the bank.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_36",
                "Festival Advance Application (උත්සව අත්පිට මුදල් ඉල්ලුම්පත)",
                CAT_TEACHER, "Salary, Agrahara & Loans",
                "Application for annual Sinhala/Tamil New Year or Christmas festival advance.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Festival Advance ([Festival Name, e.g., New Year / Christmas])\n\n" +
                "Respected Sir,\n\n" +
                "I request the allocation of the standard Government Festival Advance for the upcoming [Festival Name] festival.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        // 5. Training & Higher Education
        list.add(new LetterTemplate(
                "t_37",
                "In-service Teacher Training Request (ගුරු පුහුණු පාඨමාලා ඉල්ලුම්පත)",
                CAT_TEACHER, "Training & Education",
                "Application to enroll in National Institute of Education (NIE) training.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Permission to Enroll in NIE In-Service Training Program\n\n" +
                "Respected Principal,\n\n" +
                "I wish to enroll in the [Course Name] conducted by the National Institute of Education (NIE) / National College of Education.\n\n" +
                "Course duration: [Start Date] to [End Date] (Saturdays/Online). I kindly request school endorsement.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_38",
                "Post-Graduate Study Leave Request (පශ්චාත් උපාධි අධ්‍යයන නිවාඩු)",
                CAT_TEACHER, "Training & Education",
                "Request study leave for M.Ed / Post Graduate Diploma in Education (PGDE).",
                "[Date]\n\n" +
                "To: Secretary, Ministry of Education / Zonal Director,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Application for Study Leave for Master of Education (M.Ed) / PGDE\n\n" +
                "Respected Sir,\n\n" +
                "I have gained admission to the [M.Ed / PGDE] degree program at the University of [University Name] starting from [Start Date].\n\n" +
                "I request approval for full-pay / no-pay study leave for [1 Year / 2 Years]. Admission letter attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_39",
                "Subject Seminar Attendance Request (විෂය සමුළු සහභාගීත්ව ඉල්ලීම)",
                CAT_TEACHER, "Training & Education",
                "Permission to attend provincial subject development conference.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request Permission to Attend Provincial [Subject] Teachers Seminar\n\n" +
                "Respected Sir,\n\n" +
                "I request permission to attend the Provincial [Subject Name] Seminar organized at [Venue] on [Date].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_40",
                "Workshop Participation Permission (වැඩමුළු සහභාගීත්ව අවසරය)",
                CAT_TEACHER, "Training & Education",
                "Request permission for IT / STEM educational workshop.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application to Attend Educational Workshop on [Topic]\n\n" +
                "Respected Principal,\n\n" +
                "I request approval to participate in the 2-day workshop titled '[Workshop Title]' on [Dates] conducted by [Organization Name].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_41",
                "University Exam Duty Release (විශ්වවිද්‍යාල විභාග නිවාඩු)",
                CAT_TEACHER, "Training & Education",
                "Release request to sit for university degree examinations.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Release Permission for University Degree Examinations\n\n" +
                "Respected Principal,\n\n" +
                "I am sitting for the final year examinations of [Degree Name] at [University Name] held from [Start Date] to [End Date].\n\n" +
                "Kindly grant me duty/special study leave for the examination days. Admission ticket attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_42",
                "Research Permission Request (අධ්‍යාපනික පර්යේෂණ අවසරය)",
                CAT_TEACHER, "Training & Education",
                "Request permission to conduct action research in school classrooms.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request to Conduct Educational Action Research in School\n\n" +
                "Respected Principal,\n\n" +
                "As part of my M.Ed research thesis, I request permission to conduct classroom observation and collect anonymous feedback in Grade [Grade] for my study titled '[Research Title]'.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_43",
                "Foreign Training Recommendation Request (විදේශීය පුහුණු නිර්දේශය)",
                CAT_TEACHER, "Training & Education",
                "Principal's recommendation for overseas educational scholarship.",
                "[Date]\n\n" +
                "To: Foreign Relations Branch, Ministry of Education.\nThrough: Principal, [School Name].\n\n" +
                "Subject: Recommendation for Overseas Teacher Training Program in [Country]\n\n" +
                "Respected Sir,\n\n" +
                "I hereby submit my application for the Short-term Overseas Training Program on [Subject] in [Country Name].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        // 6. Service Certificates & Admin
        list.add(new LetterTemplate(
                "t_44",
                "Service Certificate Request (සේවා සහතික පත්‍ර ඉල්ලීම)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Request principal to issue official service record certificate.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Official Service Certificate\n\n" +
                "Respected Sir,\n\n" +
                "I request you to kindly issue an Official Service Certificate verifying my tenure as a teacher at [School Name] from [Start Year] to Present.\n\n" +
                "Purpose: [e.g., Bank loan submission / Child school admission / Visa application].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_45",
                "ETF/EPF Claim Endorsement Request (ඊ.ටී.එෆ් / ඊ.පී.එෆ් හිමිකම් සහතිකය)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Endorsement request for EPF/ETF retirement benefit claim.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Endorsement of EPF / ETF Benefit Claim Forms\n\n" +
                "Respected Principal,\n\n" +
                "Following my retirement / tenure, I request your signature and school seal on the EPF / ETF refund application form K.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_46",
                "Pension Calculation Statement Request (විශ්‍රාම වැටුප් ලේඛන ඉල්ලීම)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Request for pension computation documents prior to retirement.",
                "[Date]\n\n" +
                "To: Zonal Pensions Branch,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Submission of Pension Papers prior to Retirement\n\n" +
                "Respected Sir,\n\n" +
                "As my optional/mandatory retirement date is scheduled for [Retirement Date], I submit herewith my completed Pension Application File (PD 01).\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_47",
                "Confirmation in Service Letter (සේවය ස්ථීර කිරීමේ ඉල්ලුම්පත)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Request for service confirmation letter after 3 years probation.",
                "[Date]\n\n" +
                "To: Zonal Education Director,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Request for Official Confirmation in Teacher Service\n\n" +
                "Respected Sir,\n\n" +
                "I completed my 3-year probationary period on [Probation End Date]. I have passed all required language and efficiency bar exams.\n\n" +
                "Kindly issue my Service Confirmation Order.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_48",
                "Teacher ID Card Request Letter (ගුරු හැඳුනුම්පත් ඉල්ලුම්පත)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Request for new or duplicate Ministry Teacher Identity Card.",
                "[Date]\n\n" +
                "To: Zonal Education Office,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Application for Ministry Official Teacher Identity Card\n\n" +
                "Respected Sir,\n\n" +
                "I request the issuance of my Official Teacher ID Card. Photographs and birth certificate copies attached.\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_49",
                "Class Teacher Appointment Request (පන්ති භාර ගුරු පත්වීම් ඉල්ලීම)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Request formal appointment letter as Grade Class Teacher.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Formal Class Teacher Appointment Letter - Grade [Grade/Class]\n\n" +
                "Respected Principal,\n\n" +
                "I request the formal letter of appointment as Class Teacher for Grade [Grade/Class] for the academic year [Year].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "t_50",
                "Promotion Assessment Application (ගුරු ශ්‍රේණි උසස්වීම් ඉල්ලුම්පත)",
                CAT_TEACHER, "Service Certificates & Admin",
                "Application for Teacher Service Promotion (Grade II to Grade I).",
                "[Date]\n\n" +
                "To: Zonal Education Director,\nThrough: Principal, [School Name].\n\n" +
                "Subject: Application for Promotion to Teacher Service Grade [I / II-A]\n\n" +
                "Respected Sir,\n\n" +
                "Having fulfilled [Number of Years] years in Teacher Service Grade [II-B], I submit my appraisal file for promotion to Grade [II-A / I].\n\n" +
                "______________________\n" +
                "[Teacher Name]"
        ));

        return list;
    }

    // -------------------------------------------------------------------------
    // 50 SCHOOL ADMIN & STUDENT LETTER TEMPLATES
    // -------------------------------------------------------------------------
    private static List<LetterTemplate> getSchoolAdminStudentTemplates() {
        List<LetterTemplate> list = new ArrayList<>();

        // 1. Leaving & Character Certificates
        list.add(new LetterTemplate(
                "s_01",
                "School Leaving Certificate Application (පාසල් අස්වීමේ සහතිකය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Official student/parent application requesting School Leaving Certificate.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name],\n[School Address].\n\n" +
                "Subject: Application for School Leaving Certificate\n\n" +
                "Respected Principal,\n\n" +
                "I am the parent/guardian of [Student Name], who was enrolled in Grade [Class/Grade] under Admission Number [Admission No].\n\n" +
                "My child is leaving the school due to [Reason, e.g., Family relocation / Admission to higher institution].\n\n" +
                "All library books, sports equipment, and school dues have been cleared. Clearance certificate attached. Kindly issue the official School Leaving Certificate.\n\n" +
                "Thanking you,\n\n" +
                "______________________\n" +
                "[Parent/Guardian Name]\n" +
                "Contact No: [Phone Number]"
        ));

        list.add(new LetterTemplate(
                "s_02",
                "Student Character Certificate Request (ශිෂ්‍ය චරිත සහතිකය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Application requesting character certificate for university/job application.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Student Character & Conduct Certificate\n\n" +
                "Respected Principal,\n\n" +
                "I was a student of [School Name] from [Start Year] to [End Year] and passed G.C.E. Advanced Level in [Year] (Index No: [A/L Index No]).\n\n" +
                "I require an official Character Certificate for [Purpose, e.g., Higher Education Admission / Job Application].\n\n" +
                "Kindly issue the certificate at your earliest convenience.\n\n" +
                "______________________\n" +
                "[Student Name]\n" +
                "Admission No: [Admission No]"
        ));

        list.add(new LetterTemplate(
                "s_03",
                "Duplicate Leaving Certificate Request (දෙවන පිටපත් අස්වීමේ සහතිකය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Request duplicate leaving certificate following loss of original.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Duplicate School Leaving Certificate\n\n" +
                "Respected Sir,\n\n" +
                "I regret to inform you that my original School Leaving Certificate (Issued Year: [Year]) was lost/damaged.\n\n" +
                "I attach herewith a copy of the Police Entry Report (Police Station: [Police Station Name], Entry No: [Entry No]) and affidavit.\n\n" +
                "Kindly issue a Duplicate Leaving Certificate.\n\n" +
                "______________________\n" +
                "[Applicant Name]"
        ));

        list.add(new LetterTemplate(
                "s_04",
                "Student Service Record Certificate (ශිෂ්‍ය සේවා හා නායකත්ව සහතිකය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Certificate validating student leadership & prefect roles.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Request for Student Co-curricular & Prefectship Certificate\n\n" +
                "Respected Principal,\n\n" +
                "I served as a [Senior Prefect / House Captain / Club President] during the academic years [Years].\n\n" +
                "Kindly issue an official testimonial certifying my leadership roles and co-curricular service.\n\n" +
                "______________________\n" +
                "[Student Name]"
        ));

        list.add(new LetterTemplate(
                "s_05",
                "Principal Recommendation for Higher Studies (විශ්වවිද්‍යාල ශිෂ්‍යත්ව නිර්දේශය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Recommendation letter from Principal for overseas university or scholarship.",
                "OFFICIAL LETTERHEAD OF [SCHOOL NAME]\n\n" +
                "Date: [Date]\n\n" +
                "TO WHOM IT MAY CONCERN\n\n" +
                "RECOMMENDATION LETTER FOR [STUDENT NAME]\n\n" +
                "It is with great pleasure that I write this recommendation for [Student Name], Index No: [Index No], who completed G.C.E. A/L Examination at our institution with outstanding results.\n\n" +
                "During their tenure from [Start Year] to [End Year], [Student Name] demonstrated exceptional academic rigor, discipline, and exemplary moral character.\n\n" +
                "I strongly recommend [Student Name] for higher studies / scholarship programs without reservation.\n\n" +
                "______________________\n" +
                "[Principal Name]\n" +
                "Principal, [School Name]"
        ));

        list.add(new LetterTemplate(
                "s_06",
                "Sports Achievements Certificate Request (ක්‍රීඩා දක්ෂතා සහතිකය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Certificate validating sports participation and zonal/national colors.",
                "[Date]\n\n" +
                "To: Master-in-Charge of Sports / Principal,\n[School Name].\n\n" +
                "Subject: Request for Official Sports Achievement Certificate\n\n" +
                "Respected Sir,\n\n" +
                "I represented the school [Cricket / Athletics / Badminton / Football] team from [Start Year] to [End Year] and won [Zonal / Provincial / National] colors.\n\n" +
                "Kindly issue an official Sports Performance Certificate.\n\n" +
                "______________________\n" +
                "[Student Name]"
        ));

        list.add(new LetterTemplate(
                "s_07",
                "Conduct Certificate Request (හැසිරීම් රටා සහතික පත්‍රය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Request conduct report for visa or passport endorsement.",
                "[Date]\n\n" +
                "To: The Principal,\n[School Name].\n\n" +
                "Subject: Application for Student Conduct Certificate for Passport/Visa\n\n" +
                "Respected Principal,\n\n" +
                "I require a certified Conduct Certificate for my child [Student Name], Grade [Grade], for official passport/visa documentation.\n\n" +
                "______________________\n" +
                "[Parent Name]"
        ));

        list.add(new LetterTemplate(
                "s_08",
                "O/L Examination Certificate Recommendation (සාමාන්‍ය පෙළ සහතික පිටපත් පරීක්ෂාව)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Principal's verification letter for G.C.E. O/L results.",
                "[Date]\n\n" +
                "To: Department of Examinations, Sri Lanka.\nThrough: Principal, [School Name].\n\n" +
                "Subject: Verification of G.C.E. O/L Results - [Student Name], Index No: [O/L Index No]\n\n" +
                "This letter confirms that [Student Name] sat for G.C.E. O/L Examination [Year] from [School Name] under Index No [O/L Index No]. Results are verified accurate as per school records.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_09",
                "A/L Stream Eligibility Certificate (උසස් පෙළ විෂය ධාරා සුදුසුකම් සහතිකය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Eligibility certificate for Science / Commerce / Arts A/L stream admission.",
                "[Date]\n\n" +
                "To: The Principal, [Target School Name].\nFrom: Principal, [Current School Name].\n\n" +
                "Subject: G.C.E. A/L Stream Admission Eligibility Confirmation\n\n" +
                "This is to certify that [Student Name] has qualified for G.C.E. A/L [Bio Science / Physical Science / Commerce / Arts] stream based on G.C.E. O/L results [Year].\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_10",
                "Past Pupil Membership Endorsement (ආදි ශිෂ්‍ය සංගම් සාමාජිකත්වය)",
                CAT_ADMIN_STUDENT, "Leaving & Character Certs",
                "Endorsement for Past Pupils' Association (PPA) membership.",
                "[Date]\n\n" +
                "To: Hony. Secretary, Past Pupils' Association,\n[School Name].\n\n" +
                "Subject: Application for Life Membership of Past Pupils' Association\n\n" +
                "I request enrollment as a Life Member of the Past Pupils' Association. I was a student from [Start Year] to [End Year].\n\n" +
                "______________________\n" +
                "[Past Student Name]"
        ));

        // 2. Student Absence & Medical
        list.add(new LetterTemplate(
                "s_11",
                "Student Absence Explanation Letter (ශිෂ්‍ය නොපැමිණීම පිළිබඳ හේතු දැක්වීම)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Parent letter explaining student absence due to sickness or family event.",
                "[Date]\n\n" +
                "To: The Class Teacher / Principal,\nGrade [Grade/Class],\n[School Name].\n\n" +
                "Subject: Explanation of Student Absence - [Student Name]\n\n" +
                "Respected Teacher / Principal,\n\n" +
                "Please accept this letter as explanation for the absence of my son/daughter, [Student Name] (Admission No: [Admission No]), from [Start Date] to [End Date] ([Number of Days] days).\n\n" +
                "Reason for absence: [Reason, e.g., High fever & flu / Family bereavement / Domestic reason].\n\n" +
                "Medical certificate / Supporting document is attached herewith. Kindly excuse my child's absence and permit them to attend classes.\n\n" +
                "Thanking you,\n\n" +
                "______________________\n" +
                "[Parent/Guardian Name]\n" +
                "Contact: [Phone No]"
        ));

        list.add(new LetterTemplate(
                "s_12",
                "Parent Notice for Prolonged Absence (දීර්ඝ නොපැමිණීම පිළිබඳ දෙමාපිය දැනුම්දීම)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "School notice issued to parents regarding 10+ days unexcused absence.",
                "OFFICIAL NOTICE FROM [SCHOOL NAME]\n\n" +
                "Date: [Date]\n\n" +
                "To: Parent / Guardian of [Student Name],\nGrade: [Grade/Class], Admission No: [Admission No].\n\n" +
                "Subject: Urgent Notice Regarding Continuous Unexcused Absence\n\n" +
                "Dear Parent,\n\n" +
                "Our class attendance records indicate that your child, [Student Name], has been continuously absent from school since [Absence Start Date] without prior written permission.\n\n" +
                "You are urgently requested to meet the Principal / Sectional Head on [Meeting Date] at [Meeting Time] along with a valid explanation. Failure to respond within 5 working days may result in removal from the active school register.\n\n" +
                "______________________\n" +
                "[Principal / Sectional Head Name]\n" +
                "[School Name]"
        ));

        list.add(new LetterTemplate(
                "s_13",
                "Medical Certificate Submission for Exam (විභාග සඳහා වෛද්‍ය සහතික ඉදිරිපත් කිරීම)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Parent letter submitting medical note for missing term test exams.",
                "[Date]\n\n" +
                "To: The Principal / Section Head,\n[School Name].\n\n" +
                "Subject: Medical Certificate Submission for Absence During Term Test\n\n" +
                "Respected Sir,\n\n" +
                "My child [Student Name], Grade [Grade], was unable to sit for the [Term Name, e.g., 2nd Term] Examination papers on [Exam Dates] due to [Medical Condition].\n\n" +
                "I submit the Government Medical Certificate. I request that my child be allowed to sit for re-examination / be graded on average.\n\n" +
                "______________________\n" +
                "[Parent Name]"
        ));

        list.add(new LetterTemplate(
                "s_14",
                "Student Sick Leave Exemption Request (ශාරීරික සුවතා නිදහස් කිරීමේ ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Request exemption from Physical Education (PT) due to medical condition.",
                "[Date]\n\n" +
                "To: The Principal / PT Master,\n[School Name].\n\n" +
                "Subject: Request Exemption from Physical Education Practical Sessions\n\n" +
                "Respected Sir,\n\n" +
                "My child [Student Name], Grade [Grade], suffers from [Asthma / Heart Condition / Joint Condition]. As medical specialist advice, they must avoid strenuous physical exertion.\n\n" +
                "Kindly exempt my child from physical education drills. Medical report attached.\n\n" +
                "______________________\n" +
                "[Parent Name]"
        ));

        list.add(new LetterTemplate(
                "s_15",
                "Sports Duty Absence Exemption (ක්‍රීඩා තරඟ සඳහා නොපැමිණීම නිදහස් කිරීම)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Excusing student absence due to national/zonal sports competition.",
                "[Date]\n\n" +
                "To: Section Head / Class Teacher,\n[School Name].\n\n" +
                "Subject: Exemption of Absence for School Sports Team Representation\n\n" +
                "Please excuse the absence of [Student Name], Grade [Grade], from [Start Date] to [End Date] as they represented the school team in the [Zonal Athletics / All-Island Football Championship].\n\n" +
                "______________________\n" +
                "[Teacher-in-Charge of Sports]"
        ));

        list.add(new LetterTemplate(
                "s_16",
                "Special Needs Accommodations Request (විශේෂ අවශ්‍යතා සහිත ශිෂ්‍ය පහසුකම්)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Request special exam accommodations (extra time / scribe) for disabled student.",
                "[Date]\n\n" +
                "To: The Principal / Exam Controller,\n[School Name].\n\n" +
                "Subject: Application for Special Examination Accommodations for [Student Name]\n\n" +
                "Respected Principal,\n\n" +
                "My child [Student Name], Grade [Grade], has special needs / visual impairment / physical disability.\n\n" +
                "I request approval for 30 minutes extra exam time / scribe assistance during term tests per Ministry Guidelines.\n\n" +
                "______________________\n" +
                "[Parent Name]"
        ));

        list.add(new LetterTemplate(
                "s_17",
                "Suspension Notice to Parents (තාවකාලික පන්ති තහනම් කිරීමේ නිවේදනය)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Formal disciplinary notice informing parent of temporary suspension.",
                "CONFIDENTIAL DISCIPLINARY NOTICE\n\n" +
                "Date: [Date]\n\n" +
                "To: Parent of [Student Name], Grade [Grade].\n\n" +
                "Subject: Notice of Temporary Suspension Following Disciplinary Inquiry\n\n" +
                "Dear Parent,\n\n" +
                "Following the Disciplinary Committee hearing on [Inquiry Date] regarding serious misconduct ([Misconduct Reason]), your child has been placed on temporary suspension for [Number of Days] days from [Start Date] to [End Date].\n\n" +
                "You are requested to accompany your child for a counseling review on [Return Date] at [Time].\n\n" +
                "______________________\n" +
                "[Principal Name]\n" +
                "[School Name]"
        ));

        list.add(new LetterTemplate(
                "s_18",
                "Habitual Latecomers Notice (ප්‍රමාදවී පැමිණීම පිළිබඳ දෙමාපිය දැනුම්දීම)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Notice sent to parents regarding habitual late arrival to school.",
                "Date: [Date]\n\n" +
                "To: Parent / Guardian of [Student Name], Grade [Grade].\n\n" +
                "Subject: Notice Regarding Habitual Late Arrival to School\n\n" +
                "Dear Parent,\n\n" +
                "Our gate prefect records show that your child [Student Name] arrived late to school on [Count] occasions during the month of [Month].\n\n" +
                "School sessions commence punctually at 7:30 AM. Kindly ensure your child arrives before 7:25 AM.\n\n" +
                "______________________\n" +
                "[Disciplinary Master / Principal]"
        ));

        list.add(new LetterTemplate(
                "s_19",
                "Disciplinary Board Call Notice (විනය මණ්ඩලය හමුවීමේ කැඳවීම් පත)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Summons letter requesting parent attendance at school disciplinary board.",
                "Date: [Date]\n\n" +
                "To: Parent / Guardian of [Student Name], Grade [Grade].\n\n" +
                "Subject: Urgent Call to Attend Disciplinary Committee Meeting\n\n" +
                "Dear Parent,\n\n" +
                "You are hereby requested to present yourself along with your child [Student Name] before the School Disciplinary Board on [Date] at [Time] in the Principal's Office regarding [Incident Summary].\n\n" +
                "______________________\n" +
                "[Principal / Discipline Head]"
        ));

        list.add(new LetterTemplate(
                "s_20",
                "Absence During Term Tests Notice (වාර විභාග නොපැමිණීමේ නිවේදනය)",
                CAT_ADMIN_STUDENT, "Student Absence & Medical",
                "Notice to parents regarding unexcused absence during term exams.",
                "Date: [Date]\n\n" +
                "To: Parent of [Student Name], Grade [Grade].\n\n" +
                "Subject: Failure to Attend Term Test Examination\n\n" +
                "Your child was absent for the term exam papers on [Dates]. Medical proof or valid explanation must be submitted by [Deadline Date] to avoid non-grading.\n\n" +
                "______________________\n" +
                "[Sectional Head]"
        ));

        // 3. Parent & Community Notices
        list.add(new LetterTemplate(
                "s_21",
                "PTA General Meeting Notice (ගුරු දෙමාපිය සංගම් මහා සභා රැස්වීම)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Invitation notice to parents for Parent-Teacher Association AGM.",
                "PARENT-TEACHER ASSOCIATION (PTA)\n[SCHOOL NAME]\n\n" +
                "Date: [Date]\n\n" +
                "To: All Parents, Guardians, and Teachers.\n\n" +
                "Subject: Notice of Annual General Meeting (AGM) of Parent-Teacher Association\n\n" +
                "Dear Parents/Guardians,\n\n" +
                "Notice is hereby given that the Annual General Meeting of the Parent-Teacher Association of [School Name] will be held as follows:\n\n" +
                "Date: [Meeting Date]\n" +
                "Time: [Meeting Time]\n" +
                "Venue: [School Main Hall / Auditorium]\n" +
                "Agenda:\n" +
                "1. Reading and confirmation of previous AGM minutes\n" +
                "2. Presentation of Annual Progress & Financial Audit Report\n" +
                "3. Election of Executive Committee Members for [Academic Year]\n" +
                "4. Discussion on School Infrastructure & Academic Enhancement Projects\n\n" +
                "Your attendance is vital for the development of our school and students.\n\n" +
                "Yours sincerely,\n\n" +
                "______________________              ______________________\n" +
                "[Hony. Secretary PTA]               [Principal / President PTA]"
        ));

        list.add(new LetterTemplate(
                "s_22",
                "Special Disciplinary Meeting Call Notice (විශේෂ දෙමාපිය හමුව)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Notice inviting parents to address grade-wide discipline issues.",
                "Date: [Date]\n\n" +
                "To: All Parents of Grade [Grade/Class] Students.\n\n" +
                "Subject: Special Parent Meeting Regarding Academic Progress & Discipline\n\n" +
                "Dear Parents,\n\n" +
                "A special parent meeting for Grade [Grade] has been organized on [Meeting Date] at [Time] in [Hall/Classroom].\n\n" +
                "We will discuss student attendance, mobile phone policies, and term test performance.\n\n" +
                "______________________\n" +
                "[Principal / Grade Coordinator]"
        ));

        list.add(new LetterTemplate(
                "s_23",
                "Academic Progress Discussion Notice (වාර විභාග ලකුණු සාකච්ඡාව)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Invitation to collect student term report card.",
                "Date: [Date]\n\n" +
                "To: Parent of [Student Name], Grade [Grade].\n\n" +
                "Subject: Parent-Teacher Meeting for Term Report Card Distribution\n\n" +
                "Dear Parent,\n\n" +
                "You are invited to meet the Class Teacher on [Date] between [Start Time] and [End Time] to review your child's [Term Name] Progress Report Card.\n\n" +
                "______________________\n" +
                "[Class Teacher Name]"
        ));

        list.add(new LetterTemplate(
                "s_24",
                "Grade 6 Admissions Parent Briefing Notice (6 ශ්‍රේණිය ඇතුළත් කිරීමේ දෙමාපිය දැනුවත් කිරීම)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Orientation meeting invitation for newly admitted Grade 6 parents.",
                "Date: [Date]\n\n" +
                "To: Parents of Newly Admitted Grade 6 Students ([Year]).\n\n" +
                "Subject: Orientation Meeting & Uniform/Textbook Issuing\n\n" +
                "We warmly welcome you to [School Name]. The Grade 6 Orientation Meeting will take place on [Date] at 8:30 AM in the School Auditorium.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_25",
                "School Development Committee Meeting Call (පාසල් සංවර්ධන සමිති රැස්වීම)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Call notice for School Development Society (SDS) committee.",
                "Date: [Date]\n\n" +
                "To: Members of School Development Committee (SDC/SDS).\n\n" +
                "Subject: Monthly School Development Committee Meeting Notice\n\n" +
                "Meeting Date: [Date] at [Time] in the Boardroom. Agenda includes building maintenance, IT lab project, and sports budget.\n\n" +
                "______________________\n" +
                "[Secretary SDS]"
        ));

        list.add(new LetterTemplate(
                "s_26",
                "Prefect Board Installation Parent Invitation (ශිෂ්‍ය නායක නිල ලාංඡන පැළඳවීම)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Invitation to parents for Senior Prefects Badge Investiture Ceremony.",
                "Date: [Date]\n\n" +
                "To: Parents of Appointed Student Prefect [Student Name].\n\n" +
                "Subject: Invitation to Annual Prefect Investiture Ceremony\n\n" +
                "We take pride in informing you that your child has been selected to the Senior Prefects Board [Year]. You are cordially invited to witness the Badge Investiture on [Date] at 9:00 AM.\n\n" +
                "______________________\n" +
                "[Principal / Prefects Guild Master]"
        ));

        list.add(new LetterTemplate(
                "s_27",
                "Career Guidance Seminar Parent Notice (වෘත්තීය මාර්ගෝපදේශන සම්මන්ත්‍රණය)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Notice inviting O/L and A/L parents to career guidance seminar.",
                "Date: [Date]\n\n" +
                "To: Parents of Grade 11, 12, and 13 Students.\n\n" +
                "Subject: Career Guidance & University Pathways Seminar\n\n" +
                "A career counseling seminar conducted by experts will be held on [Date] at [Time] in the Auditorium. All parents and students are urged to attend.\n\n" +
                "______________________\n" +
                "[Career Guidance Officer]"
        ));

        list.add(new LetterTemplate(
                "s_28",
                "Educational Tour Permission Form & Notice (අධ්‍යාපනික චාරිකා අවසර පත්‍රය)",
                CAT_ADMIN_STUDENT, "Parent & Community Notices",
                "Parent consent form and notice for school educational field trip.",
                "Date: [Date]\n\n" +
                "To: Parent / Guardian of [Student Name], Grade [Grade].\n\n" +
                "Subject: Permission Form for Annual Educational Field Trip\n\n" +
                "An educational field trip to [Destination Name] has been arranged on [Tour Date]. Departure: [Time], Return: [Time]. Tour Fee: LKR [Amount].\n\n" +
                "PARENT CONSENT:\n" +
                "I hereby grant permission for my child [Student Name] to participate in the trip under school teacher supervision.\n\n" +
                "Parent Signature: ______________________ Date: _____________"
        ));

        // 4. Zonal & Provincial Education Office
        list.add(new LetterTemplate(
                "s_29",
                "Requisition for Teacher Vacancy Filling (ගුරු පුරප්පාඩු පිරවීමේ ඉල්ලුම්පත)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Principal's requisition to Zonal Director for subject teacher allocation.",
                "OFFICIAL LETTERHEAD OF [SCHOOL NAME]\n\n" +
                "Date: [Date]\n" +
                "Our Ref: [Ref No]\n\n" +
                "To: Zonal Education Director,\n[Zonal Education Office].\n\n" +
                "Subject: Urgent Requisition to Fill Teacher Vacancies for [Subject Name]\n\n" +
                "Respected Sir,\n\n" +
                "I bring to your urgent attention that there are critical teacher vacancies at our school in the following subjects:\n\n" +
                "1. Subject: [Subject 01], Grade [Grades], Required Cadre: [Count]\n" +
                "2. Subject: [Subject 02], Grade [Grades], Required Cadre: [Count]\n\n" +
                "Due to the upcoming Term Test / National Exams, students' academic progress is severely hampered. I request you to allocate trained teachers or temporary attachments immediately.\n\n" +
                "______________________\n" +
                "[Principal Name]\n" +
                "[School Name]"
        ));

        list.add(new LetterTemplate(
                "s_30",
                "Request for Classroom Furniture & Infrastructure (පන්ති කාමර මේස පුටු ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Requisition for desks, chairs, and blackboards.",
                "[Date]\n\n" +
                "To: Zonal Director of Education / Works Branch.\n\n" +
                "Subject: Requisition for Student Desks and Chairs\n\n" +
                "With the increase in student enrollment in Grade [Grade], we require an additional allocation of [Count] student desks and [Count] chairs.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_31",
                "Request for Science Lab Equipment (විද්‍යාගාර උපකරණ ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Request for laboratory chemicals, microscopes, and equipment.",
                "[Date]\n\n" +
                "To: Provincial Science Director / Zonal Office.\n\n" +
                "Subject: Requisition for G.C.E. O/L and A/L Science Laboratory Chemicals & Instruments\n\n" +
                "Attached is the annual lab inventory requisition list for Physics, Chemistry, and Biology practical examinations.\n\n" +
                "______________________\n" +
                "[Principal / Head of Science]"
        ));

        list.add(new LetterTemplate(
                "s_32",
                "School Cadre Revision Request (පාසල් ගුරු සංඛ්‍යා ලේඛන සංශෝධනය)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Request to revise school approved teacher cadre count.",
                "[Date]\n\n" +
                "To: Zonal Education Director.\n\n" +
                "Subject: Request for Revision of School Teacher Cadre based on Student Census [Year]\n\n" +
                "Current Student Enrollment: [Total Students]. Based on Ministry Cadre Formula, our school qualifies for an additional [Count] teachers.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_33",
                "Request for Free Textbooks & Uniform Vouchers (පෙළපොත් හා නිලඇඳුම් වවුචර් ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Requisition for annual Ministry free textbook deficit.",
                "[Date]\n\n" +
                "To: Zonal Educational Publications In-Charge.\n\n" +
                "Subject: Requisition for Shortage of School Textbooks and Uniform Material Vouchers\n\n" +
                "We report a deficit of [Count] copies of Grade [Grade] [Subject] textbooks. Requisition summary attached.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_34",
                "Request for Building Renovation Funds (ගොඩනැගිලි ප්‍රතිසංස්කරණ ප්‍රතිපාදන)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Request emergency funding for roof repair / building renovation.",
                "[Date]\n\n" +
                "To: Provincial Education Building Engineer / Zonal Director.\n\n" +
                "Subject: Emergency Request for Funds for Roof & Building Renovation\n\n" +
                "Due to heavy rain damage, the roof of Primary Building Block [Block Name] requires urgent repairs. Photos and engineer estimate attached.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_35",
                "Annual School Census Submission Cover Letter (වාර්ෂික පාසල් සංගණන වාර්තාව)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Covering letter for submitting annual Ministry school statistics census.",
                "[Date]\n\n" +
                "To: Statistics Division, Zonal Education Office.\n\n" +
                "Subject: Submission of Annual School Census Returns - [Year]\n\n" +
                "Enclosed please find the duly verified Annual School Census Returns for [School Name] for the academic year [Year].\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_36",
                "Request for Zonal Athletics Competition Approval (කලාපීය ක්‍රීඩා උළෙල සඳහා ලියාපදිංචිය)",
                CAT_ADMIN_STUDENT, "Zonal & Provincial Office",
                "Registration of school athletes for zonal sports meet.",
                "[Date]\n\n" +
                "To: Zonal Sports Director.\n\n" +
                "Subject: Submission of School Athletes Registration for Zonal Meet [Year]\n\n" +
                "We submit the list of [Count] qualified student athletes representing [School Name] in Under 16, Under 18, and Under 20 track and field events.\n\n" +
                "______________________\n" +
                "[Principal / Sports Master]"
        ));

        // 5. Event Invitations & Ceremonies
        list.add(new LetterTemplate(
                "s_37",
                "Chief Guest Invitation for Annual Prize Giving (තෑගි ප්‍රදානෝත්සවයේ ප්‍රධාන අමුත්තා ආරාධනාව)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Official invitation to distinguished personality to grace Prize Giving.",
                "OFFICIAL INVITATION FROM [SCHOOL NAME]\n\n" +
                "Date: [Date]\n\n" +
                "To: [Guest Name],\n[Guest Designation / Address].\n\n" +
                "Subject: Invitation as Chief Guest for Annual Prize Giving Ceremony [Year]\n\n" +
                "Respected Sir/Madam,\n\n" +
                "On behalf of the staff, students, and Parent-Teacher Association of [School Name], it is our privilege to invite you to grace our Annual Prize Giving Ceremony as Chief Guest.\n\n" +
                "Date: [Event Date]\n" +
                "Time: [Event Time]\n" +
                "Venue: [School Auditorium / Main Hall]\n\n" +
                "Your presence will greatly inspire our prize-winning students. We look forward to your gracious acceptance.\n\n" +
                "Thanking you,\n\n" +
                "Yours faithfully,\n\n" +
                "______________________\n" +
                "[Principal Name]\n" +
                "[School Name]"
        ));

        list.add(new LetterTemplate(
                "s_38",
                "Sports Meet Chief Guest Invitation (නිවාසාන්තර ක්‍රීඩා උළෙල ආරාධනය)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Invitation letter for Chief Guest at Inter-House Sports Meet.",
                "[Date]\n\n" +
                "To: [Chief Guest Name].\n\n" +
                "Subject: Invitation as Chief Guest for Annual Inter-House Sports Meet [Year]\n\n" +
                "We cordially invite you to preside over our Inter-House Sports Meet on [Date] at [Time] at the School Grounds.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_39",
                "Guest Speaker Invitation for Educational Workshop (ආරාධිත දේශක හමුව)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Invitation to guest lecturer for student workshop.",
                "[Date]\n\n" +
                "To: [Guest Lecturer Name].\n\n" +
                "Subject: Invitation as Guest Speaker for Student Leadership Seminar\n\n" +
                "We request the honor of your presence to deliver a keynote address on '[Lecture Topic]' to our G.C.E. A/L students on [Date] at [Time].\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_40",
                "Inter-School Quiz Competition Invitation (අන්තර් පාසල් දැනුම මිනුම තරඟය)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Invitation to neighboring schools for quiz competition.",
                "[Date]\n\n" +
                "To: The Principal, [Neighboring School Name].\n\n" +
                "Subject: Invitation to Participate in Inter-School General Knowledge Quiz\n\n" +
                "We invite a team of 4 students from your esteemed school to participate in the All-Island Inter-School Quiz Championship held on [Date] at 9:00 AM.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_41",
                "Colours Night Invitation to Past Pupils (වර්ණ රාත්‍රිය සඳහා ආරාධනාව)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Invitation for annual Sports Colours Night award ceremony.",
                "[Date]\n\n" +
                "To: Past Pupils & Well-wishers.\n\n" +
                "Subject: Invitation to Annual Sports Colours Night [Year]\n\n" +
                "Join us in celebrating our outstanding national student athletes on [Date] at [Time] at [Hotel / Auditorium Name].\n\n" +
                "______________________\n" +
                "[Principal / Sports Council]"
        ));

        list.add(new LetterTemplate(
                "s_42",
                "Teachers' Day Celebration Invitation (ගුරු දින සැමරුම ආරාධනාව)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Invitation to retired teachers for Teachers' Day event.",
                "[Date]\n\n" +
                "To: Retired Teachers & Distinguished Guests.\n\n" +
                "Subject: Invitation to International Teachers' Day Felicitation Ceremony\n\n" +
                "We warmly invite you to the Teachers' Day Felicitation Assembly on [Date] at 8:30 AM in the School Main Hall.\n\n" +
                "______________________\n" +
                "[Prefects Guild / Student Union]"
        ));

        list.add(new LetterTemplate(
                "s_43",
                "Annual Science Exhibition Invitation (වාර්ෂික විද්‍යා ප්‍රදර්ශනය ආරාධනාව)",
                CAT_ADMIN_STUDENT, "Event Invitations",
                "Invitation to public and schools for Annual Science & Technology Exhibition.",
                "[Date]\n\n" +
                "To: Principals, Parents, and Well-Wishers.\n\n" +
                "Subject: Invitation to Annual Science & Innovation Exhibition [Year]\n\n" +
                "Our school Science Society presents '[Exhibition Name]' featuring 100+ student STEM innovations on [Dates] from 8:00 AM to 4:00 PM.\n\n" +
                "______________________\n" +
                "[Principal / Science Master]"
        ));

        // 6. Sponsor & Donors
        list.add(new LetterTemplate(
                "s_44",
                "Sponsorship Request for School Sports Team (ක්‍රීඩා අනුග්‍රාහක ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "Proposal to corporate sponsor for school sports kits and equipment.",
                "OFFICIAL SPONSORSHIP PROPOSAL\n\n" +
                "Date: [Date]\n\n" +
                "To: The Managing Director / Marketing Manager,\n[Company / Bank Name].\n\n" +
                "Subject: Request for Official Sponsorship for School [Cricket/Football] Team\n\n" +
                "Dear Sir/Madam,\n\n" +
                "The sports teams of [School Name] have consistently achieved top rankings in Provincial and Island-wide championships.\n\n" +
                "We invite your esteemed organization to become our Official Sports Partner for the upcoming season [Year]. Your corporate brand logo will be prominently displayed on team jerseys, banners, and media releases.\n\n" +
                "Estimated Sponsorship Budget: LKR [Amount]. Sponsorship package details attached.\n\n" +
                "Thanking you,\n\n" +
                "______________________\n" +
                "[Principal Name]\n" +
                "[School Name]"
        ));

        list.add(new LetterTemplate(
                "s_45",
                "Donation Request for School Library Books (පාසල් පුස්තකාල පොත් පරිත්‍යාගය)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "Request to donors / publishers for library book donations.",
                "[Date]\n\n" +
                "To: [Donor / Foundation Name].\n\n" +
                "Subject: Request for Donation of Books for School Library Development\n\n" +
                "We request book donations (novels, encyclopedia, science journals) for our school library catering to 1,500 rural students.\n\n" +
                "______________________\n" +
                "[Principal / Librarian]"
        ));

        list.add(new LetterTemplate(
                "s_46",
                "Request for Computer Lab Equipment Donation (පරිගණක විද්‍යාගාර උපකරණ පරිත්‍යාගය)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "CSR proposal to corporate body for desktop computers & smart boards.",
                "[Date]\n\n" +
                "To: CSR Head, [Corporate Company Name].\n\n" +
                "Subject: Request for Donation of Desktop Computers for School IT Lab\n\n" +
                "To enhance digital literacy, we seek your generous CSR donation of 10-15 refurbished desktop computers or smart boards for our computer unit.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_47",
                "Band Equipment Sponsorship Request (ප පෙරහැර තූර්ය වාදක උපකරණ ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "Appeal for western/oriental musical band equipment.",
                "[Date]\n\n" +
                "To: Well-Wishers & Past Pupils.\n\n" +
                "Subject: Appeal for Sponsorship to Purchase School Band Instruments\n\n" +
                "We seek financial contributions to purchase brass band instruments for our newly formed Senior School Western Band.\n\n" +
                "______________________\n" +
                "[Principal / Band Master]"
        ));

        list.add(new LetterTemplate(
                "s_48",
                "Drinking Water Filter Donation Request (පිරිසිදු පානීය ජල පද්ධති ඉල්ලීම)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "CSR appeal for commercial drinking water purification system.",
                "[Date]\n\n" +
                "To: Rotary Club / Lions Club / CSR Director.\n\n" +
                "Subject: Project Proposal for Commercial Clean Drinking Water System\n\n" +
                "To safeguard our 1,000+ students from kidney ailments, we appeal for the installation of an industrial RO drinking water purification plant.\n\n" +
                "______________________\n" +
                "[Principal Name]"
        ));

        list.add(new LetterTemplate(
                "s_49",
                "School Ground Renovation Sponsorship (පාසල් ක්‍රීඩාංගණ සංවර්ධන අනුග්‍රහය)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "Sponsorship proposal for school turf & pavilion renovation.",
                "[Date]\n\n" +
                "To: Corporate Donors & Old Boys/Girls Association.\n\n" +
                "Subject: Sponsorship Appeal for School Sports Ground Pavilion Project\n\n" +
                "We invite sponsorship contributions for Phase II construction of the School Ground Seating Pavilion.\n\n" +
                "______________________\n" +
                "[Principal / SDS President]"
        ));

        list.add(new LetterTemplate(
                "s_50",
                "CSR Project Proposal to Bank/Corporate Body (සමාජ සත්කාරක ව්‍යාපෘති යෝජනාව)",
                CAT_ADMIN_STUDENT, "Sponsors & Donors",
                "Comprehensive CSR partnership proposal for smart classroom equipment.",
                "CSR PARTNERSHIP PROPOSAL\n\n" +
                "Date: [Date]\n\n" +
                "To: Corporate Social Responsibility Division,\n[Bank / Corporate Name].\n\n" +
                "Subject: Partnership Proposal for 'Smart Classroom' Digital Education Project\n\n" +
                "We present a impactful CSR partnership opportunity to equip 5 primary classrooms with interactive multimedia projectors and digital learning tools, impacting 500+ underprivileged children.\n\n" +
                "Duly audited budget and implementation timeline attached.\n\n" +
                "______________________\n" +
                "[Principal Name]\n" +
                "[School Name]"
        ));

        return list;
    }
}
