package com.aistudio.classroomhub.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class PinLockActivity extends AppCompatActivity {

    private EditText etPinInput;
    private View btnUnlock;
    private TextView btnForgotPin;
    private TextView tvPinSubtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_pin_lock);
        WindowInsetUtils.applySystemBarPadding(this);

        etPinInput = findViewById(R.id.etPinInput);
        btnUnlock = findViewById(R.id.btnUnlock);
        btnForgotPin = findViewById(R.id.btnForgotPin);
        tvPinSubtitle = findViewById(R.id.tvPinSubtitle);

        if (btnUnlock != null) {
            btnUnlock.setOnClickListener(v -> attemptUnlock());
        }

        if (btnForgotPin != null) {
            btnForgotPin.setOnClickListener(v -> showForgotPinDialog());
        }
    }

    private void attemptUnlock() {
        String pin = etPinInput.getText().toString().trim();
        if (pin.isEmpty()) {
            Toast.makeText(this, AppTranslation.get(this, "enter_pin"), Toast.LENGTH_SHORT).show();
            return;
        }

        if (AppSecurityManager.verifyPin(this, pin)) {
            AppSecurityManager.setPinUnlockedSession(this, true);
            Toast.makeText(this, AppTranslation.get(this, "pin_unlocked"), Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(PinLockActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, AppTranslation.get(this, "invalid_pin"), Toast.LENGTH_SHORT).show();
            etPinInput.setText("");
        }
    }

    private void showForgotPinDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_forgot_pin, null);
        RadioGroup rgMethod = view.findViewById(R.id.rgRecoveryMethod);
        RadioButton rbQuestion = view.findViewById(R.id.rbMethodQuestion);
        RadioButton rbEmail = view.findViewById(R.id.rbMethodEmail);

        LinearLayout llQuestion = view.findViewById(R.id.llContainerQuestion);
        LinearLayout llEmail = view.findViewById(R.id.llContainerEmail);

        TextView tvQuestion = view.findViewById(R.id.tvRecoveryQuestion);
        EditText etAnswer = view.findViewById(R.id.etSecurityAnswer);

        TextView tvRegisteredEmail = view.findViewById(R.id.tvRegisteredEmail);
        View btnSendOtp = view.findViewById(R.id.btnSendOtp);
        EditText etOtp = view.findViewById(R.id.etOtpInput);

        EditText etNewPin = view.findViewById(R.id.etNewPinInput);

        // Populate details
        if (tvQuestion != null) {
            tvQuestion.setText(AppTranslation.get(this, "security_question") + ": " + AppSecurityManager.getSecurityQuestion(this));
        }

        // Auto-detect currently signed in Firebase/Google user email
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        String detectedEmail = "";
        if (currentUser != null && currentUser.getEmail() != null && !currentUser.getEmail().trim().isEmpty()) {
            detectedEmail = currentUser.getEmail().trim();
        } else {
            SharedPreferences userPrefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
            detectedEmail = userPrefs.getString(LoginActivity.KEY_USER_EMAIL, "").trim();
        }
        if (detectedEmail.isEmpty()) {
            SharedPreferences schoolPrefs = getSharedPreferences("school_header_prefs", MODE_PRIVATE);
            detectedEmail = schoolPrefs.getString("user_email", "").trim();
        }

        final String userEmail = detectedEmail;
        if (tvRegisteredEmail != null) {
            if (!userEmail.isEmpty()) {
                tvRegisteredEmail.setText("Email: " + userEmail);
            } else {
                tvRegisteredEmail.setText("Email: ගිණුමේ විද්‍යුත් තැපෑල (Account Email)");
            }
        }

        if (rgMethod != null) {
            rgMethod.setOnCheckedChangeListener((group, checkedId) -> {
                if (checkedId == R.id.rbMethodQuestion) {
                    llQuestion.setVisibility(View.VISIBLE);
                    llEmail.setVisibility(View.GONE);
                } else {
                    llQuestion.setVisibility(View.GONE);
                    llEmail.setVisibility(View.VISIBLE);
                }
            });
        }

        if (btnSendOtp != null) {
            btnSendOtp.setOnClickListener(v -> {
                if (userEmail.isEmpty()) {
                    Toast.makeText(this, "විද්‍යුත් තැපැල් ලිපිනය හමු නොවීය. (No registered email found)", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Generate 6-digit OTP code (stored securely in AppSecurityPrefs)
                String generatedOtp = AppSecurityManager.generateRecoveryOtp(this);

                Toast.makeText(this, "OTP කේතය " + userEmail + " වෙත යවමින්... (Sending OTP to email...)", Toast.LENGTH_SHORT).show();

                // 1. Dispatch Firebase Auth email verification / password reset link
                try {
                    FirebaseAuth.getInstance().sendPasswordResetEmail(userEmail)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Log.d("PinLockActivity", "Firebase password reset email dispatched to " + userEmail);
                                } else {
                                    Log.w("PinLockActivity", "Firebase password reset email failed", task.getException());
                                }
                            });
                } catch (Exception e) {
                    Log.e("PinLockActivity", "Error calling sendPasswordResetEmail", e);
                }

                // 2. Dispatch real OTP payload to Firestore 'otp_dispatches' and 'mail' collections
                try {
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    Map<String, Object> mailData = new HashMap<>();
                    mailData.put("to", userEmail);
                    mailData.put("otpCode", generatedOtp);
                    mailData.put("subject", "Classroom Hub Security PIN Recovery OTP Code");

                    Map<String, Object> messageMap = new HashMap<>();
                    messageMap.put("subject", "Classroom Hub Security PIN Recovery OTP Code");
                    messageMap.put("text", "Your Classroom Hub security PIN recovery OTP code is: " + generatedOtp + ". Enter this code in the app to reset your PIN.");
                    mailData.put("message", messageMap);

                    mailData.put("timestamp", System.currentTimeMillis());
                    mailData.put("expiresAt", System.currentTimeMillis() + (10 * 60 * 1000));

                    db.collection("otp_dispatches").document(userEmail).set(mailData);
                    db.collection("mail").add(mailData);
                } catch (Exception e) {
                    Log.e("PinLockActivity", "Error writing OTP dispatch to Firestore", e);
                }

                Toast.makeText(this, "✅ OTP කේතය " + userEmail + " වෙත යවන ලදී. ඔබගේ Email Inbox / Spam පරීක්ෂා කරන්න.", Toast.LENGTH_LONG).show();
            });
        }

        new AlertDialog.Builder(this)
                .setView(view)
                .setPositiveButton(AppTranslation.get(this, "save"), (dialog, which) -> {
                    String newPin = etNewPin != null ? etNewPin.getText().toString().trim() : "";
                    if (newPin.isEmpty() || newPin.length() < 4) {
                        Toast.makeText(this, AppTranslation.get(this, "enter_pin"), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean isQuestionSelected = rbQuestion != null && rbQuestion.isChecked();
                    if (isQuestionSelected) {
                        String ans = etAnswer != null ? etAnswer.getText().toString().trim() : "";
                        if (AppSecurityManager.verifySecurityAnswer(this, ans)) {
                            AppSecurityManager.setPinCode(this, newPin);
                            AppSecurityManager.setPinUnlockedSession(this, true);
                            Toast.makeText(this, AppTranslation.get(this, "pin_unlocked"), Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(PinLockActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, AppTranslation.get(this, "invalid_pin"), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        String inputOtp = etOtp != null ? etOtp.getText().toString().trim() : "";
                        if (AppSecurityManager.verifyRecoveryOtp(this, inputOtp)) {
                            AppSecurityManager.setPinCode(this, newPin);
                            AppSecurityManager.setPinUnlockedSession(this, true);
                            Toast.makeText(this, AppTranslation.get(this, "pin_unlocked"), Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(PinLockActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, AppTranslation.get(this, "invalid_pin"), Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton(AppTranslation.get(this, "cancel"), null)
                .show();
    }

    @Override
    public void onBackPressed() {
        // Prevent bypassing PIN lock
        finishAffinity();
    }
}
