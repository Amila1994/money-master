package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class StudentRepository {
    private static final List<Student> students = new ArrayList<>();
    // Date string (YYYY-MM-DD) -> Map<Student ID, AttendanceRecord>
    private static final Map<String, Map<String, AttendanceRecord>> attendanceRecords = new HashMap<>();

    static {
        initDefaultSampleData();
    }

    private static void initDefaultSampleData() {
        // Production mode: Start with a clean empty database. Real students are added by the user.
    }

    public static List<Student> getStudents() {
        ClassModel active = ClassRepository.getActiveClass();
        String activeClassId = active != null ? active.getId() : "class_10a_2026";
        return getStudentsForClass(activeClassId);
    }

    public static List<Student> getStudentsForClass(String classId) {
        List<Student> result = new ArrayList<>();
        for (Student s : students) {
            if (s.getClassId().equals(classId)) {
                result.add(s);
            }
        }
        return result;
    }

    public static List<Student> getAllStudents() {
        return students;
    }

    public static Student getStudentById(String id) {
        for (Student s : students) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    public static void addStudent(Student student) {
        if (student == null || student.getId() == null) return;
        if (student.getClassId() == null || student.getClassId().isEmpty()) {
            ClassModel active = ClassRepository.getActiveClass();
            if (active != null) {
                student.setClassId(active.getId());
                student.setGrade(active.getClassName());
            }
        }
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getId().equals(student.getId())) {
                students.set(i, student);
                return;
            }
        }
        students.add(0, student);
    }

    public static void addStudent(android.content.Context context, Student student) {
        addStudent(student);
        if (context != null) {
            DataBackupManager.saveLocalState(context);
        }
    }

    public static void updateStudent(Student student) {
        addStudent(student);
    }

    public static void updateStudent(android.content.Context context, Student student) {
        addStudent(context, student);
    }

    public static String getNextRegistrationNumber(String gradeOrClassId) {
        int maxNum = 0;
        if (gradeOrClassId != null) {
            for (Student s : students) {
                if (s == null) continue;
                boolean matches = (s.getGrade() != null && s.getGrade().equalsIgnoreCase(gradeOrClassId)) ||
                                 (s.getClassId() != null && s.getClassId().equalsIgnoreCase(gradeOrClassId));
                if (matches) {
                    String roll = s.getRollNo();
                    if (roll != null) {
                        String digits = roll.replaceAll("[^0-9]", "");
                        if (!digits.isEmpty()) {
                            try {
                                int num = Integer.parseInt(digits);
                                if (num > maxNum) maxNum = num;
                            } catch (NumberFormatException ignored) {}
                        }
                    }
                }
            }
        }
        return String.valueOf(maxNum + 1);
    }

    public static void removeStudent(Student student) {
        if (student != null) {
            students.remove(student);
        }
    }

    public static void removeStudent(android.content.Context context, Student student) {
        if (student != null) {
            students.remove(student);
            if (context != null) {
                DataBackupManager.deleteStudentFromCloud(context, student.getId());
                DataBackupManager.saveLocalState(context);
            }
        }
    }

    public static void clear() {
        students.clear();
        attendanceRecords.clear();
    }

    public static Map<String, Map<String, AttendanceRecord>> getAttendanceRecords() {
        return attendanceRecords;
    }

    public static Map<String, AttendanceRecord> getAttendanceForDate(String dateStr) {
        if (!attendanceRecords.containsKey(dateStr)) {
            attendanceRecords.put(dateStr, new HashMap<>());
        }
        return attendanceRecords.get(dateStr);
    }

    public static void setAttendance(String dateStr, String studentId, boolean isPresent) {
        Map<String, AttendanceRecord> dayMap = getAttendanceForDate(dateStr);
        AttendanceRecord existing = dayMap.get(studentId);
        long timestamp = existing != null ? existing.getMarkedAtMillis() : System.currentTimeMillis();
        dayMap.put(studentId, new AttendanceRecord(isPresent, timestamp));
    }

    public static void setAttendance(android.content.Context context, String dateStr, String studentId, boolean isPresent) {
        setAttendance(dateStr, studentId, isPresent);
        if (context != null) {
            DataBackupManager.saveLocalState(context);
        }
    }
}
