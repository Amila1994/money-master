package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.SetOptions;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TextView tvMyUidHeader;
    private MaterialButton btnCopyMyUid;

    private EditText etReceiverUid;
    private MaterialButton btnSearchSchool;

    private LinearLayout layoutRecentChatsContainer;
    private RecyclerView rvRecentChats;

    private MaterialCardView cardTargetSchoolInfo;
    private TextView tvTargetSchoolHeader;
    private TextView tvTargetSchoolName;
    private TextView tvTargetSchoolAddress;

    private TextView tvEmptyChatState;
    private RecyclerView rvChatMessages;
    private MaterialButton btnAttachMedia;
    private EditText etMessageInput;
    private MaterialButton btnSendMessage;

    private LinearLayout layoutSearchResultsContainer;
    private RecyclerView rvSearchResults;
    private MaterialCardView cardSearchEmptyState;
    private TextView tvSearchEmptyState;

    private UserSearchResultAdapter searchResultAdapter;
    private final List<Map<String, Object>> searchResultsList = new ArrayList<>();

    private ChatMessageAdapter chatAdapter;
    private final List<ChatMessage> messageList = new ArrayList<>();

    private RecentChatAdapter recentAdapter;
    private final List<Map<String, Object>> recentChatList = new ArrayList<>();

    private String currentUid = "";
    private String currentCustomUid = "";
    private String mySchoolName = "";
    private String selectedReceiverUid = "";
    private String selectedReceiverSchoolName = "";
    private String currentChatId = "";

    private FirebaseFirestore db;
    private ListenerRegistration chatListener;
    private ListenerRegistration recentListener;

    private ActivityResultLauncher<Intent> filePickerLauncher;

    private boolean isInitialMessageLoad = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        initFirebase();
        setupFilePicker();
        initViews();
        setupListeners();
        
        loadRecentChats();
    }

    private void enforceStudentTeacherRestriction() {
        SharedPreferences schoolPrefs = getSharedPreferences("school_header_prefs", MODE_PRIVATE);
        String assignedTeacherUid = schoolPrefs.getString("assigned_teacher_uid", "");
        String assignedTeacherName = schoolPrefs.getString("assigned_teacher_name", "පන්ති භාර ගුරුතුමා");

        if (assignedTeacherUid.isEmpty()) {
            Toast.makeText(this, "පන්ති භාර ගුරුතුමාගේ UID සකසා නොමැත.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (etReceiverUid != null) {
            etReceiverUid.setText(assignedTeacherUid);
            etReceiverUid.setEnabled(false);
            etReceiverUid.setFocusable(false);
        }
        if (btnSearchSchool != null) {
            btnSearchSchool.setEnabled(false);
            btnSearchSchool.setText("ගුරුතුමා");
        }

        Toast.makeText(this, "ශිෂ්‍ය ගිණුම: ඔබගේ පන්ති භාර ගුරුතුමා සමඟ පමණක් සම්බන්ධ වී ඇත.", Toast.LENGTH_SHORT).show();
        searchAndConnectToUid(assignedTeacherUid);
    }

    private void initFirebase() {
        db = FirebaseFirestore.getInstance();
        currentUid = UserRoleManager.getPermanentUid(this);

        currentCustomUid = UserRoleManager.getCustomUid(this);
        if (currentCustomUid.isEmpty()) {
            currentCustomUid = currentUid.length() > 8 ? currentUid.substring(0, 8) : currentUid;
        }

        SharedPreferences prefs = getSharedPreferences("school_header_prefs", MODE_PRIVATE);
        mySchoolName = prefs.getString("school_name", "School/Classroom");
    }

    private void setupFilePicker() {
        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                        Uri selectedUri = result.getData().getData();
                        handleAttachmentSelected(selectedUri);
                    }
                });
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvMyUidHeader = findViewById(R.id.tvMyUidHeader);
        btnCopyMyUid = findViewById(R.id.btnCopyMyUid);

        etReceiverUid = findViewById(R.id.etReceiverUid);
        btnSearchSchool = findViewById(R.id.btnSearchSchool);

        layoutRecentChatsContainer = findViewById(R.id.layoutRecentChatsContainer);
        rvRecentChats = findViewById(R.id.rvRecentChats);

        cardTargetSchoolInfo = findViewById(R.id.cardTargetSchoolInfo);
        tvTargetSchoolHeader = findViewById(R.id.tvTargetSchoolHeader);
        tvTargetSchoolName = findViewById(R.id.tvTargetSchoolName);
        tvTargetSchoolAddress = findViewById(R.id.tvTargetSchoolAddress);

        tvEmptyChatState = findViewById(R.id.tvEmptyChatState);
        rvChatMessages = findViewById(R.id.rvChatMessages);
        btnAttachMedia = findViewById(R.id.btnAttachMedia);
        etMessageInput = findViewById(R.id.etMessageInput);
        btnSendMessage = findViewById(R.id.btnSendMessage);

        layoutSearchResultsContainer = findViewById(R.id.layoutSearchResultsContainer);
        rvSearchResults = findViewById(R.id.rvSearchResults);
        cardSearchEmptyState = findViewById(R.id.cardSearchEmptyState);
        tvSearchEmptyState = findViewById(R.id.tvSearchEmptyState);

        if (rvSearchResults != null) {
            rvSearchResults.setLayoutManager(new LinearLayoutManager(this));
            searchResultAdapter = new UserSearchResultAdapter(searchResultsList, item -> {
                String targetUid = (String) item.get("uid");
                String name = (String) item.get("name");
                String customUid = (String) item.get("customUid");
                String role = (String) item.get("role");

                String displayRole = role != null ? role.toUpperCase() : "USER";
                String displayUid = customUid != null && !customUid.isEmpty() ? customUid : targetUid;

                bindTargetProfile(targetUid, name, "Role: " + displayRole + " | ID: " + displayUid);
                if (layoutSearchResultsContainer != null) {
                    layoutSearchResultsContainer.setVisibility(View.GONE);
                }
            });
            rvSearchResults.setAdapter(searchResultAdapter);
        }

        if (tvMyUidHeader != null) {
            tvMyUidHeader.setText("My Custom UID: " + currentCustomUid);
        }

        // Messages Adapter Setup
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        rvChatMessages.setLayoutManager(layoutManager);

        chatAdapter = new ChatMessageAdapter(messageList, currentUid);
        chatAdapter.setOnMessageLongClickListener(this::showDeleteMessageDialog);
        rvChatMessages.setAdapter(chatAdapter);

        // Recent Chats Adapter Setup
        if (rvRecentChats != null) {
            rvRecentChats.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
            recentAdapter = new RecentChatAdapter(recentChatList, item -> {
                String targetUid = (String) item.get("targetUid");
                String name = (String) item.get("name");
                String customUid = (String) item.get("customUid");
                bindTargetProfile(targetUid, name, "Custom UID: " + customUid);
            });
            rvRecentChats.setAdapter(recentAdapter);
        }
    }

    private void setupListeners() {
        if (btnBack != null) {
            btnBack.setVisibility(View.GONE);
        }

        if (btnCopyMyUid != null) {
            btnCopyMyUid.setOnClickListener(v -> {
                if (!currentCustomUid.isEmpty()) {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    ClipData clip = ClipData.newPlainText("ClassroomHub Custom UID", currentCustomUid);
                    if (clipboard != null) {
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(this, "Custom UID පිටපත් කරන ලදී! (UID Copied)", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        if (btnSearchSchool != null) {
            btnSearchSchool.setOnClickListener(v -> {
                String inputUid = etReceiverUid.getText().toString().trim();
                if (inputUid.isEmpty()) {
                    Toast.makeText(this, "කරුණාකර Target UID එක ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (inputUid.equalsIgnoreCase(currentUid) || inputUid.equalsIgnoreCase(currentCustomUid)) {
                    Toast.makeText(this, "ඔබගේම UID එක සෙවිය නොහැක.", Toast.LENGTH_LONG).show();
                    return;
                }
                searchAndConnectToUid(inputUid);
            });
        }

        if (btnAttachMedia != null) {
            btnAttachMedia.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf", "text/*"});
                filePickerLauncher.launch(Intent.createChooser(intent, "Select Image or Document"));
            });
        }

        if (btnSendMessage != null) {
            btnSendMessage.setOnClickListener(v -> sendTextMessage());
        }
    }

    private void loadRecentChats() {
        if (currentUid.isEmpty()) return;

        recentListener = db.collection("chats")
                .whereArrayContains("participants", currentUid)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    recentChatList.clear();
                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        String user1 = doc.getString("user1");
                        String user2 = doc.getString("user2");
                        String otherUid = currentUid.equals(user1) ? user2 : user1;

                        if (otherUid != null && !otherUid.isEmpty()) {
                            Map<String, Object> map = new HashMap<>();
                            map.put("targetUid", otherUid);
                            map.put("name", doc.getString("name_" + otherUid) != null ? doc.getString("name_" + otherUid) : "Chat Partner");
                            map.put("customUid", doc.getString("customUid_" + otherUid) != null ? doc.getString("customUid_" + otherUid) : otherUid);
                            map.put("lastMsg", doc.getString("lastMessage") != null ? doc.getString("lastMessage") : "");
                            recentChatList.add(map);
                        }
                    }

                    if (!recentChatList.isEmpty()) {
                        layoutRecentChatsContainer.setVisibility(View.VISIBLE);
                        if (recentAdapter != null) recentAdapter.notifyDataSetChanged();
                    }
                });
    }

    private void searchAndConnectToUid(String inputUid) {
        performUserAndTeacherSearch(inputUid);
    }

    private void performUserAndTeacherSearch(String queryStr) {
        if (layoutSearchResultsContainer != null) {
            layoutSearchResultsContainer.setVisibility(View.VISIBLE);
        }
        Toast.makeText(this, "සොයමින් පවතී... (Searching...)", Toast.LENGTH_SHORT).show();

        final String queryLower = queryStr.toLowerCase().trim();
        searchResultsList.clear();
        if (searchResultAdapter != null) searchResultAdapter.notifyDataSetChanged();

        db.collection("users").get().addOnCompleteListener(task -> {
            Map<String, Map<String, Object>> resultMap = new HashMap<>();

            if (task.isSuccessful() && task.getResult() != null) {
                for (DocumentSnapshot doc : task.getResult().getDocuments()) {
                    String uUid = doc.getString("permanentUid");
                    if (uUid == null || uUid.isEmpty()) uUid = doc.getString("uid");
                    if (uUid == null || uUid.isEmpty()) uUid = doc.getId();

                    if (uUid.equalsIgnoreCase(currentUid) || uUid.equalsIgnoreCase(currentCustomUid)) {
                        continue; // skip self
                    }

                    String name = doc.getString("name");
                    if (name == null || name.isEmpty()) name = doc.getString("schoolName");
                    String customUid = doc.getString("customUid");
                    String role = doc.getString("role");
                    String email = doc.getString("email");

                    if (name == null) name = "";
                    if (customUid == null) customUid = "";
                    if (role == null) role = "user";
                    if (email == null) email = "";

                    boolean matches = false;

                    if (!customUid.isEmpty() && customUid.toLowerCase().contains(queryLower)) {
                        matches = true;
                    }
                    if (!name.isEmpty() && name.toLowerCase().contains(queryLower)) {
                        matches = true;
                    }
                    if (!email.isEmpty() && email.toLowerCase().contains(queryLower)) {
                        matches = true;
                    }
                    if (uUid.toLowerCase().contains(queryLower)) {
                        matches = true;
                    }
                    if (queryLower.contains("teacher") || queryLower.contains("guru")) {
                        if ("teacher".equalsIgnoreCase(role)) {
                            matches = true;
                        }
                    }

                    if (matches) {
                        Map<String, Object> userMap = new HashMap<>();
                        userMap.put("uid", uUid);
                        userMap.put("name", name.isEmpty() ? "User (" + uUid + ")" : name);
                        userMap.put("customUid", customUid.isEmpty() ? uUid : customUid);
                        userMap.put("role", role);
                        userMap.put("email", email);
                        resultMap.put(uUid, userMap);
                    }
                }
            }

            db.collection("custom_uids").get().addOnCompleteListener(customTask -> {
                if (customTask.isSuccessful() && customTask.getResult() != null) {
                    for (DocumentSnapshot cDoc : customTask.getResult().getDocuments()) {
                        String cId = cDoc.getId();
                        String realUid = cDoc.getString("uid");
                        if (realUid == null || realUid.isEmpty()) realUid = cDoc.getString("permanentUid");
                        if (realUid == null || realUid.isEmpty()) realUid = cId;

                        if (realUid.equalsIgnoreCase(currentUid) || cId.equalsIgnoreCase(currentCustomUid)) {
                            continue; // skip self
                        }

                        String name = cDoc.getString("name");
                        if (name == null || name.isEmpty()) name = cDoc.getString("schoolName");
                        String role = cDoc.getString("role");

                        if (cId.toLowerCase().contains(queryLower) ||
                            (name != null && name.toLowerCase().contains(queryLower))) {

                            if (!resultMap.containsKey(realUid)) {
                                Map<String, Object> userMap = new HashMap<>();
                                userMap.put("uid", realUid);
                                userMap.put("name", (name != null && !name.isEmpty()) ? name : "User (" + cId + ")");
                                userMap.put("customUid", cId);
                                userMap.put("role", role != null ? role : "teacher");
                                resultMap.put(realUid, userMap);
                            }
                        }
                    }
                }

                if (resultMap.isEmpty() && !queryLower.isEmpty()) {
                    String targetUid = queryStr.contains("@") ? UserRoleManager.getPermanentUid(queryStr) : queryStr;
                    if (!targetUid.equalsIgnoreCase(currentUid)) {
                        Map<String, Object> directMap = new HashMap<>();
                        directMap.put("uid", targetUid);
                        directMap.put("name", "Teacher / User (" + queryStr + ")");
                        directMap.put("customUid", queryStr);
                        directMap.put("role", "teacher");
                        resultMap.put(targetUid, directMap);
                    }
                }

                searchResultsList.clear();
                searchResultsList.addAll(resultMap.values());

                if (!searchResultsList.isEmpty()) {
                    if (rvSearchResults != null) rvSearchResults.setVisibility(View.VISIBLE);
                    if (cardSearchEmptyState != null) cardSearchEmptyState.setVisibility(View.GONE);
                    if (searchResultAdapter != null) searchResultAdapter.notifyDataSetChanged();
                } else {
                    if (rvSearchResults != null) rvSearchResults.setVisibility(View.GONE);
                    if (cardSearchEmptyState != null) cardSearchEmptyState.setVisibility(View.VISIBLE);
                    if (tvSearchEmptyState != null) {
                        tvSearchEmptyState.setText("No teacher or user found matching '" + queryStr + "'.");
                    }
                }
            });
        });
    }

    private void bindTargetProfile(String targetUid, String schoolName, String addressText) {
        selectedReceiverUid = targetUid;
        selectedReceiverSchoolName = schoolName;

        if (cardTargetSchoolInfo != null) {
            cardTargetSchoolInfo.setVisibility(View.VISIBLE);
        }
        if (tvTargetSchoolHeader != null) {
            tvTargetSchoolHeader.setText("💬 Chatting with: " + schoolName);
        }
        if (tvTargetSchoolName != null) {
            tvTargetSchoolName.setText(schoolName);
        }
        if (tvTargetSchoolAddress != null) {
            tvTargetSchoolAddress.setText("📍 " + addressText);
        }

        startRealtimeChatListener(targetUid);
    }

    private void startRealtimeChatListener(String targetUid) {
        if (currentUid.isEmpty()) return;

        currentChatId = getChatId(currentUid, targetUid);

        if (chatListener != null) {
            chatListener.remove();
        }

        tvEmptyChatState.setVisibility(View.GONE);
        rvChatMessages.setVisibility(View.VISIBLE);
        isInitialMessageLoad = true;

        chatListener = db.collection("chats")
                .document(currentChatId)
                .collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null || snapshots == null) return;

                    int prevSize = messageList.size();
                    messageList.clear();
                    boolean hasNewIncoming = false;

                    for (DocumentSnapshot doc : snapshots.getDocuments()) {
                        ChatMessage message = doc.toObject(ChatMessage.class);
                        if (message != null) {
                            message.setMessageId(doc.getId());
                            messageList.add(message);

                            // Auto mark as Seen for received messages
                            if (currentUid.equals(message.getReceiverUid()) && !message.isSeen()) {
                                doc.getReference().update("seen", true, "seenAt", System.currentTimeMillis());
                                hasNewIncoming = true;
                            }
                        }
                    }
                    chatAdapter.notifyDataSetChanged();
                    if (!messageList.isEmpty()) {
                        rvChatMessages.smoothScrollToPosition(messageList.size() - 1);
                    }

                    if (!isInitialMessageLoad && hasNewIncoming && messageList.size() > prevSize) {
                        NotificationSoundHelper.playNotificationChime(ChatActivity.this);
                    }
                    isInitialMessageLoad = false;
                });
    }

    private void sendTextMessage() {
        String text = etMessageInput.getText().toString().trim();
        if (text.isEmpty()) return;

        if (selectedReceiverUid.isEmpty() || currentChatId.isEmpty()) {
            Toast.makeText(this, "කරුණාකර පළමුව Target Custom UID එක Search කර සම්බන්ධ වන්න", Toast.LENGTH_SHORT).show();
            return;
        }

        long now = System.currentTimeMillis();
        ChatMessage message = new ChatMessage(currentUid, selectedReceiverUid, text, now, mySchoolName);

        postMessageToFirestore(message, text);
        etMessageInput.setText("");
    }

    private void handleAttachmentSelected(Uri uri) {
        if (selectedReceiverUid.isEmpty() || currentChatId.isEmpty()) {
            Toast.makeText(this, "කරුණාකර පළමුව Target Custom UID එක Search කරන්න", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "ගොනුව සූදානම් කරමින් පවතී...", Toast.LENGTH_SHORT).show();

        try {
            String mimeType = getContentResolver().getType(uri);
            boolean isImage = mimeType != null && mimeType.startsWith("image");

            if (isImage) {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 60, baos);
                byte[] imageBytes = baos.toByteArray();
                String base64Image = "data:image/jpeg;base64," + Base64.encodeToString(imageBytes, Base64.DEFAULT);

                ChatMessage message = new ChatMessage(currentUid, selectedReceiverUid, "📷 ඡායාරූපයක් එවන ලදී (Image)", System.currentTimeMillis(), mySchoolName);
                message.setMessageType("IMAGE");
                message.setMediaUrl(base64Image);

                postMessageToFirestore(message, "📷 Photo Attachment");
            } else {
                ChatMessage message = new ChatMessage(currentUid, selectedReceiverUid, "📄 ගොනුවක් එවන ලදී (Document)", System.currentTimeMillis(), mySchoolName);
                message.setMessageType("FILE");
                message.setFileName("Document.pdf");
                message.setMediaUrl(uri.toString());

                postMessageToFirestore(message, "📄 Document Attachment");
            }
        } catch (Exception e) {
            Toast.makeText(this, "ගොනුව යැවීමට නොහැකි විය: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void postMessageToFirestore(ChatMessage message, String summary) {
        db.collection("chats")
                .document(currentChatId)
                .collection("messages")
                .add(message)
                .addOnSuccessListener(ref -> {
                    // Update Chat Document Meta
                    Map<String, Object> chatMeta = new HashMap<>();
                    chatMeta.put("lastMessage", summary);
                    chatMeta.put("lastUpdated", System.currentTimeMillis());
                    chatMeta.put("user1", currentUid);
                    chatMeta.put("user2", selectedReceiverUid);
                    chatMeta.put("participants", java.util.Arrays.asList(currentUid, selectedReceiverUid));
                    chatMeta.put("name_" + currentUid, mySchoolName);
                    chatMeta.put("customUid_" + currentUid, currentCustomUid);
                    chatMeta.put("name_" + selectedReceiverUid, selectedReceiverSchoolName);

                    db.collection("chats").document(currentChatId).set(chatMeta, SetOptions.merge());
                });
    }

    private void showDeleteMessageDialog(ChatMessage message) {
        new AlertDialog.Builder(this)
                .setTitle("පණිවුඩය ඉවත් කරන්න (Delete Message)")
                .setMessage("මෙම පණිවුඩය ඉවත් කිරීමට ඔබට විශ්වාසද?")
                .setPositiveButton("ඔව් (Delete)", (dialog, which) -> {
                    if (message.getMessageId() != null && !currentChatId.isEmpty()) {
                        db.collection("chats")
                                .document(currentChatId)
                                .collection("messages")
                                .document(message.getMessageId())
                                .update("deleted", true, "messageText", "🚫 මේ පණිවුඩය ඉවත් කරන ලදී")
                                .addOnSuccessListener(aVoid -> Toast.makeText(ChatActivity.this, "පණිවුඩය ඉවත් කරන ලදී", Toast.LENGTH_SHORT).show());
                    }
                })
                .setNegativeButton("අවලංගුයි (Cancel)", null)
                .show();
    }

    public static String getChatId(String uid1, String uid2) {
        if (uid1 == null) uid1 = "";
        if (uid2 == null) uid2 = "";
        return uid1.compareTo(uid2) < 0 ? uid1 + "_" + uid2 : uid2 + "_" + uid1;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (chatListener != null) chatListener.remove();
        if (recentListener != null) recentListener.remove();
    }

    // Recent Chats Adapter
    private static class RecentChatAdapter extends RecyclerView.Adapter<RecentChatAdapter.ViewHolder> {
        public interface OnItemClickListener {
            void onItemClick(Map<String, Object> item);
        }

        private final List<Map<String, Object>> list;
        private final OnItemClickListener listener;

        public RecentChatAdapter(List<Map<String, Object>> list, OnItemClickListener listener) {
            this.list = list;
            this.listener = listener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recent_chat, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Map<String, Object> item = list.get(position);
            holder.tvName.setText((String) item.get("name"));
            holder.tvUid.setText((String) item.get("customUid"));
            holder.tvLastMsg.setText((String) item.get("lastMsg"));

            holder.card.setOnClickListener(v -> {
                if (listener != null) listener.onItemClick(item);
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            MaterialCardView card;
            TextView tvName, tvUid, tvLastMsg;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                card = itemView.findViewById(R.id.cardRecentChat);
                tvName = itemView.findViewById(R.id.tvRecentName);
                tvUid = itemView.findViewById(R.id.tvRecentUid);
                tvLastMsg = itemView.findViewById(R.id.tvRecentLastMsg);
            }
        }
    }

    // User / Teacher Search Results Adapter
    private static class UserSearchResultAdapter extends RecyclerView.Adapter<UserSearchResultAdapter.ViewHolder> {
        public interface OnUserSelectListener {
            void onUserSelected(Map<String, Object> userMap);
        }

        private final List<Map<String, Object>> list;
        private final OnUserSelectListener listener;

        public UserSearchResultAdapter(List<Map<String, Object>> list, OnUserSelectListener listener) {
            this.list = list;
            this.listener = listener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_search_result, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Map<String, Object> item = list.get(position);
            String name = (String) item.get("name");
            String uid = (String) item.get("uid");
            String customUid = (String) item.get("customUid");
            String role = (String) item.get("role");

            if (name == null || name.isEmpty()) name = "User (" + customUid + ")";
            if (role == null) role = "user";

            holder.tvName.setText(name);
            String displayUid = (customUid != null && !customUid.isEmpty()) ? customUid : uid;
            holder.tvUid.setText("UID: " + displayUid);

            String roleLabel = role.equalsIgnoreCase("teacher") ? "👨‍🏫 Teacher / ගුරුතුමා" :
                    (role.equalsIgnoreCase("student") ? "🎓 Student / ශිෂ්‍යයා" : "🏫 School");
            holder.tvRole.setText(roleLabel);

            if (name != null && !name.isEmpty()) {
                holder.tvInitial.setText(String.valueOf(name.charAt(0)).toUpperCase());
                holder.tvInitial.setVisibility(View.VISIBLE);
                holder.imgAvatar.setVisibility(View.GONE);
            } else {
                holder.tvInitial.setVisibility(View.GONE);
                holder.imgAvatar.setVisibility(View.VISIBLE);
            }

            View.OnClickListener clickListener = v -> {
                if (listener != null) listener.onUserSelected(item);
            };

            holder.card.setOnClickListener(clickListener);
            if (holder.btnStartChat != null) {
                holder.btnStartChat.setOnClickListener(clickListener);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            MaterialCardView card;
            ImageView imgAvatar;
            TextView tvInitial, tvName, tvUid, tvRole;
            MaterialButton btnStartChat;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                card = itemView.findViewById(R.id.cardSearchResult);
                imgAvatar = itemView.findViewById(R.id.imgSearchAvatar);
                tvInitial = itemView.findViewById(R.id.tvSearchInitial);
                tvName = itemView.findViewById(R.id.tvSearchName);
                tvUid = itemView.findViewById(R.id.tvSearchUid);
                tvRole = itemView.findViewById(R.id.tvSearchRole);
                btnStartChat = itemView.findViewById(R.id.btnStartChat);
            }
        }
    }
}
