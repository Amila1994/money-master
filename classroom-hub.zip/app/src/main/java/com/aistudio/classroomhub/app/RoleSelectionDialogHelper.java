package com.aistudio.classroomhub.app;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

public class RoleSelectionDialogHelper {

    public interface OnRoleSelectedListener {
        void onRoleSelected(String role, String customUid);
    }

    public static void showRoleSelectionDialog(@NonNull Context context, OnRoleSelectedListener listener) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_role_selection, null);
        dialog.setContentView(view);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT
            );
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }

        dialog.setCancelable(false); // Force selection

        MaterialCardView cardTeacher = view.findViewById(R.id.cardTeacher);
        MaterialCardView cardStudent = view.findViewById(R.id.cardStudent);
        MaterialButton btnConfirmRole = view.findViewById(R.id.btnConfirmRole);

        final String[] selectedRole = {"TEACHER"}; // Default selection

        cardTeacher.setOnClickListener(v -> {
            selectedRole[0] = "TEACHER";
            cardTeacher.setStrokeColor(Color.parseColor("#38BDF8"));
            cardTeacher.setStrokeWidth(4);
            cardStudent.setStrokeColor(Color.parseColor("#334155"));
            cardStudent.setStrokeWidth(2);
        });

        cardStudent.setOnClickListener(v -> {
            selectedRole[0] = "STUDENT";
            cardStudent.setStrokeColor(Color.parseColor("#38BDF8"));
            cardStudent.setStrokeWidth(4);
            cardTeacher.setStrokeColor(Color.parseColor("#334155"));
            cardTeacher.setStrokeWidth(2);
        });

        btnConfirmRole.setOnClickListener(v -> {
            String role = selectedRole[0];
            Toast.makeText(context, "කාර්යභාරය: " + (role.equals("TEACHER") ? "ගුරුවරයා/පාසල" : "ශිෂ්‍යයා"), Toast.LENGTH_SHORT).show();

            UserRoleManager.setUserRoleAndGenerateUid(context, role, (customUid, assignedRole) -> {
                dialog.dismiss();
                if (listener != null) {
                    listener.onRoleSelected(assignedRole, customUid);
                }
            });
        });

        dialog.show();
    }
}
