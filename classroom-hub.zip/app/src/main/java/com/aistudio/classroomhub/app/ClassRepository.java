package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.List;

public class ClassRepository {

    public interface OnClassChangeListener {
        void onActiveClassChanged(ClassModel newClass);
    }

    private static final List<ClassModel> classes = new ArrayList<>();
    private static ClassModel activeClass;
    private static final List<OnClassChangeListener> listeners = new ArrayList<>();

    static {
        initDefaultClasses();
    }

    private static void initDefaultClasses() {
        // Production mode: Start with a clean empty database.
        // Teacher adds their own classes/grades.
    }

    public static List<ClassModel> getClasses() {
        return new ArrayList<>(classes);
    }

    public static ClassModel getActiveClass() {
        if (activeClass == null && !classes.isEmpty()) {
            activeClass = classes.get(0);
        }
        return activeClass;
    }

    public static void setClasses(List<ClassModel> newClasses) {
        classes.clear();
        if (newClasses != null && !newClasses.isEmpty()) {
            classes.addAll(newClasses);
            if (activeClass == null || !classes.contains(activeClass)) {
                activeClass = classes.get(0);
            }
        } else {
            activeClass = null;
        }
        notifyListeners(activeClass);
    }

    public static void setActiveClass(ClassModel newClass) {
        if (newClass == null) return;
        activeClass = newClass;
        notifyListeners(newClass);
    }

    public static void setActiveClassById(String classId) {
        for (ClassModel c : classes) {
            if (c.getId().equals(classId)) {
                setActiveClass(c);
                break;
            }
        }
    }

    public static void addClass(ClassModel newClass) {
        if (newClass == null) return;
        // Prevent duplicate IDs
        for (int i = 0; i < classes.size(); i++) {
            if (classes.get(i).getId().equals(newClass.getId())) {
                classes.set(i, newClass);
                setActiveClass(newClass);
                return;
            }
        }
        classes.add(0, newClass);
        setActiveClass(newClass);
    }

    public static void updateClass(String classId, String newName, String newYear, String newRole) {
        for (ClassModel c : classes) {
            if (c.getId().equals(classId)) {
                c.setClassName(newName);
                c.setAcademicYear(newYear);
                c.setRole(newRole);
                if (activeClass != null && activeClass.getId().equals(classId)) {
                    notifyListeners(c);
                }
                break;
            }
        }
    }

    public static ClassModel promoteClass(String classId, String nextClassName, String nextAcademicYear) {
        ClassModel target = null;
        for (ClassModel c : classes) {
            if (c.getId().equals(classId)) {
                target = c;
                break;
            }
        }
        if (target == null) return null;

        // 1. Archive previous class records as read-only history
        target.setArchived(true);
        target.setRole("Class Teacher (Past - " + target.getAcademicYear() + ")");

        // 2. Create new active class model
        String newClassId = "class_" + System.currentTimeMillis();
        ClassModel promotedClass = new ClassModel(newClassId, nextClassName, nextAcademicYear, "Class Teacher", false);
        classes.add(0, promotedClass);

        // 3. Automatically clone the student list into the new active class
        List<Student> oldStudents = StudentRepository.getStudentsForClass(classId);
        for (Student oldS : oldStudents) {
            String newStudentId = java.util.UUID.randomUUID().toString();
            Student newS = new Student(
                    newStudentId,
                    oldS.getName(),
                    oldS.getRollNo(),
                    nextClassName,
                    oldS.getMarks(),
                    true
            );
            newS.setNameWithInitials(oldS.getNameWithInitials());
            newS.setDob(oldS.getDob());
            newS.setGender(oldS.getGender());
            newS.setPlaceOfBirth(oldS.getPlaceOfBirth());
            newS.setEthnicity(oldS.getEthnicity());
            newS.setReligion(oldS.getReligion());
            newS.setBirthCertNo(oldS.getBirthCertNo());
            newS.setMedium(oldS.getMedium());
            newS.setPermAddress(oldS.getPermAddress());
            newS.setFatherName(oldS.getFatherName());
            newS.setFatherNic(oldS.getFatherNic());
            newS.setFatherPhone(oldS.getFatherPhone());
            newS.setMotherName(oldS.getMotherName());
            newS.setMotherNic(oldS.getMotherNic());
            newS.setMotherPhone(oldS.getMotherPhone());
            newS.setGuardianName(oldS.getGuardianName());
            newS.setEmergencyName(oldS.getEmergencyName());
            newS.setEmergencyRelation(oldS.getEmergencyRelation());
            newS.setEmergencyPhone(oldS.getEmergencyPhone());
            newS.setClassId(newClassId);

            StudentRepository.addStudent(newS);
        }

        // 4. Set active class to new promoted class
        setActiveClass(promotedClass);
        return promotedClass;
    }

    public static void removeClass(String classId) {
        ClassModel target = null;
        for (ClassModel c : classes) {
            if (c.getId().equals(classId)) {
                target = c;
                break;
            }
        }
        if (target != null) {
            classes.remove(target);
            if (activeClass != null && activeClass.getId().equals(classId) && !classes.isEmpty()) {
                setActiveClass(classes.get(0));
            }
        }
    }

    public static void markClassAsHandedOver(String classId) {
        for (ClassModel c : classes) {
            if (c.getId().equals(classId)) {
                c.setArchived(true);
                c.setRole("Handed Over (Archived)");
                break;
            }
        }
    }

    public static void restoreClass(String classId) {
        for (ClassModel c : classes) {
            if (c.getId().equals(classId)) {
                c.setArchived(false);
                c.setRole("Class Teacher");
                setActiveClass(c);
                break;
            }
        }
    }

    public static void clear() {
        classes.clear();
        activeClass = null;
    }

    public static void addListener(OnClassChangeListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public static void removeListener(OnClassChangeListener listener) {
        listeners.remove(listener);
    }

    private static void notifyListeners(ClassModel newClass) {
        for (OnClassChangeListener listener : new ArrayList<>(listeners)) {
            listener.onActiveClassChanged(newClass);
        }
    }
}
