package com.aistudio.classroomhub.app

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassManagementModalContent(
    context: Context,
    onDismissRequest: () -> Unit
) {
    var availableClasses by remember { mutableStateOf(ClassRepository.getClasses()) }
    var activeClass by remember { mutableStateOf(ClassRepository.getActiveClass()) }

    // Dialog state for Editing class
    var classToEdit by remember { mutableStateOf<ClassModel?>(null) }
    var editClassName by remember { mutableStateOf("") }
    var editAcademicYear by remember { mutableStateOf("") }
    var editRole by remember { mutableStateOf("") }

    // Dialog state for Promoting class
    var classToPromote by remember { mutableStateOf<ClassModel?>(null) }
    var promoteNextName by remember { mutableStateOf("") }
    var promoteNextYear by remember { mutableStateOf("") }

    // Dialog state for Deleting class
    var classToDelete by remember { mutableStateOf<ClassModel?>(null) }

    // New Class Form State
    var newClassName by remember { mutableStateOf("") }
    var newAcademicYear by remember { mutableStateOf("") }
    var newRole by remember { mutableStateOf("Class Teacher") }

    fun refreshState() {
        availableClasses = ClassRepository.getClasses()
        activeClass = ClassRepository.getActiveClass()
    }

    // Group classes by Academic Year (Sorted descending)
    val yearGroups = availableClasses.groupBy { it.academicYear }.toSortedMap(compareByDescending { it })

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .wrapContentHeight()
                .padding(8.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Class,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "පන්ති පාලනය & ප්‍රවර්ධනය",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Class Edit, Delete, Year Separation & Promotion",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Current Active Class Badge Summary
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "දැනට සක්‍රිය පන්තිය (Active Class):",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = activeClass?.getDisplayName() ?: "කිසිවක් තෝරා නොමැත",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // YEAR-WISE SEPARATION LIST
                Text(
                    text = "🗓️ වර්ෂ අනුව වෙන්කළ පන්ති ලැයිස්තුව (Year-Wise Class Separation):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (yearGroups.isEmpty()) {
                    Text(
                        text = "පන්ති කිසිවක් හමු නොවීය.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                } else {
                    yearGroups.forEach { (year, classList) ->
                        Text(
                            text = "📌 Academic Year: $year",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )

                        classList.forEach { classModel ->
                            val isActive = activeClass?.id == classModel.id

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                                    else MaterialTheme.colorScheme.surfaceVariant
                                ),
                                border = if (isActive) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = classModel.getDisplayName(),
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                if (isActive) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        color = Color(0xFF16A34A),
                                                        shape = RoundedCornerShape(6.dp)
                                                    ) {
                                                        Text(
                                                            text = "ACTIVE",
                                                            fontSize = 9.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(2.dp))

                                            Text(
                                                text = "තනතුර: ${classModel.role}",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        // EDIT & DELETE ICONS DIRECTLY ON CLASS ITEM
                                        Row {
                                            // Edit Icon
                                            IconButton(
                                                onClick = {
                                                    classToEdit = classModel
                                                    editClassName = classModel.className
                                                    editAcademicYear = classModel.academicYear
                                                    editRole = classModel.role
                                                },
                                                modifier = Modifier.size(34.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Edit,
                                                    contentDescription = "Edit Class Name / Year",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }

                                            // Delete Icon
                                            IconButton(
                                                onClick = {
                                                    classToDelete = classModel
                                                },
                                                modifier = Modifier.size(34.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete Class",
                                                    tint = Color(0xFFEF4444),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // ACTION BUTTONS: SELECT ACTIVE & PROMOTE CLASS
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        if (!isActive) {
                                            OutlinedButton(
                                                onClick = {
                                                    ClassRepository.setActiveClass(classModel)
                                                    refreshState()
                                                    Toast.makeText(context, "${classModel.className} සක්‍රිය පන්තිය ලෙස තෝරාගන්නා ලදී.", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                                            ) {
                                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("සක්‍රිය කරන්න", fontSize = 11.sp)
                                            }
                                        }

                                        // Class Promotion Button
                                        Button(
                                            onClick = {
                                                classToPromote = classModel
                                                // Auto suggest next grade name e.g., Grade 10-A -> Grade 11-A
                                                val nextName = if (classModel.className.contains("10")) {
                                                    classModel.className.replace("10", "11")
                                                } else if (classModel.className.contains("9")) {
                                                    classModel.className.replace("9", "10")
                                                } else if (classModel.className.contains("11")) {
                                                    classModel.className.replace("11", "12")
                                                } else {
                                                    classModel.className + " (Promoted)"
                                                }

                                                val currentYearInt = classModel.academicYear.toIntOrNull() ?: 2026
                                                val nextYearStr = (currentYearInt + 1).toString()

                                                promoteNextName = nextName
                                                promoteNextYear = nextYearStr
                                            },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                            contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                                        ) {
                                            Icon(Icons.Default.TrendingUp, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("පන්තිය ප්‍රවර්ධනය", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                Spacer(modifier = Modifier.height(14.dp))

                // BOTTOM FORM: ADD NEW CLASS
                Text(
                    text = "➕ නව පන්තියක් එකතු කරන්න (+ Add New Class):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = newClassName,
                    onValueChange = { newClassName = it },
                    label = { Text("පන්තියේ නම (e.g. Grade 10-A)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = newAcademicYear,
                        onValueChange = { newAcademicYear = it },
                        label = { Text("අධ්‍යයන වර්ෂය (e.g. 2027)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newRole,
                        onValueChange = { newRole = it },
                        label = { Text("තනතුර (Role)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        val nameStr = if (newClassName.trim().isNotEmpty()) newClassName.trim() else "Grade 10-A"
                        val yearStr = if (newAcademicYear.trim().isNotEmpty()) newAcademicYear.trim() else "2027"
                        val roleStr = if (newRole.trim().isNotEmpty()) newRole.trim() else "Class Teacher"

                        val newId = "class_" + System.currentTimeMillis()
                        val newClass = ClassModel(newId, nameStr, yearStr, roleStr, false)
                        ClassRepository.addClass(newClass)
                        DataBackupManager.saveLocalState(context)
                        refreshState()

                        newClassName = ""
                        newAcademicYear = ""
                        Toast.makeText(context, "$nameStr ($yearStr) සාර්ථකව එක් විය!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("නව පන්තිය එක් කරන්න & Activate කරන්න")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Dismiss Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismissRequest) {
                        Text("වසා දමන්න (Close)")
                    }
                }
            }
        }
    }

    // ==================== EDIT CLASS DIALOG ====================
    if (classToEdit != null) {
        AlertDialog(
            onDismissRequest = { classToEdit = null },
            title = { Text("✏️ පන්ති විස්තර සංස්කරණය (Edit Class)", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = editClassName,
                        onValueChange = { editClassName = it },
                        label = { Text("පන්තියේ නම (Class Name)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editAcademicYear,
                        onValueChange = { editAcademicYear = it },
                        label = { Text("අධ්‍යයන වර්ෂය (Academic Year)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editRole,
                        onValueChange = { editRole = it },
                        label = { Text("තනතුර (Role)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val c = classToEdit
                        if (c != null) {
                            val name = if (editClassName.trim().isNotEmpty()) editClassName.trim() else c.className
                            val year = if (editAcademicYear.trim().isNotEmpty()) editAcademicYear.trim() else c.academicYear
                            val role = if (editRole.trim().isNotEmpty()) editRole.trim() else c.role

                            ClassRepository.updateClass(c.id, name, year, role)
                            DataBackupManager.saveLocalState(context)
                            refreshState()
                            Toast.makeText(context, "$name විස්තර වෙනස් විය.", Toast.LENGTH_SHORT).show()
                        }
                        classToEdit = null
                    }
                ) {
                    Text("සුරකින්න (Save)")
                }
            },
            dismissButton = {
                TextButton(onClick = { classToEdit = null }) {
                    Text("අවලංගු කරන්න")
                }
            }
        )
    }

    // ==================== DELETE CLASS CONFIRMATION DIALOG ====================
    if (classToDelete != null) {
        AlertDialog(
            onDismissRequest = { classToDelete = null },
            title = { Text("🗑️ පන්තිය ඉවත් කිරීම (Delete Class)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626)) },
            text = {
                Text("ඔබට සැබවින්ම '${classToDelete?.getDisplayName()}' පන්තිය පද්ධතියෙන් ඉවත් කිරීමට අවශ්‍යද? එම පන්තියේ සිසුන් සහ වාර්තාද ඉවත් විය හැක.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        val c = classToDelete
                        if (c != null) {
                            ClassRepository.removeClass(c.id)
                            DataBackupManager.saveLocalState(context)
                            refreshState()
                            Toast.makeText(context, "${c.className} සාර්ථකව ඉවත් කරන ලදී.", Toast.LENGTH_SHORT).show()
                        }
                        classToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("ඔවු, ඉවත් කරන්න (Delete)")
                }
            },
            dismissButton = {
                TextButton(onClick = { classToDelete = null }) {
                    Text("අවලංගු කරන්න")
                }
            }
        )
    }

    // ==================== PROMOTING CLASS DIALOG ====================
    if (classToPromote != null) {
        AlertDialog(
            onDismissRequest = { classToPromote = null },
            title = { Text("🚀 පන්තිය ප්‍රවර්ධනය (Class Promotion)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2563EB)) },
            text = {
                Column {
                    Text(
                        text = "'${classToPromote?.getDisplayName()}' පන්තියේ සියලුම ළමුන් ඊළඟ වසර සඳහා පහත පන්තියට මාරු (Clone) වේ. පෙර වසරේ වාර්තා Read-Only History ලෙස සුරක්ෂිත වේ.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = promoteNextName,
                        onValueChange = { promoteNextName = it },
                        label = { Text("ඊළඟ පන්තියේ නම (Target Grade/Class)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = promoteNextYear,
                        onValueChange = { promoteNextYear = it },
                        label = { Text("ඊළඟ අධ්‍යයන වර්ෂය (Target Academic Year)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val targetClass = classToPromote
                        if (targetClass != null) {
                            val nextName = if (promoteNextName.trim().isNotEmpty()) promoteNextName.trim() else "Grade 11-A"
                            val nextYear = if (promoteNextYear.trim().isNotEmpty()) promoteNextYear.trim() else "2027"

                            val promoted = ClassRepository.promoteClass(targetClass.id, nextName, nextYear)
                            refreshState()

                            if (promoted != null) {
                                Toast.makeText(
                                    context,
                                    "පන්තිය සාර්ථකව $nextName ($nextYear) ලෙස ප්‍රවර්ධනය විය! ළමුන් ලැයිස්තුවද මාරු විය.",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                        classToPromote = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Text("ප්‍රවර්ධනය කරන්න & Clone Roster")
                }
            },
            dismissButton = {
                TextButton(onClick = { classToPromote = null }) {
                    Text("අවලංගු කරන්න")
                }
            }
        )
    }
}

fun showClassManagementDialog(context: Context) {
    val composeView = ComposeView(context)
    val dialog = AlertDialog.Builder(context)
        .setView(composeView)
        .create()

    dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

    composeView.setContent {
        ClassManagementModalContent(
            context = context,
            onDismissRequest = { dialog.dismiss() }
        )
    }

    dialog.show()
}
