package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LetterTemplatesActivity extends AppCompatActivity {

    public static final String CAT_ALL_OFFICIAL = "ALL_OFFICIAL";
    public static final String CAT_TEACHER = "TEACHER";
    public static final String CAT_ADMIN_STUDENT = "ADMIN_STUDENT";
    public static final String CAT_SAVED_DOCS = "SAVED_DOCS";
    public static final String CAT_CUSTOM_TMPL = "CUSTOM_TMPL";

    private ImageView btnBack;
    private EditText etSearchTemplate;
    private TextView tvTemplateCountBadge;
    private MaterialButton btnCatAll, btnCatTeacher, btnCatAdminStudent, btnCatSavedDocs, btnCatCustomTmpl;
    private LinearLayout layoutSubCategoryChips;
    private RecyclerView rvLetterTemplates;
    private MaterialCardView cardEmptyState;
    private TextView tvEmptyMessage;

    private List<LetterTemplate> repositoryTemplatesList = new ArrayList<>();
    private List<LetterTemplate> cloudSavedLettersList = new ArrayList<>();
    private List<LetterTemplate> cloudCustomTemplatesList = new ArrayList<>();

    private List<LetterTemplate> currentCategoryList = new ArrayList<>();
    private List<LetterTemplate> filteredList = new ArrayList<>();
    private TemplateAdapter adapter;

    private String selectedCategory = CAT_ALL_OFFICIAL;
    private String selectedSubCategory = "ALL";
    private String searchQuery = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_letter_templates);
        WindowInsetUtils.applySystemBarPadding(this);

        initViews();
        setupListeners();
        loadRepositoryData();
        loadCloudData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCloudData(); // Refresh cloud saved documents when returning
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        etSearchTemplate = findViewById(R.id.etSearchTemplate);
        tvTemplateCountBadge = findViewById(R.id.tvTemplateCountBadge);

        btnCatAll = findViewById(R.id.btnCatAll);
        btnCatTeacher = findViewById(R.id.btnCatTeacher);
        btnCatAdminStudent = findViewById(R.id.btnCatAdminStudent);

        // Dynamic category horizontal layout
        btnCatSavedDocs = findViewById(R.id.btnCatSavedDocs);
        btnCatCustomTmpl = findViewById(R.id.btnCatCustomTmpl);

        layoutSubCategoryChips = findViewById(R.id.layoutSubCategoryChips);
        rvLetterTemplates = findViewById(R.id.rvLetterTemplates);
        cardEmptyState = findViewById(R.id.cardEmptyState);
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage);

        rvLetterTemplates.setLayoutManager(new LinearLayoutManager(this));
        adapter = new TemplateAdapter(filteredList, new TemplateAdapter.OnTemplateActionListener() {
            @Override
            public void onEdit(LetterTemplate template) {
                Intent intent = new Intent(LetterTemplatesActivity.this, LetterEditorActivity.class);
                intent.putExtra("template_obj", template);
                startActivity(intent);
            }

            @Override
            public void onView(LetterTemplate template) {
                Intent intent = new Intent(LetterTemplatesActivity.this, LetterEditorActivity.class);
                intent.putExtra("template_obj", template);
                intent.putExtra("is_read_only", true);
                startActivity(intent);
            }

            @Override
            public void onDuplicate(LetterTemplate template) {
                LetterTemplate duplicate = new LetterTemplate();
                duplicate.setId("doc_" + System.currentTimeMillis());
                duplicate.setTitle("Copy of " + template.getTitle());
                duplicate.setContent(template.getContent());
                duplicate.setCategory(template.getCategory());
                duplicate.setSubCategory(template.getSubCategory());
                duplicate.setDescription(template.getDescription());

                Intent intent = new Intent(LetterTemplatesActivity.this, LetterEditorActivity.class);
                intent.putExtra("template_obj", duplicate);
                startActivity(intent);
            }

            @Override
            public void onDelete(LetterTemplate template) {
                confirmDeleteDocument(template);
            }
        });
        rvLetterTemplates.setAdapter(adapter);
    }

    private void loadRepositoryData() {
        repositoryTemplatesList = LetterTemplatesRepository.getAllTemplates();
        switchCategory(CAT_ALL_OFFICIAL);
    }

    private void loadCloudData() {
        LetterCloudManager.loadSavedLetters(this, new LetterCloudManager.FirestoreCallback<List<LetterTemplate>>() {
            @Override
            public void onSuccess(List<LetterTemplate> result) {
                cloudSavedLettersList = result != null ? result : new ArrayList<>();
                if (CAT_SAVED_DOCS.equals(selectedCategory)) {
                    switchCategory(CAT_SAVED_DOCS);
                }
            }

            @Override
            public void onError(Exception e) {
                // Ignore
            }
        });

        LetterCloudManager.loadCustomTemplates(this, new LetterCloudManager.FirestoreCallback<List<LetterTemplate>>() {
            @Override
            public void onSuccess(List<LetterTemplate> result) {
                cloudCustomTemplatesList = result != null ? result : new ArrayList<>();
                if (CAT_CUSTOM_TMPL.equals(selectedCategory)) {
                    switchCategory(CAT_CUSTOM_TMPL);
                }
            }

            @Override
            public void onError(Exception e) {
                // Ignore
            }
        });
    }

    private void setupListeners() {
        if (btnBack != null) {
            btnBack.setVisibility(View.GONE);
        }

        if (btnCatAll != null) {
            btnCatAll.setOnClickListener(v -> switchCategory(CAT_ALL_OFFICIAL));
        }

        if (btnCatTeacher != null) {
            btnCatTeacher.setOnClickListener(v -> switchCategory(CAT_TEACHER));
        }

        if (btnCatAdminStudent != null) {
            btnCatAdminStudent.setOnClickListener(v -> switchCategory(CAT_ADMIN_STUDENT));
        }

        if (btnCatSavedDocs != null) {
            btnCatSavedDocs.setOnClickListener(v -> switchCategory(CAT_SAVED_DOCS));
        }

        if (btnCatCustomTmpl != null) {
            btnCatCustomTmpl.setOnClickListener(v -> switchCategory(CAT_CUSTOM_TMPL));
        }

        if (etSearchTemplate != null) {
            etSearchTemplate.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    searchQuery = s.toString().trim().toLowerCase();
                    applyFilters();
                }

                @Override
                public void afterTextChanged(Editable s) {}
            });
        }
    }

    private void switchCategory(String category) {
        selectedCategory = category;
        selectedSubCategory = "ALL";

        currentCategoryList.clear();
        if (CAT_ALL_OFFICIAL.equals(category)) {
            currentCategoryList.addAll(repositoryTemplatesList);
        } else if (CAT_TEACHER.equals(category)) {
            for (LetterTemplate t : repositoryTemplatesList) {
                if (LetterTemplatesRepository.CAT_TEACHER.equalsIgnoreCase(t.getCategory())) {
                    currentCategoryList.add(t);
                }
            }
        } else if (CAT_ADMIN_STUDENT.equals(category)) {
            for (LetterTemplate t : repositoryTemplatesList) {
                if (LetterTemplatesRepository.CAT_ADMIN_STUDENT.equalsIgnoreCase(t.getCategory())) {
                    currentCategoryList.add(t);
                }
            }
        } else if (CAT_SAVED_DOCS.equals(category)) {
            currentCategoryList.addAll(cloudSavedLettersList);
        } else if (CAT_CUSTOM_TMPL.equals(category)) {
            currentCategoryList.addAll(cloudCustomTemplatesList);
        }

        updateCategoryButtonsUI();
        rebuildSubCategoryChips();
        applyFilters();
    }

    private void updateCategoryButtonsUI() {
        int activeBg = 0xFF0284C7;
        int activeText = 0xFFFFFFFF;
        int inactiveText = 0xFF94A3B8;

        setButtonStyle(btnCatAll, CAT_ALL_OFFICIAL.equals(selectedCategory), activeBg, activeText, inactiveText);
        setButtonStyle(btnCatTeacher, CAT_TEACHER.equals(selectedCategory), activeBg, activeText, inactiveText);
        setButtonStyle(btnCatAdminStudent, CAT_ADMIN_STUDENT.equals(selectedCategory), activeBg, activeText, inactiveText);
        setButtonStyle(btnCatSavedDocs, CAT_SAVED_DOCS.equals(selectedCategory), activeBg, activeText, inactiveText);
        setButtonStyle(btnCatCustomTmpl, CAT_CUSTOM_TMPL.equals(selectedCategory), activeBg, activeText, inactiveText);
    }

    private void setButtonStyle(MaterialButton btn, boolean isActive, int activeBg, int activeText, int inactiveText) {
        if (btn == null) return;
        if (isActive) {
            btn.setBackgroundColor(activeBg);
            btn.setTextColor(activeText);
            btn.setStrokeWidth(0);
        } else {
            btn.setBackgroundColor(0x00000000);
            btn.setTextColor(inactiveText);
            btn.setStrokeColor(android.content.res.ColorStateList.valueOf(0xFF334155));
            btn.setStrokeWidth(dpToPx(1));
        }
    }

    private void rebuildSubCategoryChips() {
        if (layoutSubCategoryChips == null) return;
        layoutSubCategoryChips.removeAllViews();

        Set<String> subCats = new HashSet<>();
        subCats.add("ALL");

        for (LetterTemplate t : currentCategoryList) {
            if (t.getSubCategory() != null && !t.getSubCategory().isEmpty()) {
                subCats.add(t.getSubCategory());
            }
        }

        for (String sub : subCats) {
            MaterialButton chip = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            chip.setText(sub.equals("ALL") ? "All Subcategories" : sub);
            chip.setTextSize(11f);
            chip.setCornerRadius(30);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    dpToPx(34)
            );
            params.setMargins(0, 0, dpToPx(6), 0);
            chip.setLayoutParams(params);

            if (selectedSubCategory.equalsIgnoreCase(sub)) {
                chip.setBackgroundColor(0xFF38BDF8);
                chip.setTextColor(0xFF0F172A);
                chip.setStrokeWidth(0);
            } else {
                chip.setBackgroundColor(0x00000000);
                chip.setTextColor(0xFF94A3B8);
                chip.setStrokeColor(android.content.res.ColorStateList.valueOf(0xFF334155));
                chip.setStrokeWidth(dpToPx(1));
            }

            chip.setOnClickListener(v -> {
                selectedSubCategory = sub;
                rebuildSubCategoryChips();
                applyFilters();
            });

            layoutSubCategoryChips.addView(chip);
        }
    }

    private void applyFilters() {
        filteredList.clear();

        for (LetterTemplate t : currentCategoryList) {
            // 1. Subcategory Filter
            if (!selectedSubCategory.equals("ALL") && !t.getSubCategory().equalsIgnoreCase(selectedSubCategory)) {
                continue;
            }

            // 2. Search Query Filter
            if (!searchQuery.isEmpty()) {
                boolean matchesTitle = t.getTitle() != null && t.getTitle().toLowerCase().contains(searchQuery);
                boolean matchesSub = t.getSubCategory() != null && t.getSubCategory().toLowerCase().contains(searchQuery);
                boolean matchesDesc = t.getDescription() != null && t.getDescription().toLowerCase().contains(searchQuery);
                boolean matchesContent = t.getContent() != null && t.getContent().toLowerCase().contains(searchQuery);

                if (!matchesTitle && !matchesSub && !matchesDesc && !matchesContent) {
                    continue;
                }
            }

            filteredList.add(t);
        }

        if (tvTemplateCountBadge != null) {
            tvTemplateCountBadge.setText(filteredList.size() + " Documents");
        }

        if (filteredList.isEmpty()) {
            if (rvLetterTemplates != null) rvLetterTemplates.setVisibility(View.GONE);
            if (cardEmptyState != null) cardEmptyState.setVisibility(View.VISIBLE);
            if (tvEmptyMessage != null) {
                tvEmptyMessage.setText("No templates found matching '" + searchQuery + "'.");
            }
        } else {
            if (rvLetterTemplates != null) rvLetterTemplates.setVisibility(View.VISIBLE);
            if (cardEmptyState != null) cardEmptyState.setVisibility(View.GONE);
        }

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private void confirmDeleteDocument(LetterTemplate template) {
        new AlertDialog.Builder(this)
                .setTitle("🗑️ Confirm Deletion")
                .setMessage("Are you sure you want to delete '" + template.getTitle() + "'? This action cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    LetterCloudManager.deleteDocument(this, template, new LetterCloudManager.FirestoreCallback<Boolean>() {
                        @Override
                        public void onSuccess(Boolean result) {
                            ToastHelper.showShort(LetterTemplatesActivity.this, "Document deleted.");
                            loadCloudData();
                        }

                        @Override
                        public void onError(Exception e) {
                            ToastHelper.showShort(LetterTemplatesActivity.this, "Deleted locally.");
                            loadCloudData();
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    // Template RecyclerView Adapter
    private static class TemplateAdapter extends RecyclerView.Adapter<TemplateAdapter.ViewHolder> {

        public interface OnTemplateActionListener {
            void onEdit(LetterTemplate template);
            void onView(LetterTemplate template);
            void onDuplicate(LetterTemplate template);
            void onDelete(LetterTemplate template);
        }

        private final List<LetterTemplate> list;
        private final OnTemplateActionListener listener;

        public TemplateAdapter(List<LetterTemplate> list, OnTemplateActionListener listener) {
            this.list = list;
            this.listener = listener;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_letter_template, parent, false);
            return new ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            LetterTemplate item = list.get(position);

            holder.tvTitle.setText(item.getTitle());
            holder.tvDescription.setText(item.getDescription() != null ? item.getDescription() : "Official school document format.");
            holder.tvCategory.setText(item.getCategory() != null ? item.getCategory() : "Official Template");
            holder.tvSubCategory.setText(item.getSubCategory() != null ? item.getSubCategory() : "Official");

            if (item.isCustomTemplate() || item.isSavedDocument()) {
                holder.btnDelete.setVisibility(View.VISIBLE);
            } else {
                holder.btnDelete.setVisibility(View.GONE);
            }

            holder.card.setOnClickListener(v -> {
                if (listener != null) listener.onEdit(item);
            });

            if (holder.btnEdit != null) {
                holder.btnEdit.setOnClickListener(v -> {
                    if (listener != null) listener.onEdit(item);
                });
            }

            if (holder.btnView != null) {
                holder.btnView.setOnClickListener(v -> {
                    if (listener != null) listener.onView(item);
                });
            }

            if (holder.btnDuplicate != null) {
                holder.btnDuplicate.setOnClickListener(v -> {
                    if (listener != null) listener.onDuplicate(item);
                });
            }

            if (holder.btnDelete != null) {
                holder.btnDelete.setOnClickListener(v -> {
                    if (listener != null) listener.onDelete(item);
                });
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            MaterialCardView card;
            TextView tvSubCategory, tvCategory, tvTitle, tvDescription;
            MaterialButton btnEdit, btnView, btnDuplicate, btnDelete;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                card = itemView.findViewById(R.id.cardTemplateItem);
                tvSubCategory = itemView.findViewById(R.id.tvSubCategoryBadge);
                tvCategory = itemView.findViewById(R.id.tvCategoryLabel);
                tvTitle = itemView.findViewById(R.id.tvTemplateTitle);
                tvDescription = itemView.findViewById(R.id.tvTemplateDescription);

                btnEdit = itemView.findViewById(R.id.btnEditTemplate);
                btnView = itemView.findViewById(R.id.btnViewTemplate);
                btnDuplicate = itemView.findViewById(R.id.btnDuplicateTemplate);
                btnDelete = itemView.findViewById(R.id.btnDeleteTemplate);
            }
        }
    }
}
