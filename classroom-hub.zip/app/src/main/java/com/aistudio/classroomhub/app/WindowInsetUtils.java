package com.aistudio.classroomhub.app;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class WindowInsetUtils {

    /**
     * Dynamically applies system bar insets (status bar / camera notch / punch hole top inset
     * and gesture navigation bar bottom inset) to the root view of an Activity.
     */
    public static void applySystemBarPadding(Activity activity) {
        if (activity == null) return;
        View rootView = activity.findViewById(android.R.id.content);
        if (rootView == null) return;

        View targetView = rootView;
        if (rootView instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) rootView;
            if (group.getChildCount() > 0) {
                targetView = group.getChildAt(0);
            }
        }

        final View viewToPad = targetView;
        final int initialPaddingLeft = viewToPad.getPaddingLeft();
        final int initialPaddingTop = viewToPad.getPaddingTop();
        final int initialPaddingRight = viewToPad.getPaddingRight();
        final int initialPaddingBottom = viewToPad.getPaddingBottom();

        ViewCompat.setOnApplyWindowInsetsListener(viewToPad, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(
                    initialPaddingLeft + systemBars.left,
                    initialPaddingTop + systemBars.top,
                    initialPaddingRight + systemBars.right,
                    initialPaddingBottom + systemBars.bottom
            );
            return insets;
        });
    }
}
