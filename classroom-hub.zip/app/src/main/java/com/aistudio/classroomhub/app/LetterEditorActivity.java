package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.Spannable;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LetterEditorActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TextView tvEditorTitle;
    private MaterialButton btnSaveDocument, btnSaveTemplate;
    private MaterialButton btnExportDocx, btnExportPdf;
    private MaterialButton btnToggleViewMode, btnPageSize, btnPageOrientation;
    private MaterialButton btnZoomOut, btnZoomIn, btnZoomReset;
    private TextView tvZoomLevel;
    private MaterialButton btnInsertSchoolHeader, btnFillPlaceholders;

    private MaterialButton btnFormatBold, btnFormatItalic, btnFormatUnderline;
    private MaterialButton btnTextSizeSmall, btnTextSizeLarge;
    private MaterialButton btnAlignLeft, btnAlignCenter, btnAlignRight;
    private View btnColorBlack, btnColorNavy, btnColorRed, btnColorBlue;

    private MaterialCardView cardA4Paper;
    private LinearLayout layoutPaperContent;
    private TextView tvA4HeaderBanner, tvPaperFooterWatermark;
    private EditText etLetterDocumentContent;
    private ScrollView editorScrollView;
    private ScaleGestureDetector scaleGestureDetector;

    private LetterTemplate currentTemplate;
    private float baseTextSize;

    // View States
    private boolean isPrintPreviewMode = false;
    private String currentPageSize = "A4"; // "A4", "A3", "Letter", "Legal"
    private String currentOrientation = "PORTRAIT"; // "PORTRAIT", "LANDSCAPE"
    private int currentZoomPercent = 100; // 50 to 200

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_letter_editor);
        WindowInsetUtils.applySystemBarPadding(this);

        if (getIntent().hasExtra("template_obj")) {
            currentTemplate = (LetterTemplate) getIntent().getSerializableExtra("template_obj");
        }

        initViews();
        setupListeners();
        loadInitialContent();
        applyViewModeAndPageSetup();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvEditorTitle = findViewById(R.id.tvEditorTitle);
        btnSaveDocument = findViewById(R.id.btnSaveDocument);
        btnSaveTemplate = findViewById(R.id.btnSaveTemplate);
        btnExportDocx = findViewById(R.id.btnExportDocx);
        btnExportPdf = findViewById(R.id.btnExportPdf);

        btnToggleViewMode = findViewById(R.id.btnToggleViewMode);
        btnPageSize = findViewById(R.id.btnPageSize);
        btnPageOrientation = findViewById(R.id.btnPageOrientation);

        btnZoomOut = findViewById(R.id.btnZoomOut);
        btnZoomIn = findViewById(R.id.btnZoomIn);
        btnZoomReset = findViewById(R.id.btnZoomReset);
        tvZoomLevel = findViewById(R.id.tvZoomLevel);

        btnInsertSchoolHeader = findViewById(R.id.btnInsertSchoolHeader);
        btnFillPlaceholders = findViewById(R.id.btnFillPlaceholders);

        btnFormatBold = findViewById(R.id.btnFormatBold);
        btnFormatItalic = findViewById(R.id.btnFormatItalic);
        btnFormatUnderline = findViewById(R.id.btnFormatUnderline);
        btnTextSizeSmall = findViewById(R.id.btnTextSizeSmall);
        btnTextSizeLarge = findViewById(R.id.btnTextSizeLarge);
        btnAlignLeft = findViewById(R.id.btnAlignLeft);
        btnAlignCenter = findViewById(R.id.btnAlignCenter);
        btnAlignRight = findViewById(R.id.btnAlignRight);

        btnColorBlack = findViewById(R.id.btnColorBlack);
        btnColorNavy = findViewById(R.id.btnColorNavy);
        btnColorRed = findViewById(R.id.btnColorRed);
        btnColorBlue = findViewById(R.id.btnColorBlue);

        cardA4Paper = findViewById(R.id.cardA4Paper);
        layoutPaperContent = findViewById(R.id.layoutPaperContent);
        tvA4HeaderBanner = findViewById(R.id.tvA4HeaderBanner);
        tvPaperFooterWatermark = findViewById(R.id.tvPaperFooterWatermark);
        etLetterDocumentContent = findViewById(R.id.etLetterDocumentContent);
        editorScrollView = findViewById(R.id.editorScrollView);

        baseTextSize = spToPx14();
    }

    private void loadInitialContent() {
        if (currentTemplate != null) {
            tvEditorTitle.setText(currentTemplate.getTitle());
            etLetterDocumentContent.setText(currentTemplate.getContent());
            if (currentTemplate.getPageSize() != null) {
                currentPageSize = currentTemplate.getPageSize();
            }
            if (currentTemplate.getOrientation() != null) {
                currentOrientation = currentTemplate.getOrientation();
            }
        } else {
            tvEditorTitle.setText("Official Letter Editor");
            etLetterDocumentContent.setText("[Date]\n\nTo: [Recipient Name]\n[Recipient Address]\n\nSubject: [Subject Title]\n\nRespected Sir/Madam,\n\nType letter body content here...\n\nThanking you,\n\nYours faithfully,\n\n______________________\n[Your Name]\n[Designation]");
        }
    }

    private void setupListeners() {
        if (btnBack != null) btnBack.setVisibility(View.GONE);

        // Touch Pinch-to-Zoom Gesture Setup
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float scaleFactor = detector.getScaleFactor();
                currentZoomPercent = Math.max(50, Math.min(250, (int) (currentZoomPercent * scaleFactor)));
                applyZoom();
                return true;
            }
        });

        if (editorScrollView != null) {
            editorScrollView.setOnTouchListener((v, event) -> {
                if (scaleGestureDetector != null) {
                    scaleGestureDetector.onTouchEvent(event);
                }
                return false;
            });
        }

        // Save Document & Custom Template
        if (btnSaveDocument != null) {
            btnSaveDocument.setOnClickListener(v -> showSaveDocumentDialog());
        }

        if (btnSaveTemplate != null) {
            btnSaveTemplate.setOnClickListener(v -> showSaveCustomTemplateDialog());
        }

        // View Mode Toggle
        if (btnToggleViewMode != null) {
            btnToggleViewMode.setOnClickListener(v -> {
                isPrintPreviewMode = !isPrintPreviewMode;
                applyViewModeAndPageSetup();
                ToastHelper.showShort(this, isPrintPreviewMode ? "Switched to Print Preview Mode" : "Switched to Mobile Typing View");
            });
        }

        // Page Size Selector
        if (btnPageSize != null) {
            btnPageSize.setOnClickListener(v -> showPageSizeSelectionDialog());
        }

        // Page Orientation Selector
        if (btnPageOrientation != null) {
            btnPageOrientation.setOnClickListener(v -> {
                currentOrientation = "PORTRAIT".equalsIgnoreCase(currentOrientation) ? "LANDSCAPE" : "PORTRAIT";
                applyViewModeAndPageSetup();
            });
        }

        // Zoom Controls
        if (btnZoomOut != null) {
            btnZoomOut.setOnClickListener(v -> {
                if (currentZoomPercent > 50) {
                    currentZoomPercent -= 10;
                    applyZoom();
                }
            });
        }

        if (btnZoomIn != null) {
            btnZoomIn.setOnClickListener(v -> {
                if (currentZoomPercent < 200) {
                    currentZoomPercent += 10;
                    applyZoom();
                }
            });
        }

        if (btnZoomReset != null) {
            btnZoomReset.setOnClickListener(v -> {
                currentZoomPercent = 100;
                applyZoom();
            });
        }

        // Downloads
        if (btnExportDocx != null) {
            btnExportDocx.setOnClickListener(v -> exportWordDocx());
        }

        if (btnExportPdf != null) {
            btnExportPdf.setOnClickListener(v -> exportPdfDocument());
        }

        // Quick Tools
        if (btnInsertSchoolHeader != null) {
            btnInsertSchoolHeader.setOnClickListener(v -> insertSchoolHeaderToTop());
        }

        if (btnFillPlaceholders != null) {
            btnFillPlaceholders.setOnClickListener(v -> showFillPlaceholdersDialog());
        }

        // Formatting Toolbar Actions
        if (btnFormatBold != null) {
            btnFormatBold.setOnClickListener(v -> applySpanToSelection(new StyleSpan(Typeface.BOLD)));
        }

        if (btnFormatItalic != null) {
            btnFormatItalic.setOnClickListener(v -> applySpanToSelection(new StyleSpan(Typeface.ITALIC)));
        }

        if (btnFormatUnderline != null) {
            btnFormatUnderline.setOnClickListener(v -> applySpanToSelection(new UnderlineSpan()));
        }

        if (btnTextSizeSmall != null) {
            btnTextSizeSmall.setOnClickListener(v -> {
                if (baseTextSize > spToPx10()) {
                    baseTextSize -= 2;
                    applyZoom();
                }
            });
        }

        if (btnTextSizeLarge != null) {
            btnTextSizeLarge.setOnClickListener(v -> {
                if (baseTextSize < spToPx28()) {
                    baseTextSize += 2;
                    applyZoom();
                }
            });
        }

        if (btnAlignLeft != null) {
            btnAlignLeft.setOnClickListener(v -> etLetterDocumentContent.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START));
        }

        if (btnAlignCenter != null) {
            btnAlignCenter.setOnClickListener(v -> etLetterDocumentContent.setTextAlignment(View.TEXT_ALIGNMENT_CENTER));
        }

        if (btnAlignRight != null) {
            btnAlignRight.setOnClickListener(v -> etLetterDocumentContent.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END));
        }

        if (btnColorBlack != null) btnColorBlack.setOnClickListener(v -> applyColorSpan(0xFF000000));
        if (btnColorNavy != null) btnColorNavy.setOnClickListener(v -> applyColorSpan(0xFF1E293B));
        if (btnColorRed != null) btnColorRed.setOnClickListener(v -> applyColorSpan(0xFF991B1B));
        if (btnColorBlue != null) btnColorBlue.setOnClickListener(v -> applyColorSpan(0xFF1D4ED8));
    }

    private void applyViewModeAndPageSetup() {
        if (btnToggleViewMode != null) {
            btnToggleViewMode.setText(isPrintPreviewMode ? "📄 A4 Print Preview" : "📱 Mobile Edit View");
        }

        if (btnPageSize != null) {
            btnPageSize.setText("📐 Size: " + currentPageSize);
        }

        if (btnPageOrientation != null) {
            btnPageOrientation.setText("PORTRAIT".equalsIgnoreCase(currentOrientation) ? "🖼️ Portrait" : "🖼️ Landscape");
        }

        if (isPrintPreviewMode) {
            // True A4 Print Preview Mode (Realistic White Paper Canvas with Shadows & Official Margins)
            if (tvA4HeaderBanner != null) {
                tvA4HeaderBanner.setVisibility(View.VISIBLE);
                tvA4HeaderBanner.setText("📄 A4 PRINT PREVIEW (" + currentPageSize + " - " + currentOrientation + ") | Official Margins");
            }
            if (tvPaperFooterWatermark != null) {
                tvPaperFooterWatermark.setVisibility(View.VISIBLE);
            }

            if (cardA4Paper != null) {
                cardA4Paper.setCardElevation(dpToPx(16));
                cardA4Paper.setStrokeColor(0xFF94A3B8);
                cardA4Paper.setCardBackgroundColor(0xFFFFFFFF);

                ViewGroup.LayoutParams lp = cardA4Paper.getLayoutParams();
                if ("LANDSCAPE".equalsIgnoreCase(currentOrientation)) {
                    cardA4Paper.setMinimumHeight(dpToPx(480));
                } else {
                    cardA4Paper.setMinimumHeight(dpToPx(680));
                }
                cardA4Paper.setLayoutParams(lp);
            }

            if (etLetterDocumentContent != null) {
                etLetterDocumentContent.setTypeface(Typeface.SERIF);
                etLetterDocumentContent.setLineSpacing(0, 1.35f);
            }

        } else {
            // Mobile Text Edit View (Responsive Typing Mode)
            if (tvA4HeaderBanner != null) {
                tvA4HeaderBanner.setVisibility(View.GONE);
            }
            if (tvPaperFooterWatermark != null) {
                tvPaperFooterWatermark.setVisibility(View.GONE);
            }

            if (cardA4Paper != null) {
                cardA4Paper.setCardElevation(dpToPx(4));
                cardA4Paper.setStrokeColor(0xFFCBD5E1);
                cardA4Paper.setCardBackgroundColor(0xFFFFFFFF);
                cardA4Paper.setMinimumHeight(dpToPx(550));
            }

            if (etLetterDocumentContent != null) {
                etLetterDocumentContent.setTypeface(Typeface.DEFAULT);
                etLetterDocumentContent.setLineSpacing(0, 1.2f);
            }
        }

        applyZoom();
    }

    private void applyZoom() {
        if (tvZoomLevel != null) {
            tvZoomLevel.setText(currentZoomPercent + "%");
        }

        float scaleFactor = currentZoomPercent / 100f;
        float scaledTextSize = baseTextSize * scaleFactor;
        if (etLetterDocumentContent != null) {
            etLetterDocumentContent.setTextSize(pxToSp(scaledTextSize));
        }

        // Scale paper canvas smoothly in print preview mode
        if (cardA4Paper != null) {
            if (isPrintPreviewMode) {
                cardA4Paper.setPivotX(cardA4Paper.getWidth() / 2f);
                cardA4Paper.setPivotY(0f);
                cardA4Paper.setScaleX(scaleFactor);
                cardA4Paper.setScaleY(scaleFactor);
            } else {
                cardA4Paper.setScaleX(1.0f);
                cardA4Paper.setScaleY(1.0f);
            }
        }
    }

    private void showPageSizeSelectionDialog() {
        String[] options = {"A4 (Standard 210 x 297 mm)", "A3 (Large 297 x 420 mm)", "Letter (US 8.5 x 11 in)", "Legal (US 8.5 x 14 in)"};
        int selectedIndex = 0;
        if ("A3".equalsIgnoreCase(currentPageSize)) selectedIndex = 1;
        else if ("Letter".equalsIgnoreCase(currentPageSize)) selectedIndex = 2;
        else if ("Legal".equalsIgnoreCase(currentPageSize)) selectedIndex = 3;

        new AlertDialog.Builder(this)
                .setTitle("Select Paper Canvas Size")
                .setSingleChoiceItems(options, selectedIndex, (dialog, which) -> {
                    switch (which) {
                        case 0: currentPageSize = "A4"; break;
                        case 1: currentPageSize = "A3"; break;
                        case 2: currentPageSize = "Letter"; break;
                        case 3: currentPageSize = "Legal"; break;
                    }
                    applyViewModeAndPageSetup();
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showSaveDocumentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("💾 Save Document to Firestore");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_save_document, null);
        builder.setView(dialogView);

        EditText etTitle = dialogView.findViewById(R.id.etDocumentTitle);
        if (currentTemplate != null && currentTemplate.getTitle() != null) {
            etTitle.setText(currentTemplate.getTitle());
        }

        builder.setPositiveButton("Save", (dialog, which) -> {
            String titleStr = etTitle.getText().toString().trim();
            if (titleStr.isEmpty()) titleStr = "Untitled Document";

            LetterTemplate savedDoc = new LetterTemplate();
            savedDoc.setId("doc_" + System.currentTimeMillis());
            savedDoc.setTitle(titleStr);
            savedDoc.setContent(etLetterDocumentContent.getText().toString());
            savedDoc.setPageSize(currentPageSize);
            savedDoc.setOrientation(currentOrientation);
            savedDoc.setSavedDocument(true);

            LetterCloudManager.saveLetterToCloud(this, savedDoc, new LetterCloudManager.FirestoreCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean result) {
                    ToastHelper.showShort(LetterEditorActivity.this, "✅ Document saved successfully to Firestore!");
                }

                @Override
                public void onError(Exception e) {
                    ToastHelper.showShort(LetterEditorActivity.this, "Saved locally");
                }
            });
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showSaveCustomTemplateDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🎨 Save as Custom Template");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_save_document, null);
        builder.setView(dialogView);

        EditText etTitle = dialogView.findViewById(R.id.etDocumentTitle);
        etTitle.setHint("Template Name (e.g., My School Transfer Draft)");

        builder.setPositiveButton("Save Template", (dialog, which) -> {
            String titleStr = etTitle.getText().toString().trim();
            if (titleStr.isEmpty()) titleStr = "My Custom Template";

            LetterTemplate customTmpl = new LetterTemplate();
            customTmpl.setId("tmpl_" + System.currentTimeMillis());
            customTmpl.setTitle(titleStr);
            customTmpl.setContent(etLetterDocumentContent.getText().toString());
            customTmpl.setPageSize(currentPageSize);
            customTmpl.setOrientation(currentOrientation);
            customTmpl.setCustomTemplate(true);
            customTmpl.setSubCategory("Custom");
            customTmpl.setDescription("User created template");

            LetterCloudManager.saveCustomTemplateToCloud(this, customTmpl, new LetterCloudManager.FirestoreCallback<Boolean>() {
                @Override
                public void onSuccess(Boolean result) {
                    ToastHelper.showShort(LetterEditorActivity.this, "✅ Custom Template saved to Firestore!");
                }

                @Override
                public void onError(Exception e) {
                    ToastHelper.showShort(LetterEditorActivity.this, "Template saved locally");
                }
            });
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void applySpanToSelection(Object span) {
        int start = etLetterDocumentContent.getSelectionStart();
        int end = etLetterDocumentContent.getSelectionEnd();
        if (start < 0 || end < 0 || start >= end) {
            ToastHelper.showShort(this, "Select text to apply formatting");
            return;
        }
        Editable editable = etLetterDocumentContent.getText();
        editable.setSpan(span, start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void applyColorSpan(int colorInt) {
        int start = etLetterDocumentContent.getSelectionStart();
        int end = etLetterDocumentContent.getSelectionEnd();
        if (start < 0 || end < 0 || start >= end) {
            etLetterDocumentContent.setTextColor(colorInt);
            return;
        }
        Editable editable = etLetterDocumentContent.getText();
        editable.setSpan(new ForegroundColorSpan(colorInt), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void insertSchoolHeaderToTop() {
        SharedPreferences prefs = getSharedPreferences("school_header_prefs", Context.MODE_PRIVATE);
        String schoolName = prefs.getString("school_name", "මධ්‍ය මහා විද්‍යාලය - කොළඹ (Central College)");
        String schoolAddress = prefs.getString("school_address", "නො. 123, ගාලු පාර, කොළඹ 03 | Tel: 011-2345678");
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        String headerBlock = schoolName.toUpperCase() + "\n" +
                schoolAddress + "\n" +
                "--------------------------------------------------------------------------------\n" +
                "Date: " + todayDate + "\n\n";

        String currentText = etLetterDocumentContent.getText().toString();
        etLetterDocumentContent.setText(headerBlock + currentText);
        ToastHelper.showShort(this, "School Letterhead Header inserted!");
    }

    private void showFillPlaceholdersDialog() {
        String content = etLetterDocumentContent.getText().toString();

        Pattern pattern = Pattern.compile("\\[([^\\]]+)\\]");
        Matcher matcher = pattern.matcher(content);

        Set<String> placeholdersSet = new LinkedHashSet<>();
        while (matcher.find()) {
            placeholdersSet.add(matcher.group(1));
        }

        if (placeholdersSet.isEmpty()) {
            ToastHelper.showShort(this, "No [Placeholders] detected in this document.");
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_fill_placeholders, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        LinearLayout container = dialogView.findViewById(R.id.layoutPlaceholderInputsContainer);
        MaterialButton btnCancel = dialogView.findViewById(R.id.btnCancelPlaceholders);
        MaterialButton btnApply = dialogView.findViewById(R.id.btnApplyPlaceholders);

        SharedPreferences prefs = getSharedPreferences("school_header_prefs", Context.MODE_PRIVATE);
        String savedSchool = prefs.getString("school_name", "මධ්‍ය මහා විද්‍යාලය");

        Map<String, EditText> inputMap = new HashMap<>();

        for (String placeholderKey : placeholdersSet) {
            LinearLayout itemLayout = new LinearLayout(this);
            itemLayout.setOrientation(LinearLayout.VERTICAL);
            itemLayout.setPadding(0, 0, 0, dpToPx(12));

            TextView label = new TextView(this);
            label.setText("  • [" + placeholderKey + "]");
            label.setTextColor(0xFF38BDF8);
            label.setTextSize(13);
            label.setTypeface(Typeface.DEFAULT_BOLD);
            itemLayout.addView(label);

            EditText etInput = new EditText(this);
            etInput.setTextColor(0xFFFFFFFF);
            etInput.setTextSize(14);
            etInput.setBackgroundResource(R.drawable.bg_dialog_input_field);
            etInput.setPadding(dpToPx(12), dpToPx(8), dpToPx(12), dpToPx(8));

            String keyLower = placeholderKey.toLowerCase();
            if (keyLower.contains("date")) {
                etInput.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
            } else if (keyLower.contains("school name") || keyLower.contains("school")) {
                etInput.setText(savedSchool);
            } else if (keyLower.contains("year")) {
                etInput.setText("2026");
            }

            inputMap.put(placeholderKey, etInput);
            itemLayout.addView(etInput);
            container.addView(itemLayout);
        }

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnApply.setOnClickListener(v -> {
            String updatedContent = etLetterDocumentContent.getText().toString();
            for (Map.Entry<String, EditText> entry : inputMap.entrySet()) {
                String key = entry.getKey();
                String val = entry.getValue().getText().toString().trim();
                if (!val.isEmpty()) {
                    updatedContent = updatedContent.replace("[" + key + "]", val);
                }
            }
            etLetterDocumentContent.setText(updatedContent);
            dialog.dismiss();
            ToastHelper.showShort(LetterEditorActivity.this, "Placeholders updated in document!");
        });

        dialog.show();
    }

    private void exportWordDocx() {
        String title = currentTemplate != null ? currentTemplate.getTitle() : "School_Letter";
        String content = etLetterDocumentContent.getText().toString();

        File docxFile = DocxGenerator.createDocxFile(this, title, content, currentPageSize, currentOrientation);
        if (docxFile != null && docxFile.exists()) {
            ToastHelper.showLong(this, "✅ Word Document exported to Downloads:\n" + docxFile.getName());
            LetterPdfExporter.openFile(this, docxFile, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        } else {
            ToastHelper.showShort(this, "Failed to export Word document.");
        }
    }

    private void exportPdfDocument() {
        String title = currentTemplate != null ? currentTemplate.getTitle() : "School_Letter";
        String content = etLetterDocumentContent.getText().toString();

        File pdfFile = LetterPdfExporter.exportLetterToPdf(this, title, content, false, currentPageSize, currentOrientation);
        if (pdfFile != null && pdfFile.exists()) {
            ToastHelper.showLong(this, "✅ PDF Document exported to Downloads:\n" + pdfFile.getName());
            LetterPdfExporter.openFile(this, pdfFile, "application/pdf");
        } else {
            ToastHelper.showShort(this, "Failed to export PDF document.");
        }
    }

    private float spToPx(float sp) {
        return sp * getResources().getDisplayMetrics().scaledDensity;
    }

    private float pxToSp(float px) {
        return px / getResources().getDisplayMetrics().scaledDensity;
    }

    private float spToPx14() {
        return spToPx(14);
    }

    private float spToPx10() {
        return spToPx(10);
    }

    private float spToPx28() {
        return spToPx(28);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
