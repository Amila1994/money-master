package com.aistudio.classroomhub.app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class AddStudentDialogHelper {

    public interface OnStudentAddedListener {
        void onStudentAdded(Student student);
    }

    public interface OnStudentUpdatedListener {
        void onStudentUpdated(Student student);
    }

    public static void showAddStudentDialog(final Activity activity, final OnStudentAddedListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Add New Student (ළමයා එකතු කරන්න)");

        View dialogView = LayoutInflater.from(activity).inflate(R.layout.dialog_add_student, null);

        final EditText etName = dialogView.findViewById(R.id.etDialogStudentName);
        final EditText etInitials = dialogView.findViewById(R.id.etDialogInitials);
        final EditText etDob = dialogView.findViewById(R.id.etDialogDob);
        final TextView tvCalculatedAge = dialogView.findViewById(R.id.tvDialogCalculatedAge);
        final Spinner spinnerGender = dialogView.findViewById(R.id.spinnerDialogGender);
        final EditText etEthRel = dialogView.findViewById(R.id.etDialogEthRel);

        final EditText etRollNo = dialogView.findViewById(R.id.etDialogRollNo);
        final Spinner spinnerGrade = dialogView.findViewById(R.id.spinnerDialogGrade);
        final EditText etMedium = dialogView.findViewById(R.id.etDialogMedium);
        final EditText etAddress = dialogView.findViewById(R.id.etDialogAddress);

        final EditText etFather = dialogView.findViewById(R.id.etDialogFather);
        final EditText etFatherPhone = dialogView.findViewById(R.id.etDialogFatherPhone);
        final EditText etMother = dialogView.findViewById(R.id.etDialogMother);
        final EditText etMotherPhone = dialogView.findViewById(R.id.etDialogMotherPhone);

        final EditText etGuardian = dialogView.findViewById(R.id.etDialogGuardian);
        final EditText etEmergencyName = dialogView.findViewById(R.id.etDialogEmergencyName);
        final EditText etContact = dialogView.findViewById(R.id.etDialogContact);
        final EditText etMarks = dialogView.findViewById(R.id.etDialogMarks);

        // 1. DOB DatePicker & Age Calculation
        final Calendar selectedDobCal = Calendar.getInstance();
        etDob.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    activity,
                    (view, year, month, dayOfMonth) -> {
                        selectedDobCal.set(year, month, dayOfMonth);
                        String formattedDob = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        etDob.setText(formattedDob);

                        // Calculate age
                        Calendar today = Calendar.getInstance();
                        int ageYears = today.get(Calendar.YEAR) - year;
                        int ageMonths = today.get(Calendar.MONTH) - month;
                        if (today.get(Calendar.DAY_OF_MONTH) < dayOfMonth) {
                            ageMonths--;
                        }
                        if (ageMonths < 0) {
                            ageYears--;
                            ageMonths += 12;
                        }
                        if (ageYears < 0) ageYears = 0;

                        if (tvCalculatedAge != null) {
                            tvCalculatedAge.setText("ස්වයංක්‍රීය වයස (Calculated Age): " + ageYears + " වසර " + ageMonths + " මාස");
                        }
                    },
                    calendar.get(Calendar.YEAR) - 14,
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        // 2. Gender Dropdown Setup
        final String[] genderOptions = new String[]{"පිරිමි (Male)", "ගැහැණු (Female)"};
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, genderOptions);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spinnerGender != null) {
            spinnerGender.setAdapter(genderAdapter);
        }

        // 3. Grade/Class Dropdown Setup with "+ අලුත් පන්තියක් එකතු කරන්න"
        final List<ClassModel> existingClasses = new ArrayList<>(ClassRepository.getClasses());
        final List<String> gradeItems = new ArrayList<>();
        for (ClassModel c : existingClasses) {
            gradeItems.add(c.getDisplayName());
        }
        gradeItems.add("➕ අලුත් පන්තියක් එකතු කරන්න (Add New Class)");

        final ArrayAdapter<String> gradeAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, gradeItems);
        gradeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        if (spinnerGrade != null) {
            spinnerGrade.setAdapter(gradeAdapter);

            // Select active class by default if available
            ClassModel activeClass = ClassRepository.getActiveClass();
            if (activeClass != null) {
                for (int i = 0; i < existingClasses.size(); i++) {
                    if (existingClasses.get(i).getId().equals(activeClass.getId())) {
                        spinnerGrade.setSelection(i);
                        break;
                    }
                }
            }

            // Auto-generate permanent registration number based on selected grade
            spinnerGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == gradeItems.size() - 1) {
                        // User selected "+ Add New Class"
                        showAddNewClassSubDialog(activity, new OnClassAddedListener() {
                            @Override
                            public void onClassAdded(ClassModel newClass) {
                                existingClasses.add(newClass);
                                gradeItems.add(gradeItems.size() - 1, newClass.getDisplayName());
                                gradeAdapter.notifyDataSetChanged();
                                spinnerGrade.setSelection(gradeItems.size() - 2);
                            }
                        });
                    } else if (position < existingClasses.size()) {
                        ClassModel targetClass = existingClasses.get(position);
                        String autoRegNo = StudentRepository.getNextRegistrationNumber(targetClass.getId());
                        if (etRollNo != null) {
                            etRollNo.setText(autoRegNo);
                        }
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        // Set initial auto-generated registration number if not yet set
        if (etRollNo != null && (etRollNo.getText() == null || etRollNo.getText().toString().trim().isEmpty())) {
            ClassModel active = ClassRepository.getActiveClass();
            String initialClassId = active != null ? active.getId() : "class_10a_2026";
            etRollNo.setText(StudentRepository.getNextRegistrationNumber(initialClassId));
        }

        builder.setView(dialogView);
        builder.setPositiveButton("Add (එකතු කරන්න)", (dialog, which) -> {
            String name = etName != null ? etName.getText().toString().trim() : "";
            String roll = etRollNo != null ? etRollNo.getText().toString().trim() : "";
            String marksStr = etMarks != null ? etMarks.getText().toString().trim() : "";

            if (name.isEmpty()) {
                Toast.makeText(activity, "කරුණාකර ශිෂ්‍යයාගේ නම ඇතුලත් කරන්න.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Determine selected grade & class
            String selectedGrade = "Grade 10-A";
            String selectedClassId = "";
            if (spinnerGrade != null) {
                int pos = spinnerGrade.getSelectedItemPosition();
                if (pos < existingClasses.size()) {
                    selectedGrade = existingClasses.get(pos).getDisplayName();
                    selectedClassId = existingClasses.get(pos).getId();
                }
            }

            if (roll.isEmpty()) {
                roll = StudentRepository.getNextRegistrationNumber(selectedClassId);
            }

            int marks = 80;
            if (!marksStr.isEmpty()) {
                try {
                    marks = Integer.parseInt(marksStr);
                } catch (NumberFormatException ignored) {}
            }

            // Determine selected gender
            String selectedGender = "පිරිමි";
            if (spinnerGender != null) {
                int pos = spinnerGender.getSelectedItemPosition();
                if (pos == 1) {
                    selectedGender = "ගැහැණු";
                }
            }

            Student newStudent = new Student(UUID.randomUUID().toString(), name, roll, selectedGrade, marks, true);
            newStudent.setGender(selectedGender);
            if (!selectedClassId.isEmpty()) {
                newStudent.setClassId(selectedClassId);
            }

            if (etInitials != null) newStudent.setNameWithInitials(etInitials.getText().toString().trim());
            if (etDob != null) newStudent.setDob(etDob.getText().toString().trim());
            if (etEthRel != null) newStudent.setEthnicity(etEthRel.getText().toString().trim());
            if (etMedium != null) newStudent.setMedium(etMedium.getText().toString().trim());
            if (etAddress != null) newStudent.setPermAddress(etAddress.getText().toString().trim());
            if (etFather != null) newStudent.setFatherName(etFather.getText().toString().trim());
            if (etFatherPhone != null) newStudent.setFatherPhone(etFatherPhone.getText().toString().trim());
            if (etMother != null) newStudent.setMotherName(etMother.getText().toString().trim());
            if (etMotherPhone != null) newStudent.setMotherPhone(etMotherPhone.getText().toString().trim());
            if (etGuardian != null) newStudent.setGuardianName(etGuardian.getText().toString().trim());
            if (etEmergencyName != null) newStudent.setEmergencyName(etEmergencyName.getText().toString().trim());
            if (etContact != null) newStudent.setEmergencyPhone(etContact.getText().toString().trim());

            StudentRepository.addStudent(newStudent);
            DataBackupManager.saveLocalState(activity);

            Toast.makeText(activity, name + " සාර්ථකව ඇතුළත් කරන ලදී! (Reg No: " + roll + ")", Toast.LENGTH_SHORT).show();

            if (listener != null) {
                listener.onStudentAdded(newStudent);
            }
        });

        builder.setNegativeButton("Cancel (අවලංගු කරන්න)", null);
        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }
        dialog.show();
    }

    public static void showEditStudentDialog(final Activity activity, final Student student, final OnStudentUpdatedListener listener) {
        if (student == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Edit Student Details (ශිෂ්‍ය තොරතුරු සංස්කරණය)");

        View dialogView = LayoutInflater.from(activity).inflate(R.layout.dialog_add_student, null);

        final EditText etName = dialogView.findViewById(R.id.etDialogStudentName);
        final EditText etInitials = dialogView.findViewById(R.id.etDialogInitials);
        final EditText etDob = dialogView.findViewById(R.id.etDialogDob);
        final TextView tvCalculatedAge = dialogView.findViewById(R.id.tvDialogCalculatedAge);
        final Spinner spinnerGender = dialogView.findViewById(R.id.spinnerDialogGender);
        final EditText etEthRel = dialogView.findViewById(R.id.etDialogEthRel);

        final EditText etRollNo = dialogView.findViewById(R.id.etDialogRollNo);
        final Spinner spinnerGrade = dialogView.findViewById(R.id.spinnerDialogGrade);
        final EditText etMedium = dialogView.findViewById(R.id.etDialogMedium);
        final EditText etAddress = dialogView.findViewById(R.id.etDialogAddress);

        final EditText etFather = dialogView.findViewById(R.id.etDialogFather);
        final EditText etFatherPhone = dialogView.findViewById(R.id.etDialogFatherPhone);
        final EditText etMother = dialogView.findViewById(R.id.etDialogMother);
        final EditText etMotherPhone = dialogView.findViewById(R.id.etDialogMotherPhone);

        final EditText etGuardian = dialogView.findViewById(R.id.etDialogGuardian);
        final EditText etEmergencyName = dialogView.findViewById(R.id.etDialogEmergencyName);
        final EditText etContact = dialogView.findViewById(R.id.etDialogContact);
        final EditText etMarks = dialogView.findViewById(R.id.etDialogMarks);

        // Pre-fill student data
        if (etName != null) etName.setText(student.getName());
        if (etInitials != null) etInitials.setText(student.getNameWithInitials());
        if (etDob != null) etDob.setText(student.getDob());
        if (etEthRel != null) etEthRel.setText(student.getEthnicity());
        if (etMedium != null) etMedium.setText(student.getMedium());
        if (etAddress != null) etAddress.setText(student.getPermAddress());
        if (etFather != null) etFather.setText(student.getFatherName());
        if (etFatherPhone != null) etFatherPhone.setText(student.getFatherPhone());
        if (etMother != null) etMother.setText(student.getMotherName());
        if (etMotherPhone != null) etMotherPhone.setText(student.getMotherPhone());
        if (etGuardian != null) etGuardian.setText(student.getGuardianName());
        if (etEmergencyName != null) etEmergencyName.setText(student.getEmergencyName());
        if (etContact != null) etContact.setText(student.getEmergencyPhone());
        if (etMarks != null) etMarks.setText(String.valueOf(student.getMarks()));

        // Preserve Permanent Registration Number (Display read-only / disabled)
        if (etRollNo != null) {
            etRollNo.setText(student.getRollNo());
            etRollNo.setEnabled(false);
            etRollNo.setFocusable(false);
        }

        // DOB DatePicker
        final Calendar selectedDobCal = Calendar.getInstance();
        etDob.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    activity,
                    (view, year, month, dayOfMonth) -> {
                        selectedDobCal.set(year, month, dayOfMonth);
                        String formattedDob = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        etDob.setText(formattedDob);

                        Calendar today = Calendar.getInstance();
                        int ageYears = today.get(Calendar.YEAR) - year;
                        int ageMonths = today.get(Calendar.MONTH) - month;
                        if (today.get(Calendar.DAY_OF_MONTH) < dayOfMonth) ageMonths--;
                        if (ageMonths < 0) { ageYears--; ageMonths += 12; }
                        if (ageYears < 0) ageYears = 0;

                        if (tvCalculatedAge != null) {
                            tvCalculatedAge.setText("ස්වයංක්‍රීය වයස (Calculated Age): " + ageYears + " වසර " + ageMonths + " මාස");
                        }
                    },
                    calendar.get(Calendar.YEAR) - 14,
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        // Gender Spinner
        final String[] genderOptions = new String[]{"පිරිමි (Male)", "ගැහැණු (Female)"};
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, genderOptions);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spinnerGender != null) {
            spinnerGender.setAdapter(genderAdapter);
            if (student.getGender() != null && (student.getGender().contains("ගැහැණු") || student.getGender().equalsIgnoreCase("Female"))) {
                spinnerGender.setSelection(1);
            } else {
                spinnerGender.setSelection(0);
            }
        }

        // Grade/Class Spinner
        final List<ClassModel> existingClasses = new ArrayList<>(ClassRepository.getClasses());
        final List<String> gradeItems = new ArrayList<>();
        int selectedClassIndex = 0;
        for (int i = 0; i < existingClasses.size(); i++) {
            ClassModel c = existingClasses.get(i);
            gradeItems.add(c.getDisplayName());
            if (c.getId().equals(student.getClassId()) || c.getDisplayName().equalsIgnoreCase(student.getGrade())) {
                selectedClassIndex = i;
            }
        }
        gradeItems.add("➕ අලුත් පන්තියක් එකතු කරන්න (Add New Class)");

        final ArrayAdapter<String> gradeAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, gradeItems);
        gradeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        if (spinnerGrade != null) {
            spinnerGrade.setAdapter(gradeAdapter);
            spinnerGrade.setSelection(selectedClassIndex);

            spinnerGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == gradeItems.size() - 1) {
                        showAddNewClassSubDialog(activity, new OnClassAddedListener() {
                            @Override
                            public void onClassAdded(ClassModel newClass) {
                                existingClasses.add(newClass);
                                gradeItems.add(gradeItems.size() - 1, newClass.getDisplayName());
                                gradeAdapter.notifyDataSetChanged();
                                spinnerGrade.setSelection(gradeItems.size() - 2);
                            }
                        });
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        builder.setView(dialogView);
        builder.setPositiveButton("Save Changes (සුරකින්න)", (dialog, which) -> {
            String name = etName != null ? etName.getText().toString().trim() : "";
            if (name.isEmpty()) {
                Toast.makeText(activity, "කරුණාකර නම ඇතුලත් කරන්න.", Toast.LENGTH_SHORT).show();
                return;
            }

            student.setName(name);

            if (etInitials != null) student.setNameWithInitials(etInitials.getText().toString().trim());
            if (etDob != null) student.setDob(etDob.getText().toString().trim());
            if (etEthRel != null) student.setEthnicity(etEthRel.getText().toString().trim());
            if (etMedium != null) student.setMedium(etMedium.getText().toString().trim());
            if (etAddress != null) student.setPermAddress(etAddress.getText().toString().trim());
            if (etFather != null) student.setFatherName(etFather.getText().toString().trim());
            if (etFatherPhone != null) student.setFatherPhone(etFatherPhone.getText().toString().trim());
            if (etMother != null) student.setMotherName(etMother.getText().toString().trim());
            if (etMotherPhone != null) student.setMotherPhone(etMotherPhone.getText().toString().trim());
            if (etGuardian != null) student.setGuardianName(etGuardian.getText().toString().trim());
            if (etEmergencyName != null) student.setEmergencyName(etEmergencyName.getText().toString().trim());
            if (etContact != null) student.setEmergencyPhone(etContact.getText().toString().trim());

            if (etMarks != null) {
                try {
                    student.setMarks(Integer.parseInt(etMarks.getText().toString().trim()));
                } catch (NumberFormatException ignored) {}
            }

            // Gender
            if (spinnerGender != null) {
                int pos = spinnerGender.getSelectedItemPosition();
                student.setGender(pos == 1 ? "ගැහැණු" : "පිරිමි");
            }

            // Grade/Class
            if (spinnerGrade != null) {
                int pos = spinnerGrade.getSelectedItemPosition();
                if (pos < existingClasses.size()) {
                    student.setGrade(existingClasses.get(pos).getDisplayName());
                    student.setClassId(existingClasses.get(pos).getId());
                }
            }

            // Update in repository & sync local state / cloud
            StudentRepository.updateStudent(student);
            DataBackupManager.saveLocalState(activity);

            Toast.makeText(activity, name + " ගේ විස්තර සාර්ථකව යාවත්කාලීන විය!", Toast.LENGTH_SHORT).show();

            if (listener != null) {
                listener.onStudentUpdated(student);
            }
        });

        builder.setNeutralButton("Delete (මකා දමන්න)", (dialog, which) -> {
            SafeDeleteHelper.showSafeDeleteDialog(activity, student, () -> {
                StudentRepository.removeStudent(activity, student);
                Toast.makeText(activity, student.getName() + " මකා දමන ලදී.", Toast.LENGTH_SHORT).show();
                if (listener != null) {
                    listener.onStudentUpdated(null);
                }
            });
        });

        builder.setNegativeButton("Cancel (අවලංගු කරන්න)", null);
        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }
        dialog.show();
    }

    public interface OnClassAddedListener {
        void onClassAdded(ClassModel newClass);
    }

    private static void showAddNewClassSubDialog(final Activity activity, final OnClassAddedListener callback) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("නව පන්තියක් එකතු කරන්න (Add Class)");

        android.widget.LinearLayout container = new android.widget.LinearLayout(activity);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        int padding = (int) (16 * activity.getResources().getDisplayMetrics().density);
        container.setPadding(padding, padding, padding, padding);

        final EditText etClassName = new EditText(activity);
        etClassName.setHint("පන්තියේ නම (උදා: Grade 10-A)");
        container.addView(etClassName);

        final EditText etYear = new EditText(activity);
        etYear.setHint("අධ්‍යයන වර්ෂය (උදා: 2026)");
        etYear.setText("2026");
        container.addView(etYear);

        builder.setView(container);
        builder.setPositiveButton("Save (සුරකින්න)", (dialog, which) -> {
            String name = etClassName.getText().toString().trim();
            String year = etYear.getText().toString().trim();
            if (year.isEmpty()) year = "2026";
            if (name.isEmpty()) {
                Toast.makeText(activity, "පන්තියේ නම ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                return;
            }
            ClassModel newClass = new ClassModel("class_" + System.currentTimeMillis(), name, year, "Class Teacher", false);
            ClassRepository.addClass(newClass);
            Toast.makeText(activity, name + " පන්තිය සාර්ථකව එකතු විය!", Toast.LENGTH_SHORT).show();
            if (callback != null) {
                callback.onClassAdded(newClass);
            }
        });
        builder.setNegativeButton("Cancel", null);
        AlertDialog dialog = builder.create();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }
        dialog.show();
    }
}
