package com.aistudio.classroomhub.app;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class AddStudentDialogHelper {

    public interface OnStudentAddedListener {
        void onStudentAdded(Student student);
    }

    public static void showAddStudentDialog(final Activity activity, final OnStudentAddedListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Add New Student (ළමයා එකතු කරන්න)");

        View dialogView = LayoutInflater.from(activity).inflate(R.layout.dialog_add_student, null);

        final EditText etName = dialogView.findViewById(R.id.etDialogStudentName);
        final EditText etInitials = dialogView.findViewById(R.id.etDialogInitials);
        final EditText etDob = dialogView.findViewById(R.id.etDialogDob);
        final TextView tvCalculatedAge = dialogView.findViewById(R.id.tvDialogCalculatedAge);
        final Spinner spinnerGender = dialogView.findViewById(R.id.spinnerDialogGender);
        final EditText etEthRel = dialogView.findViewById(R.id.etDialogEthRel);
        final EditText etBirthCert = dialogView.findViewById(R.id.etDialogBirthCert);
        final View btnSearchBcnHistory = dialogView.findViewById(R.id.btnSearchBcnHistory);

        if (btnSearchBcnHistory != null) {
            btnSearchBcnHistory.setOnClickListener(v -> {
                String bcn = etBirthCert != null ? etBirthCert.getText().toString().trim() : "";
                if (bcn.isEmpty()) {
                    Toast.makeText(activity, "කරුණාකර උප්පැන්න සහතික අංකය ඇතුළත් කරන්න (Enter BCN)", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(activity, "සෙවුම් තොරතුරු පරීක්ෂා කරමින්...", Toast.LENGTH_SHORT).show();
                com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        .collection("student_transfers")
                        .whereEqualTo("birthCertNo", bcn)
                        .get()
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful() && task.getResult() != null && !task.getResult().isEmpty()) {
                                StringBuilder historyText = new StringBuilder();
                                historyText.append("📜 ශිෂ්‍ය මාරුවීම් සහ ලියාපදිංචි ඉතිහාසය (Student BCN Transfer History):\n\n");
                                for (com.google.firebase.firestore.DocumentSnapshot doc : task.getResult().getDocuments()) {
                                    historyText.append("🏫 Previous School: ").append(doc.getString("schoolName") != null ? doc.getString("schoolName") : "N/A").append("\n");
                                    historyText.append("📅 Reg Date: ").append(doc.getString("regDate") != null ? doc.getString("regDate") : "N/A").append("\n");
                                    historyText.append("🚪 Departure Date: ").append(doc.getString("departureDate") != null ? doc.getString("departureDate") : "Active / Present").append("\n");
                                    historyText.append("👨‍🏫 Last Assigned Teacher: ").append(doc.getString("teacherName") != null ? doc.getString("teacherName") : "N/A");
                                    historyText.append(" (UID: ").append(doc.getString("teacherUid") != null ? doc.getString("teacherUid") : "N/A").append(")\n");
                                    historyText.append("-------------------------------------------\n\n");
                                }
                                new AlertDialog.Builder(activity)
                                        .setTitle("මාරුවීම් ඉතිහාසය (BCN History Found)")
                                        .setMessage(historyText.toString())
                                        .setPositiveButton("තහවුරුයි (OK)", null)
                                        .show();
                            } else {
                                new AlertDialog.Builder(activity)
                                        .setTitle("මාරුවීම් ඉතිහාසය (No Transfer History)")
                                        .setMessage("මෙම උප්පැන්න සහතික අංකයට (BCN: " + bcn + ") පූර්ව ලියාපදිංචි ඉතිහාසයක් Firestore හි හමු නොවීය. මෙය නව ඇතුළත් කිරීමකි.")
                                        .setPositiveButton("තහවුරුයි (OK)", null)
                                        .show();
                            }
                        });
            });
        }

        final EditText etRollNo = dialogView.findViewById(R.id.etDialogRollNo);
        final Spinner spinnerGrade = dialogView.findViewById(R.id.spinnerDialogGrade);
        final EditText etMedium = dialogView.findViewById(R.id.etDialogMedium);
        final EditText etAddress = dialogView.findViewById(R.id.etDialogAddress);

        final EditText etFather = dialogView.findViewById(R.id.etDialogFather);
        final EditText etFatherPhone = dialogView.findViewById(R.id.etDialogFatherPhone);
        final EditText etMother = dialogView.findViewById(R.id.etDialogMother);
        final EditText etMotherPhone = dialogView.findViewById(R.id.etDialogMotherPhone);

        final EditText etGuardian = dialogView.findViewById(R.id.etDialogGuardian);
        final EditText etEmergencyName = dialogView.findViewById(R.id.etDialogEmergencyName);
        final EditText etContact = dialogView.findViewById(R.id.etDialogContact);
        final EditText etMarks = dialogView.findViewById(R.id.etDialogMarks);

        // 1. DOB DatePicker & Age Calculation
        final Calendar selectedDobCal = Calendar.getInstance();
        etDob.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    activity,
                    (view, year, month, dayOfMonth) -> {
                        selectedDobCal.set(year, month, dayOfMonth);
                        String formattedDob = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
                        etDob.setText(formattedDob);

                        // Calculate age
                        Calendar today = Calendar.getInstance();
                        int ageYears = today.get(Calendar.YEAR) - year;
                        int ageMonths = today.get(Calendar.MONTH) - month;
                        if (today.get(Calendar.DAY_OF_MONTH) < dayOfMonth) {
                            ageMonths--;
                        }
                        if (ageMonths < 0) {
                            ageYears--;
                            ageMonths += 12;
                        }
                        if (ageYears < 0) ageYears = 0;

                        if (tvCalculatedAge != null) {
                            tvCalculatedAge.setText("ස්වයංක්‍රීය වයස (Calculated Age): " + ageYears + " වසර " + ageMonths + " මාස");
                        }
                    },
                    calendar.get(Calendar.YEAR) - 14,
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );
            datePickerDialog.show();
        });

        // 2. Gender Dropdown Setup
        final String[] genderOptions = new String[]{"පිරිමි (Male)", "ගැහැණු (Female)"};
        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, genderOptions);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spinnerGender != null) {
            spinnerGender.setAdapter(genderAdapter);
        }

        // 3. Grade/Class Dropdown Setup with "+ අලුත් පන්තියක් එකතු කරන්න"
        final List<ClassModel> existingClasses = new ArrayList<>(ClassRepository.getClasses());
        final List<String> gradeItems = new ArrayList<>();
        for (ClassModel c : existingClasses) {
            gradeItems.add(c.getDisplayName());
        }
        gradeItems.add("➕ අලුත් පන්තියක් එකතු කරන්න (Add New Class)");

        final ArrayAdapter<String> gradeAdapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_item, gradeItems);
        gradeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        if (spinnerGrade != null) {
            spinnerGrade.setAdapter(gradeAdapter);

            // Select active class by default if available
            ClassModel activeClass = ClassRepository.getActiveClass();
            if (activeClass != null) {
                for (int i = 0; i < existingClasses.size(); i++) {
                    if (existingClasses.get(i).getId().equals(activeClass.getId())) {
                        spinnerGrade.setSelection(i);
                        break;
                    }
                }
            }

            spinnerGrade.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position == gradeItems.size() - 1) {
                        // User selected "+ Add New Class"
                        showAddNewClassSubDialog(activity, new OnClassAddedListener() {
                            @Override
                            public void onClassAdded(ClassModel newClass) {
                                existingClasses.add(newClass);
                                gradeItems.add(gradeItems.size() - 1, newClass.getDisplayName());
                                gradeAdapter.notifyDataSetChanged();
                                spinnerGrade.setSelection(gradeItems.size() - 2);
                            }
                        });
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        builder.setView(dialogView);
        builder.setPositiveButton("Add (එකතු කරන්න)", (dialog, which) -> {
            String name = etName != null ? etName.getText().toString().trim() : "";
            String roll = etRollNo != null ? etRollNo.getText().toString().trim() : "";
            String marksStr = etMarks != null ? etMarks.getText().toString().trim() : "";

            if (name.isEmpty() || roll.isEmpty()) {
                Toast.makeText(activity, "කරුණාකර නම සහ ඇතුළත් වීමේ අංකය ඇතුලත් කරන්න.", Toast.LENGTH_SHORT).show();
                return;
            }

            int marks = 80;
            if (!marksStr.isEmpty()) {
                try {
                    marks = Integer.parseInt(marksStr);
                } catch (NumberFormatException ignored) {}
            }

            // Determine selected grade
            String selectedGrade = "Grade 10-A";
            String selectedClassId = "";
            if (spinnerGrade != null) {
                int pos = spinnerGrade.getSelectedItemPosition();
                if (pos < existingClasses.size()) {
                    selectedGrade = existingClasses.get(pos).getDisplayName();
                    selectedClassId = existingClasses.get(pos).getId();
                }
            }

            // Determine selected gender
            String selectedGender = "පිරිමි";
            if (spinnerGender != null) {
                int pos = spinnerGender.getSelectedItemPosition();
                if (pos == 1) {
                    selectedGender = "ගැහැණු";
                }
            }

            Student newStudent = new Student(UUID.randomUUID().toString(), name, roll, selectedGrade, marks, true);
            newStudent.setGender(selectedGender);
            if (!selectedClassId.isEmpty()) {
                newStudent.setClassId(selectedClassId);
            }

            if (etInitials != null) newStudent.setNameWithInitials(etInitials.getText().toString().trim());
            if (etDob != null) newStudent.setDob(etDob.getText().toString().trim());
            if (etEthRel != null) newStudent.setEthnicity(etEthRel.getText().toString().trim());
            if (etBirthCert != null) newStudent.setBirthCertNo(etBirthCert.getText().toString().trim());
            if (etMedium != null) newStudent.setMedium(etMedium.getText().toString().trim());
            if (etAddress != null) newStudent.setPermAddress(etAddress.getText().toString().trim());
            if (etFather != null) newStudent.setFatherName(etFather.getText().toString().trim());
            if (etFatherPhone != null) newStudent.setFatherPhone(etFatherPhone.getText().toString().trim());
            if (etMother != null) newStudent.setMotherName(etMother.getText().toString().trim());
            if (etMotherPhone != null) newStudent.setMotherPhone(etMotherPhone.getText().toString().trim());
            if (etGuardian != null) newStudent.setGuardianName(etGuardian.getText().toString().trim());
            if (etEmergencyName != null) newStudent.setEmergencyName(etEmergencyName.getText().toString().trim());
            if (etContact != null) newStudent.setEmergencyPhone(etContact.getText().toString().trim());

            StudentRepository.addStudent(newStudent);
            DataBackupManager.saveLocalState(activity);

            // Record BCN transfer log to Firestore
            String bcn = newStudent.getBirthCertNo();
            if (bcn != null && !bcn.trim().isEmpty()) {
                android.content.SharedPreferences prefs = activity.getSharedPreferences("school_header_prefs", android.content.Context.MODE_PRIVATE);
                String schoolName = prefs.getString("school_name", "School/Classroom");
                String teacherName = prefs.getString("teacher_name", "ගුරුතුමා");
                String teacherUid = UserRoleManager.getCustomUid(activity);
                String todayDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());

                Map<String, Object> transferLog = new HashMap<>();
                transferLog.put("studentId", newStudent.getId());
                transferLog.put("studentName", newStudent.getName());
                transferLog.put("birthCertNo", bcn);
                transferLog.put("schoolName", schoolName);
                transferLog.put("teacherName", teacherName);
                transferLog.put("teacherUid", teacherUid);
                transferLog.put("regDate", todayDate);
                transferLog.put("departureDate", "Active / Current");
                transferLog.put("timestamp", System.currentTimeMillis());

                com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        .collection("student_transfers")
                        .document(bcn + "_" + System.currentTimeMillis())
                        .set(transferLog);
            }

            Toast.makeText(activity, name + " සාර්ථකව ඇතුළත් කරන ලදී!", Toast.LENGTH_SHORT).show();

            if (listener != null) {
                listener.onStudentAdded(newStudent);
            }
        });

        builder.setNegativeButton("Cancel (අවලංගු කරන්න)", null);
        builder.show();
    }

    public interface OnClassAddedListener {
        void onClassAdded(ClassModel newClass);
    }

    private static void showAddNewClassSubDialog(final Activity activity, final OnClassAddedListener callback) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("නව පන්තියක් එකතු කරන්න (Add Class)");

        android.widget.LinearLayout container = new android.widget.LinearLayout(activity);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        int padding = (int) (16 * activity.getResources().getDisplayMetrics().density);
        container.setPadding(padding, padding, padding, padding);

        final EditText etClassName = new EditText(activity);
        etClassName.setHint("පන්තියේ නම (උදා: Grade 10-A)");
        container.addView(etClassName);

        final EditText etYear = new EditText(activity);
        etYear.setHint("අධ්‍යයන වර්ෂය (උදා: 2026)");
        etYear.setText("2026");
        container.addView(etYear);

        builder.setView(container);
        builder.setPositiveButton("Save (සුරකින්න)", (dialog, which) -> {
            String name = etClassName.getText().toString().trim();
            String year = etYear.getText().toString().trim();
            if (year.isEmpty()) year = "2026";
            if (name.isEmpty()) {
                Toast.makeText(activity, "පන්තියේ නම ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                return;
            }
            ClassModel newClass = new ClassModel("class_" + System.currentTimeMillis(), name, year, "Class Teacher", false);
            ClassRepository.addClass(newClass);
            Toast.makeText(activity, name + " පන්තිය සාර්ථකව එකතු විය!", Toast.LENGTH_SHORT).show();
            if (callback != null) {
                callback.onClassAdded(newClass);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}
