package com.aistudio.classroomhub.app

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// --- Teacher Attendance Status Enum ---
enum class TeacherAttendanceStatus(val code: String, val label: String, val badgeColor: Color) {
    PRESENT("PRESENT", "පැමිණ ඇත - Full Day", Color(0xFF16A34A)),
    PAPER_MARKING("PAPER_MARKING", "ප්රශ්න පත්ර ඇගයීම් රාජකාරි - Exam Paper Marking", Color(0xFF9333EA)),
    ON_DUTY("ON_DUTY", "රාජකාරි සඳහා පිටත්ව ගොස් ඇත - On Duty / Seminar", Color(0xFF2563EB)),
    HALF_DAY("HALF_DAY", "අර්ධ නිවාඩු - Half Day", Color(0xFFEA580C)),
    CASUAL_LEAVE("CASUAL_LEAVE", "පෞද්ගලික නිවාඩු - Casual Leave", Color(0xFFD97706)),
    SICK_LEAVE("SICK_LEAVE", "ගිලන් නිවාඩු - Sick Leave", Color(0xFFDB2777)),
    ABSENT("ABSENT", "පැමිණ නැත - Absent", Color(0xFFDC2626))
}

// Data Record for Teacher Attendance
data class TeacherAttendanceRecord(
    val id: String,
    val teacherName: String,
    val date: String,
    val status: TeacherAttendanceStatus,
    val reasonOrNote: String
)

// Repository with Local Persistence
object TeacherAttendanceRepository {
    private val records = mutableStateListOf<TeacherAttendanceRecord>()
    private var isLoaded = false

    fun init(context: Context) {
        if (isLoaded) return
        isLoaded = true
        val prefs = context.getSharedPreferences("teacher_attendance_prefs", Context.MODE_PRIVATE)
        val json = prefs.getString("records_json", "")
        if (!json.isNullOrEmpty()) {
            try {
                val array = org.json.JSONArray(json)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val statusCode = obj.optString("status", "PRESENT")
                    var statusEnum = TeacherAttendanceStatus.PRESENT
                    for (st in TeacherAttendanceStatus.values()) {
                        if (st.code == statusCode) {
                            statusEnum = st
                            break
                        }
                    }
                    records.add(
                        TeacherAttendanceRecord(
                            id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                            teacherName = obj.optString("teacherName", "ගුරුතුමා"),
                            date = obj.optString("date", "2026-08-01"),
                            status = statusEnum,
                            reasonOrNote = obj.optString("reasonOrNote", "")
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (records.isEmpty()) {
            val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            records.add(
                TeacherAttendanceRecord(
                    id = "1",
                    teacherName = "කේ. ඒ. පෙරේරා මහතා",
                    date = today,
                    status = TeacherAttendanceStatus.PRESENT,
                    reasonOrNote = "පංති භාර රාජකාරි"
                )
            )
        }
    }

    fun addRecord(context: Context, record: TeacherAttendanceRecord) {
        records.add(0, record)
        saveToPrefs(context)
    }

    private fun saveToPrefs(context: Context) {
        try {
            val array = org.json.JSONArray()
            for (r in records) {
                val obj = org.json.JSONObject()
                obj.put("id", r.id)
                obj.put("teacherName", r.teacherName)
                obj.put("date", r.date)
                obj.put("status", r.status.code)
                obj.put("reasonOrNote", r.reasonOrNote)
                array.put(obj)
            }
            val prefs = context.getSharedPreferences("teacher_attendance_prefs", Context.MODE_PRIVATE)
            prefs.edit().putString("records_json", array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getAll(context: Context): List<TeacherAttendanceRecord> {
        init(context)
        return records
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeacherAttendanceModalContent(
    context: Context,
    onDismissRequest: () -> Unit,
    onSaveSuccess: (TeacherAttendanceRecord) -> Unit
) {
    TeacherAttendanceRepository.init(context)

    // Form Handler States
    var teacherNameText by remember { mutableStateOf("කේ. ඒ. පෙරේරා මහතා") }
    var selectedStatus by remember { mutableStateOf(TeacherAttendanceStatus.PRESENT) }
    var isStatusDropdownExpanded by remember { mutableStateOf(false) }
    var reasonNoteText by remember { mutableStateOf("") }
    var showHistoryDialog by remember { mutableStateOf(false) }

    val todayDate = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
    var selectedDateText by remember { mutableStateOf(todayDate) }

    val calendar = remember { Calendar.getInstance() }

    fun openDatePicker() {
        val datePickerDialog = android.app.DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                selectedDateText = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(calendar.time)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.show()
    }

    if (showHistoryDialog) {
        TeacherAttendanceHistoryDialog(
            context = context,
            onDismiss = { showHistoryDialog = false }
        )
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = "Teacher Attendance",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "ගුරු පැමිණීම සටහන් කිරීම",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // 1. Teacher Name
                OutlinedTextField(
                    value = teacherNameText,
                    onValueChange = { teacherNameText = it },
                    label = { Text("ගුරුතුමාගේ / තුමියගේ නම") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // 2. Interactive Calendar Date Picker
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = selectedDateText,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("දිනය (Calendar Date Picker)") },
                        leadingIcon = {
                            IconButton(onClick = { openDatePicker() }) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Select Date",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    // Click overlay for date picker
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable { openDatePicker() }
                    )
                }

                // 3. ATTENDANCE / LEAVE STATUS DROPDOWN (Dynamic Select Option)
                Text(
                    text = "පැමිණීමේ / නිවාඩු තත්ත්වය (Attendance / Leave Status):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                ExposedDropdownMenuBox(
                    expanded = isStatusDropdownExpanded,
                    onExpandedChange = { isStatusDropdownExpanded = !isStatusDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedStatus.label,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStatusDropdownExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = selectedStatus.badgeColor,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = isStatusDropdownExpanded,
                        onDismissRequest = { isStatusDropdownExpanded = false }
                    ) {
                        TeacherAttendanceStatus.values().forEach { status ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .background(status.badgeColor, RoundedCornerShape(5.dp))
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = status.label,
                                            fontWeight = if (status == selectedStatus) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                },
                                onClick = {
                                    selectedStatus = status
                                    isStatusDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 4. Reason / Notes Field
                OutlinedTextField(
                    value = reasonNoteText,
                    onValueChange = { reasonNoteText = it },
                    label = { Text("හේතුව / අමතර සටහන් (Reason / Remarks)") },
                    placeholder = { Text("උදා: අධ්‍යාපන සම්මන්ත්‍රණය සඳහා හෝ නිවාඩු හේතුව") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // History & PDF Export Card Button
                OutlinedButton(
                    onClick = { showHistoryDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "History",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "📜 පැමිණීම් වාර්තා ඉතිහාසය බලන්න (View History & PDF)",
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismissRequest) {
                        Text("අවලංගු කරන්න")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (teacherNameText.trim().isEmpty()) {
                                return@Button
                            }
                            val record = TeacherAttendanceRecord(
                                id = java.util.UUID.randomUUID().toString(),
                                teacherName = teacherNameText.trim(),
                                date = selectedDateText,
                                status = selectedStatus,
                                reasonOrNote = reasonNoteText.trim()
                            )
                            TeacherAttendanceRepository.addRecord(context, record)
                            onSaveSuccess(record)
                            onDismissRequest()
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("සූරක්ෂිත කරන්න (Save Record)")
                    }
                }
            }
        }
    }
}

@Composable
fun TeacherAttendanceHistoryDialog(
    context: Context,
    onDismiss: () -> Unit
) {
    val records = remember { TeacherAttendanceRepository.getAll(context) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxSize()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📜 ගුරු පැමිණීම් වාර්තා ඉතිහාසය",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                Button(
                    onClick = {
                        PdfReportExporter.exportTeacherAttendancePdf(context, records)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Export PDF"
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📄 PDF වාර්තාව බාගන්න (Download PDF)")
                }

                Spacer(modifier = Modifier.height(14.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (rec in records) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = rec.teacherName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = rec.date,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(rec.status.badgeColor, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = rec.status.label,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        color = rec.status.badgeColor
                                    )
                                }
                                if (rec.reasonOrNote.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "සටහන: ${rec.reasonOrNote}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun showTeacherAttendanceDialog(context: Context, onComplete: (() -> Unit)? = null) {
    val composeView = ComposeView(context)
    val dialog = AlertDialog.Builder(context)
        .setView(composeView)
        .create()

    dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)

    composeView.setContent {
        TeacherAttendanceModalContent(
            context = context,
            onDismissRequest = { dialog.dismiss() },
            onSaveSuccess = { record ->
                Toast.makeText(
                    context,
                    "ගුරු පැමිණීම සටහන් විය! [${record.status.code}]: ${record.teacherName}",
                    Toast.LENGTH_LONG
                ).show()
                onComplete?.invoke()
            }
        )
    }

    dialog.show()
}
