package com.aistudio.classroomhub.app

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- Announcement / Note Types ---
enum class AnnouncementType(val code: String, val displayName: String, val badgeColor: Color) {
    ANNOUNCEMENT("ANNOUNCEMENT", "දැනුම්දීම (Announcement)", Color(0xFF0284C7)),
    HOMEWORK("HOMEWORK", "ගෙදර වැඩ / Homework", Color(0xFF16A34A)),
    ASSIGNMENT("ASSIGNMENT", "ඇගයීම් / Assignment", Color(0xFF9333EA)),
    EXAM_NOTICE("EXAM_NOTICE", "විභාග පණිවුඩ (Exam Notice)", Color(0xFFDC2626)),
    GENERAL_NOTE("GENERAL_NOTE", "සාමාන්ය සටහන (General Note)", Color(0xFF475569))
}

// Data class for Announcement
data class AnnouncementRecord(
    val id: String,
    val type: AnnouncementType,
    val title: String,
    val content: String,
    val targetGrade: String,
    val datePosted: String
)

// Repository in memory
object AnnouncementRepository {
    private val announcements = mutableStateListOf<AnnouncementRecord>()

    fun addAnnouncement(record: AnnouncementRecord) {
        announcements.add(0, record)
    }

    fun updateAnnouncement(record: AnnouncementRecord) {
        val index = announcements.indexOfFirst { it.id == record.id }
        if (index != -1) {
            announcements[index] = record
        }
    }

    fun deleteAnnouncement(id: String) {
        announcements.removeAll { it.id == id }
    }

    fun getAll(): List<AnnouncementRecord> = announcements
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnnouncementModalContent(
    onDismissRequest: () -> Unit,
    onPostSuccess: (AnnouncementRecord) -> Unit
) {
    // Form Handler States
    var selectedType by remember { mutableStateOf(AnnouncementType.ANNOUNCEMENT) }
    var isTypeDropdownExpanded by remember { mutableStateOf(false) }
    var titleText by remember { mutableStateOf("") }
    var contentText by remember { mutableStateOf("") }
    var targetGradeText by remember { mutableStateOf("Grade 10-A") }

    val todayDate = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Modal Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = "Announcement Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "දැනුම්දීම් සහ සටහන් (Announcements)",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // 1. SELECT TYPE DROPDOWN (Dynamic Select Option)
                Text(
                    text = "වර්ගය තෝරන්න (Select Type):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                ExposedDropdownMenuBox(
                    expanded = isTypeDropdownExpanded,
                    onExpandedChange = { isTypeDropdownExpanded = !isTypeDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedType.displayName,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = isTypeDropdownExpanded)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    ExposedDropdownMenu(
                        expanded = isTypeDropdownExpanded,
                        onDismissRequest = { isTypeDropdownExpanded = false }
                    ) {
                        AnnouncementType.values().forEach { type ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .background(type.badgeColor, RoundedCornerShape(5.dp))
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = type.displayName,
                                            fontWeight = if (type == selectedType) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                },
                                onClick = {
                                    selectedType = type
                                    isTypeDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 2. Title Field
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("මාතෘකාව (Title / Subject)") },
                    placeholder = { Text("උදා: හෙට දිනයේ පන්ති පරීක්ෂණය") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 3. Content Field
                OutlinedTextField(
                    value = contentText,
                    onValueChange = { contentText = it },
                    label = { Text("සටහන / විස්තරය (Announcement Content)") },
                    placeholder = { Text("කරුණාකර අදාළ තොරතුරු පැහැදිලිව සඳහන් කරන්න...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 4. Target Class / Grade & Date
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = targetGradeText,
                        onValueChange = { targetGradeText = it },
                        label = { Text("අදාළ පන්තිය") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = todayDate,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("දිනය") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismissRequest) {
                        Text("අවලංගු කරන්න")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (titleText.trim().isEmpty()) {
                                return@Button
                            }
                            val record = AnnouncementRecord(
                                id = java.util.UUID.randomUUID().toString(),
                                type = selectedType,
                                title = titleText.trim(),
                                content = contentText.trim(),
                                targetGrade = targetGradeText.trim(),
                                datePosted = todayDate
                            )
                            AnnouncementRepository.addAnnouncement(record)

                            // Real-time sync to Firestore collection 'announcements'
                            val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
                            if (currentUser != null) {
                                val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                val data = hashMapOf(
                                    "id" to record.id,
                                    "type" to record.type.code,
                                    "title" to record.title,
                                    "content" to record.content,
                                    "targetGrade" to record.targetGrade,
                                    "datePosted" to record.datePosted,
                                    "authorUid" to currentUser.uid,
                                    "timestamp" to System.currentTimeMillis()
                                )
                                db.collection("announcements").document(record.id).set(data)
                            }

                            onPostSuccess(record)
                            onDismissRequest()
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("පළ කරන්න (Post Announcement)")
                    }
                }
            }
        }
    }
}

fun showAnnouncementDialog(context: Context, onComplete: (() -> Unit)? = null) {
    val composeView = ComposeView(context)
    val dialog = AlertDialog.Builder(context)
        .setView(composeView)
        .create()

    dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    dialog.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)

    composeView.setContent {
        AnnouncementModalContent(
            onDismissRequest = { dialog.dismiss() },
            onPostSuccess = { record ->
                Toast.makeText(
                    context,
                    "සාර්ථකව පළ කරන ලදී! [${record.type.code}]: ${record.title}",
                    Toast.LENGTH_LONG
                ).show()
                onComplete?.invoke()
            }
        )
    }

    dialog.show()
}
