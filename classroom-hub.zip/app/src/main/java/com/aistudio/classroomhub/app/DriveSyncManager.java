package com.aistudio.classroomhub.app;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.api.client.http.ByteArrayContent;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.concurrent.Executors;

public class DriveSyncManager {

    private final Drive mDriveService;
    private static final String PRIMARY_BACKUP_FILE_NAME = "app_backup.json";
    private static final String SECONDARY_BACKUP_FILE_NAME = "ClassApp_Backup.json";
    private static final String TERTIARY_BACKUP_FILE_NAME = "classroom_master_backup.json";

    public DriveSyncManager(Drive driveService) {
        this.mDriveService = driveService;
    }

    // 1. Auto-Overwrite Backup (පැරණි එක Overwrite කරමින් Save වීම)
    public Task<Boolean> autoBackupToDrive(String jsonContent) {
        return Tasks.call(Executors.newSingleThreadExecutor(), () -> {
            try {
                ByteArrayContent contentStream = new ByteArrayContent("application/json", jsonContent.getBytes("UTF-8"));

                // 1. App Data Folder එකට Save කිරීමට උත්සාහ කිරීම
                try {
                    FileList files = mDriveService.files().list()
                            .setQ("name = '" + PRIMARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .setSpaces("appDataFolder")
                            .execute();

                    if (files != null && files.getFiles() != null && !files.getFiles().isEmpty()) {
                        String fileId = files.getFiles().get(0).getId();
                        mDriveService.files().update(fileId, null, contentStream).execute();
                    } else {
                        File metadata = new File()
                                .setName(PRIMARY_BACKUP_FILE_NAME)
                                .setMimeType("application/json")
                                .setParents(Collections.singletonList("appDataFolder"));
                        mDriveService.files().create(metadata, contentStream).execute();
                    }
                    return true;
                } catch (Exception appDataEx) {
                    // 2. App Data Folder අසාර්ථක නම් Main Root Drive space එකට Save කිරීම
                    FileList files = mDriveService.files().list()
                            .setQ("name = '" + PRIMARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .execute();

                    if (files != null && files.getFiles() != null && !files.getFiles().isEmpty()) {
                        String fileId = files.getFiles().get(0).getId();
                        mDriveService.files().update(fileId, null, contentStream).execute();
                    } else {
                        File metadata = new File()
                                .setName(PRIMARY_BACKUP_FILE_NAME)
                                .setMimeType("application/json");
                        mDriveService.files().create(metadata, contentStream).execute();
                    }
                    return true;
                }
            } catch (Exception e) {
                com.google.android.gms.common.internal.Preconditions.checkNotNull(e);
                return false;
            }
        });
    }

    // 2. Fetch Latest Backup from Drive (Re-install වූ පසු)
    public Task<String> fetchLatestBackup() {
        return Tasks.call(Executors.newSingleThreadExecutor(), () -> {
            FileList files = null;

            // 1. Query appDataFolder for primary filename
            try {
                files = mDriveService.files().list()
                        .setQ("name = '" + PRIMARY_BACKUP_FILE_NAME + "' and trashed = false")
                        .setSpaces("appDataFolder")
                        .execute();
            } catch (Exception ignored) {}

            // 2. Query root drive for primary filename
            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                try {
                    files = mDriveService.files().list()
                            .setQ("name = '" + PRIMARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .execute();
                } catch (Exception ignored) {}
            }

            // 3. Query root drive for secondary filename
            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                try {
                    files = mDriveService.files().list()
                            .setQ("name = '" + SECONDARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .execute();
                } catch (Exception ignored) {}
            }

            // 4. Query root drive for tertiary filename
            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                try {
                    files = mDriveService.files().list()
                            .setQ("name = '" + TERTIARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .execute();
                } catch (Exception ignored) {}
            }

            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                return null;
            }

            String fileId = files.getFiles().get(0).getId();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    mDriveService.files().get(fileId).executeMediaAsInputStream(), "UTF-8"))) {
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                return stringBuilder.toString();
            }
        });
    }

    // 3. Fetch Metadata of the latest backup file (modifiedTime, createdTime, name, size)
    public Task<File> getLatestBackupMetadata() {
        return Tasks.call(Executors.newSingleThreadExecutor(), () -> {
            FileList files = null;

            // 1. Query appDataFolder for primary filename
            try {
                files = mDriveService.files().list()
                        .setQ("name = '" + PRIMARY_BACKUP_FILE_NAME + "' and trashed = false")
                        .setSpaces("appDataFolder")
                        .setFields("files(id, name, modifiedTime, createdTime, size)")
                        .execute();
            } catch (Exception ignored) {}

            // 2. Query root drive for primary filename
            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                try {
                    files = mDriveService.files().list()
                            .setQ("name = '" + PRIMARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .setFields("files(id, name, modifiedTime, createdTime, size)")
                            .execute();
                } catch (Exception ignored) {}
            }

            // 3. Query root drive for secondary filename
            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                try {
                    files = mDriveService.files().list()
                            .setQ("name = '" + SECONDARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .setFields("files(id, name, modifiedTime, createdTime, size)")
                            .execute();
                } catch (Exception ignored) {}
            }

            // 4. Query root drive for tertiary filename
            if (files == null || files.getFiles() == null || files.getFiles().isEmpty()) {
                try {
                    files = mDriveService.files().list()
                            .setQ("name = '" + TERTIARY_BACKUP_FILE_NAME + "' and trashed = false")
                            .setFields("files(id, name, modifiedTime, createdTime, size)")
                            .execute();
                } catch (Exception ignored) {}
            }

            if (files != null && files.getFiles() != null && !files.getFiles().isEmpty()) {
                return files.getFiles().get(0);
            }
            return null;
        });
    }
}
