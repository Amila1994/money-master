package com.aistudio.classroomhub.app;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.api.client.http.ByteArrayContent;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.concurrent.Executors;

public class DriveSyncManager {

    private final Drive mDriveService;
    private static final String BACKUP_FILE_NAME = "classroom_master_backup.json";

    public DriveSyncManager(Drive driveService) {
        this.mDriveService = driveService;
    }

    // 1. Auto-Overwrite Backup (පැරණි එක Overwrite කරමින් Real-time Save වීම)
    public Task<Boolean> autoBackupToDrive(String jsonContent) {
        return Tasks.call(Executors.newSingleThreadExecutor(), () -> {
            FileList files = mDriveService.files().list()
                    .setQ("name = '" + BACKUP_FILE_NAME + "' and trashed = false")
                    .setSpaces("appDataFolder")
                    .execute();

            ByteArrayContent contentStream = new ByteArrayContent("application/json", jsonContent.getBytes());

            if (!files.getFiles().isEmpty()) {
                // කලින් එක Overwrite කිරීම
                String fileId = files.getFiles().get(0).getId();
                mDriveService.files().update(fileId, null, contentStream).execute();
            } else {
                // පළමු වතාවට සාදයි
                File metadata = new File()
                        .setName(BACKUP_FILE_NAME)
                        .setMimeType("application/json")
                        .setParents(Collections.singletonList("appDataFolder"));
                mDriveService.files().create(metadata, contentStream).execute();
            }
            return true;
        });
    }

    // 2. Fetch Latest Backup from Drive (Re-install වූ පසු)
    public Task<String> fetchLatestBackup() {
        return Tasks.call(Executors.newSingleThreadExecutor(), () -> {
            FileList files = mDriveService.files().list()
                    .setQ("name = '" + BACKUP_FILE_NAME + "' and trashed = false")
                    .setSpaces("appDataFolder")
                    .execute();

            if (files.getFiles().isEmpty()) {
                return null;
            }

            String fileId = files.getFiles().get(0).getId();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    mDriveService.files().get(fileId).executeMediaAsInputStream()))) {
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                return stringBuilder.toString();
            }
        });
    }
}
