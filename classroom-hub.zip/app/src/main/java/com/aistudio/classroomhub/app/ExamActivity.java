package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ExamActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TabLayout tabLayout;
    private FrameLayout tabContainer;

    private View viewTab1;
    private View viewTab2;
    private View viewTab3;
    private View viewTab4;

    // Tab 1 UI
    private RecyclerView rvStudentSubjects;
    private StudentSubjectAdapter studentSubjectAdapter;

    // Tab 2 UI
    private Spinner spExamType;
    private RecyclerView rvMarkEntry;
    private MarkEntryAdapter markEntryAdapter;

    // Tab 3 UI
    private TextView tvCurrentExamTitle;
    private TextView tvSummarySubtitle;
    private RecyclerView rvRankings;
    private RankingAdapter rankingAdapter;
    private LinearLayout llSubjectHighLowContainer;
    private Spinner spChartType;
    private ChartVisualizerView chartVisualizerView;

    // Tab 4 UI (Old Tests)
    private Spinner spFilterYear;
    private Spinner spFilterExamType;
    private TextView tvFilterStatus;
    private TextView tvEmptyOldTests;
    private RecyclerView rvOldTestsList;
    private OldTestsAdapter oldTestsAdapter;

    private String selectedFilterYear = "2026";
    private String selectedFilterExamType = "1 වන වාර විභාගය";

    private String currentExamType = "1 වන වාර විභාගය";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_exam);
        WindowInsetUtils.applySystemBarPadding(this);

        btnBack = findViewById(R.id.btnBack);
        tabLayout = findViewById(R.id.tabLayout);
        tabContainer = findViewById(R.id.tabContainer);

        if (btnBack != null) {
            btnBack.setVisibility(View.GONE);
        }

        setupHeaderControls();
        setupTabs();
        loadTabViews();
        selectTab(0);
    }

    private void setupHeaderControls() {
        Spinner spHeaderYear = findViewById(R.id.spHeaderYear);
        View btnHeaderPdf = findViewById(R.id.btnHeaderPdf);

        if (spHeaderYear != null) {
            String[] years = new String[]{"2026", "2025", "2024", "2023"};
            ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, years);
            yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spHeaderYear.setAdapter(yearAdapter);
            spHeaderYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    ExamRepository.currentYear = years[position];
                    refreshCurrentTabView();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        if (btnHeaderPdf != null) {
            btnHeaderPdf.setOnClickListener(v -> {
                List<ExamRepository.StudentExamResult> ranked = ExamRepository.getRankedResultsForTerm(ExamActivity.this, ExamRepository.currentYear, ExamRepository.currentTermId);
                PdfReportExporter.exportClassResultsPdf(ExamActivity.this, currentExamType + " (" + ExamRepository.currentYear + ")", ranked);
            });
        }
    }

    private void refreshCurrentTabView() {
        int pos = tabLayout != null ? tabLayout.getSelectedTabPosition() : 0;
        selectTab(pos);
    }

    private void setupTabs() {
        tabLayout.addTab(tabLayout.newTab().setText(AppTranslation.get(this, "students_subjects")));
        tabLayout.addTab(tabLayout.newTab().setText(AppTranslation.get(this, "quick_marks")));
        tabLayout.addTab(tabLayout.newTab().setText(AppTranslation.get(this, "results_charts")));
        tabLayout.addTab(tabLayout.newTab().setText(AppTranslation.get(this, "old_tests")));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                selectTab(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void loadTabViews() {
        LayoutInflater inflater = LayoutInflater.from(this);
        viewTab1 = inflater.inflate(R.layout.tab_students_subjects, tabContainer, false);
        viewTab2 = inflater.inflate(R.layout.tab_fast_mark_entry, tabContainer, false);
        viewTab3 = inflater.inflate(R.layout.tab_results_analytics, tabContainer, false);
        viewTab4 = inflater.inflate(R.layout.tab_old_tests, tabContainer, false);

        initTab1();
        initTab2();
        initTab3();
        initTab4();
    }

    private void selectTab(int position) {
        tabContainer.removeAllViews();
        if (position == 0) {
            tabContainer.addView(viewTab1);
            if (studentSubjectAdapter != null) studentSubjectAdapter.notifyDataSetChanged();
        } else if (position == 1) {
            tabContainer.addView(viewTab2);
            if (markEntryAdapter != null) markEntryAdapter.notifyDataSetChanged();
        } else if (position == 2) {
            tabContainer.addView(viewTab3);
            refreshTab3Data();
        } else {
            tabContainer.addView(viewTab4);
            refreshTab4Data();
        }
    }

    // ==========================================
    // TAB 1: Student & Subject Enrollment
    // ==========================================
    private void initTab1() {
        rvStudentSubjects = viewTab1.findViewById(R.id.rvStudentSubjects);
        rvStudentSubjects.setLayoutManager(new LinearLayoutManager(this));
        studentSubjectAdapter = new StudentSubjectAdapter();
        rvStudentSubjects.setAdapter(studentSubjectAdapter);
    }

    private class StudentSubjectAdapter extends RecyclerView.Adapter<StudentSubjectAdapter.ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exam_student_subject, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Student student = StudentRepository.getStudents().get(position);
            holder.tvStudentName.setText(student.getName());
            holder.tvStudentRollNo.setText((student.getRollNo() != null ? student.getRollNo() : "") + " | " + student.getGrade());

            List<String> enrolled = ExamRepository.getStudentSubjects(student.getId());
            holder.tvEnrolledSubjects.setText("ලියාපදිංචි විෂයයන්: " + String.join(", ", enrolled));

            View.OnClickListener clickListener = v -> showEditSubjectsDialog(student);
            holder.itemView.setOnClickListener(clickListener);
            holder.btnEditSubjects.setOnClickListener(clickListener);
        }

        @Override
        public int getItemCount() {
            return StudentRepository.getStudents().size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvStudentName, tvStudentRollNo, tvEnrolledSubjects;
            ImageView btnEditSubjects;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvStudentName = itemView.findViewById(R.id.tvStudentName);
                tvStudentRollNo = itemView.findViewById(R.id.tvStudentRollNo);
                tvEnrolledSubjects = itemView.findViewById(R.id.tvEnrolledSubjects);
                btnEditSubjects = itemView.findViewById(R.id.btnEditSubjects);
            }
        }
    }

    private void showEditSubjectsDialog(Student student) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_subjects, null);
        TextView tvTitle = dialogView.findViewById(R.id.tvDialogStudentTitle);
        EditText etCustomSub = dialogView.findViewById(R.id.etCustomSubject);
        View btnAddSub = dialogView.findViewById(R.id.btnAddSubject);
        LinearLayout llCheckboxContainer = dialogView.findViewById(R.id.llCheckboxContainer);

        if (tvTitle != null) {
            tvTitle.setText(student.getName() + " - විෂයන් තෝරන්න");
        }

        List<String> currentEnrolled = new ArrayList<>(ExamRepository.getStudentSubjects(student.getId()));
        Map<String, CheckBox> checkBoxMap = new java.util.LinkedHashMap<>();

        Runnable populateCheckboxes = new Runnable() {
            @Override
            public void run() {
                llCheckboxContainer.removeAllViews();
                checkBoxMap.clear();

                for (String sub : ExamRepository.ALL_SUBJECTS) {
                    CheckBox cb = new CheckBox(ExamActivity.this);
                    cb.setText(sub);
                    cb.setTextColor(0xFFFFFFFF);
                    cb.setTextSize(14);
                    cb.setPadding(12, 12, 12, 12);
                    boolean isChecked = currentEnrolled.contains(sub);
                    cb.setChecked(isChecked);

                    llCheckboxContainer.addView(cb);
                    checkBoxMap.put(sub, cb);
                }
            }
        };

        populateCheckboxes.run();

        if (btnAddSub != null) {
            btnAddSub.setOnClickListener(v -> {
                String newSubName = etCustomSub.getText().toString().trim();
                if (newSubName.isEmpty()) {
                    Toast.makeText(ExamActivity.this, "කරුණාකර විෂයයේ නම ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show();
                    return;
                }
                ExamRepository.addSubjectToMasterList(newSubName);
                if (!currentEnrolled.contains(newSubName)) {
                    currentEnrolled.add(newSubName);
                }

                etCustomSub.setText("");
                populateCheckboxes.run();
                Toast.makeText(ExamActivity.this, "'" + newSubName + "' විෂයයන් අතරට එකතු කරන ලදී!", Toast.LENGTH_SHORT).show();
            });
        }

        new AlertDialog.Builder(this)
                .setView(dialogView)
                .setPositiveButton("Save (සුරකින්න)", (dialog, which) -> {
                    List<String> selected = new ArrayList<>();
                    for (Map.Entry<String, CheckBox> entry : checkBoxMap.entrySet()) {
                        if (entry.getValue().isChecked()) {
                            selected.add(entry.getKey());
                        }
                    }
                    ExamRepository.setStudentSubjects(student.getId(), selected);

                    // Instant reflection across tabs
                    if (studentSubjectAdapter != null) studentSubjectAdapter.notifyDataSetChanged();
                    if (markEntryAdapter != null) markEntryAdapter.notifyDataSetChanged();
                    refreshTab3Data();

                    Toast.makeText(ExamActivity.this, "විෂයයන් සාර්ථකව සුරකින ලදී!", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("අවලංගුයි", null)
                .show();
    }

    // ==========================================
    // TAB 2: Fast Mark Entry
    // ==========================================
    private void initTab2() {
        spExamType = viewTab2.findViewById(R.id.spExamType);
        rvMarkEntry = viewTab2.findViewById(R.id.rvMarkEntry);
        View btnSave = viewTab2.findViewById(R.id.btnSaveMarks);
        View btnViewResults = viewTab2.findViewById(R.id.btnViewResults);

        String[] examTypes = new String[]{"1 වන වාර විභාගය", "2 වන වාර විභාගය", "3 වන වාර විභාගය", "ඒකක පරීක්ෂණය"};
        ArrayAdapter<String> examAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, examTypes);
        examAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spExamType.setAdapter(examAdapter);

        spExamType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentExamType = examTypes[position];
                ExamRepository.currentTermId = ExamRepository.getTermIdFromExamType(currentExamType);
                if (markEntryAdapter != null) markEntryAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        rvMarkEntry.setLayoutManager(new LinearLayoutManager(this));
        markEntryAdapter = new MarkEntryAdapter();
        rvMarkEntry.setAdapter(markEntryAdapter);

        if (btnSave != null) {
            btnSave.setOnClickListener(v -> {
                for (Student s : StudentRepository.getStudents()) {
                    Map<String, Double> mMap = ExamRepository.getStudentMarksForTerm(s.getId(), ExamRepository.currentYear, ExamRepository.currentTermId);
                    ExamRepository.saveMarksToPrefsAndFirestore(ExamActivity.this, s.getId(), ExamRepository.currentYear, ExamRepository.currentTermId, mMap);
                }
                Toast.makeText(this, "සියලු ලකුණු සාර්ථකව සුරකින ලදී!", Toast.LENGTH_SHORT).show();
                if (markEntryAdapter != null) markEntryAdapter.notifyDataSetChanged();
            });
        }

        if (btnViewResults != null) {
            btnViewResults.setOnClickListener(v -> {
                if (tabLayout != null && tabLayout.getTabAt(2) != null) {
                    tabLayout.getTabAt(2).select();
                }
            });
        }
    }

    private class MarkEntryAdapter extends RecyclerView.Adapter<MarkEntryAdapter.ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exam_mark_entry, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Student student = StudentRepository.getStudents().get(position);
            holder.tvStudentTitle.setText(student.getName() + " (" + (student.getRollNo() != null ? student.getRollNo() : "") + ")");

            holder.llSubjectsContainer.removeAllViews();
            List<String> subjects = ExamRepository.getStudentSubjects(student.getId());
            Map<String, Double> marks = ExamRepository.getStudentMarksForTerm(student.getId(), ExamRepository.currentYear, ExamRepository.currentTermId);

            for (String sub : subjects) {
                LinearLayout row = new LinearLayout(ExamActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(0, 8, 0, 8);

                TextView tvSubName = new TextView(ExamActivity.this);
                tvSubName.setText(sub);
                tvSubName.setTextColor(0xFFFFFFFF);
                tvSubName.setTextSize(14);
                tvSubName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));

                EditText etMark = new EditText(ExamActivity.this);
                etMark.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                etMark.setHint("0-100");
                etMark.setTextColor(0xFF38BDF8);
                etMark.setTextSize(14);
                etMark.setBackgroundResource(android.R.drawable.edit_text);
                etMark.setPadding(16, 8, 16, 8);
                etMark.setMinimumWidth(160);

                Double val = marks.get(sub);
                if (val != null) {
                    etMark.setText(String.format(Locale.US, "%.0f", val));
                } else {
                    etMark.setText("");
                }

                etMark.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        String input = s.toString().trim();
                        if (input.isEmpty()) {
                            ExamRepository.setStudentMarkForTerm(ExamActivity.this, student.getId(), sub, null, ExamRepository.currentYear, ExamRepository.currentTermId);
                        } else {
                            try {
                                double m = Double.parseDouble(input);
                                ExamRepository.setStudentMarkForTerm(ExamActivity.this, student.getId(), sub, m, ExamRepository.currentYear, ExamRepository.currentTermId);
                            } catch (Exception ignored) {}
                        }
                    }

                    @Override
                    public void afterTextChanged(Editable s) {}
                });

                row.addView(tvSubName);
                row.addView(etMark);
                holder.llSubjectsContainer.addView(row);
            }
        }

        @Override
        public int getItemCount() {
            return StudentRepository.getStudents().size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvStudentTitle;
            LinearLayout llSubjectsContainer;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvStudentTitle = itemView.findViewById(R.id.tvStudentTitle);
                llSubjectsContainer = itemView.findViewById(R.id.llSubjectsContainer);
            }
        }
    }

    // ==========================================
    // TAB 3: Results & 12 Charts Analytics
    // ==========================================
    private com.google.android.material.button.MaterialButton btnTermFilter1;
    private com.google.android.material.button.MaterialButton btnTermFilter2;
    private com.google.android.material.button.MaterialButton btnTermFilter3;
    private com.google.android.material.button.MaterialButton btnTermFilterUnit;

    private void initTab3() {
        tvCurrentExamTitle = viewTab3.findViewById(R.id.tvCurrentExamTitle);
        tvSummarySubtitle = viewTab3.findViewById(R.id.tvSummarySubtitle);
        rvRankings = viewTab3.findViewById(R.id.rvRankings);
        llSubjectHighLowContainer = viewTab3.findViewById(R.id.llSubjectHighLowContainer);
        spChartType = viewTab3.findViewById(R.id.spChartType);
        chartVisualizerView = viewTab3.findViewById(R.id.chartVisualizerView);

        btnTermFilter1 = viewTab3.findViewById(R.id.btnTermFilter1);
        btnTermFilter2 = viewTab3.findViewById(R.id.btnTermFilter2);
        btnTermFilter3 = viewTab3.findViewById(R.id.btnTermFilter3);
        btnTermFilterUnit = viewTab3.findViewById(R.id.btnTermFilterUnit);

        View.OnClickListener termFilterListener = v -> {
            int id = v.getId();
            if (id == R.id.btnTermFilter1) {
                ExamRepository.currentTermId = "term_1";
                currentExamType = "1 වන වාර විභාගය";
            } else if (id == R.id.btnTermFilter2) {
                ExamRepository.currentTermId = "term_2";
                currentExamType = "2 වන වාර විභාගය";
            } else if (id == R.id.btnTermFilter3) {
                ExamRepository.currentTermId = "term_3";
                currentExamType = "3 වන වාර විභාගය";
            } else if (id == R.id.btnTermFilterUnit) {
                ExamRepository.currentTermId = "unit_test";
                currentExamType = "ඒකක පරීක්ෂණය";
            }
            updateTermFilterStyles(ExamRepository.currentTermId);
            refreshTab3Data();
        };

        if (btnTermFilter1 != null) btnTermFilter1.setOnClickListener(termFilterListener);
        if (btnTermFilter2 != null) btnTermFilter2.setOnClickListener(termFilterListener);
        if (btnTermFilter3 != null) btnTermFilter3.setOnClickListener(termFilterListener);
        if (btnTermFilterUnit != null) btnTermFilterUnit.setOnClickListener(termFilterListener);

        updateTermFilterStyles(ExamRepository.currentTermId);

        rvRankings.setLayoutManager(new LinearLayoutManager(this));
        rankingAdapter = new RankingAdapter();
        rvRankings.setAdapter(rankingAdapter);

        // Setup 12 Charts Dropdown
        String[] chartNames = new String[]{
                "1. Bar Chart (ලකුණු බාර්)",
                "2. Line Chart (වර්ධන රේඛා)",
                "3. Pie Chart (සාමාර්ථ ප්‍රතිශත)",
                "4. Doughnut Chart (විෂය බෙදී යාම)",
                "5. Radar Chart (සාපේක්ෂ දක්ෂතා)",
                "6. Polar Area Chart (විෂය ලකුණු)",
                "7. Scatter Chart (ලකුණු විග්‍රහය)",
                "8. Bubble Chart (සංසන්දනාත්මක)",
                "9. Stacked Bar Chart (එකතු කළ බාර්)",
                "10. Area Chart (ක්ෂේත්‍ර ප්‍රස්ථාරය)",
                "11. Funnel Chart (ශ්‍රේණිගත කිරීම්)",
                "12. Gauge Chart (මධ්‍යන්‍ය දර්ශකය)"
        };

        ArrayAdapter<String> chartAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, chartNames);
        chartAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spChartType.setAdapter(chartAdapter);

        spChartType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (chartVisualizerView != null) {
                    chartVisualizerView.setChartType(position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void updateTermFilterStyles(String termId) {
        if (btnTermFilter1 == null) return;
        int activeBg = 0xFF2563EB;
        int inactiveBg = 0x00000000;
        int activeText = 0xFFFFFFFF;
        int inactiveText = 0xFF64748B;
        int activeStroke = 0xFF2563EB;
        int inactiveStroke = 0xFFCBD5E1;

        btnTermFilter1.setBackgroundColor("term_1".equals(termId) ? activeBg : inactiveBg);
        btnTermFilter1.setTextColor("term_1".equals(termId) ? activeText : inactiveText);
        btnTermFilter1.setStrokeColor(android.content.res.ColorStateList.valueOf("term_1".equals(termId) ? activeStroke : inactiveStroke));

        btnTermFilter2.setBackgroundColor("term_2".equals(termId) ? activeBg : inactiveBg);
        btnTermFilter2.setTextColor("term_2".equals(termId) ? activeText : inactiveText);
        btnTermFilter2.setStrokeColor(android.content.res.ColorStateList.valueOf("term_2".equals(termId) ? activeStroke : inactiveStroke));

        btnTermFilter3.setBackgroundColor("term_3".equals(termId) ? activeBg : inactiveBg);
        btnTermFilter3.setTextColor("term_3".equals(termId) ? activeText : inactiveText);
        btnTermFilter3.setStrokeColor(android.content.res.ColorStateList.valueOf("term_3".equals(termId) ? activeStroke : inactiveStroke));

        btnTermFilterUnit.setBackgroundColor("unit_test".equals(termId) ? activeBg : inactiveBg);
        btnTermFilterUnit.setTextColor("unit_test".equals(termId) ? activeText : inactiveText);
        btnTermFilterUnit.setStrokeColor(android.content.res.ColorStateList.valueOf("unit_test".equals(termId) ? activeStroke : inactiveStroke));
    }

    private void refreshTab3Data() {
        if (tvCurrentExamTitle != null) {
            tvCurrentExamTitle.setText("විභාගය: " + currentExamType + " (" + ExamRepository.currentYear + ")");
        }

        List<ExamRepository.StudentExamResult> ranked = ExamRepository.getRankedResultsForTerm(this, ExamRepository.currentYear, ExamRepository.currentTermId);
        double totalClassAvg = 0.0;
        for (ExamRepository.StudentExamResult r : ranked) {
            totalClassAvg += r.averageMarks;
        }
        double classAvg = ranked.isEmpty() ? 0.0 : totalClassAvg / ranked.size();

        if (tvSummarySubtitle != null) {
            tvSummarySubtitle.setText("මුළු ශිෂ්‍යයන්: " + ranked.size() + " | පන්තියේ මධ්‍යන්‍යය: " + String.format(Locale.US, "%.1f%%", classAvg));
        }

        if (rankingAdapter != null) {
            rankingAdapter.updateData(ranked);
        }

        // Populate High/Low per Subject
        if (llSubjectHighLowContainer != null) {
            llSubjectHighLowContainer.removeAllViews();
            List<ExamRepository.SubjectStat> stats = ExamRepository.getSubjectStats();

            for (ExamRepository.SubjectStat stat : stats) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackgroundColor(0xFF1E293B);
                card.setPadding(16, 12, 16, 12);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, 8);
                card.setLayoutParams(lp);

                TextView tvSubHeader = new TextView(this);
                tvSubHeader.setText(stat.subject);
                tvSubHeader.setTextColor(0xFF38BDF8);
                tvSubHeader.setTextSize(14);
                tvSubHeader.setTypeface(null, android.graphics.Typeface.BOLD);

                TextView tvHigh = new TextView(this);
                tvHigh.setText("වැඩිම: " + (stat.highestStudentName != null ? stat.highestStudentName : "-") + " (" + String.format(Locale.US, "%.0f", stat.highestMark) + ")");
                tvHigh.setTextColor(0xFF4ADE80);
                tvHigh.setTextSize(12);

                TextView tvLow = new TextView(this);
                tvLow.setText("අඩුම: " + (stat.lowestStudentName != null ? stat.lowestStudentName : "-") + " (" + String.format(Locale.US, "%.0f", stat.lowestMark) + ")");
                tvLow.setTextColor(0xFFF43F5E);
                tvLow.setTextSize(12);

                card.addView(tvSubHeader);
                card.addView(tvHigh);
                card.addView(tvLow);
                llSubjectHighLowContainer.addView(card);
            }
        }

        if (chartVisualizerView != null) {
            chartVisualizerView.invalidate();
        }
    }

    private class RankingAdapter extends RecyclerView.Adapter<RankingAdapter.ViewHolder> {

        private List<ExamRepository.StudentExamResult> list = new ArrayList<>();

        public void updateData(List<ExamRepository.StudentExamResult> newList) {
            this.list = newList;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_exam_result_card, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ExamRepository.StudentExamResult res = list.get(position);
            
            com.google.android.material.card.MaterialCardView cardView = (com.google.android.material.card.MaterialCardView) holder.itemView;
            
            if (res.rank == 1) {
                holder.tvRankBadge.setText("🥇 1st");
                holder.tvRankBadge.setTextColor(0xFFB45309);
                if (holder.rankBadgeContainer != null) holder.rankBadgeContainer.setBackgroundColor(0xFFFEF3C7);
                cardView.setCardBackgroundColor(0xFF281F08);
                cardView.setStrokeColor(0xFFF59E0B);
                cardView.setStrokeWidth(3);
            } else if (res.rank == 2) {
                holder.tvRankBadge.setText("🥈 2nd");
                holder.tvRankBadge.setTextColor(0xFF334155);
                if (holder.rankBadgeContainer != null) holder.rankBadgeContainer.setBackgroundColor(0xFFF1F5F9);
                cardView.setCardBackgroundColor(0xFF1E2638);
                cardView.setStrokeColor(0xFF94A3B8);
                cardView.setStrokeWidth(3);
            } else if (res.rank == 3) {
                holder.tvRankBadge.setText("🥉 3rd");
                holder.tvRankBadge.setTextColor(0xFFC2410C);
                if (holder.rankBadgeContainer != null) holder.rankBadgeContainer.setBackgroundColor(0xFFFFEDD5);
                cardView.setCardBackgroundColor(0xFF291A12);
                cardView.setStrokeColor(0xFFEA580C);
                cardView.setStrokeWidth(3);
            } else {
                holder.tvRankBadge.setText("#" + res.rank);
                holder.tvRankBadge.setTextColor(0xFF0F172A);
                if (holder.rankBadgeContainer != null) holder.rankBadgeContainer.setBackgroundColor(0xFF94A3B8);
                cardView.setCardBackgroundColor(0xFF1E293B);
                cardView.setStrokeColor(0xFF334155);
                cardView.setStrokeWidth(1);
            }

            holder.tvStudentNameRank.setText(res.student.getName());
            holder.tvResultSummary.setText(String.format(Locale.US, "එකතුව: %.0f | මධ්‍යන්‍යය: %.1f%%", res.totalMarks, res.averageMarks));

            if (holder.tvPassFailBadge != null) {
                boolean isPass = res.averageMarks >= GradeBoundaryManager.getSMin(ExamActivity.this);
                holder.tvPassFailBadge.setText(isPass ? "PASS" : "FAIL");
                holder.tvPassFailBadge.setBackgroundColor(isPass ? 0xFF16A34A : 0xFFDC2626);
            }

            StringBuilder breakdown = new StringBuilder();
            for (Map.Entry<String, Double> entry : res.marks.entrySet()) {
                if (entry.getValue() != null) {
                    String g = GradeBoundaryManager.calculateGrade(ExamActivity.this, entry.getValue());
                    if (breakdown.length() > 0) breakdown.append(" | ");
                    breakdown.append(entry.getKey()).append(": ").append(String.format(Locale.US, "%.0f", entry.getValue())).append(" (").append(g).append(")");
                }
            }
            holder.tvGradesBreakdown.setText(breakdown.length() > 0 ? breakdown.toString() : "ලකුණු සටහන් කර නැත");

            if (holder.tvProgressT1vsT2 != null) {
                if (res.hasTerm1 && res.hasTerm2) {
                    String arrow = res.progressTerm1vs2 >= 0 ? "📈" : "📉";
                    holder.tvProgressT1vsT2.setText(String.format(Locale.US, "T1➔T2: %+.1f%% %s", res.progressTerm1vs2, arrow));
                    holder.tvProgressT1vsT2.setTextColor(res.progressTerm1vs2 >= 0 ? 0xFF4ADE80 : 0xFFF43F5E);
                } else {
                    holder.tvProgressT1vsT2.setText("T1➔T2: -");
                    holder.tvProgressT1vsT2.setTextColor(0xFF94A3B8);
                }
            }

            if (holder.tvProgressT2vsT3 != null) {
                if (res.hasTerm2 && res.hasTerm3) {
                    String arrow = res.progressTerm2vs3 >= 0 ? "📈" : "📉";
                    holder.tvProgressT2vsT3.setText(String.format(Locale.US, "T2➔T3: %+.1f%% %s", res.progressTerm2vs3, arrow));
                    holder.tvProgressT2vsT3.setTextColor(res.progressTerm2vs3 >= 0 ? 0xFF4ADE80 : 0xFFF43F5E);
                } else {
                    holder.tvProgressT2vsT3.setText("T2➔T3: -");
                    holder.tvProgressT2vsT3.setTextColor(0xFF94A3B8);
                }
            }

            // Click listener for Student Progress & Exam Report Modal
            holder.itemView.setOnClickListener(v -> showStudentProgressModal(res.student));
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvRankBadge, tvStudentNameRank, tvResultSummary, tvGradesBreakdown, tvPassFailBadge;
            TextView tvProgressT1vsT2, tvProgressT2vsT3;
            View rankBadgeContainer;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvRankBadge = itemView.findViewById(R.id.tvRankBadge);
                rankBadgeContainer = (View) tvRankBadge.getParent();
                tvStudentNameRank = itemView.findViewById(R.id.tvStudentNameRank);
                tvResultSummary = itemView.findViewById(R.id.tvResultSummary);
                tvGradesBreakdown = itemView.findViewById(R.id.tvGradesBreakdown);
                tvPassFailBadge = itemView.findViewById(R.id.tvPassFailBadge);
                tvProgressT1vsT2 = itemView.findViewById(R.id.tvProgressT1vsT2);
                tvProgressT2vsT3 = itemView.findViewById(R.id.tvProgressT2vsT3);
            }
        }
    }

    private void showStudentProgressModal(Student student) {
        if (student == null) return;

        double total = ExamRepository.calculateTotalMarks(student.getId());
        double avg = ExamRepository.calculateAverageMarks(student.getId());
        boolean isPass = avg >= GradeBoundaryManager.getSMin(this);
        String overallGrade = GradeBoundaryManager.calculateGrade(this, avg);

        List<ExamRepository.StudentExamResult> ranked = ExamRepository.getRankedResults();
        int rank = 0;
        for (ExamRepository.StudentExamResult r : ranked) {
            if (r.student.getId().equals(student.getId())) {
                rank = r.rank;
                break;
            }
        }

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setPadding(40, 24, 40, 24);

        // Header Summary Card
        LinearLayout headerCard = new LinearLayout(this);
        headerCard.setOrientation(LinearLayout.VERTICAL);
        headerCard.setBackgroundColor(0xFF1E293B);
        headerCard.setPadding(24, 20, 24, 20);

        TextView tvTitle = new TextView(this);
        tvTitle.setText("📊 " + student.getName() + " - ප්‍රගති වාර්තාව");
        tvTitle.setTextColor(0xFF38BDF8);
        tvTitle.setTextSize(16);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView tvSub = new TextView(this);
        tvSub.setText("ලියාපදිංචි අංකය: " + (student.getRollNo() != null ? student.getRollNo() : "-") + " | පන්තිය: " + (student.getGrade() != null ? student.getGrade() : "-"));
        tvSub.setTextColor(0xFF94A3B8);
        tvSub.setTextSize(12);

        TextView tvBadges = new TextView(this);
        tvBadges.setText(String.format("පන්ති ස්ථානය: #%d  |  සාමාන්‍යය: %.1f%%  |  සාමාර්ථය: %s  |  තත්වය: %s",
                rank, avg, overallGrade, isPass ? "PASSED" : "FAILED"));
        tvBadges.setTextColor(isPass ? 0xFF4ADE80 : 0xFFF43F5E);
        tvBadges.setTextSize(13);
        tvBadges.setTypeface(null, android.graphics.Typeface.BOLD);
        tvBadges.setPadding(0, 8, 0, 0);

        headerCard.addView(tvTitle);
        headerCard.addView(tvSub);
        headerCard.addView(tvBadges);
        container.addView(headerCard);

        // Term-by-Term Subject Breakdown Header
        TextView tvBreakdownTitle = new TextView(this);
        tvBreakdownTitle.setText("\n📚 විෂයානුබද්ධ වාර සටහන සහ සාමාර්ථ (Subject & Term Breakdown):");
        tvBreakdownTitle.setTextSize(13);
        tvBreakdownTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvBreakdownTitle.setTextColor(0xFF0F172A);
        container.addView(tvBreakdownTitle);

        List<String> subjects = ExamRepository.getStudentSubjects(student.getId());
        Map<String, Double> marksMap = ExamRepository.getStudentMarks(student.getId());

        for (String sub : subjects) {
            Double val = marksMap.get(sub);
            double m = val != null ? val : 60.0;
            String grade = GradeBoundaryManager.calculateGrade(this, m);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 10, 0, 10);

            TextView tvSubName = new TextView(this);
            tvSubName.setText("• " + sub);
            tvSubName.setTextColor(0xFF334155);
            tvSubName.setTextSize(13);
            tvSubName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));

            TextView tvSubMark = new TextView(this);
            tvSubMark.setText(String.format("%.0f ( Grade %s )", m, grade));
            tvSubMark.setTextSize(13);
            tvSubMark.setTypeface(null, android.graphics.Typeface.BOLD);
            if ("A".equals(grade)) tvSubMark.setTextColor(0xFF16A34A);
            else if ("F".equals(grade)) tvSubMark.setTextColor(0xFFDC2626);
            else tvSubMark.setTextColor(0xFF2563EB);

            row.addView(tvSubName);
            row.addView(tvSubMark);
            container.addView(row);
        }

        // PDF Export Button
        com.google.android.material.button.MaterialButton btnPdf = new com.google.android.material.button.MaterialButton(this);
        btnPdf.setText("📄 මෙම ශිෂ්‍යයාගේ ප්‍රතිඵල වාර්තාව PDF ලෙස (Download Student Marks PDF)");
        btnPdf.setTextSize(12);
        btnPdf.setTextColor(android.graphics.Color.WHITE);
        btnPdf.setBackgroundColor(0xFF2563EB);
        LinearLayout.LayoutParams lpBtn = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lpBtn.setMargins(0, 20, 0, 0);
        btnPdf.setLayoutParams(lpBtn);

        btnPdf.setOnClickListener(v -> PdfReportExporter.exportStudentMarksPdf(ExamActivity.this, student));
        container.addView(btnPdf);

        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.addView(container);

        new AlertDialog.Builder(this)
                .setTitle("ශිෂ්‍ය ප්‍රතිඵල & ප්‍රගති වාර්තාව")
                .setView(scrollView)
                .setPositiveButton("වසා දමන්න", null)
                .show();
    }

    // ==========================================
    // TAB 4: Old Tests (Historical Exam Records)
    // ==========================================
    private void initTab4() {
        if (viewTab4 == null) return;
        spFilterYear = viewTab4.findViewById(R.id.spFilterYear);
        spFilterExamType = viewTab4.findViewById(R.id.spFilterExamType);
        tvFilterStatus = viewTab4.findViewById(R.id.tvFilterStatus);
        tvEmptyOldTests = viewTab4.findViewById(R.id.tvEmptyOldTests);
        rvOldTestsList = viewTab4.findViewById(R.id.rvOldTestsList);

        String[] yearList = new String[]{"2026", "2025", "2024", "2023"};
        ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, yearList);
        yearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spFilterYear != null) {
            spFilterYear.setAdapter(yearAdapter);
            spFilterYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedFilterYear = yearList[position];
                    refreshTab4Data();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        String[] examTypesList = new String[]{"1 වන වාර විභාගය", "2 වන වාර විභාගය", "3 වන වාර විභාගය", "ඒකක පරීක්ෂණය"};
        ArrayAdapter<String> examTypeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, examTypesList);
        examTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        if (spFilterExamType != null) {
            spFilterExamType.setAdapter(examTypeAdapter);
            spFilterExamType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    selectedFilterExamType = examTypesList[position];
                    refreshTab4Data();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        if (rvOldTestsList != null) {
            rvOldTestsList.setLayoutManager(new LinearLayoutManager(this));
            oldTestsAdapter = new OldTestsAdapter();
            rvOldTestsList.setAdapter(oldTestsAdapter);
        }
    }

    private void refreshTab4Data() {
        if (tvFilterStatus != null) {
            tvFilterStatus.setText("පෙන්වන්නේ: " + selectedFilterYear + " Academic Year | " + selectedFilterExamType);
        }

        String termId = ExamRepository.getTermIdFromExamType(selectedFilterExamType);
        List<ExamRepository.StudentExamResult> results = ExamRepository.getRankedResultsForTerm(this, selectedFilterYear, termId);

        if (oldTestsAdapter != null) {
            oldTestsAdapter.updateData(results);
        }

        if (tvEmptyOldTests != null) {
            if (results.isEmpty()) {
                tvEmptyOldTests.setVisibility(View.VISIBLE);
            } else {
                tvEmptyOldTests.setVisibility(View.GONE);
            }
        }
    }

    private class OldTestsAdapter extends RecyclerView.Adapter<OldTestsAdapter.ViewHolder> {
        private List<ExamRepository.StudentExamResult> list = new ArrayList<>();

        public void updateData(List<ExamRepository.StudentExamResult> newList) {
            this.list = newList != null ? newList : new ArrayList<>();
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_old_test_student, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ExamRepository.StudentExamResult res = list.get(position);
            holder.tvStudentRankBadge.setText("#" + res.rank);
            holder.tvStudentName.setText(res.student.getName());
            holder.tvStudentSubDetail.setText("Roll No: " + (res.student.getRollNo() != null ? res.student.getRollNo() : "STU") + " | " + res.student.getGrade());
            holder.tvTotalMarks.setText(String.format(java.util.Locale.US, "%.1f", res.totalMarks));
            holder.tvAverageMarks.setText(String.format(java.util.Locale.US, "Avg: %.1f%%", res.averageMarks));

            // Implement 2-second long press touch listener (delayLongPress={2000})
            holder.itemView.setOnTouchListener(new View.OnTouchListener() {
                private final Handler handler = new Handler(Looper.getMainLooper());
                private boolean isTriggered = false;
                private float startX, startY;
                private final Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        isTriggered = true;
                        try {
                            android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                            if (v != null) {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                    v.vibrate(android.os.VibrationEffect.createOneShot(100, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
                                } else {
                                    v.vibrate(100);
                                }
                            }
                        } catch (Exception ignored) {}
                        showExamDetailModal(res, selectedFilterYear, selectedFilterExamType);
                    }
                };

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            isTriggered = false;
                            startX = event.getX();
                            startY = event.getY();
                            v.setPressed(true);
                            handler.postDelayed(runnable, 2000); // 2000 ms hold threshold
                            return true;

                        case MotionEvent.ACTION_MOVE:
                            float dx = Math.abs(event.getX() - startX);
                            float dy = Math.abs(event.getY() - startY);
                            if (dx > 30 || dy > 30) {
                                handler.removeCallbacks(runnable);
                                v.setPressed(false);
                            }
                            return true;

                        case MotionEvent.ACTION_UP:
                            v.setPressed(false);
                            handler.removeCallbacks(runnable);
                            if (!isTriggered) {
                                Toast.makeText(ExamActivity.this, "ලකුණු පත්‍රිකාව බැලීමට තත්පර 2ක් ඔබාගෙන සිටින්න (Hold 2s for full report)", Toast.LENGTH_SHORT).show();
                            }
                            return true;

                        case MotionEvent.ACTION_CANCEL:
                            v.setPressed(false);
                            handler.removeCallbacks(runnable);
                            return true;
                    }
                    return false;
                }
            });
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvStudentRankBadge, tvStudentName, tvStudentSubDetail, tvTotalMarks, tvAverageMarks;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvStudentRankBadge = itemView.findViewById(R.id.tvStudentRankBadge);
                tvStudentName = itemView.findViewById(R.id.tvStudentName);
                tvStudentSubDetail = itemView.findViewById(R.id.tvStudentSubDetail);
                tvTotalMarks = itemView.findViewById(R.id.tvTotalMarks);
                tvAverageMarks = itemView.findViewById(R.id.tvAverageMarks);
            }
        }
    }

    private void showExamDetailModal(ExamRepository.StudentExamResult studentResult, String year, String examType) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_exam_detail_modal, null);
        TextView tvStudentName = dialogView.findViewById(R.id.tvModalStudentName);
        TextView tvExamSubInfo = dialogView.findViewById(R.id.tvModalExamSubInfo);
        TextView tvTotalBadge = dialogView.findViewById(R.id.tvModalTotalBadge);
        TextView tvAvgBadge = dialogView.findViewById(R.id.tvModalAvgBadge);
        TextView tvRankBadge = dialogView.findViewById(R.id.tvModalRankBadge);
        LinearLayout llMarksContainer = dialogView.findViewById(R.id.llModalMarksContainer);
        ImageView btnCloseHeader = dialogView.findViewById(R.id.btnModalClose);
        View btnCloseBottom = dialogView.findViewById(R.id.btnModalCloseBottom);
        View btnExportPdf = dialogView.findViewById(R.id.btnModalExportPdf);

        if (tvStudentName != null) tvStudentName.setText(studentResult.student.getName());
        if (tvExamSubInfo != null) tvExamSubInfo.setText("විභාගය: " + year + " Academic Year | " + examType);
        if (tvTotalBadge != null) tvTotalBadge.setText("එකතුව: " + String.format(java.util.Locale.US, "%.1f", studentResult.totalMarks));
        if (tvAvgBadge != null) tvAvgBadge.setText("සාමාන්‍යය: " + String.format(java.util.Locale.US, "%.1f%%", studentResult.averageMarks));
        if (tvRankBadge != null) tvRankBadge.setText("ස්ථානය: #" + studentResult.rank);

        if (llMarksContainer != null) {
            llMarksContainer.removeAllViews();
            List<String> subjects = ExamRepository.getStudentSubjects(studentResult.student.getId());
            Map<String, Double> marksMap = studentResult.marks;

            for (String sub : subjects) {
                View row = LayoutInflater.from(this).inflate(R.layout.item_exam_detail_subject_mark, llMarksContainer, false);
                TextView tvSubName = row.findViewById(R.id.tvModalSubjectName);
                TextView tvSubMark = row.findViewById(R.id.tvModalSubjectMark);
                TextView tvSubGrade = row.findViewById(R.id.tvModalSubjectGrade);

                tvSubName.setText(sub);
                Double m = marksMap != null ? marksMap.get(sub) : null;
                if (m == null || m < 0) {
                    tvSubMark.setText("ABSENT / නැත");
                    tvSubMark.setTextColor(0xFFEF4444);
                    tvSubGrade.setText("ABS");
                    tvSubGrade.setTextColor(0xFFEF4444);
                } else {
                    tvSubMark.setText(String.format(java.util.Locale.US, "%.1f", m));
                    tvSubMark.setTextColor(0xFF38BDF8);
                    String grade = ExamRepository.calculateGrade(this, m);
                    tvSubGrade.setText(grade);
                    if ("A".equals(grade)) tvSubGrade.setTextColor(0xFF4ADE80);
                    else if ("F".equals(grade)) tvSubGrade.setTextColor(0xFFEF4444);
                    else tvSubGrade.setTextColor(0xFFFACC15);
                }
                llMarksContainer.addView(row);
            }
        }

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        if (btnCloseHeader != null) btnCloseHeader.setOnClickListener(v -> dialog.dismiss());
        if (btnCloseBottom != null) btnCloseBottom.setOnClickListener(v -> dialog.dismiss());
        if (btnExportPdf != null) {
            btnExportPdf.setOnClickListener(v -> {
                dialog.dismiss();
                PdfReportExporter.exportStudentMarksPdf(ExamActivity.this, studentResult.student);
            });
        }

        dialog.show();
    }
}
