package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExamRepository {

    public static final List<String> ALL_SUBJECTS = new ArrayList<>(Arrays.asList(
            "ගණිතය", "විද්‍යාව", "සිංහල", "ඉංග්‍රීසි", "ඉතිහාසය",
            "බුද්ධ ධර්මය", "තොරතුරු තාක්ෂණය (ICT)", "වාණිජ", "චිත්‍ර", "සංගීතය"
    ));

    public static void addSubjectToMasterList(String subject) {
        if (subject != null && !subject.trim().isEmpty()) {
            String trimmed = subject.trim();
            if (!ALL_SUBJECTS.contains(trimmed)) {
                ALL_SUBJECTS.add(trimmed);
            }
        }
    }

    private static final Map<String, List<String>> studentSubjects = new HashMap<>();
    private static final Map<String, Map<String, Double>> studentMarks = new HashMap<>();
    private static final Map<String, Double> previousExamTotals = new HashMap<>();

    static {
        initDefaults();
    }

    private static void initDefaults() {
        // Production mode: Start empty. Real marks are added by the teacher per student.
    }

    public static List<String> getStudentSubjects(String studentId) {
        if (!studentSubjects.containsKey(studentId)) {
            studentSubjects.put(studentId, new ArrayList<>(ALL_SUBJECTS));
        }
        return studentSubjects.get(studentId);
    }

    public static void setStudentSubjects(String studentId, List<String> subjects) {
        studentSubjects.put(studentId, new ArrayList<>(subjects));
        // Remove marks for unselected subjects
        Map<String, Double> marks = getStudentMarks(studentId);
        List<String> toRemove = new ArrayList<>();
        for (String key : marks.keySet()) {
            if (!subjects.contains(key)) {
                toRemove.add(key);
            }
        }
        for (String r : toRemove) marks.remove(r);
        // Add default 0 for new subjects if needed
        for (String s : subjects) {
            if (!marks.containsKey(s)) {
                marks.put(s, 60.0);
            }
        }
    }

    public static String currentYear = "2026";
    public static String currentTermId = "term_1";
    public static String currentClassFilter = "All";

    private static String getStoreKey(String year, String termId, String studentId) {
        return year + "_" + termId + "_" + studentId;
    }

    public static Map<String, Double> getStudentMarks(String studentId) {
        return getStudentMarksForTerm(studentId, currentYear, currentTermId);
    }

    public static Map<String, Double> getStudentMarksForTerm(String studentId, String year, String termId) {
        String key = getStoreKey(year, termId, studentId);
        if (!studentMarks.containsKey(key)) {
            studentMarks.put(key, new HashMap<>());
        }
        return studentMarks.get(key);
    }

    public static void setStudentMark(String studentId, String subject, double mark) {
        setStudentMarkForTerm(null, studentId, subject, mark, currentYear, currentTermId);
    }

    public static void setStudentMarkForTerm(android.content.Context context, String studentId, String subject, double mark, String year, String termId) {
        Map<String, Double> marks = getStudentMarksForTerm(studentId, year, termId);
        marks.put(subject, mark);

        if (context != null) {
            saveMarksToPrefsAndFirestore(context, studentId, year, termId, marks);
        }
    }

    public static void saveMarksToPrefsAndFirestore(android.content.Context context, String studentId, String year, String termId, Map<String, Double> marks) {
        if (context == null) return;
        try {
            // 1. Local Prefs
            android.content.SharedPreferences prefs = context.getSharedPreferences("exam_marks_prefs", android.content.Context.MODE_PRIVATE);
            org.json.JSONObject obj = new org.json.JSONObject();
            for (Map.Entry<String, Double> e : marks.entrySet()) {
                obj.put(e.getKey(), e.getValue());
            }
            prefs.edit().putString(getStoreKey(year, termId, studentId), obj.toString()).apply();

            // 2. Firestore Sync
            com.google.firebase.auth.FirebaseUser currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser();
            if (currentUser == null || currentUser.getUid() == null || currentUser.getUid().isEmpty()) {
                android.util.Log.d("ExamRepository", "User not logged in. Aborting Firestore mark sync.");
                return;
            }
            String uid = currentUser.getUid();
            com.google.firebase.firestore.FirebaseFirestore db = com.google.firebase.firestore.FirebaseFirestore.getInstance();
            Map<String, Object> data = new HashMap<>();
            data.put("studentId", studentId);
            data.put("year", year);
            data.put("termId", termId);
            data.put("marks", marks);
            data.put("updatedAt", com.google.firebase.Timestamp.now());

            db.collection("users").document(uid)
                    .collection("exams").document(year)
                    .collection("terms").document(termId)
                    .collection("marks").document(studentId)
                    .set(data, com.google.firebase.firestore.SetOptions.merge());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadMarksFromPrefs(android.content.Context context, String studentId, String year, String termId) {
        if (context == null) return;
        try {
            android.content.SharedPreferences prefs = context.getSharedPreferences("exam_marks_prefs", android.content.Context.MODE_PRIVATE);
            String jsonStr = prefs.getString(getStoreKey(year, termId, studentId), "");
            if (jsonStr != null && !jsonStr.isEmpty()) {
                org.json.JSONObject obj = new org.json.JSONObject(jsonStr);
                Map<String, Double> marks = getStudentMarksForTerm(studentId, year, termId);
                java.util.Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String sub = keys.next();
                    marks.put(sub, obj.optDouble(sub, 0.0));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static double getPreviousExamTotal(String studentId) {
        Double prev = previousExamTotals.get(studentId);
        return prev != null ? prev : 220.0;
    }

    public static String calculateGrade(android.content.Context context, double mark) {
        return GradeBoundaryManager.calculateGrade(context, mark);
    }

    public static String calculateGrade(double mark) {
        return GradeBoundaryManager.calculateGrade(null, mark);
    }

    public static double calculateTotalMarks(String studentId) {
        Map<String, Double> marks = getStudentMarks(studentId);
        double total = 0.0;
        for (Double m : marks.values()) {
            if (m != null) total += m;
        }
        return total;
    }

    public static double calculateAverageMarks(String studentId) {
        Map<String, Double> marks = getStudentMarks(studentId);
        if (marks.isEmpty()) return 0.0;
        return calculateTotalMarks(studentId) / marks.size();
    }

    public static class StudentExamResult {
        public Student student;
        public double totalMarks;
        public double averageMarks;
        public int rank;
        public double progressGrowth;
        public Map<String, Double> marks;

        public StudentExamResult(Student student, double totalMarks, double averageMarks, Map<String, Double> marks) {
            this.student = student;
            this.totalMarks = totalMarks;
            this.averageMarks = averageMarks;
            this.marks = marks;
        }
    }

    public static List<StudentExamResult> getRankedResults() {
        List<Student> students = StudentRepository.getStudents();
        List<StudentExamResult> results = new ArrayList<>();

        for (Student s : students) {
            double total = calculateTotalMarks(s.getId());
            double avg = calculateAverageMarks(s.getId());
            Map<String, Double> marks = getStudentMarks(s.getId());
            StudentExamResult res = new StudentExamResult(s, total, avg, marks);

            double prevTotal = getPreviousExamTotal(s.getId());
            res.progressGrowth = total - prevTotal;

            results.add(res);
        }

        // Sort by total marks descending
        Collections.sort(results, (a, b) -> Double.compare(b.totalMarks, a.totalMarks));

        // Assign rank
        for (int i = 0; i < results.size(); i++) {
            results.get(i).rank = i + 1;
        }

        return results;
    }

    public static class SubjectStat {
        public String subject;
        public String highestStudentName;
        public double highestMark = -1;
        public String lowestStudentName;
        public double lowestMark = 101;
        public double averageMark = 0.0;
    }

    public static List<SubjectStat> getSubjectStats() {
        List<SubjectStat> stats = new ArrayList<>();
        List<Student> students = StudentRepository.getStudents();

        for (String sub : ALL_SUBJECTS) {
            SubjectStat stat = new SubjectStat();
            stat.subject = sub;
            double sum = 0.0;
            int count = 0;

            for (Student s : students) {
                Map<String, Double> marks = getStudentMarks(s.getId());
                if (marks.containsKey(sub)) {
                    double m = marks.get(sub);
                    sum += m;
                    count++;

                    if (m > stat.highestMark) {
                        stat.highestMark = m;
                        stat.highestStudentName = s.getName();
                    }
                    if (m < stat.lowestMark) {
                        stat.lowestMark = m;
                        stat.lowestStudentName = s.getName();
                    }
                }
            }

            if (count > 0) {
                stat.averageMark = sum / count;
                stats.add(stat);
            }
        }

        return stats;
    }

    public static void clear() {
        studentSubjects.clear();
        studentMarks.clear();
        previousExamTotals.clear();
    }
}
