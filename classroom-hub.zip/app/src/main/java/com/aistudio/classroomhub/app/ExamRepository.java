package com.aistudio.classroomhub.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExamRepository {

    public static final List<String> ALL_SUBJECTS = new ArrayList<>(Arrays.asList(
            "ගණිතය", "විද්‍යාව", "සිංහල", "ඉංග්‍රීසි", "ඉතිහාසය",
            "බුද්ධ ධර්මය", "තොරතුරු තාක්ෂණය (ICT)", "වාණිජ", "චිත්‍ර", "සංගීතය"
    ));

    public static void addSubjectToMasterList(String subject) {
        if (subject != null && !subject.trim().isEmpty()) {
            String trimmed = subject.trim();
            if (!ALL_SUBJECTS.contains(trimmed)) {
                ALL_SUBJECTS.add(trimmed);
            }
        }
    }

    private static final Map<String, List<String>> studentSubjects = new HashMap<>();
    private static final Map<String, Map<String, Double>> studentMarks = new HashMap<>();
    private static final Map<String, Double> previousExamTotals = new HashMap<>();

    static {
        initDefaults();
    }

    private static void initDefaults() {
        // Production mode: Start empty. Real marks are added by the teacher per student.
    }

    public static List<String> getStudentSubjects(String studentId) {
        if (!studentSubjects.containsKey(studentId)) {
            studentSubjects.put(studentId, new ArrayList<>(ALL_SUBJECTS));
        }
        return studentSubjects.get(studentId);
    }

    public static void setStudentSubjects(String studentId, List<String> subjects) {
        studentSubjects.put(studentId, new ArrayList<>(subjects));
        // Remove marks for unselected subjects
        Map<String, Double> marks = getStudentMarks(studentId);
        List<String> toRemove = new ArrayList<>();
        for (String key : marks.keySet()) {
            if (!subjects.contains(key)) {
                toRemove.add(key);
            }
        }
        for (String r : toRemove) marks.remove(r);
        // Do NOT populate hardcoded default marks like 60.0. Keep blank/unentered.
    }

    public static String currentYear = "2026";
    public static String currentTermId = "term_1";
    public static String currentClassFilter = "All";

    private static String getStoreKey(String year, String termId, String studentId) {
        return year + "_" + termId + "_" + studentId;
    }

    public static Map<String, Double> getStudentMarks(String studentId) {
        return getStudentMarksForTerm(studentId, currentYear, currentTermId);
    }

    public static Map<String, Double> getStudentMarksForTerm(String studentId, String year, String termId) {
        String key = getStoreKey(year, termId, studentId);
        if (!studentMarks.containsKey(key)) {
            studentMarks.put(key, new HashMap<>());
        }
        return studentMarks.get(key);
    }

    public static void setStudentMark(String studentId, String subject, double mark) {
        setStudentMarkForTerm(null, studentId, subject, mark, currentYear, currentTermId);
    }

    public static void setStudentMarkForTerm(android.content.Context context, String studentId, String subject, Double mark, String year, String termId) {
        Map<String, Double> marks = getStudentMarksForTerm(studentId, year, termId);
        if (mark == null) {
            marks.remove(subject);
        } else {
            marks.put(subject, mark);
        }

        if (context != null) {
            saveMarksToPrefsAndFirestore(context, studentId, year, termId, marks);
        }
    }

    public static void saveMarksToPrefsAndFirestore(android.content.Context context, String studentId, String year, String termId, Map<String, Double> marks) {
        if (context == null) return;
        try {
            // Local Prefs
            android.content.SharedPreferences prefs = context.getSharedPreferences("exam_marks_prefs", android.content.Context.MODE_PRIVATE);
            org.json.JSONObject obj = new org.json.JSONObject();
            for (Map.Entry<String, Double> e : marks.entrySet()) {
                obj.put(e.getKey(), e.getValue());
            }
            prefs.edit().putString(getStoreKey(year, termId, studentId), obj.toString()).apply();
            DataBackupManager.saveLocalState(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void loadMarksFromPrefs(android.content.Context context, String studentId, String year, String termId) {
        if (context == null) return;
        try {
            android.content.SharedPreferences prefs = context.getSharedPreferences("exam_marks_prefs", android.content.Context.MODE_PRIVATE);
            String jsonStr = prefs.getString(getStoreKey(year, termId, studentId), "");
            if (jsonStr != null && !jsonStr.isEmpty()) {
                org.json.JSONObject obj = new org.json.JSONObject(jsonStr);
                Map<String, Double> marks = getStudentMarksForTerm(studentId, year, termId);
                java.util.Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String sub = keys.next();
                    marks.put(sub, obj.optDouble(sub, 0.0));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static double getPreviousExamTotal(String studentId) {
        Double prev = previousExamTotals.get(studentId);
        return prev != null ? prev : 220.0;
    }

    public static String calculateGrade(android.content.Context context, double mark) {
        return GradeBoundaryManager.calculateGrade(context, mark);
    }

    public static String calculateGrade(double mark) {
        return GradeBoundaryManager.calculateGrade(null, mark);
    }

    public static double calculateTotalMarks(String studentId) {
        Map<String, Double> marks = getStudentMarks(studentId);
        double total = 0.0;
        for (Double m : marks.values()) {
            if (m != null) total += m;
        }
        return total;
    }

    public static double calculateAverageMarks(String studentId) {
        Map<String, Double> marks = getStudentMarks(studentId);
        if (marks.isEmpty()) return 0.0;
        return calculateTotalMarks(studentId) / marks.size();
    }

    public static class StudentExamResult {
        public Student student;
        public double totalMarks;
        public double averageMarks;
        public int rank;
        public double progressGrowth;
        public Map<String, Double> marks;

        // Progress Analytics
        public double avgTerm1 = 0.0;
        public double avgTerm2 = 0.0;
        public double avgTerm3 = 0.0;
        public boolean hasTerm1 = false;
        public boolean hasTerm2 = false;
        public boolean hasTerm3 = false;
        public double progressTerm1vs2 = 0.0; // Term 2 Avg - Term 1 Avg
        public double progressTerm2vs3 = 0.0; // Term 3 Avg - Term 2 Avg

        public StudentExamResult(Student student, double totalMarks, double averageMarks, Map<String, Double> marks) {
            this.student = student;
            this.totalMarks = totalMarks;
            this.averageMarks = averageMarks;
            this.marks = marks;
        }
    }

    public static String getTermIdFromExamType(String examType) {
        if (examType == null) return "term_1";
        if (examType.contains("2 වන") || examType.contains("2nd")) return "term_2";
        if (examType.contains("3 වන") || examType.contains("3rd")) return "term_3";
        if (examType.contains("ඒකක") || examType.contains("Unit")) return "unit_test";
        return "term_1";
    }

    public static List<StudentExamResult> getRankedResultsForTerm(android.content.Context context, String year, String termId) {
        List<Student> students = StudentRepository.getStudents();
        List<StudentExamResult> results = new ArrayList<>();

        for (Student s : students) {
            if (context != null) {
                loadMarksFromPrefs(context, s.getId(), year, "term_1");
                loadMarksFromPrefs(context, s.getId(), year, "term_2");
                loadMarksFromPrefs(context, s.getId(), year, "term_3");
                loadMarksFromPrefs(context, s.getId(), year, "unit_test");
            }

            Map<String, Double> marks = getStudentMarksForTerm(s.getId(), year, termId);
            double total = 0.0;
            int count = 0;
            for (Double m : marks.values()) {
                if (m != null && m >= 0) {
                    total += m;
                    count++;
                }
            }
            double avg = count > 0 ? total / count : 0.0;
            StudentExamResult res = new StudentExamResult(s, total, avg, marks);

            // Compute Term 1 Average
            Map<String, Double> t1 = getStudentMarksForTerm(s.getId(), year, "term_1");
            int countT1 = 0; double sumT1 = 0;
            for (Double m : t1.values()) { if (m != null && m >= 0) { sumT1 += m; countT1++; } }
            if (countT1 > 0) { res.hasTerm1 = true; res.avgTerm1 = sumT1 / countT1; }

            // Compute Term 2 Average
            Map<String, Double> t2 = getStudentMarksForTerm(s.getId(), year, "term_2");
            int countT2 = 0; double sumT2 = 0;
            for (Double m : t2.values()) { if (m != null && m >= 0) { sumT2 += m; countT2++; } }
            if (countT2 > 0) { res.hasTerm2 = true; res.avgTerm2 = sumT2 / countT2; }

            // Compute Term 3 Average
            Map<String, Double> t3 = getStudentMarksForTerm(s.getId(), year, "term_3");
            int countT3 = 0; double sumT3 = 0;
            for (Double m : t3.values()) { if (m != null && m >= 0) { sumT3 += m; countT3++; } }
            if (countT3 > 0) { res.hasTerm3 = true; res.avgTerm3 = sumT3 / countT3; }

            // Calculate differences
            if (res.hasTerm1 && res.hasTerm2) {
                res.progressTerm1vs2 = res.avgTerm2 - res.avgTerm1;
            }
            if (res.hasTerm2 && res.hasTerm3) {
                res.progressTerm2vs3 = res.avgTerm3 - res.avgTerm2;
            }

            results.add(res);
        }

        // Sort by total marks descending
        Collections.sort(results, (a, b) -> Double.compare(b.totalMarks, a.totalMarks));

        // Assign rank
        for (int i = 0; i < results.size(); i++) {
            results.get(i).rank = i + 1;
        }

        return results;
    }

    public static List<StudentExamResult> getRankedResults() {
        return getRankedResultsForTerm(null, currentYear, currentTermId);
    }

    public static class SubjectStat {
        public String subject;
        public String highestStudentName;
        public double highestMark = -1;
        public String lowestStudentName;
        public double lowestMark = 101;
        public double averageMark = 0.0;
    }

    public static List<SubjectStat> getSubjectStats() {
        List<SubjectStat> stats = new ArrayList<>();
        List<Student> students = StudentRepository.getStudents();

        for (String sub : ALL_SUBJECTS) {
            SubjectStat stat = new SubjectStat();
            stat.subject = sub;
            double sum = 0.0;
            int count = 0;

            for (Student s : students) {
                Map<String, Double> marks = getStudentMarks(s.getId());
                if (marks.containsKey(sub)) {
                    double m = marks.get(sub);
                    sum += m;
                    count++;

                    if (m > stat.highestMark) {
                        stat.highestMark = m;
                        stat.highestStudentName = s.getName();
                    }
                    if (m < stat.lowestMark) {
                        stat.lowestMark = m;
                        stat.lowestStudentName = s.getName();
                    }
                }
            }

            if (count > 0) {
                stat.averageMark = sum / count;
                stats.add(stat);
            }
        }

        return stats;
    }

    public static void clear() {
        studentSubjects.clear();
        studentMarks.clear();
        previousExamTotals.clear();
    }
}
