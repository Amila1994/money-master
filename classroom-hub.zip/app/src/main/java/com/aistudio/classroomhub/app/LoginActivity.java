package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.aistudio.classroomhub.app.databinding.ActivityLoginBinding;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.api.services.drive.DriveScopes;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    public static final String PREFS_NAME = "ClassroomHubPrefs";
    public static final String KEY_USER_NAME = "user_name";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_PHOTO = "user_photo";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";

    private ActivityLoginBinding binding;
    private GoogleSignInClient mGoogleSignInClient;
    private FirebaseAuth mAuth;

    private ActivityResultLauncher<Intent> googleSignInLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize Firebase Auth safely
        initFirebaseAuth();

        // Configure Google Sign-In
        configureGoogleSignIn();

        // Register Activity Result Launcher for Google Sign-In
        setupSignInLauncher();

        // Check if user is already logged in
        checkExistingSession();

        // Apply smooth entrance animations
        applyEntranceAnimations();

        // Setup click listeners
        setupClickListeners();
    }

    private void initFirebaseAuth() {
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this);
            }
            mAuth = FirebaseAuth.getInstance();
        } catch (Exception e) {
            Log.w(TAG, "Firebase unavailable: " + e.getMessage());
            mAuth = null;
        }
    }

    private void configureGoogleSignIn() {
        // Configure Google Sign-In options
        String webClientId;
        try {
            webClientId = getString(R.string.default_web_client_id);
        } catch (Exception e) {
            webClientId = "9530189130-dtpkvsafqeaa9rjslkq3ag8p581gugu1.apps.googleusercontent.com";
        }

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(webClientId)
                .requestEmail()
                .requestScopes(new Scope(DriveScopes.DRIVE_APPDATA))
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    private void setupSignInLauncher() {
        googleSignInLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getData() != null) {
                            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(result.getData());
                            handleSignInResult(task);
                        } else {
                            showLoading(false);
                            Toast.makeText(LoginActivity.this, "Google Sign-In canceled or failed.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void applyEntranceAnimations() {
        // Load the smooth fade_in animation
        Animation fadeInIllustration = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        Animation fadeInHeader = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        Animation fadeInCard = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        // Stagger start times for enhanced visual fluidity
        fadeInIllustration.setStartOffset(100);
        fadeInHeader.setStartOffset(300);
        fadeInCard.setStartOffset(500);

        binding.cardIllustration.startAnimation(fadeInIllustration);
        binding.layoutBrandHeader.startAnimation(fadeInHeader);
        binding.cardLoginAction.startAnimation(fadeInCard);
    }

    private void setupClickListeners() {
        // Google Sign-In Button
        binding.btnGoogleSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signInWithGoogle();
            }
        });
    }

    private void signInWithGoogle() {
        showLoading(true);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        googleSignInLauncher.launch(signInIntent);
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            if (account != null) {
                Log.d(TAG, "firebaseAuthWithGoogle:" + account.getId());
                firebaseAuthWithGoogle(account.getIdToken(), account);
            } else {
                showLoading(false);
                Toast.makeText(this, getString(R.string.sign_in_failed), Toast.LENGTH_SHORT).show();
            }
        } catch (ApiException e) {
            Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            showLoading(false);
            Toast.makeText(this, "Error: " + e.getStatusCode(), Toast.LENGTH_LONG).show();
            GoogleSignInAccount lastAccount = GoogleSignIn.getLastSignedInAccount(this);
            if (lastAccount != null) {
                saveUserSession(
                        lastAccount.getDisplayName() != null ? lastAccount.getDisplayName() : "Teacher User",
                        lastAccount.getEmail() != null ? lastAccount.getEmail() : "teacher@classroomhub.edu",
                        lastAccount.getPhotoUrl() != null ? lastAccount.getPhotoUrl().toString() : ""
                );
                navigateToDashboard();
            }
        } catch (Exception e) {
            Log.w(TAG, "signInResult:unexpected error", e);
            showLoading(false);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void firebaseAuthWithGoogle(String idToken, final GoogleSignInAccount account) {
        if (idToken == null || idToken.isEmpty() || mAuth == null) {
            // Fallback directly to Google Account details if Firebase ID Token is empty or Firebase unavailable
            if (account != null) {
                saveUserSession(
                        account.getDisplayName() != null ? account.getDisplayName() : "Teacher User",
                        account.getEmail() != null ? account.getEmail() : "teacher@classroomhub.edu",
                        account.getPhotoUrl() != null ? account.getPhotoUrl().toString() : ""
                );
                navigateToDashboard();
            }
            return;
        }

        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        showLoading(false);
                        if (task.isSuccessful()) {
                            // Firebase Sign-In successful
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                saveUserSession(
                                        user.getDisplayName() != null ? user.getDisplayName() : (account != null ? account.getDisplayName() : "Teacher User"),
                                        user.getEmail() != null ? user.getEmail() : (account != null ? account.getEmail() : ""),
                                        user.getPhotoUrl() != null ? user.getPhotoUrl().toString() : (account != null && account.getPhotoUrl() != null ? account.getPhotoUrl().toString() : "")
                                );
                            } else if (account != null) {
                                saveUserSession(
                                        account.getDisplayName() != null ? account.getDisplayName() : "Teacher User",
                                        account.getEmail() != null ? account.getEmail() : "",
                                        account.getPhotoUrl() != null ? account.getPhotoUrl().toString() : ""
                                );
                            }
                            navigateToDashboard();
                        } else {
                            // Sign In failed / Account disabled
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            
                            if (mGoogleSignInClient != null) {
                                mGoogleSignInClient.signOut();
                            }
                            if (mAuth != null) {
                                mAuth.signOut();
                            }

                            Toast.makeText(LoginActivity.this,
                                    "Your account has been disabled. Please contact support.",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void saveUserSession(String name, String email, String photoUrl) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_USER_NAME, name);
        editor.putString(KEY_USER_EMAIL, email);
        editor.putString(KEY_USER_PHOTO, photoUrl);
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.apply();
    }

    private void checkExistingSession() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false);
        FirebaseUser currentUser = mAuth != null ? mAuth.getCurrentUser() : null;

        if (isLoggedIn || currentUser != null) {
            navigateToDashboard();
        }
    }

    private void navigateToDashboard() {
        Intent intent = new Intent(LoginActivity.this, SplashActivity.class);
        startActivity(intent);
        finish();
    }

    private void showLoading(boolean isLoading) {
        if (isLoading) {
            binding.progressLoading.setVisibility(View.VISIBLE);
            binding.btnGoogleSignIn.setEnabled(false);
        } else {
            binding.progressLoading.setVisibility(View.GONE);
            binding.btnGoogleSignIn.setEnabled(true);
        }
    }
}
