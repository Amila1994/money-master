package com.aistudio.classroomhub.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StudentAdapter extends RecyclerView.Adapter<StudentAdapter.StudentViewHolder> {

    public interface OnStudentActionListener {
        void onDeleteStudent(Student student);
        void onStudentClick(Student student);
        void onStudentLongClick(Student student);
    }

    private List<Student> studentList;
    private OnStudentActionListener listener;

    public StudentAdapter(List<Student> studentList, OnStudentActionListener listener) {
        this.studentList = studentList;
        this.listener = listener;
    }

    public void updateList(List<Student> newList) {
        this.studentList = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_student_card, parent, false);
        return new StudentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StudentViewHolder holder, int position) {
        Student student = studentList.get(position);
        holder.bind(student, listener);
    }

    @Override
    public int getItemCount() {
        return studentList != null ? studentList.size() : 0;
    }

    static class StudentViewHolder extends RecyclerView.ViewHolder {
        TextView tvStudentInitial, tvStudentName, tvNameWithInitials, tvRegNoBadge;
        ImageButton btnDeleteStudent;

        public StudentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvStudentInitial = itemView.findViewById(R.id.tvStudentInitial);
            tvStudentName = itemView.findViewById(R.id.tvStudentName);
            tvNameWithInitials = itemView.findViewById(R.id.tvNameWithInitials);
            tvRegNoBadge = itemView.findViewById(R.id.tvRegNoBadge);
            btnDeleteStudent = itemView.findViewById(R.id.btnDeleteStudent);
        }

        public void bind(final Student student, final OnStudentActionListener listener) {
            String fullName = student.getName() != null && !student.getName().isEmpty() ? student.getName() : "Unknown";
            String initialsName = student.getNameWithInitials() != null && !student.getNameWithInitials().isEmpty() 
                    ? student.getNameWithInitials() : fullName;

            tvStudentInitial.setText(String.valueOf(initialsName.charAt(0)).toUpperCase());
            tvStudentName.setText(fullName);
            tvNameWithInitials.setText(initialsName);

            String regNo = student.getRollNo() != null && !student.getRollNo().isEmpty() ? student.getRollNo() : "REG-0";
            tvRegNoBadge.setText(regNo);

            btnDeleteStudent.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeleteStudent(student);
                }
            });

            itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onStudentClick(student);
                }
            });

            itemView.setOnLongClickListener(v -> {
                if (listener != null) {
                    listener.onStudentLongClick(student);
                }
                return true;
            });
        }
    }
}
