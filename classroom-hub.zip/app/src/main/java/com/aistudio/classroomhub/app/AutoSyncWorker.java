package com.aistudio.classroomhub.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.aistudio.classroomhub.app.db.AppDatabase;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.tasks.Tasks;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;

import java.util.Collections;

public class AutoSyncWorker extends Worker {

    private static final String TAG = "AutoSyncWorker";

    public AutoSyncWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        Log.d(TAG, "Executing silent background sync via WorkManager...");

        try {
            // 1. Save state locally first (Offline-First)
            DataBackupManager.saveLocalState(context);

            // 2. Obtain JSON string
            String jsonContent = DataBackupManager.exportAllDataToJson(context);
            if (jsonContent == null || jsonContent.isEmpty() || jsonContent.equals("{}")) {
                Log.d(TAG, "No app data to sync.");
                return Result.success();
            }

            // Save under user's Firestore document
            DataBackupManager.saveUserScopedDataToFirestore(context, jsonContent);

            // 3. Initialize Google Drive Service
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(context);
            if (account == null || account.getAccount() == null) {
                Log.w(TAG, "Google Account not signed in. Will retry sync when signed in.");
                return Result.success();
            }

            GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(
                    context, Collections.singleton(DriveScopes.DRIVE_APPDATA));
            credential.setSelectedAccount(account.getAccount());

            Drive driveService = new Drive.Builder(
                    new NetHttpTransport(),
                    new GsonFactory(),
                    credential)
                    .setApplicationName("Classroom Hub")
                    .build();

            DriveServiceHelper driveHelper = new DriveServiceHelper(driveService);
            DriveSyncManager syncManager = new DriveSyncManager(driveService);

            // 4. Perform silent upload to Google Drive App Data Folder
            Boolean success = Tasks.await(syncManager.autoBackupToDrive(jsonContent));
            Tasks.await(driveHelper.saveDataToDrive("classroom_master_backup.json", jsonContent));

            if (Boolean.TRUE.equals(success)) {
                // Update local sync state in Room and SharedPreferences
                AppDatabase.getInstance(context).backupDao().setSyncStatus(true);
                SharedPreferences syncPrefs = context.getSharedPreferences(DataBackupManager.PREFS_SYNC, Context.MODE_PRIVATE);
                syncPrefs.edit().putLong(DataBackupManager.KEY_LAST_SYNC_TIME, System.currentTimeMillis()).apply();

                Log.d(TAG, "Silent background sync completed successfully!");
                return Result.success();
            } else {
                return Result.retry();
            }

        } catch (Exception e) {
            Log.e(TAG, "Background sync failed: " + e.getMessage(), e);
            return Result.retry();
        }
    }
}
