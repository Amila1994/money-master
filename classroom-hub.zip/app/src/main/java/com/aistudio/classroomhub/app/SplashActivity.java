package com.aistudio.classroomhub.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    private static final long SPLASH_DURATION_MS = 5000; // 5 Seconds Splash Duration

    private TextView tvDigitalClock;
    private TextView tvLiveDate;
    private TextView tvSyncStatus;
    private TextView tvSyncDetail;
    private TextView tvCountdown;
    private AppLoadingView splashLoader;

    private Handler clockHandler = new Handler(Looper.getMainLooper());
    private Runnable clockRunnable;
    private CountDownTimer countDownTimer;

    private SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a", Locale.getDefault());
    private SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault());

    private boolean isSessionChecked = false;
    private boolean shouldNavigateToMain = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ClassroomHubApplication.initFirestoreSettings();
        setContentView(R.layout.activity_splash);

        initViews();
        startClockAndDateUpdates();
        setupSplashLoaderStyle();
        checkNetworkAndStartSplashTimer();
    }

    private void initViews() {
        tvDigitalClock = findViewById(R.id.tvDigitalClock);
        tvLiveDate = findViewById(R.id.tvLiveDate);
        tvSyncStatus = findViewById(R.id.tvSyncStatus);
        tvSyncDetail = findViewById(R.id.tvSyncDetail);
        tvCountdown = findViewById(R.id.tvCountdown);
        splashLoader = findViewById(R.id.splashLoader);
    }

    private void setupSplashLoaderStyle() {
        if (splashLoader != null) {
            LoadingAnimationManager.LoaderStyle style = LoadingAnimationManager.getSelectedStyle(this);
            splashLoader.setLoaderStyle(style);
        }
    }

    private void startClockAndDateUpdates() {
        clockRunnable = new Runnable() {
            @Override
            public void run() {
                Date now = new Date();
                if (tvDigitalClock != null) {
                    String timePattern = TimeFormatManager.is24HourFormat(SplashActivity.this) ? "HH:mm:ss" : "hh:mm:ss a";
                    SimpleDateFormat timeFormat = new SimpleDateFormat(timePattern, Locale.getDefault());
                    tvDigitalClock.setText(timeFormat.format(now));
                }
                if (tvLiveDate != null) {
                    tvLiveDate.setText(dateFormat.format(now));
                }
                clockHandler.postDelayed(this, 1000);
            }
        };
        clockHandler.post(clockRunnable);
    }

    private void startSyncAnimations() {
        // AppLoadingView handles its own smooth canvas animation
    }

    private void checkNetworkAndStartSplashTimer() {
        if (!NetworkUtils.isInternetAvailable(this)) {
            showNoInternetDialog();
            return;
        }

        // Verify Session in Background while timer runs
        verifyUserSession();

        // 5-Second Countdown Timer
        countDownTimer = new CountDownTimer(SPLASH_DURATION_MS, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int secondsRemaining = (int) Math.ceil(millisUntilFinished / 1000.0);
                if (tvCountdown != null) {
                    tvCountdown.setText("තව " + secondsRemaining + "s");
                }

                if (tvSyncStatus != null) {
                    tvSyncStatus.setText("දත්ත ලෝඩ් වෙමින් පවතී... (" + secondsRemaining + "s)");
                }

                if (secondsRemaining <= 2 && tvSyncDetail != null) {
                    tvSyncDetail.setText("Classroom Hub පද්ධතිය සූදානම්!");
                } else if (secondsRemaining <= 4 && tvSyncDetail != null) {
                    tvSyncDetail.setText("ශිෂ්‍ය වාර්තා හා පැමිණීම් සසඳමින් පවතී...");
                }
            }

            @Override
            public void onFinish() {
                if (tvCountdown != null) {
                    tvCountdown.setText("තව 0s");
                }
                proceedToNextActivity();
            }
        }.start();
    }

    private void verifyUserSession() {
        final SharedPreferences prefs = getSharedPreferences(LoginActivity.PREFS_NAME, MODE_PRIVATE);
        final boolean isLoggedIn = prefs.getBoolean(LoginActivity.KEY_IS_LOGGED_IN, false);

        FirebaseUser currentUser = null;
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this);
            }
            currentUser = FirebaseAuth.getInstance().getCurrentUser();
        } catch (Exception ignored) {
        }

        if (currentUser != null) {
            currentUser.reload().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    isSessionChecked = true;
                    if (task.isSuccessful()) {
                        shouldNavigateToMain = true;
                    } else {
                        shouldNavigateToMain = false;
                        prefs.edit().clear().apply();
                        try {
                            FirebaseAuth.getInstance().signOut();
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        } else {
            isSessionChecked = true;
            shouldNavigateToMain = false;
            prefs.edit().clear().apply();
        }
    }

    private void proceedToNextActivity() {
        if (shouldNavigateToMain) {
            SharedPreferences syncPrefs = getSharedPreferences(DataBackupManager.PREFS_SYNC, MODE_PRIVATE);
            boolean isRestored = syncPrefs.getBoolean(DataBackupManager.KEY_IS_RESTORED, false);

            if (!isRestored) {
                Intent intent = new Intent(SplashActivity.this, BackupRestoreActivity.class);
                startActivity(intent);
            } else {
                boolean isPinRequired = (AppSecurityManager.isPinEnabled(this) || !AppSecurityManager.getPinCode(this).isEmpty());
                if (isPinRequired) {
                    AppSecurityManager.setPinUnlockedSession(this, false);
                    Intent intent = new Intent(SplashActivity.this, PinLockActivity.class);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        } else {
            Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }
    }

    private void showNoInternetDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Internet Connection Required")
                .setMessage("Please check your internet connection to access the app.")
                .setCancelable(false)
                .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        checkNetworkAndStartSplashTimer();
                    }
                })
                .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (clockHandler != null && clockRunnable != null) {
            clockHandler.removeCallbacks(clockRunnable);
        }
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
