package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;

import java.util.Collections;

public class BackupRestoreActivity extends AppCompatActivity {

    private static final String TAG = "BackupRestoreActivity";

    private ProgressBar progressBar;
    private TextView tvCheckingStatus;
    private DriveSyncManager syncManager;
    private DriveServiceHelper driveHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_backup_restore);

        progressBar = findViewById(R.id.progressBar);
        tvCheckingStatus = findViewById(R.id.tvCheckingStatus);

        sharedPreferences = getSharedPreferences(DataBackupManager.PREFS_SYNC, Context.MODE_PRIVATE);

        performFirestoreUserRestore();
    }

    private void performFirestoreUserRestore() {
        com.google.firebase.auth.FirebaseUser user = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser();
        if (user == null || user.getUid() == null || user.getUid().isEmpty()) {
            Log.d(TAG, "No authenticated user for restore. Skipping.");
            sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
            finishAndNavigateToMain();
            return;
        }

        if (progressBar != null) {
            progressBar.setVisibility(View.VISIBLE);
        }
        if (tvCheckingStatus != null) {
            tvCheckingStatus.setText("ගිණුම් දත්ත නැවත ලබා ගනිමින් පවතී... / Restoring user profile & data...");
        }

        DataBackupManager.fetchUserScopedDataFromFirestore(this, new DataBackupManager.FirestoreFetchCallback() {
            @Override
            public void onSuccess(boolean restored) {
                Log.d(TAG, "Firestore user restore completed. Data restored: " + restored);
                sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
                if (restored && !isFinishing()) {
                    Toast.makeText(BackupRestoreActivity.this, "දත්ත සාර්ථකව පිහිටුවන ලදී / Data restored successfully", Toast.LENGTH_SHORT).show();
                }
                finishAndNavigateToMain();
            }

            @Override
            public void onFailure(Exception e) {
                Log.e(TAG, "Firestore user restore failed", e);
                sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
                finishAndNavigateToMain();
            }
        });
    }

    private void initDriveService() {
        try {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
            if (account != null && account.getAccount() != null) {
                GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(
                        this, Collections.singleton(DriveScopes.DRIVE_APPDATA));
                credential.setSelectedAccount(account.getAccount());

                Drive driveService = new Drive.Builder(
                        new NetHttpTransport(),
                        new GsonFactory(),
                        credential)
                        .setApplicationName("Classroom Hub")
                        .build();

                syncManager = new DriveSyncManager(driveService);
                driveHelper = new DriveServiceHelper(driveService);
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to init Google Drive client", e);
        }
    }

    private void checkForCloudBackup() {
        if (syncManager == null && driveHelper == null) {
            // Drive client unavailable, skip to main
            finishAndNavigateToMain();
            return;
        }

        // Search Google Drive App Data Folder for backup files
        syncManager.fetchLatestBackup()
                .addOnSuccessListener(jsonContent -> {
                    if (jsonContent != null && !jsonContent.trim().isEmpty() && !jsonContent.equals("{}") && !jsonContent.equals("[]")) {
                        showBackupFoundDialog(jsonContent);
                    } else {
                        // Check secondary driveHelper filename
                        driveHelper.readDataFromDrive("classroom_data.json")
                                .addOnSuccessListener(secondJson -> {
                                    if (secondJson != null && !secondJson.trim().isEmpty() && !secondJson.equals("{}") && !secondJson.equals("[]")) {
                                        showBackupFoundDialog(secondJson);
                                    } else {
                                        onNoBackupFound();
                                    }
                                })
                                .addOnFailureListener(e -> onNoBackupFound());
                    }
                })
                .addOnFailureListener(e -> onNoBackupFound());
    }

    private void showBackupFoundDialog(final String jsonContent) {
        if (isFinishing()) return;

        new AlertDialog.Builder(this)
                .setTitle(AppTranslation.get(this, "backup_found_title"))
                .setMessage(AppTranslation.get(this, "backup_found_msg"))
                .setCancelable(false)
                .setPositiveButton(AppTranslation.get(this, "restore_btn"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        performBlockingRestore(jsonContent);
                    }
                })
                .setNegativeButton(AppTranslation.get(this, "skip_btn"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
                        finishAndNavigateToMain();
                    }
                })
                .show();
    }

    private void performBlockingRestore(final String jsonContent) {
        // Show non-cancelable Progress Dialog as required
        final ProgressDialog restoreProgress = new ProgressDialog(this);
        restoreProgress.setMessage(AppTranslation.get(this, "restoring_progress"));
        restoreProgress.setCancelable(false);
        restoreProgress.setCanceledOnTouchOutside(false);
        restoreProgress.show();

        new Thread(() -> {
            // Restore into Room Database & Repositories
            boolean success = DataBackupManager.restoreDataFromJson(BackupRestoreActivity.this, jsonContent);

            new Handler(Looper.getMainLooper()).post(() -> {
                if (!isFinishing()) {
                    restoreProgress.dismiss();
                    if (success) {
                        Toast.makeText(BackupRestoreActivity.this, AppTranslation.get(BackupRestoreActivity.this, "restore_success"), Toast.LENGTH_SHORT).show();
                    }
                    sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
                    finishAndNavigateToMain();
                }
            });
        }).start();
    }

    private void onNoBackupFound() {
        if (isFinishing()) return;
        sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
        finishAndNavigateToMain();
    }

    private void finishAndNavigateToMain() {
        SyncScheduler.scheduleDailyPeriodicSync(this);

        boolean isPinRequired = (AppSecurityManager.isPinEnabled(this) || !AppSecurityManager.getPinCode(this).isEmpty());
        Intent intent;
        if (isPinRequired) {
            AppSecurityManager.setPinUnlockedSession(this, false);
            intent = new Intent(this, PinLockActivity.class);
        } else {
            intent = new Intent(this, MainActivity.class);
        }
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
