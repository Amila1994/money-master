package com.aistudio.classroomhub.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

public class BackupRestoreActivity extends AppCompatActivity {

    private static final String TAG = "BackupRestoreActivity";
    private static final String KEY_LAST_BACKUP_TIMESTAMP = "last_drive_backup_timestamp";
    public static final String KEY_AUTO_BACKUP_ENABLED = "drive_auto_backup_enabled";
    public static final String KEY_AUTO_BACKUP_FREQUENCY = "drive_auto_backup_frequency";

    private ImageView btnBack;
    private TextView tvAccountEmail;
    private TextView tvAuthScopeStatus;
    private MaterialButton btnGoogleAuth;

    private TextView tvLastBackupDate;
    private TextView tvBackupFileName;

    private SwitchMaterial switchAutoBackup;
    private Spinner spAutoBackupFrequency;
    private LinearLayout layoutAutoBackupFreq;

    private MaterialButton btnBackupNow;
    private MaterialButton btnRestoreNow;

    private RelativeLayout layoutLoadingOverlay;
    private TextView tvProgressStatus;

    private DriveSyncManager driveSyncManager;
    private DriveServiceHelper driveServiceHelper;
    private SharedPreferences sharedPreferences;

    private ActivityResultLauncher<Intent> googleSignInLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppSecurityManager.applyAppLocale(this);
        setContentView(R.layout.activity_backup_restore);
        WindowInsetUtils.applySystemBarPadding(this);

        sharedPreferences = getSharedPreferences(DataBackupManager.PREFS_SYNC, Context.MODE_PRIVATE);

        initViews();
        setupGoogleSignInLauncher();
        initDriveServiceAndUI();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        tvAccountEmail = findViewById(R.id.tvAccountEmail);
        tvAuthScopeStatus = findViewById(R.id.tvAuthScopeStatus);
        btnGoogleAuth = findViewById(R.id.btnGoogleAuth);

        tvLastBackupDate = findViewById(R.id.tvLastBackupDate);
        tvBackupFileName = findViewById(R.id.tvBackupFileName);

        switchAutoBackup = findViewById(R.id.switchAutoBackup);
        spAutoBackupFrequency = findViewById(R.id.spAutoBackupFrequency);
        layoutAutoBackupFreq = findViewById(R.id.layoutAutoBackupFreq);

        btnBackupNow = findViewById(R.id.btnBackupNow);
        btnRestoreNow = findViewById(R.id.btnRestoreNow);

        layoutLoadingOverlay = findViewById(R.id.layoutLoadingOverlay);
        tvProgressStatus = findViewById(R.id.tvProgressStatus);

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> navigateToMainDashboard());
        }

        if (btnGoogleAuth != null) {
            btnGoogleAuth.setOnClickListener(v -> startGoogleSignIn());
        }

        if (btnBackupNow != null) {
            btnBackupNow.setOnClickListener(v -> showBackupConfirmationDialog());
        }

        if (btnRestoreNow != null) {
            btnRestoreNow.setOnClickListener(v -> showRestoreConfirmationDialog());
        }

        setupAutoBackupControls();
        updateLastBackupDateUI();
    }

    private void setupAutoBackupControls() {
        sharedPreferences.edit().putBoolean(KEY_AUTO_BACKUP_ENABLED, false).apply();
        if (switchAutoBackup != null) {
            switchAutoBackup.setChecked(false);
            switchAutoBackup.setEnabled(false);
        }
        if (layoutAutoBackupFreq != null) {
            layoutAutoBackupFreq.setVisibility(View.GONE);
        }
    }

    private void setupGoogleSignInLauncher() {
        googleSignInLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        GoogleSignIn.getSignedInAccountFromIntent(result.getData())
                                .addOnSuccessListener(account -> {
                                    Toast.makeText(this, "Google account linked successfully!", Toast.LENGTH_SHORT).show();
                                    initDriveServiceAndUI();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(this, "Sign in failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    Log.e(TAG, "Google sign in failed", e);
                                });
                    }
                }
        );
    }

    private void startGoogleSignIn() {
        Scope driveFileScope = new Scope(DriveScopes.DRIVE_FILE);
        Scope driveAppDataScope = new Scope(DriveScopes.DRIVE_APPDATA);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(driveFileScope, driveAppDataScope)
                .build();

        GoogleSignInClient client = GoogleSignIn.getClient(this, gso);
        googleSignInLauncher.launch(client.getSignInIntent());
    }

    private void initDriveServiceAndUI() {
        try {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
            if (account != null && account.getAccount() != null) {
                if (tvAccountEmail != null) {
                    tvAccountEmail.setText("ගිණුම: " + account.getEmail());
                }
                if (tvAuthScopeStatus != null) {
                    tvAuthScopeStatus.setText("අවසරය: drive.file & drive.appdata (Authorized)");
                    tvAuthScopeStatus.setTextColor(0xFF4ADE80);
                }

                GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(
                        this, Arrays.asList(DriveScopes.DRIVE_FILE, DriveScopes.DRIVE_APPDATA));
                credential.setSelectedAccount(account.getAccount());

                Drive driveService = new Drive.Builder(
                        new NetHttpTransport(),
                        new GsonFactory(),
                        credential)
                        .setApplicationName("Classroom Hub")
                        .build();

                driveSyncManager = new DriveSyncManager(driveService);
                driveServiceHelper = new DriveServiceHelper(driveService);

                if (btnGoogleAuth != null) {
                    btnGoogleAuth.setText("වෙනත් Google ගිණුමක් තෝරන්න (Switch Account)");
                }

                fetchDriveMetadataAndUpdateUI();
            } else {
                if (tvAccountEmail != null) {
                    tvAccountEmail.setText("ගිණුම: සම්බන්ධ වී නැත (Not Signed In)");
                }
                if (tvAuthScopeStatus != null) {
                    tvAuthScopeStatus.setText("අවසරය: Google Sign-In අවශ්‍යයි");
                    tvAuthScopeStatus.setTextColor(0xFFEF4444);
                }
                if (btnGoogleAuth != null) {
                    btnGoogleAuth.setText("Google ගිණුම සක්‍රිය කරන්න / Sign In");
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error initializing Drive service", e);
        }
    }

    private void fetchDriveMetadataAndUpdateUI() {
        if (driveSyncManager == null) return;
        driveSyncManager.getLatestBackupMetadata()
                .addOnSuccessListener(file -> {
                    if (file != null) {
                        String fileName = file.getName();
                        if (tvBackupFileName != null && fileName != null) {
                            tvBackupFileName.setText(fileName);
                        }
                        com.google.api.client.util.DateTime modifiedTime = file.getModifiedTime();
                        if (modifiedTime == null) {
                            modifiedTime = file.getCreatedTime();
                        }
                        if (modifiedTime != null) {
                            long millis = modifiedTime.getValue();
                            sharedPreferences.edit().putLong(KEY_LAST_BACKUP_TIMESTAMP, millis).apply();
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
                            String formattedDate = sdf.format(new Date(millis));
                            if (tvLastBackupDate != null) {
                                tvLastBackupDate.setText(formattedDate + " (Google Drive)");
                                tvLastBackupDate.setTextColor(0xFF4ADE80);
                            }
                            return;
                        }
                    }
                    updateLastBackupDateUI();
                })
                .addOnFailureListener(e -> updateLastBackupDateUI());
    }

    private void updateLastBackupDateUI() {
        long timestamp = sharedPreferences.getLong(KEY_LAST_BACKUP_TIMESTAMP, 0);
        if (timestamp > 0) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            String formattedDate = sdf.format(new Date(timestamp));
            if (tvLastBackupDate != null) {
                tvLastBackupDate.setText(formattedDate);
                tvLastBackupDate.setTextColor(0xFF4ADE80);
            }
        } else {
            if (tvLastBackupDate != null) {
                tvLastBackupDate.setText("තවම නොමැත (No backup recorded)");
                tvLastBackupDate.setTextColor(0xFFFACC15);
            }
        }
    }

    private void showBackupConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("☁️ Google Drive Backup")
                .setMessage("ඔබගේ සියලු සිසුන්, විභාග, පැමිණීම, සහ ලකුණු ඇතුළු දත්ත 'app_backup.json' ලෙස Google Drive එකට Save කිරීමට අවශ්‍යද?\n\n(පැරණි Backup එක Overwrite වේ)")
                .setPositiveButton("ඔව් (Backup Now)", (dialog, which) -> performBackupAction())
                .setNegativeButton("අවලංගුයි (Cancel)", null)
                .show();
    }

    private void performBackupAction() {
        if (!NetworkUtils.isInternetAvailable(this)) {
            Toast.makeText(this, "අන්තර්ජාල සම්බන්ධතාවය පරීක්ෂා කරන්න (Please check your internet connection)", Toast.LENGTH_LONG).show();
            return;
        }

        if (driveSyncManager == null && driveServiceHelper == null) {
            Toast.makeText(this, "කරුණාකර පළමුව Google ගිණුම සක්‍රිය (Sign In) කරන්න.", Toast.LENGTH_LONG).show();
            startGoogleSignIn();
            return;
        }

        showLoadingOverlay("දත්ත 'app_backup.json' ලෙස Google Drive එකට Backup වෙමින් පවතී...");

        new Thread(() -> {
            try {
                // 1. Export all local app data to JSON string
                String jsonContent = DataBackupManager.exportAllDataToJson(BackupRestoreActivity.this);

                // 2. Upload to Google Drive using DriveSyncManager / DriveServiceHelper
                if (driveSyncManager != null) {
                    driveSyncManager.autoBackupToDrive(jsonContent)
                            .addOnSuccessListener(success -> onBackupSuccess())
                            .addOnFailureListener(this::onBackupFailed);
                } else {
                    driveServiceHelper.saveDataToDrive("app_backup.json", jsonContent)
                            .addOnSuccessListener(fileId -> onBackupSuccess())
                            .addOnFailureListener(this::onBackupFailed);
                }
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> onBackupFailed(e));
            }
        }).start();
    }

    private void onBackupSuccess() {
        long now = System.currentTimeMillis();
        sharedPreferences.edit().putLong(KEY_LAST_BACKUP_TIMESTAMP, now).apply();

        hideLoadingOverlay();
        updateLastBackupDateUI();

        new AlertDialog.Builder(this)
                .setTitle("✅ Backup Successful")
                .setMessage("ඔබගේ සියලුම දත්ත 'app_backup.json' නමින් Google Drive එකට සාර්ථකව Upload / Overwrite කරන ලදී.")
                .setPositiveButton("හරි (OK)", null)
                .show();
    }

    private void onBackupFailed(Exception e) {
        hideLoadingOverlay();
        Log.e(TAG, "Backup failed", e);
        Toast.makeText(this, "Backup අසාර්ථක විය: " + e.getMessage(), Toast.LENGTH_LONG).show();
    }

    private void showRestoreConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("📥 Restore App Data")
                .setMessage("⚠️ අවධානයයි: Google Drive හි ඇති 'app_backup.json' ගොනුවෙන් දත්ත ලබාගෙන දැනට ඇති Local Data Overwrite කිරීමට අවශ්‍යද?\n\n(මෙමගින් වත්මන් දත්ත වෙනස් විය හැක)")
                .setPositiveButton("ඔව් (Restore Now)", (dialog, which) -> performRestoreAction())
                .setNegativeButton("අවලංගුයි (Cancel)", null)
                .show();
    }

    private void performRestoreAction() {
        if (!NetworkUtils.isInternetAvailable(this)) {
            Toast.makeText(this, "අන්තර්ජාල සම්බන්ධතාවය පරීක්ෂා කරන්න (Please check your internet connection)", Toast.LENGTH_LONG).show();
            return;
        }

        if (driveSyncManager == null && driveServiceHelper == null) {
            Toast.makeText(this, "කරුණාකර පළමුව Google ගිණුම සක්‍රිය (Sign In) කරන්න.", Toast.LENGTH_LONG).show();
            startGoogleSignIn();
            return;
        }

        showLoadingOverlay("'app_backup.json' ගොනුව Google Drive එකෙන් Download වෙමින් පවතී...");

        if (driveSyncManager != null) {
            driveSyncManager.fetchLatestBackup()
                    .addOnSuccessListener(jsonContent -> {
                        if (jsonContent != null && !jsonContent.trim().isEmpty() && !jsonContent.equals("{}")) {
                            processRestoreJson(jsonContent);
                        } else {
                            // Check fallback from driveServiceHelper
                            fetchFallbackRestoreJson();
                        }
                    })
                    .addOnFailureListener(e -> fetchFallbackRestoreJson());
        } else {
            fetchFallbackRestoreJson();
        }
    }

    private void fetchFallbackRestoreJson() {
        if (driveServiceHelper != null) {
            driveServiceHelper.readDataFromDrive("app_backup.json")
                    .addOnSuccessListener(jsonContent -> {
                        if (jsonContent != null && !jsonContent.trim().isEmpty()) {
                            processRestoreJson(jsonContent);
                        } else {
                            hideLoadingOverlay();
                            Toast.makeText(this, "Google Drive හි 'app_backup.json' ගොනුව සොයාගත නොහැකි විය.", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        hideLoadingOverlay();
                        Toast.makeText(this, "Restore කිරීමට අපොහොසත් විය: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    });
        } else {
            hideLoadingOverlay();
            Toast.makeText(this, "Google Drive service නොමැත.", Toast.LENGTH_SHORT).show();
        }
    }

    private void processRestoreJson(String jsonContent) {
        if (tvProgressStatus != null) {
            tvProgressStatus.setText("දත්ත Local Database එකට Restore කරමින් පවතී...");
        }

        new Thread(() -> {
            boolean success = DataBackupManager.restoreDataFromJson(BackupRestoreActivity.this, jsonContent);

            new Handler(Looper.getMainLooper()).post(() -> {
                hideLoadingOverlay();
                if (success) {
                    sharedPreferences.edit().putBoolean(DataBackupManager.KEY_IS_RESTORED, true).apply();
                    new AlertDialog.Builder(BackupRestoreActivity.this)
                            .setTitle("🎉 Restore Successful")
                            .setMessage("Google Drive හි 'app_backup.json' ගොනුවෙන් සිසුන්, විභාග, පැමිණීම සහ ලකුණු ඇතුළු සියලු දත්ත සාර්ථකව Restore කරන ලදී!")
                            .setPositiveButton("හරි (OK)", (dialog, which) -> {
                                Intent intent = new Intent(BackupRestoreActivity.this, MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            })
                            .setCancelable(false)
                            .show();
                } else {
                    Toast.makeText(BackupRestoreActivity.this, "දත්ත Restore කිරීම අසාර්ථක විය. JSON වලංගු නැත.", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void showLoadingOverlay(String message) {
        if (layoutLoadingOverlay != null) {
            layoutLoadingOverlay.setVisibility(View.VISIBLE);
        }
        if (tvProgressStatus != null) {
            tvProgressStatus.setText(message);
        }
        if (btnBackupNow != null) btnBackupNow.setEnabled(false);
        if (btnRestoreNow != null) btnRestoreNow.setEnabled(false);
    }

    private void hideLoadingOverlay() {
        if (layoutLoadingOverlay != null) {
            layoutLoadingOverlay.setVisibility(View.GONE);
        }
        if (btnBackupNow != null) btnBackupNow.setEnabled(true);
        if (btnRestoreNow != null) btnRestoreNow.setEnabled(true);
    }

    private void navigateToMainDashboard() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        navigateToMainDashboard();
    }
}
