package com.aistudio.classroomhub.app;

import android.app.Application;
import android.util.Log;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;

public class ClassroomHubApplication extends Application {

    private static final String TAG = "ClassroomHubApp";

    @Override
    public void onCreate() {
        super.onCreate();
        initFirestoreSettings();
    }

    public static void initFirestoreSettings() {
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                    .setPersistenceEnabled(true)
                    .build();
            db.setFirestoreSettings(settings);
            Log.d(TAG, "Firestore offline persistence enabled.");
        } catch (Exception e) {
            Log.d(TAG, "Firestore persistence setting exception (might be already configured): " + e.getMessage());
        }
    }
}
