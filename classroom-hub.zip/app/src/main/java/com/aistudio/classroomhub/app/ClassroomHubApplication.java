package com.aistudio.classroomhub.app;

import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;

public class ClassroomHubApplication extends Application {

    private static final String TAG = "ClassroomHubApp";

    @Override
    public void onCreate() {
        super.onCreate();
        initFirestoreSettings();
        registerNetworkCallback();
        SyncScheduler.scheduleDailyPeriodicSync(this);
    }

    public static void initFirestoreSettings() {
        try {
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                    .setPersistenceEnabled(true)
                    .build();
            db.setFirestoreSettings(settings);
            Log.d(TAG, "Firestore offline persistence enabled.");
        } catch (Exception e) {
            Log.d(TAG, "Firestore persistence setting exception: " + e.getMessage());
        }
    }

    private void registerNetworkCallback() {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                connectivityManager.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(@NonNull Network network) {
                        super.onAvailable(network);
                        Log.d(TAG, "Internet connection restored. Checking for pending Google Drive sync...");
                        DataBackupManager.processPendingSyncIfOnline(getApplicationContext());
                    }
                });
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register network callback: " + e.getMessage());
        }
    }
}
