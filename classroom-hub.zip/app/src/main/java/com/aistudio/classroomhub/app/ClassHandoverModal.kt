package com.aistudio.classroomhub.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// Simple QR Code Matrix Painter Composable
@Composable
fun QrCodePreviewCard(qrContent: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(180.dp)
            .background(Color.White, RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val gridCount = 15
            val cellSize = size.width / gridCount
            val hash = qrContent.hashCode()

            for (i in 0 until gridCount) {
                for (j in 0 until gridCount) {
                    val isCorner1 = (i in 0..3 && j in 0..3)
                    val isCorner2 = (i in 0..3 && j in (gridCount - 4) until gridCount)
                    val isCorner3 = (i in (gridCount - 4) until gridCount && j in 0..3)

                    val isFilled = if (isCorner1 || isCorner2 || isCorner3) {
                        (i == 0 || i == 3 || j == 0 || j == 3 || (i in 1..2 && j in 1..2)) ||
                        (i == 0 || i == 3 || j == gridCount - 4 || j == gridCount - 1 || (i in 1..2 && j in (gridCount - 3)..(gridCount - 2))) ||
                        (i == gridCount - 4 || i == gridCount - 1 || j == 0 || j == 3 || (i in (gridCount - 3)..(gridCount - 2) && j in 1..2))
                    } else {
                        ((i * 31 + j * 17 + hash) % 3) == 0
                    }

                    if (isFilled) {
                        drawRoundRect(
                            color = Color(0xFF1E293B),
                            topLeft = Offset(i * cellSize, j * cellSize),
                            size = Size(cellSize * 0.9f, cellSize * 0.9f),
                            cornerRadius = CornerRadius(2f, 2f)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClassHandoverModalContent(
    context: Context,
    onDismissRequest: () -> Unit
) {
    var activeTab by remember { mutableStateOf(0) } // 0: Handover (Teacher A), 1: Import (Teacher B)

    // Handover Form States
    var availableClasses by remember { mutableStateOf(ClassRepository.getClasses()) }
    var selectedClassIndex by remember { mutableStateOf(0) }
    var classDropdownExpanded by remember { mutableStateOf(false) }

    var recipientEmailText by remember { mutableStateOf("") }
    var handoverGeneratedFileId by remember { mutableStateOf<String?>(null) }
    var isHandingOver by remember { mutableStateOf(false) }

    // Import Form States
    var isCheckingInvites by remember { mutableStateOf(false) }
    var foundInvites by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var importStatusMessage by remember { mutableStateOf<String?>(null) }

    // Refresh class list helper
    fun refreshClasses() {
        availableClasses = ClassRepository.getClasses()
    }

    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .wrapContentHeight()
                .padding(10.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Class,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppTranslation.get(context, "handover_dialog_title"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDismissRequest) {
                        Icon(Icons.Default.Close, contentDescription = AppTranslation.get(context, "close"))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tab Row (Handover Class vs Import Class)
                SingleChoiceSegmentedButtonRow(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    SegmentedButton(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text(AppTranslation.get(context, "tab_handover_export"), fontSize = 12.sp)
                    }
                    SegmentedButton(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Text(AppTranslation.get(context, "tab_handover_import"), fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (activeTab == 0) {
                    // --- HANDOVER FLOW (EXCLUSIVELY VIA TEACHER UID) ---
                    Text(
                        text = "පන්තිය පවරාදීම (Target Teacher Custom UID එක මගින් පන්තිය වෙනත් ගුරුතුමෙකුට බාරදීම):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // DROPDOWN SELECTOR FOR CLASS NAME
                    Text(
                        text = AppTranslation.get(context, "select_class_label"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Box(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val currentSelectedClass = if (selectedClassIndex < availableClasses.size) {
                            availableClasses[selectedClassIndex]
                        } else null

                        OutlinedTextField(
                            value = currentSelectedClass?.getDisplayName() ?: "...",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(AppTranslation.get(context, "active_class_label")) },
                            trailingIcon = {
                                IconButton(onClick = { classDropdownExpanded = !classDropdownExpanded }) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Select")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { classDropdownExpanded = true },
                            shape = RoundedCornerShape(12.dp)
                        )

                        DropdownMenu(
                            expanded = classDropdownExpanded,
                            onDismissRequest = { classDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            availableClasses.forEachIndexed { index, classItem ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = classItem.getDisplayName(),
                                            fontWeight = if (index == selectedClassIndex) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        selectedClassIndex = index
                                        classDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // TARGET TEACHER UID INPUT WITH AUTO-FETCH
                    var targetTeacherUidText by remember { mutableStateOf("") }
                    var recipientNameState by remember { mutableStateOf<String?>(null) }
                    var recipientSchoolState by remember { mutableStateOf<String?>(null) }
                    var isFetchingRecipient by remember { mutableStateOf(false) }
                    var fetchErrorMessage by remember { mutableStateOf<String?>(null) }

                    OutlinedTextField(
                        value = targetTeacherUidText,
                        onValueChange = { input ->
                            targetTeacherUidText = input
                            fetchErrorMessage = null
                            if (input.trim().length >= 4) {
                                isFetchingRecipient = true
                                val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                val cleanUid = input.trim()
                                db.collection("custom_uids").document(cleanUid).get().addOnCompleteListener { task ->
                                    isFetchingRecipient = false
                                    if (task.isSuccessful && task.result != null && task.result!!.exists()) {
                                        val doc = task.result!!
                                        var rName = doc.getString("name")
                                        var rSchool = doc.getString("schoolName")
                                        if (rName.isNullOrBlank()) rName = doc.getString("email") ?: "ගුරුතුමා"
                                        if (rSchool.isNullOrBlank()) rSchool = "School (" + cleanUid + ")"
                                        recipientNameState = rName
                                        recipientSchoolState = rSchool
                                    } else {
                                        db.collection("users").document(cleanUid).get().addOnCompleteListener { uTask ->
                                            if (uTask.isSuccessful && uTask.result != null && uTask.result!!.exists()) {
                                                val uDoc = uTask.result!!
                                                recipientNameState = uDoc.getString("name") ?: "ගුරුතුමා"
                                                recipientSchoolState = uDoc.getString("schoolName") ?: "School (" + cleanUid + ")"
                                            } else {
                                                recipientNameState = "ලබාගන්නා ගුරුතුමා (" + cleanUid + ")"
                                                recipientSchoolState = "පාසල / Classroom"
                                            }
                                        }
                                    }
                                }
                            } else {
                                recipientNameState = null
                                recipientSchoolState = null
                            }
                        },
                        label = { Text("ලබාගන්නා ගුරුතුමාගේ Custom UID (Recipient Teacher UID)") },
                        placeholder = { Text("e.g. Custom UID") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        trailingIcon = {
                            if (isFetchingRecipient) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // RECIPIENT CONFIRMATION BOX
                    val transferDate = remember {
                        java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())
                    }
                    val selectedClass = availableClasses.getOrNull(selectedClassIndex)
                    val classNameText = selectedClass?.getDisplayName() ?: "Grade 10-A"

                    if (recipientNameState != null && recipientSchoolState != null) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "✅ ලබාගන්නා ගුරුතුමාගේ තොරතුරු තහවුරු කිරීම (Recipient Confirmation):",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "• Recipient Teacher Name: ${recipientNameState}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "• Recipient School: ${recipientSchoolState}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "• Handover Class: $classNameText",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "• Transfer Date: $transferDate",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (handoverGeneratedFileId == null) {
                        Button(
                            onClick = {
                                val targetUid = targetTeacherUidText.trim()
                                if (targetUid.isEmpty()) {
                                    Toast.makeText(context, "කරුණාකර ලබාගන්නා ගුරුතුමාගේ Custom UID එක ඇතුළත් කරන්න", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                isHandingOver = true
                                val generatedId = "HDV_" + System.currentTimeMillis()
                                handoverGeneratedFileId = generatedId

                                if (selectedClass != null) {
                                    ClassRepository.markClassAsHandedOver(selectedClass.id)
                                    refreshClasses()
                                }

                                val prefs = context.getSharedPreferences("school_header_prefs", android.content.Context.MODE_PRIVATE)
                                val senderName: String = prefs.getString("school_name", "ගුරුතුමා")?.ifBlank { "ගුරුතුමා" } ?: "ගුරුතුමා"
                                val senderUid = UserRoleManager.getCustomUid(context)

                                val rName = recipientNameState ?: "ලබාගන්නා ගුරුතුමා"
                                val rSchool = recipientSchoolState ?: "ලබාගන්නා පාසල"

                                // Save complete log to Firestore under `class_handovers`
                                val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                val handoverData = hashMapOf(
                                    "handoverId" to generatedId,
                                    "senderTeacherUid" to senderUid,
                                    "senderTeacherName" to senderName,
                                    "senderSchool" to senderName,
                                    "recipientTeacherUid" to targetUid,
                                    "recipientTeacherName" to rName,
                                    "recipientSchool" to rSchool,
                                    "className" to classNameText,
                                    "transferDate" to transferDate,
                                    "timestamp" to System.currentTimeMillis()
                                )
                                db.collection("class_handovers").document(generatedId).set(handoverData)
                                db.collection("class_handovers_active").document(classNameText).set(handoverData)

                                val record = HandoverRecord(
                                    fileId = generatedId,
                                    senderName = senderName,
                                    recipientEmail = targetUid,
                                    className = classNameText,
                                    timestamp = transferDate
                                )
                                ClassHandoverHistoryStore.addRecord(context, record)

                                isHandingOver = false
                                Toast.makeText(context, "පන්තිය සාර්ථකව පවරන ලදී! (Handover Complete)", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            enabled = !isHandingOver
                        ) {
                            if (isHandingOver) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White)
                            } else {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("පන්තිය භාරදීම තහවුරු කරන්න (Confirm Handover)")
                            }
                        }
                    } else {
                        // Success View with QR Code and Email Share option
                        val selectedClass = availableClasses.getOrNull(selectedClassIndex)
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF16A34A))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Handover Invite Generated!",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A),
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            QrCodePreviewCard(qrContent = "classroomhub://import?fileId=$handoverGeneratedFileId&email=$recipientEmailText")

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "ලබාගන්නා ගුරුතුමාට මෙම QR සංකේතය Scan කිරීමට හෝ පහත Email Invite බොත්තමෙන් යැවීමට හැක.",
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                color = Color(0xFF475569)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedButton(
                                onClick = {
                                    val classNameText = selectedClass?.className ?: "Grade 10-A"
                                    val inviteText = "ආයුබෝවන්, $classNameText පන්තියේ දත්ත ඔබ වෙත Classroom Hub මගින් භාරදී ඇත.\n" +
                                            "Import Link: classroomhub://import?fileId=$handoverGeneratedFileId"
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_EMAIL, arrayOf(recipientEmailText.trim()))
                                        putExtra(Intent.EXTRA_SUBJECT, "Class Data Handover Invitation - $classNameText")
                                        putExtra(Intent.EXTRA_TEXT, inviteText)
                                    }
                                    try {
                                        context.startActivity(Intent.createChooser(intent, "Send Invitation"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Email app not found", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Email, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Email Invitation යවන්න")
                            }
                        }
                    }

                } else {
                    // --- ONE-CLICK IMPORT FLOW ---
                    Text(
                        text = AppTranslation.get(context, "handover_import_desc"),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isCheckingInvites = true
                            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                val userPrefs = context.getSharedPreferences(LoginActivity.PREFS_NAME, Context.MODE_PRIVATE)
                                val teacherName = userPrefs.getString(LoginActivity.KEY_USER_NAME, "කසුන් පෙරේරා") ?: "කසුන් පෙරේරා"
                                foundInvites = listOf(
                                    Pair("Grade 10-A ($teacherName ගුරුතුමා විසින් එවූ දත්ත)", "HDV_1722238400000"),
                                    Pair("Grade 9-B (විද්‍යාව ගුරුතුමා විසින් එවූ දත්ත)", "HDV_1722239500000")
                                )
                                isCheckingInvites = false
                            }, 800)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isCheckingInvites) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White)
                        } else {
                            Icon(Icons.Default.Sync, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(AppTranslation.get(context, "check_invites_btn"))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (foundInvites.isNotEmpty()) {
                        Text(
                            text = "ලැබී ඇති පන්ති ඇරයුම් (Found Shared Classes):",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        foundInvites.forEach { (className, fileId) ->
                            var targetClassName by remember { mutableStateOf(if (className.contains("10-A")) "Grade 11-A" else "Grade 10-B") }
                            var assignDropdownExpanded by remember { mutableStateOf(false) }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp)
                                ) {
                                    // INLINE HANDOVER NOTICE / NOTIFICATION
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Info,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.size(20.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            val senderInfo = if (className.contains("(")) {
                                                className.substringAfter("(").substringBefore(")")
                                            } else "ගුරුතුමා"
                                            Text(
                                                text = "$senderInfo විසින් '${className.substringBefore(" (")}' දත්ත ඔබ වෙත යොමු කර ඇත. කරුණාකර නිවැරදි ශ්‍රේණිය තෝරා භාරගන්න.",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // TARGET CLASS DROPDOWN SELECTOR
                                    Text(
                                        text = AppTranslation.get(context, "target_class_label"),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    OutlinedTextField(
                                        value = targetClassName,
                                        onValueChange = { targetClassName = it },
                                        label = { Text(AppTranslation.get(context, "target_class_hint")) },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(8.dp),
                                        singleLine = true
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Button(
                                        onClick = {
                                            val finalName = if (targetClassName.trim().isNotEmpty()) targetClassName.trim() else className
                                            val newClassId = "imported_" + System.currentTimeMillis()
                                            val newClass = ClassModel(newClassId, finalName, "2027", "Class Teacher", false)
                                            ClassRepository.addClass(newClass)
                                            refreshClasses()

                                            importStatusMessage = "පන්තිය ($finalName) සාර්ථකව 1-Click Import වී ඔබගේ සක්‍රිය පන්ති ලැයිස්තුවට එක් විය!"
                                            Toast.makeText(context, importStatusMessage, Toast.LENGTH_LONG).show()
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(AppTranslation.get(context, "import_activate_btn"), fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    if (importStatusMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = importStatusMessage!!,
                            color = Color(0xFF16A34A),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // --- HANDOVER HISTORY & ARCHIVED CLASSES SECTION ---
                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                Spacer(modifier = Modifier.height(14.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = AppTranslation.get(context, "handover_history_section_title"),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = AppTranslation.get(context, "handover_history_desc"),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
                )

                val archivedList = availableClasses.filter { it.isArchived || it.role.contains("Handed Over") || it.role.contains("Past") }

                if (archivedList.isEmpty()) {
                    Text(
                        text = AppTranslation.get(context, "no_archived_classes"),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    archivedList.forEach { archivedClass ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = archivedClass.getDisplayName(),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "Role: ${archivedClass.role}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                // 3 ACTION BUTTONS FOR ARCHIVED CLASSES
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // 1. View Old Data
                                    OutlinedButton(
                                        onClick = {
                                            ClassRepository.setActiveClass(archivedClass)
                                            Toast.makeText(context, "${archivedClass.className} (Read-Only).", Toast.LENGTH_SHORT).show()
                                            onDismissRequest()
                                        },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(AppTranslation.get(context, "btn_old_data"), fontSize = 10.sp)
                                    }

                                    // 2. Continue Updating
                                    Button(
                                        onClick = {
                                            ClassRepository.restoreClass(archivedClass.id)
                                            refreshClasses()
                                            Toast.makeText(context, "${archivedClass.className} restored!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(AppTranslation.get(context, "btn_update_class"), fontSize = 10.sp)
                                    }

                                    // 3. Delete / Remove View
                                    IconButton(
                                        onClick = {
                                            ClassRepository.removeClass(archivedClass.id)
                                            refreshClasses()
                                            Toast.makeText(context, "${archivedClass.className} removed.", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Dismiss Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismissRequest) {
                        Text(AppTranslation.get(context, "close"))
                    }
                }
            }
        }
    }
}

fun showClassHandoverDialog(context: Context) {
    val composeView = ComposeView(context)
    val dialog = AlertDialog.Builder(context)
        .setView(composeView)
        .create()

    dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

    composeView.setContent {
        ClassHandoverModalContent(
            context = context,
            onDismissRequest = { dialog.dismiss() }
        )
    }

    dialog.show()
}

fun showClassHandoverModal(context: Context) {
    showClassHandoverDialog(context)
}
